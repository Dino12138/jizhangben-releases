"""按「内部成本单模板.xlsx」导出项目成本单：版式/公式/下拉与模板一致，行数按实际增减，发票与支付截图以高清图嵌入。"""
import io, os, re, shutil, tempfile
from copy import copy
import openpyxl
import store


# 导出时用到的合作方名字：程序里是通用叫法（中间方 / 代垫方 / 渠道方），本机设置里有你自己的叫法就用你的；
# 某一格要原样用你以前的文字，可在本机设置 export_text 里按键名写（如 "tpl.J128"、"a.rb_label"）
def _T(key, default):
    n = store.names()
    v = (store.load_config().get("export_text") or {}).get(key)
    return v if isinstance(v, str) and v else default.format(mid=n["mid"], adv=n["adv"], ch=n["ch"], rb=n["rb"])


_TPL = {"F2": "{adv}\n利润", "A123": "{adv}代垫付", "A124": "{ch}代垫付", "A125": "{adv}代垫付含服务费含税", "A126": "{ch}代垫付含服务费",
        "A127": "{ch}代垫付含税", "J128": "各渠道返点点数；右侧填点数", "A129": "{mid}收款", "J129": "客户报价 × {mid}收款点数；右侧填点数",
        "A130": "{adv}收款", "J131": "右侧填税率", "J132": "（{adv}收款-总成本-税费）×税率；右侧填税率", "A133": "{adv}利润", "A134": "{adv}利润率"}
from openpyxl.drawing.image import Image as XLImage
from openpyxl.worksheet.datavalidation import DataValidation
from PIL import Image as PILImage

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, "template", "内部成本单模板.xlsx")
SEC_ORDER = [("搭建部分", 15, 16, 17, 25), ("第三方人员", 26, 27, 28, 48), ("物料部分", 49, 50, 51, 83), ("执行人员杂费", 84, 85, 86, 120)]
NCOL = 14
IMG_BOX = (150, 100)   # 单元格内图片的显示框(px)
PAID = ("已付", "备用金垫付")


def _copy_row(src, r0, dst, r1, merges_by_row, values=False):
    for c in range(1, NCOL + 1):
        s = src.cell(r0, c)
        d = dst.cell(r1, c)
        d._style = copy(s._style)
        if values:
            d.value = s.value
    h = src.row_dimensions[r0].height
    if h:
        dst.row_dimensions[r1].height = h
    for rng in merges_by_row.get(r0, []):
        dst.merge_cells(start_row=r1, end_row=r1, start_column=rng[0], end_column=rng[1])


def _fit(path, box):
    with PILImage.open(path) as im:
        w, h = im.size
    k = min(box[0] / w, box[1] / h, 1.0)
    return max(1, int(w * k)), max(1, int(h * k)), w, h


def _thumb(path, tmpdir):
    """主表单元格里放缩略图(省体积)，原图放在『发票与支付截图』页，保持高清。"""
    os.makedirs(tmpdir, exist_ok=True)
    out = os.path.join(tmpdir, os.path.basename(path) + ".t.jpg")
    if not os.path.exists(out):
        with PILImage.open(path) as im:
            im = im.convert("RGB")
            im.thumbnail((640, 420))
            im.save(out, "JPEG", quality=85)
    return out


def _add_img(ws, path, anchor, box):
    img = XLImage(path)
    w, h, _, _ = _fit(path, box)
    img.width, img.height = w, h
    ws.add_image(img, anchor)
    return h


def _mode_a_summary(out, src, merges, r, rowmap, sec_rows, adv_total, P):
    """模式A：实报实销返还/服务费是我方收入，中间方收款用闭式公式。返回最后一行行号。"""
    tc = r
    def put(row, src_row, label=None, g=None, i=None, note=None):
        _copy_row(src, src_row, out, row, merges)
        for rng in src.merged_cells.ranges:
            if rng.min_row == src_row and rng.max_row > src_row:
                out.merge_cells(start_row=row, end_row=rng.max_row - src_row + row, start_column=rng.min_col, end_column=rng.max_col)
        if label is not None:
            out.cell(row, 1).value = label
        if g is not None:
            out.cell(row, 7).value = g
        if i is not None:
            out.cell(row, 9).value = i
        if note is not None:
            out.cell(row, 10).value = note
    subs = [rowmap[25], rowmap[48], rowmap[83], rowmap[120]]
    put(tc, 121); out.cell(tc, 8).value = "总成本"; out.cell(tc, 9).value = "=" + "+".join(f"I{x}" for x in subs)
    Q, R, F, RB, ZH, TX, IT, PF, PR, PD, UP = [tc + k for k in range(1, 12)]
    put(Q, 122, "客户报价", None, P.get("quote", 0), _T("a.q_note", "与结算单合计一致（含实报实销及其服务费、税）"))
    put(R, 123, "实报实销返还（我方收入，不分成）", None, P.get("reimb", 0), "结算单「实报实销」小计原价：客户按实际金额返还，是我方收入；对应付款已在总成本里，不重复扣减")
    put(F, 128, "实报实销服务费（我方收入，不分成）", P.get("r_reimb_fee", 0), f"=I{R}*G{F}", _T("a.f_note", "实报实销另收服务费（我方人员差旅及执行人员费用不收服务费）；也是我方收入，不与返点、{mid}分成"))
    put(RB, 128, _T("a.rb_label", "{rb}+客户公关费"), P.get("r_rebate", 0), f"=(I{Q}-I{F}-I{ZH}-I{TX}-I{R})*G{RB}", _T("a.rb_note", "各渠道返点点数；右侧填点数"))
    put(ZH, 128, _T("a.zh_label", "{mid}收款"), P.get("r_mid", 0),
        f"=(G{ZH}*(I{Q}-I{R}-I{F})*(1-G{RB})+G{RB}*G{ZH}*G{TX}*I{Q})/(1-G{RB}*G{ZH}*(1-G{TX}))",
        _T("a.zh_note", "客户报价 × {mid}收款点数；右侧填点数"))
    put(TX, 128, _T("a.tx_label", "税费（减去{mid}收款）"), P.get("r_tax", 0.06), f"=(I{Q}-I{ZH})*G{TX}", _T("a.tx_note", "右侧填税率"))
    put(IT, 128, "企业所得税", P.get("r_income_tax", 0.0566), f"=(I{Q}-I{tc}-I{TX}-I{ZH})*G{IT}", _T("a.it_note", "（客户报价-总成本-税费-{mid}收款）×税率"))
    put(PF, 133, _T("a.pf_label", "{adv}利润"), None, f"=I{Q}-I{tc}-I{RB}-I{ZH}-I{TX}-I{IT}", _T("a.pf_note", "利润=客户报价-总成本-返点-{mid}收款-税费-所得税；验算：总成本+返点+{mid}收款+税费+所得税+利润=客户报价"))
    put(PR, 134, _T("a.pr_label", "{adv}利润率"), None, f"=IF(I{Q}=0,0,I{PF}/I{Q})")
    paid = "+".join(f"SUM($L${a}:$L${b})" for a, b in sec_rows.values())
    put(PD, 135, "已付合计（含备用金垫付）", None, "=" + paid, "各行「已付金额」之和")
    put(UP, 136, "待付合计", None, f"=I{tc}-I{PD}", "总成本 - 已付合计")
    # 抬头里的三个公式
    out["G2"] = f"=I{PF}"
    out["J3"] = f"=I{adv_total}"
    parts = []
    for a, b in sec_rows.values():
        parts.append(f'SUMIF($K${a}:$K${b},"备用金垫付",$I${a}:$I${b})')
    out["K3"] = f"=J3-({'+'.join(parts)})"
    return UP


def _custom_summary(out, r, sec_rows, P):
    """自定义公式的利润测算：A 名称、B 怎么算、G 百分比、I 这一项金额、J 算到这一步剩下的；全是 Excel 公式，改数字会自动重算。"""
    from openpyxl.styles import Font
    labels = P.get("labels") or {}
    r += 1
    out.cell(r, 1).value = "利润测算（自定义公式）"
    out.cell(r, 1).font = Font(bold=True, size=12)
    r += 1
    for c, t in ((1, "项目"), (2, "怎么算"), (7, "百分比"), (9, "金额"), (10, "算到这一步剩下")):
        out.cell(r, c).value = t
        out.cell(r, c).font = Font(bold=True)
    r += 1
    q_row = r
    out.cell(r, 1).value = "客户报价"
    out.cell(r, 9).value = float(P.get("quote") or 0)
    out.cell(r, 10).value = f"=I{r}"
    cost = "+".join(f"SUM(I{a}:I{b})" for a, b in sec_rows.values()) or "0"
    for it in (P.get("custom") or []):
        r += 1
        k, v, plus = it.get("kind"), float(it.get("v") or 0), it.get("op") == "+"
        out.cell(r, 1).value = (it.get("name") or "未命名") + ("（加）" if plus else "")
        if k == "pct_quote":
            out.cell(r, 2).value, out.cell(r, 7).value, out.cell(r, 9).value = "按客户报价的 %", v, f"=I${q_row}*G{r}"
        elif k == "pct_left":
            out.cell(r, 2).value, out.cell(r, 7).value, out.cell(r, 9).value = "按上一步剩下的 %", v, f"=J{r - 1}*G{r}"
        elif k == "cost":
            out.cell(r, 2).value, out.cell(r, 9).value = "成本单合计", f"={cost}"
        else:
            out.cell(r, 2).value, out.cell(r, 9).value = "固定金额", v
        if out.cell(r, 7).value is not None:
            out.cell(r, 7).number_format = "0.00%"
        out.cell(r, 10).value = f"=J{r - 1}{'+' if plus else '-'}I{r}"
    r += 1
    out.cell(r, 1).value = labels.get("o_profit") or "利润"
    out.cell(r, 10).value = f"=J{r - 1}"
    out.cell(r, 1).font = out.cell(r, 10).font = Font(bold=True)
    r += 1
    out.cell(r, 1).value = "利润率"
    out.cell(r, 10).value = f"=IF(I{q_row}=0,0,J{r - 1}/I{q_row})"
    out.cell(r, 10).number_format = "0.00%"
    for rr in range(q_row, r + 1):
        for c in (9, 10):
            if out.cell(rr, c).number_format == "General":
                out.cell(rr, c).number_format = "#,##0.00"
    return r


def export_project(project, params, lines, files, out_path, project_name_override=None, reimbs=None):
    """project: dict(name, leader, time_text, location, customer, source)
    lines: list[dict] 含 id/sec/cat/name/spec/craft/qty/unit/price/vendor/pay/date/who
    files: {line_id: [{'kind': 'invoice'|'pay', 'path': ..., 'name': ...}]}"""
    tmpdir = tempfile.mkdtemp(prefix="cx_")
    wb = openpyxl.load_workbook(TEMPLATE)
    src = wb["成本汇总"]
    for cell, d in _TPL.items():                       # 模板里的合作方叫法：换成本机设置里的名字
        src[cell].value = _T("tpl." + cell, d)
    merges = {}
    for rng in src.merged_cells.ranges:
        if rng.min_row == rng.max_row:
            merges.setdefault(rng.min_row, []).append((rng.min_col, rng.max_col))
    out = wb.create_sheet("tmp")
    for k, v in src.column_dimensions.items():
        out.column_dimensions[k].width = v.width
    out.column_dimensions["N"].width = 22
    out.column_dimensions["M"].width = 22
    out.sheet_view.showGridLines = src.sheet_view.showGridLines
    out.page_setup.orientation = src.page_setup.orientation
    out.page_setup.fitToWidth = 1
    out.page_setup.fitToHeight = 0
    out.sheet_properties.pageSetUpPr = openpyxl.worksheet.properties.PageSetupProperties(fitToPage=True)

    # 1) 抬头 1-5 行
    for r in range(1, 6):
        _copy_row(src, r, out, r, merges, values=True)
    for rng in src.merged_cells.ranges:
        if rng.min_row <= 5 and rng.max_row > rng.min_row:      # G2:I4、F2:F4 这类跨行合并
            out.merge_cells(str(rng))
    out["B2"] = project["name"]
    out["E2"] = project.get("leader", "")
    out["B3"] = project.get("time_text", "")
    out["E3"] = project.get("location", "")
    out["B4"] = project.get("customer", "")
    out["E4"] = project.get("source", "")

    by_sec = {}
    for ln in lines:
        by_sec.setdefault(ln["sec"], []).append(ln)
    r = 6
    # 2) 备用金
    _copy_row(src, 6, out, r, merges); out.cell(r, 1).value = "备用金"; r += 1
    _copy_row(src, 7, out, r, merges, values=True)
    r += 1
    adv = by_sec.get("备用金", []) or [None]
    adv_first = r
    for i, a in enumerate(adv, 1):
        _copy_row(src, 8, out, r, merges)
        out.cell(r, 2).value = i
        if a:
            out.cell(r, 3).value = a.get("date") or None
            out.cell(r, 4).value = a.get("who") or a.get("name")
            out.cell(r, 9).value = round(a["qty"] * a["price"], 2)
        r += 1
    adv_last = r - 1
    out.cell(adv_first, 1).value = "备用金"
    if adv_last > adv_first:
        out.merge_cells(start_row=adv_first, end_row=adv_last, start_column=1, end_column=1)
    adv_total = r
    _copy_row(src, 13, out, r, merges)
    out.cell(r, 8).value = "备用金总额"
    out.cell(r, 9).value = f"=SUM(I{adv_first}:I{adv_last})"
    r += 1
    _copy_row(src, 14, out, r, merges); r += 1

    # 3) 四个成本板块
    rowmap = {13: adv_total}
    sec_rows = {}
    img_jobs = []
    for sec, t_row, h_row, d_row, s_row in SEC_ORDER:
        _copy_row(src, t_row, out, r, merges); out.cell(r, 1).value = sec; r += 1
        hdr = r
        _copy_row(src, h_row, out, r, merges, values=True)
        r += 1
        items = by_sec.get(sec, []) or [None]
        first = r
        prev_cat, cat_start = None, r
        for ln in items:
            _copy_row(src, d_row, out, r, merges)
            out.cell(r, 2).value = f"=ROW()-ROW(B${hdr})"
            out.cell(r, 6).value = 1
            out.cell(r, 7).value = src.cell(d_row, 7).value
            out.cell(r, 8).value = 0
            out.cell(r, 9).value = f"=F{r}*H{r}"
            out.cell(r, 12).value = f'=IF(OR(K{r}="已付",K{r}="备用金垫付"),I{r},0)'
            if ln:
                excluded = ln["pay"] == "无需付款"
                out.cell(r, 3).value = ln["name"] or None
                out.cell(r, 4).value = ln["spec"] or None
                out.cell(r, 5).value = ln["craft"] or None
                out.cell(r, 6).value = ln["qty"]
                out.cell(r, 7).value = ln["unit"]
                out.cell(r, 8).value = 0 if excluded else ln["price"]
                note = ln["vendor"] or ""
                if excluded:
                    note = (note + "；" if note else "") + f"原金额¥{ln['qty'] * ln['price']:,.2f}，无需付款，不计入成本"
                out.cell(r, 10).value = note or None
                out.cell(r, 11).value = ln["pay"]
                if ln.get("inv_note"):                         # 「发票」格的文字：开票方 + 状态（有发票图时图片浮在上面）
                    out.cell(r, 13).value = ln["inv_note"]
                if ln.get("memo"):                             # 表格最右边的其他备注（如「待退回」）
                    out.cell(r, 15).value = ln["memo"]
                out.cell(r, 1).value = None
                # 类别（A 列）：同类连续行合并
                cat = ln.get("cat") or ""
                if cat != prev_cat:
                    if prev_cat and r - 1 > cat_start:
                        out.merge_cells(start_row=cat_start, end_row=r - 1, start_column=1, end_column=1)
                    cat_start = r
                    out.cell(r, 1).value = cat or None
                    prev_cat = cat
                fs = files.get(ln["id"], [])
                for col, kinds in ((13, ("invoice", "trip")), (14, ("pay",))):
                    imgs = [f for k in kinds for f in fs if f["kind"] == k and os.path.exists(f["path"])]
                    if imgs:
                        img_jobs.append((r, col, imgs))
            r += 1
        if prev_cat and r - 1 > cat_start:
            out.merge_cells(start_row=cat_start, end_row=r - 1, start_column=1, end_column=1)
        last = r - 1
        _copy_row(src, s_row, out, r, merges)
        out.cell(r, 8).value = "小计"
        out.cell(r, 9).value = f"=SUM(I{first}:I{last})"
        rowmap[s_row] = r
        rowmap[d_row], rowmap[d_row + (s_row - d_row - 1)] = first, last
        sec_rows[sec] = (first, last)
        r += 1
    # 4) 利润测算（按项目类型：模式A 用自己的逻辑；模式B / 通用用模板底部）
    P = params
    mode = (P or {}).get("mode", "standard")
    if mode == "mode_a":
        last_row = _mode_a_summary(out, src, merges, r, rowmap, sec_rows, adv_total, P)
    elif mode == "custom":
        last_row = _custom_summary(out, r, sec_rows, P)
    else:
            # 模板底部利润测算
        off = r - 121
        for rr in range(121, 137):
            _copy_row(src, rr, out, rr + off, merges)
            for rng in src.merged_cells.ranges:
                if rng.min_row == rr and rng.max_row > rr:
                    out.merge_cells(start_row=rr + off, end_row=rng.max_row + off, start_column=rng.min_col, end_column=rng.max_col)
        rowmap_ranges = {}
        for (sec, t, h, d, s), nm in zip(SEC_ORDER, sec_rows):
            pass
        def mp(old):
            if old in rowmap:
                return rowmap[old]
            if old >= 121:
                return old + off
            return old
        # 区间端点：模板里 K17:K24 的 24=d_row+7 等，用实际首尾行替换
        ends = {}
        for sec, t, h, d, s in SEC_ORDER:
            first, last = sec_rows[sec]
            ends[d] = first
            ends[s - 1] = last
        def tr(formula):
            def rep(m):
                col, dollar, row = m.group(1), m.group(2), int(m.group(3))
                if row in ends:
                    nr = ends[row]
                else:
                    nr = mp(row)
                return f"{col}{dollar}{nr}"
            return re.sub(r"(\$?[A-Z]{1,2})(\$?)(\d+)", rep, formula)
        for rr in range(121, 137):
            for c in range(1, NCOL + 1):
                v = src.cell(rr, c).value
                cell = out.cell(rr + off, c)
                if type(cell).__name__ == "MergedCell":
                    continue
                cell.value = tr(v) if isinstance(v, str) and v.startswith("=") else v
        for c in range(1, NCOL + 1):          # 抬头里的公式（G2、J3、K3）
            for rr in (2, 3):
                v = src.cell(rr, c).value
                if isinstance(v, str) and v.startswith("="):
                    out.cell(rr, c).value = tr(v)
        P = params
        base = 122 + off
        out.cell(base, 9).value = P.get("quote", 0)
        out.cell(base + 1, 9).value = P.get("adv_daifu", 0)
        out.cell(base + 2, 9).value = P.get("ch_daifu", 0)
        out.cell(base + 3, 7).value = P.get("r_adv_fee", 0)
        out.cell(base + 4, 7).value = P.get("r_ch_fee", 0)
        out.cell(base + 5, 7).value = P.get("r_ch_tax", 0)
        out.cell(base + 6, 7).value = P.get("r_channel", 0)
        out.cell(base + 7, 7).value = P.get("r_mid", 0)
        out.cell(base + 9, 7).value = P.get("r_tax", 0.06)
        out.cell(base + 10, 7).value = P.get("r_income_tax", 0.0566)
        last_row = 136 + off
        if mode == "mode_b":
            out.cell(base + 6, 1).value = _T("b.ch_label", "{ch}返点")
            out.cell(base + 7, 1).value = _T("b.mid_label", "{mid}收款") + "%d%%" % round(P.get("r_mid", 0) * 100)

    # 5) 付款情况下拉
    dv = DataValidation(type="list", formula1='"未付,预付,已付,备用金垫付,无需付款"', allow_blank=True)
    out.add_data_validation(dv)
    for sec in sec_rows:
        a, b = sec_rows[sec]
        dv.add(f"K{a}:K{b}")
    out.print_area = f"A1:N{last_row}"

    # 6) 图片
    for (rr, col, imgs) in img_jobs:
        k = len(imgs)
        letter = openpyxl.utils.get_column_letter(col)
        box = (IMG_BOX[0], IMG_BOX[1])
        y_total = 0
        for i, f in enumerate(imgs):
            h = _add_img(out, f["path"], f"{letter}{rr}", box)       # 主表直接放高清原图（显示按格子缩放，放大就是原图）
            # 多张图：纵向叠放，用偏移实现
            img = out._images[-1]
            if i > 0:
                from openpyxl.drawing.spreadsheet_drawing import OneCellAnchor, AnchorMarker
                from openpyxl.drawing.xdr import XDRPositiveSize2D
                from openpyxl.utils.units import pixels_to_EMU
                marker = AnchorMarker(col=col - 1, row=rr - 1, colOff=0, rowOff=pixels_to_EMU(y_total))
                img.anchor = OneCellAnchor(_from=marker, ext=XDRPositiveSize2D(pixels_to_EMU(img.width), pixels_to_EMU(img.height)))
            y_total += h + 4
        need = y_total * 0.75 + 4
        cur = out.row_dimensions[rr].height or 40
        out.row_dimensions[rr].height = max(cur, need)

    # 7) 原来的「发票与支付截图」附表已去掉：主表直接放高清原图；要原件请用项目页「导出发票原图」
    from openpyxl.styles import Font

    wb.remove(src)
    out.title = "成本汇总"
    # 8) 报销申请单（同事经手的备用金和报销项）
    if reimbs:
        rs = wb.create_sheet("报销申请单")
        for col, w in zip("ABCDEFG", (14, 12, 34, 12, 30, 14, 40)):
            rs.column_dimensions[col].width = w
        rr = 1
        for rb in reimbs:
            rs.cell(rr, 1, f"报销申请单：{rb.get('name', '')}").font = Font(bold=True)
            rr += 1
            for lab, v in (("申请人", rb.get("applicant") or "同事"), ("日期", rb.get("date") or ""), ("报销总额", rb.get("total") or 0),
                           ("备用金", rb.get("advance") or 0), ("已退回", rb.get("refund") or 0), ("说明", rb.get("note") or "")):
                rs.cell(rr, 1, lab); rs.cell(rr, 2, v); rr += 1
            rs.cell(rr, 1, "备用金结余"); rs.cell(rr, 2, f"=B{rr - 3}-B{rr - 2}-B{rr - 4}"); rr += 1
            hdr = rr
            for i, t in enumerate(("费用类型", "", "费用明细", "报销金额", "对应成本行", "付款情况")):
                rs.cell(rr, i + 1, t).font = Font(bold=True)
            rr += 1
            first = rr
            for it in rb.get("items", []):
                rs.cell(rr, 1, it.get("type") or ""); rs.cell(rr, 3, it.get("detail") or ""); rs.cell(rr, 4, it.get("amount") or 0)
                rs.cell(rr, 5, ("新加：" if it.get("created") else "") + (it.get("line_name") or "")); rs.cell(rr, 6, "备用金垫付")
                rr += 1
            rs.cell(rr, 3, "合计").font = Font(bold=True); rs.cell(rr, 4, f"=SUM(D{first}:D{rr - 1})" if rr > first else 0)
            rr += 3
    wb.move_sheet("成本汇总", offset=-wb.index(wb["成本汇总"]))
    wb.active = 0
    wb.save(out_path)
    shutil.rmtree(tmpdir, ignore_errors=True)
    return out_path
