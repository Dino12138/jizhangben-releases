"""CD的记账本 · 项目台（后端）
功能：账单上传分类(工作/生活/待确认)、项目与成本单、发票/支付截图上传、按模板导出带高清图的成本单 Excel，
并把账单/项目支出同步进CD的记账本(ezBookkeeping)。
"""
import json, os, re, shutil, sys, tempfile, threading, time, uuid
from datetime import datetime, date, timedelta
from typing import List, Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.environ.get("CHAIMI_TOOLS", os.path.join(os.path.dirname(HERE), "工具"))
sys.path.insert(0, TOOLS)
sys.path.insert(0, HERE)
import store, exporter                   # noqa: E402
import bill_tool as bt                    # noqa: E402
import cost_match as cm                   # noqa: E402
from api_import import Api, ApiError, push_rows, rid  # noqa: E402

store.init()
app = FastAPI(title="CD的记账本·项目台")


def seed_projects():
    """首次启动把工具里已登记的项目(众安8个等)带进项目台，避免项目周期丢失。"""
    ps = []
    for src in (lambda: json.load(open(bt.PROJECTS, encoding="utf-8")),
                lambda: [dict(p, customer="众安") for p in bt.load_json(bt.RULES, {}).get("项目周期", [])]):
        try:
            ps += src()
        except Exception:
            pass
    with store.db() as c:
        for p in ps:
            if not c.execute("select 1 from projects where name=?", (p["name"],)).fetchone():
                c.execute("insert into projects(name,customer,start,end,params) values(?,?,?,?,'{}')",
                          (p["name"], p.get("customer", ""), p.get("start", ""), p.get("end", "")))


seed_projects()


# ---------------------------------------------------------------- 记账软件连接
_api = {"obj": None, "key": None}
_tx_cache = {"t": 0, "rows": None}


def ezb():
    cfg = store.load_config()
    key = (os.environ.get("CHAIMI_EZB_API") or cfg["ezb_url"], cfg["ezb_user"], cfg["ezb_pass"])
    if not cfg["ezb_user"]:
        raise HTTPException(400, "还没设置记账软件账号，请先到「设置」里填写。")
    if _api["key"] != key:
        try:
            _api["obj"], _api["key"] = Api(*key), key
        except ApiError as e:
            raise HTTPException(400, f"登录记账软件失败：{e}")
    return _api["obj"]


def ezb_transactions(force=False):
    if force or time.time() - _tx_cache["t"] > 4 or _tx_cache["rows"] is None:
        _tx_cache["rows"] = ezb().call("GET", "/api/v1/transactions/list/all.json?start_time=0&end_time=9999999999999")
        _tx_cache["t"] = time.time()
    return _tx_cache["rows"]


def ezb_existing_ids():
    return {rid(t.get("comment")) for t in ezb_transactions() if rid(t.get("comment"))}


HOOKS = {}          # txedit 注册的钩子（账单→成本单自动同步）


def invalidate():
    _tx_cache["rows"] = None
    _catname["t"] = 0


# ---------------------------------------------------------------- 小工具
def row(r):
    return dict(r) if r is not None else None


def parse_dates(text):
    """'2026年4月25日-4月27日' → ('2026-04-25','2026-04-27')"""
    m = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日?\s*[-~—至到]+\s*(?:(\d{4})年)?(?:(\d{1,2})月)?(\d{1,2})日?", text or "")
    if m:
        y = int(m.group(1))
        s = date(y, int(m.group(2)), int(m.group(3)))
        e = date(int(m.group(4) or y), int(m.group(5) or m.group(2)), int(m.group(6)))
        return s.isoformat(), e.isoformat()
    m = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日?", text or "")
    if m:
        d = date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
        return d, d
    return "", ""


def sync_projects_json():
    """把项目登记表同步给分类器（夜间打车按项目周期归项目）。"""
    with store.db() as c:
        ps = [dict(name=r["name"], start=r["start"], end=r["end"], customer=r["customer"]) for r in c.execute("select * from projects")]
    json.dump(ps, open(bt.PROJECTS, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    threading.Thread(target=_ensure_project_cats, args=([p["name"] for p in ps],), daemon=True).start()


def _ensure_project_cats(names):
    """记账本里给每个项目建好『项目·名称』大类和子分类（在记账本里选项目时能接着选子分类）。"""
    try:
        from api_import import ensure_project_categories, ensure_base_categories
        cs = custom_subs()
        n = ensure_base_categories(ezb(), {"工作": [x for x in WORK_SUBS if x != "项目回款"] + cs["工作"], "生活": [x for x in LIFE_SUBS if x not in ("红包转账", "工资薪酬")] + cs["生活"]})
        if ensure_project_categories(ezb(), names, cs["工作"]) + n:
            invalidate()
    except Exception:
        pass


def line_amount(l):
    return 0 if l["pay"] == "无需付款" else round((l["qty"] or 0) * (l["price"] or 0), 2)


def summarize(lines):
    lines = [l for l in lines if not l.get("hold")]       # 待核对的不算
    total = sum(line_amount(l) for l in lines if l["sec"] != "备用金")
    paid = sum(line_amount(l) for l in lines if l["sec"] != "备用金" and l["pay"] in ("已付", "备用金垫付"))
    adv = sum((l["qty"] or 0) * (l["price"] or 0) for l in lines if l["sec"] == "备用金")
    cash_used = sum(line_amount(l) for l in lines if l["sec"] != "备用金" and l["pay"] == "备用金垫付")
    return dict(total=round(total, 2), paid=round(paid, 2), unpaid=round(total - paid, 2), advance=round(adv, 2),
                cash_used=round(cash_used, 2), cash_left=round(adv - cash_used, 2))


def zhongan_profit(P, total):
    """杭马V3公式修复版：梓慧收款用闭式解，避免返点↔税费↔梓慧收款的循环引用。"""
    Q, R = P["quote"], P["reimb"]
    F = R * P["r_reimb_fee"]
    g_rb, g_zh, g_tx, g_it = P["r_rebate"], P["r_zihui"], P["r_tax"], P["r_income_tax"]
    den = 1 - g_rb * g_zh * (1 - g_tx)
    ZH = (g_zh * (Q - R - F) * (1 - g_rb) + g_rb * g_zh * g_tx * Q) / den if den else 0
    TX = (Q - ZH) * g_tx
    RB = (Q - F - ZH - TX - R) * g_rb
    IT = (Q - total - TX - ZH) * g_it
    PF = Q - total - RB - ZH - TX - IT
    return dict(income=round(Q - ZH, 2), tax=round(TX, 2), income_tax=round(IT, 2), profit=round(PF, 2),
                rate=round(PF / Q, 4) if Q else 0, reimb_fee=round(F, 2), rebate=round(RB, 2), zihui=round(ZH, 2))


def profit(params, total):
    P = {**store.DEFAULT_PARAMS, **params}
    if P.get("mode") == "zhongan":
        return zhongan_profit(P, total)
    q, yd, ju = P["quote"], P["yd_daifu"], P["juno_daifu"]
    yd_fee = yd * (1 + P["r_yd_fee"]) * (1 + P["r_tax"]) if P["r_yd_fee"] > 0 else 0
    ju_fee = ju * P["r_juno_fee"]
    ju_tax = (ju + ju_fee) * P["r_juno_tax"]
    ch = (q - yd_fee - ju - ju_fee - ju_tax) * P["r_channel"]
    zh = q * P["r_zihui"]
    income = q - yd_fee - ju - ju_fee - ju_tax - ch - zh
    tax = income * P["r_tax"]
    itax = (income - total - tax) * P["r_income_tax"]
    pf = income - total - tax - itax
    base = income - yd
    return dict(income=round(income, 2), tax=round(tax, 2), income_tax=round(itax, 2), profit=round(pf, 2),
                rate=round(pf / base, 4) if base else 0)


def project_detail(pid):
    if HOOKS.get("cost_sync"):
        try:
            HOOKS["cost_sync"]()
        except Exception as e:
            print("成本单自动同步失败：", e)
    if HOOKS.get("inv_attach"):
        try:
            HOOKS["inv_attach"]()
        except Exception as e:
            print("发票自动放进成本行失败：", e)
    with store.db() as c:
        p = row(c.execute("select * from projects where id=?", (pid,)).fetchone())
        if not p:
            raise HTTPException(404, "项目不存在")
        lines = [row(r) for r in c.execute("select * from lines where project_id=? order by case sec when '备用金' then 0 when '搭建部分' then 1 when '第三方人员' then 2 when '物料部分' then 3 else 4 end, seq, id", (pid,))]
        hold = [l for l in lines if l.get("hold")]
        lines = [l for l in lines if not l.get("hold")]
        fl = {}
        for f in c.execute("select * from files where line_id in (select id from lines where project_id=?) order by id", (pid,)):
            fl.setdefault(f["line_id"], []).append(dict(id=f["id"], kind=f["kind"], name=f["name"], w=f["w"], h=f["h"], orig=bool(f["orig"])))
    saved = json.loads(p["params"] or "{}")
    if "mode" not in saved:
        saved = {**store.MODE_DEFAULTS[store.detect_mode(p)], **saved}
    p["params"] = {**store.DEFAULT_PARAMS, **saved}
    p["mode_name"] = store.MODE_NAMES.get(p["params"]["mode"], "")
    for l in lines + hold:
        l["amount"] = line_amount(l)
        l["files"] = fl.get(l["id"], [])
    inc = []
    if HOOKS.get("project_income"):
        try:
            inc = HOOKS["project_income"](p["name"])
        except Exception:
            inc = []
    # 每行归到哪个月：自己的日期 > 对上的账单日期 > 项目开始日期；都没有就是「未标日期」
    try:
        tdate = HOOKS["tx_dates"]() if HOOKS.get("tx_dates") else {}
    except Exception:
        tdate = {}
    p_month = (p.get("start") or "")[:7]
    for l in lines:
        d = l.get("date") or (tdate.get(l["uid"], "") if l.get("uid") else "")
        l["month"] = d[:7] if d else p_month
    for v in inc:
        v["month"] = v["date"][:7]

    def view_of(ls, iv):
        s = summarize(ls)
        s["income"] = round(sum(v["amount"] for v in iv), 2)
        s["net"] = round(s["income"] - s["total"], 2)
        if not float(p["params"].get("quote") or 0):     # 客户报价没填：不套结算公式，直接按 项目收入 − 项目支出
            pf = dict(simple=True, income=s["income"], total=s["total"], profit=s["net"],
                      rate=round(s["net"] / s["income"], 4) if s["income"] else 0,
                      tax=0, income_tax=0, reimb_fee=0, rebate=0, zihui=0)
        else:
            pf = profit(p["params"], s["total"])
        return s, pf

    s, pf = view_of(lines, inc)
    months = sorted({l["month"] for l in lines if l["sec"] != "备用金" or l["month"]} | {v["month"] for v in inc})
    by_month = {}
    if months:
        for m in months:
            ms, mp = view_of([l for l in lines if l["month"] == m], [v for v in inc if v["month"] == m])
            by_month[m or "未标日期"] = dict(summary=ms, profit=mp)
    with store.db() as c:
        segs = {r["month"]: r["name"] for r in c.execute("select month,name from segs where project_id=?", (pid,))}
        dset = {r["month"]: dict(rate=r["rate"], amount=r["amount"]) for r in c.execute("select * from div_set where project_id=?", (pid,))}
        drec = [row(r) for r in c.execute("select * from divs where project_id=? order by date, id", (pid,))]
    for k, v in by_month.items():
        v["name"] = segs.get(k, "")
    # ---- 我的分红：应得 = 利润 × 分红比例（某个月单独填了比例/金额就用那个月的）；到账另记，和应得分开
    base = dset.get("", {})
    for d in drec:
        d["month"] = (d["date"] or "")[:7]

    def div_of(key, prof, recs):
        st = dset.get(key, {}) if key else base
        rate = st.get("rate") if st.get("rate") is not None else (base.get("rate") if key else None)
        auto = round(max(prof or 0, 0) * (rate or 0) / 100, 2)
        manual = st.get("amount")
        got = round(sum(r["amount"] for r in recs), 2)
        return dict(rate=rate, own_rate=st.get("rate"), manual=manual, auto=auto, profit=round(prof or 0, 2),
                    due=round(manual if manual is not None else auto, 2), got=got, records=recs)

    for k, v in by_month.items():
        m = "" if k == "未标日期" else k
        v["div"] = div_of(k, v["profit"].get("profit", 0), [d for d in drec if d["month"] == m])
    dv = div_of("", pf.get("profit", 0), drec)
    own = [k for k in by_month if (k if k != "未标日期" else "未标日期") in dset]
    if base.get("amount") is None and len(by_month) > 1 and own:   # 有月份单独填了比例/金额：整个项目的应得 = 各月应得相加
        dv["auto"] = round(sum(v["div"]["due"] for v in by_month.values()), 2)
        dv["due"] = dv["auto"]
        dv["by_month_sum"] = True
    for x in [dv] + [v["div"] for v in by_month.values()]:
        x["gap"] = round(x["due"] - x["got"], 2)
    rb = HOOKS["reimbs"](pid) if HOOKS.get("reimbs") else []
    return dict(project=p, lines=lines, hold=hold, summary=s, profit=pf, income=inc, by_month=by_month, div=dv, reimbs=rb)


# ---------------------------------------------------------------- 我的分红
class DivSet(BaseModel):
    month: str = ""                 # '' = 整个项目；'2026-09' = 只改这个月
    rate: Optional[float] = None    # 分红比例 %，不填 = 跟整个项目的比例
    amount: Optional[float] = None  # 直接填分红金额（覆盖自动计算）；不填 = 按 利润 × 比例 自动算


@app.put("/api/projects/{pid}/div")
def set_div(pid: int, b: DivSet):
    m = "" if b.month in ("", "未标日期") else b.month
    if b.rate is not None and not (0 <= b.rate <= 100):
        raise HTTPException(400, "分红比例要在 0 到 100 之间")
    with store.db() as c:
        if b.rate is None and b.amount is None:
            c.execute("delete from div_set where project_id=? and month=?", (pid, m))
        else:
            c.execute("insert or replace into div_set(project_id,month,rate,amount) values(?,?,?,?)", (pid, m, b.rate, b.amount))
    return project_detail(pid)


class DivGot(BaseModel):
    date: str
    amount: float
    note: str = ""


@app.post("/api/projects/{pid}/div-got")
def add_div_got(pid: int, b: DivGot):
    if not b.amount:
        raise HTTPException(400, "请填到账金额")
    with store.db() as c:
        c.execute("insert into divs(project_id,date,amount,note) values(?,?,?,?)", (pid, b.date[:10], round(b.amount, 2), b.note.strip()))
    return project_detail(pid)


@app.delete("/api/div-got/{did}")
def del_div_got(did: int):
    with store.db() as c:
        r = c.execute("select project_id from divs where id=?", (did,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这条到账记录")
        c.execute("delete from divs where id=?", (did,))
    return project_detail(r["project_id"])


# ---------------------------------------------------------------- 设置
class Cfg(BaseModel):
    ezb_url: str
    ezb_user: str
    ezb_pass: str = ""


@app.get("/api/config")
def get_config():
    c = store.load_config()
    return dict(ezb_url=c["ezb_url"], ezb_user=c["ezb_user"], has_pass=bool(c["ezb_pass"]))


class MeIn(BaseModel):
    my_name: str = ""


@app.get("/api/config/me")
def get_me():
    return dict(my_name=store.load_config().get("my_name", ""))


@app.put("/api/config/me")
def put_me(b: MeIn):
    """成本单里打车行「工艺说明」开头写的乘车人（如「小王 家-公司」）"""
    cfg = store.load_config()
    cfg["my_name"] = b.my_name.strip()[:20]
    store.save_config(cfg)
    if HOOKS.get("cab_refresh"):
        HOOKS["cab_refresh"]()
    return dict(ok=True, my_name=cfg["my_name"])


@app.put("/api/config")
def put_config(c: Cfg):
    old = store.load_config()
    store.save_config(dict(old, ezb_url=c.ezb_url.strip(), ezb_user=c.ezb_user.strip(), ezb_pass=c.ezb_pass or old["ezb_pass"]))
    _api["key"] = None
    invalidate()
    try:
        ezb()
        return dict(ok=True, msg="已连上CD的记账本")
    except HTTPException as e:
        return dict(ok=False, msg=e.detail)


# ---------------------------------------------------------------- 项目
class ProjectIn(BaseModel):
    name: str
    leader: str = ""
    time_text: str = ""
    location: str = ""
    customer: str = ""
    source: str = ""
    start: str = ""
    end: str = ""


@app.get("/api/projects")
def list_projects():
    out = []
    with store.db() as c:
        ps = [row(r) for r in c.execute("select * from projects order by id desc")]
    for p in ps:
        d = project_detail(p["id"])
        nfiles = sum(len(l["files"]) for l in d["lines"])
        out.append(dict(**{k: v for k, v in p.items() if k != 'params'}, mode=d['project']['params']['mode'], mode_name=d['project']['mode_name'], summary=d["summary"], profit=d["profit"], n_lines=len(d["lines"]), n_files=nfiles,
                        div={k: d["div"][k] for k in ("rate", "due", "got", "gap")}))
    return out


@app.post("/api/projects")
def create_project(p: ProjectIn):
    s, e = parse_dates(p.time_text)
    with store.db() as c:
        try:
            md = store.detect_mode(dict(name=p.name, customer=p.customer, source=p.source))
            cur = c.execute("insert into projects(name,leader,time_text,location,customer,source,start,end,params) values(?,?,?,?,?,?,?,?,?)",
                            (p.name.strip(), p.leader, p.time_text, p.location, p.customer, p.source, p.start or s, p.end or e, json.dumps(store.MODE_DEFAULTS[md])))
        except Exception:
            raise HTTPException(400, "已有同名项目")
        pid = cur.lastrowid
    sync_projects_json()
    return project_detail(pid)


@app.put("/api/projects/{pid}")
def update_project(pid: int, p: ProjectIn):
    s, e = parse_dates(p.time_text)
    with store.db() as c:
        c.execute("update projects set name=?,leader=?,time_text=?,location=?,customer=?,source=?,start=?,end=? where id=?",
                  (p.name.strip(), p.leader, p.time_text, p.location, p.customer, p.source, p.start or s, p.end or e, pid))
    sync_projects_json()
    return project_detail(pid)


class ModeIn(BaseModel):
    mode: str


@app.put("/api/projects/{pid}/mode")
def set_mode(pid: int, m: ModeIn):
    """切换结算逻辑：套用该类型的默认点数/税率，保留客户报价等已填金额。"""
    if m.mode not in store.MODE_DEFAULTS:
        raise HTTPException(400, "类型不对")
    with store.db() as c:
        r = c.execute("select params from projects where id=?", (pid,)).fetchone()
        old = json.loads(r["params"] or "{}") if r else {}
        keep = {k: old[k] for k in ("quote", "yd_daifu", "juno_daifu", "reimb") if k in old}
        c.execute("update projects set params=? where id=?", (json.dumps({**store.MODE_DEFAULTS[m.mode], **keep}), pid))
    return project_detail(pid)


@app.put("/api/projects/{pid}/params")
def update_params(pid: int, params: dict):
    with store.db() as c:
        c.execute("update projects set params=? where id=?", (json.dumps(params), pid))
    return project_detail(pid)


@app.delete("/api/projects/{pid}")
def delete_project(pid: int):
    with store.db() as c:
        ids = [r["id"] for r in c.execute("select id from lines where project_id=?", (pid,))]
        for lid in ids:
            _drop_files(c, lid)
        c.execute("delete from lines where project_id=?", (pid,))
        c.execute("delete from projects where id=?", (pid,))
    sync_projects_json()
    return dict(ok=True)


@app.get("/api/projects/{pid}")
def get_project(pid: int):
    return project_detail(pid)


# ---------------------------------------------------------------- 成本行
class LineIn(BaseModel):
    sec: str
    cat: str = ""
    name: str = ""
    spec: str = ""
    craft: str = ""
    qty: float = 1
    unit: str = "项"
    price: float = 0
    vendor: str = ""
    pay: str = "未付"
    date: str = ""
    who: str = ""
    inv_note: str = ""
    memo: str = ""


@app.post("/api/projects/{pid}/lines")
def add_line(pid: int, l: LineIn):
    if l.sec not in store.SECTIONS:
        raise HTTPException(400, "板块不对")
    with store.db() as c:
        seq = (c.execute("select coalesce(max(seq),0)+1 from lines where project_id=? and sec=?", (pid, l.sec)).fetchone()[0])
        c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,date,who,inv_note,memo) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (pid, l.sec, l.cat, seq, l.name, l.spec, l.craft, l.qty, l.unit, l.price, l.vendor, l.pay, l.date, l.who, l.inv_note, l.memo))
    return project_detail(pid)


def _sync_line_to_ledger(lid):
    """成本行是『记入记账本』的备用金支出时，改了金额/名称，记账本里那一笔同步改。"""
    try:
        with store.db() as c:
            l = row(c.execute("select * from lines where id=?", (lid,)).fetchone())
            p = row(c.execute("select * from projects where id=?", (l["project_id"],)).fetchone()) if l else None
        if not l or not p or not l["uid"].startswith("成本单:"):
            return
        if l["pay"] != "备用金垫付":                       # 不再是备用金垫付：从记账本撤掉
            _delete_ledger_tx(l["uid"])
            with store.db() as c:
                c.execute("update lines set uid='' where id=?", (lid,))
            return
        when_day = p["start"] or date.today().isoformat()
        desc = " | ".join(x for x in (l["name"], l["spec"], l["vendor"][:60]) if x)
        r_ = _row_for(None, p, l, l["uid"], "备用金", f"{when_day} 12:00:00", line_amount(l), "支出", desc)
        push_rows(ezb(), [r_], log=lambda *_: None)
        invalidate()
    except Exception:
        pass


def _delete_ledger_tx(uid):
    for t in ezb_transactions(force=True):
        if rid(t.get("comment")) == uid:
            ezb().call("POST", "/api/v1/transactions/delete.json", {"id": str(t["id"])})
    invalidate()


@app.put("/api/lines/{lid}")
def update_line(lid: int, l: LineIn):
    with store.db() as c:
        r = c.execute("select project_id from lines where id=?", (lid,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这一行")
        c.execute("update lines set sec=?,cat=?,name=?,spec=?,craft=?,qty=?,unit=?,price=?,vendor=?,pay=?,date=?,who=?,inv_note=?,memo=? where id=?",
                  (l.sec, l.cat, l.name, l.spec, l.craft, l.qty, l.unit, l.price, l.vendor, l.pay, l.date, l.who, l.inv_note, l.memo, lid))
    _sync_line_to_ledger(lid)
    return project_detail(r["project_id"])


def _drop_files(c, lid):
    fs = c.execute("select * from files where line_id=?", (lid,)).fetchall()
    for f in fs:
        for p_ in (f["path"], f["path"] + ".t.jpg"):
            try:
                os.remove(p_)
            except OSError:
                pass
    c.execute("delete from files where line_id=?", (lid,))
    for o in {f["orig"] for f in fs if f["orig"]}:
        if not c.execute("select 1 from files where orig=?", (o,)).fetchone():
            try:
                os.remove(o)
            except OSError:
                pass
    c.execute("update inv set status='new', line_id=0 where line_id=?", (lid,))


@app.delete("/api/lines/{lid}")
def delete_line(lid: int):
    with store.db() as c:
        r = c.execute("select project_id from lines where id=?", (lid,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这一行")
        _drop_files(c, lid)
        lr = c.execute("select uid,auto from lines where id=?", (lid,)).fetchone()
        uid = lr["uid"] if lr else ""
        c.execute("delete from lines where id=?", (lid,))
    if lr and lr["auto"] and uid and HOOKS.get("cost_ignore"):
        HOOKS["cost_ignore"](uid)          # 自动同步来的行被手动删掉：以后不再自动加回来
    if uid.startswith("成本单:"):
        try:
            _delete_ledger_tx(uid)
        except Exception:
            pass
    return project_detail(r["project_id"])


# ---------------------------------------------------------------- 发票/支付截图
def _save_image_bytes(lid, kind, name, data, c):
    from PIL import Image
    import io
    ext = os.path.splitext(name)[1].lower()
    saved = []
    imgs = []
    if ext == ".pdf":
        import fitz
        doc = fitz.open(stream=data, filetype="pdf")
        for i, page in enumerate(doc):
            pix = page.get_pixmap(dpi=300)
            imgs.append((f"{os.path.splitext(name)[0]}-{i + 1}.png", pix.tobytes("png")))
    else:
        imgs.append((name, data))
    pdir = os.path.join(store.FILES, str(lid))
    os.makedirs(pdir, exist_ok=True)
    for nm, b in imgs:
        try:
            im = Image.open(io.BytesIO(b))
            w, h = im.size
        except Exception:
            raise HTTPException(400, f"{nm} 不是图片或PDF")
        e = os.path.splitext(nm)[1].lower() or ".png"
        if e not in (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"):
            e = ".png"
            buf = io.BytesIO()
            im.convert("RGB").save(buf, "PNG")
            b = buf.getvalue()
        path = os.path.join(pdir, f"{uuid.uuid4().hex[:10]}{e}")
        open(path, "wb").write(b)
        cur = c.execute("insert into files(line_id,kind,path,name,w,h) values(?,?,?,?,?,?)", (lid, kind, path, nm, w, h))
        saved.append(cur.lastrowid)
    return saved


@app.post("/api/lines/{lid}/files")
async def upload_files(lid: int, kind: str = Form("invoice"), files: List[UploadFile] = File(...)):
    """成本行上传发票/支付截图：图片（截图、照片、HEIC）或 PDF（原件保留，每页转图）都行，zip 会自动拆开。"""
    if kind not in ("invoice", "pay", "trip"):
        raise HTTPException(400, "类型只能是 发票 / 支付截图 / 行程单")
    with store.db() as c:
        r = c.execute("select project_id from lines where id=?", (lid,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这一行")
        for f in files:
            items = INV["expand"](f.filename or "image.png", await f.read())
            if not items:
                raise HTTPException(400, f"{f.filename} 不是图片或 PDF")
            for nm, data in items:
                INV["save_to_line"](c, lid, kind, nm, data)
    return project_detail(r["project_id"])


@app.get("/api/files/{fid}")
def get_file(fid: int, thumb: int = 0):
    with store.db() as c:
        f = c.execute("select * from files where id=?", (fid,)).fetchone()
    if not f or not os.path.exists(f["path"]):
        raise HTTPException(404, "文件不存在")
    if thumb:
        from PIL import Image
        tp = f["path"] + ".t.jpg"
        if not os.path.exists(tp):
            with Image.open(f["path"]) as im:
                im = im.convert("RGB")
                im.thumbnail((360, 360))
                im.save(tp, "JPEG", quality=80)
        return FileResponse(tp)
    return FileResponse(f["path"], filename=f["name"])


@app.delete("/api/files/{fid}")
def delete_file(fid: int):
    with store.db() as c:
        f = c.execute("select f.*, l.project_id from files f join lines l on l.id=f.line_id where f.id=?", (fid,)).fetchone()
        if not f:
            raise HTTPException(404, "文件不存在")
        for p in (f["path"], f["path"] + ".t.jpg"):
            try:
                os.remove(p)
            except OSError:
                pass
        c.execute("delete from files where id=?", (fid,))
        if f["orig"] and not c.execute("select 1 from files where orig=?", (f["orig"],)).fetchone():
            try:
                os.remove(f["orig"])
            except OSError:
                pass
        if f["inv_no"]:
            c.execute("update inv set status='new', line_id=0 where inv_no=? and line_id=?", (f["inv_no"], f["line_id"]))
    return project_detail(f["project_id"])


# ---------------------------------------------------------------- 导入已有成本单
@app.post("/api/projects/import-cost")
async def import_cost(file: UploadFile = File(...), replace: int = Form(0), target: str = Form("")):
    tmp = tempfile.mkdtemp()
    path = os.path.join(tmp, "cost.xlsx")
    open(path, "wb").write(await file.read())
    try:
        info, params, lines, imgs = store.parse_cost_xlsx(path)
    except Exception as e:
        raise HTTPException(400, f"读不懂这个成本单（需要『成本汇总』表）：{e}")
    if target.strip():
        info["name"] = target.strip()  # 导入到指定名字的项目（记账本标签用的就是这个名字）
    if not info["name"]:
        raise HTTPException(400, "成本单里没有项目名称")
    s, e = parse_dates(info["time_text"])
    with store.db() as c:
        ex = c.execute("select id from projects where name=?", (info["name"],)).fetchone()
        if ex and not replace:
            raise HTTPException(409, f"已有项目「{info['name']}」。要覆盖请勾选『覆盖同名项目』。")
        if ex:
            pid = ex["id"]
            for r in c.execute("select id from lines where project_id=?", (pid,)).fetchall():
                _drop_files(c, r["id"])
            c.execute("delete from lines where project_id=?", (pid,))
            c.execute("update projects set leader=?,time_text=?,location=?,customer=?,source=?,start=?,end=?,params=? where id=?",
                      (info["leader"], info["time_text"], info["location"], info["customer"], info["source"], s, e, json.dumps(params), pid))
        else:
            pid = c.execute("insert into projects(name,leader,time_text,location,customer,source,start,end,params) values(?,?,?,?,?,?,?,?,?)",
                            (info["name"], info["leader"], info["time_text"], info["location"], info["customer"], info["source"], s, e, json.dumps(params))).lastrowid
        seqs, n_img = {}, 0
        for l in lines:
            seqs[l["sec"]] = seqs.get(l["sec"], 0) + 1
            lid = c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,date,who,inv_note,memo) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            (pid, l["sec"], l["cat"], seqs[l["sec"]], l["name"], l["spec"], l["craft"], l["qty"], l["unit"], l["price"], l["vendor"], l["pay"], l["date"], l["who"], l.get("inv_note", ""), l.get("memo", ""))).lastrowid
            for kind, key in (("invoice", "_inv"), ("pay", "_pay")):
                if l.get(key) and l[key] in imgs:
                    ext, b = imgs[l[key]]
                    _save_image_bytes(lid, kind, f"{kind}.{ext}", b, c)
                    n_img += 1
    sync_projects_json()
    shutil.rmtree(tmp, ignore_errors=True)
    d = project_detail(pid)
    d["imported"] = dict(lines=len(lines), images=n_img)
    return d


class HoldIn(BaseModel):
    action: str          # keep = 算进成本单；drop = 不算（以后也不再自动加回来）


@app.post("/api/lines/{lid}/hold")
def resolve_hold(lid: int, b: HoldIn):
    """「待核对」的行：算进成本单，或者不算。"""
    with store.db() as c:
        l = c.execute("select * from lines where id=?", (lid,)).fetchone()
        if not l:
            raise HTTPException(404, "这一行不存在")
        if b.action == "keep":
            c.execute("update lines set hold=0 where id=?", (lid,))
        elif b.action == "drop":
            if l["uid"]:
                c.execute("create table if not exists cost_ignore(uid text primary key)")
                c.execute("insert or ignore into cost_ignore(uid) values(?)", (l["uid"],))
            if c.execute("select count(*) from files where line_id=?", (lid,)).fetchone()[0]:
                raise HTTPException(400, "这一行上传过发票/截图，先把图片挪到对应的成本行再点「不算」")
            c.execute("delete from lines where id=?", (lid,))
        else:
            raise HTTPException(400, "action 只能是 keep / drop")
        pid = l["project_id"]
    return project_detail(pid)


@app.post("/api/projects/{pid}/upload-cost")
async def upload_cost_into(pid: int, file: UploadFile = File(...)):
    """在项目里上传之前做好的成本单：
    1) 成本单里的行替换这个项目里手动加的行（从账单自动同步来的行先保留）；
    2) 自动同步来的行和成本单里金额一样的行合并（成本单那行接管这笔账，图片也搬过去），避免重复；
    3) 剩下的行再去记账本里按金额/日期/名称匹配账单，对上的把项目名和用途写回账单。"""
    with store.db() as c:
        p = c.execute("select * from projects where id=?", (pid,)).fetchone()
    if not p:
        raise HTTPException(404, "项目不存在")
    tmp = tempfile.mkdtemp()
    path = os.path.join(tmp, "cost.xlsx")
    open(path, "wb").write(await file.read())
    try:
        info, params, lines, imgs = store.parse_cost_xlsx(path)
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        raise HTTPException(400, f"读不懂这个成本单（需要『成本汇总』表）：{e}")
    if not lines:
        raise HTTPException(400, "成本单里没有读到成本行")
    merged = n_img = kept = carried = 0
    with store.db() as c:
        olds = [dict(r) for r in c.execute("select l.*, (select count(*) from files f where f.line_id=l.id) as nf from lines l "
                                           "where project_id=? and auto=0", (pid,))]
        old = dict(json.loads(p["params"] or "{}"))
        if params:
            old.update({k: v for k, v in params.items() if v not in (None, "")})
        upd = dict(leader=p["leader"] or info.get("leader", ""), time_text=p["time_text"] or info.get("time_text", ""),
                   location=p["location"] or info.get("location", ""), customer=p["customer"] or info.get("customer", ""))
        c.execute("update projects set leader=?,time_text=?,location=?,customer=?,params=? where id=?",
                  (upd["leader"], upd["time_text"], upd["location"], upd["customer"], json.dumps(old), pid))
        seqs, new_ids = {}, []
        for l in lines:
            seqs[l["sec"]] = seqs.get(l["sec"], 0) + 1
            lid = c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,date,who,inv_note,memo) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            (pid, l["sec"], l["cat"], seqs[l["sec"]], l["name"], l["spec"], l["craft"], l["qty"], l["unit"], l["price"], l["vendor"], l["pay"], l["date"], l["who"], l.get("inv_note", ""), l.get("memo", ""))).lastrowid
            new_ids.append(lid)
            for kind, key in (("invoice", "_inv"), ("pay", "_pay")):
                if l.get(key) and l[key] in imgs:
                    ext, b = imgs[l[key]]
                    _save_image_bytes(lid, kind, f"{kind}.{ext}", b, c)
                    n_img += 1
        # 原来手动的行：同板块+同名+同金额的，把发票/截图和对上的账单搬到新行；新成本单里没有、但有发票或对上了账单的，原样保留
        news0 = {r["id"]: dict(r) for r in c.execute("select * from lines where id in (%s)" % ",".join("?" * len(new_ids)), new_ids)}
        used_new = set()
        for o in olds:
            oa = round(o["qty"] * o["price"], 2)
            hit = next((n for n in news0.values() if n["id"] not in used_new and n["sec"] == o["sec"]
                        and (n["name"] or "").strip() == (o["name"] or "").strip() and abs(round(n["qty"] * n["price"], 2) - oa) < 0.011), None)
            if hit:
                used_new.add(hit["id"])
                if o["nf"]:
                    # 原来传的发票/截图是原件，优先保留；成本单表格里嵌的同类图片就不要了（避免一张票出现两次）
                    for k in {r["kind"] for r in c.execute("select kind from files where line_id=?", (o["id"],))}:
                        for f in c.execute("select * from files where line_id=? and kind=?", (hit["id"], k)).fetchall():
                            for p_ in (f["path"], f["path"] + ".t.jpg"):
                                try:
                                    os.remove(p_)
                                except OSError:
                                    pass
                            c.execute("delete from files where id=?", (f["id"],))
                    c.execute("update files set line_id=? where line_id=?", (hit["id"], o["id"]))
                    c.execute("update inv set line_id=? where line_id=?", (hit["id"], o["id"]))
                    carried += 1
                if o["uid"] and not hit["uid"]:
                    c.execute("update lines set uid=? where id=?", (o["uid"], hit["id"]))
                c.execute("delete from lines where id=?", (o["id"],))
            elif o["nf"] or o["uid"]:
                kept += 1
            else:
                c.execute("delete from lines where id=?", (o["id"],))
        # 自动同步行 ↔ 成本单行：金额一样（日期近的优先）就合并
        autos = [dict(r) for r in c.execute("select * from lines where project_id=? and auto=1", (pid,))]
        news = [dict(r) for r in c.execute("select * from lines where id in (%s)" % ",".join("?" * len(new_ids)), new_ids)]
        for a in sorted(autos, key=lambda x: -(x["qty"] * x["price"])):
            amt = round(a["qty"] * a["price"], 2)
            cand = [n for n in news if not n["uid"] and n["sec"] != "备用金" and abs(round(n["qty"] * n["price"], 2) - amt) < 0.011]
            if not cand:
                continue
            def dd(n):
                try:
                    return abs((datetime.strptime(n["date"][:10], "%Y-%m-%d") - datetime.strptime(a["date"][:10], "%Y-%m-%d")).days)
                except Exception:
                    return 999
            n = min(cand, key=dd)
            n["uid"] = a["uid"]
            c.execute("update lines set uid=?, date=case when date='' then ? else date end where id=?", (a["uid"], a["date"], n["id"]))
            c.execute("update files set line_id=? where line_id=?", (n["id"], a["id"]))
            c.execute("update inv set line_id=? where line_id=?", (n["id"], a["id"]))
            c.execute("delete from lines where id=?", (a["id"],))
            merged += 1
        # 剩下没合并上的自动同步行：放进「待核对」（不算合计、不导出），免得和成本单重复计算
        held = c.execute("update lines set hold=1 where project_id=? and auto=1", (pid,)).rowcount
    shutil.rmtree(tmp, ignore_errors=True)
    try:
        rep = match_bills(pid, apply=1)
    except Exception as e:
        rep = dict(n_matched=0, n_unmatched=0, matched=[], unmatched=[], error=str(e)[:120])
    d = project_detail(pid)
    d["imported"] = dict(lines=len(lines), images=n_img, merged=merged, matched=rep.get("n_matched", 0),
                         unmatched=rep.get("n_unmatched", 0), kept=kept, carried=carried, held=held)
    d["report"] = rep
    return d


# ---------------------------------------------------------------- 成本行 ↔ 账单 匹配
def _strip_prefix(comment):
    return re.sub(r"^【[^】]*】", "", re.sub(r"〔ID:.*?〕", "", comment or ""))


def _bills_from_ezb():
    out = []
    for t in ezb_transactions():
        i = rid(t.get("comment"))
        if not i or t["type"] not in (2, 3):
            continue
        dt = datetime.fromtimestamp(t["time"])
        out.append(dict(uid=i, kind="收入" if t["type"] == 2 else "支出", amount=t["sourceAmount"] / 100, day=dt.date(),
                        time=dt.strftime("%Y-%m-%d %H:%M:%S"), cp=_strip_prefix(t["comment"]), item="", note="",
                        src=(t.get("sourceAccount") or {}).get("name", ""), _tx=t))
    return out


def _sub_of_line(l):
    class _I(dict):
        pass
    it = dict(sec=l["sec"], name=l["name"], spec=l["spec"], kind="收入" if l["sec"] == "备用金" else "支出")
    return cm.sub_of(it)


def _purpose_of_line(l):
    return cm.purpose_of(dict(sec=l["sec"], name=l["name"], spec=(l["spec"] + " " + l["craft"]).strip(), kind="支出"))


def _row_for(tx_or_none, p, l, uid, account, when, amount, kind, extra_desc=""):
    purpose = _purpose_of_line(l) if l["sec"] != "备用金" else "备用金"
    sub = _sub_of_line(l)
    pre = f"【{p['name']}｜{purpose}】"
    core = extra_desc
    return {"Time": when, "Type": "Income" if kind == "收入" else "Expense", "Category": "工作", "Sub Category": f"工作·{sub}",
            "Account": account, "Amount": f"{amount:.2f}", "Tags": f"工作;项目:{p['name']}", "Description": pre + core[:max(0, 240 - len(pre))] + f"〔ID:{uid}〕"}


@app.post("/api/projects/{pid}/match")
def match_bills(pid: int, apply: int = 1):
    d = project_detail(pid)
    p, lines = d["project"], d["lines"]
    items, by_id = [], {}
    linked = 0
    for l in lines:
        if l.get("uid"):                 # 已经对上账单的行不再重新匹配（避免改掉原来的对应关系）
            linked += 1
            continue
        if l["sec"] == "备用金":
            if l["date"]:
                items.append(dict(sec="备用金", no=l["id"], name="备用金", spec=l["who"], remark="", amount=l["qty"] * l["price"],
                                  date=datetime.strptime(l["date"][:10], "%Y-%m-%d").date(), kind="收入"))
            by_id[l["id"]] = l
            continue
        if l["pay"] in ("未付", "无需付款", "预付"):
            items.append(dict(sec=l["sec"], no=l["id"], name=l["name"], spec=l["spec"], remark=l["vendor"], amount=line_amount(l), date=None, kind="支出", skip="未付/无需付款"))
        elif l["pay"] == "已付" and "微信" not in l["vendor"]:
            items.append(dict(sec=l["sec"], no=l["id"], name=l["name"], spec="", remark="", amount=line_amount(l), date=None, kind="支出", skip="他人支付/非微信，账单里不会有"))
        else:
            items.append(dict(sec=l["sec"], no=l["id"], name=l["name"], spec=l["spec"] + " " + l["craft"], remark=l["vendor"], amount=line_amount(l), date=None, kind="支出"))
        by_id[l["id"]] = l
    s = p["start"] or "2026-01-01"
    e = p["end"] or s
    from datetime import timedelta
    start = datetime.strptime(s, "%Y-%m-%d").date() - timedelta(days=45)
    end = datetime.strptime(e, "%Y-%m-%d").date() + timedelta(days=90)
    with store.db() as c:
        taken = {r["uid"] for r in c.execute("select uid from lines where uid<>'' union select uid from divs where uid<>''")}
    bills = [b for b in _bills_from_ezb() if start <= b["day"] <= end and b["uid"] not in taken]
    res = cm.match(items, bills, (start, end))
    ok = [r for r in res if r[3] == "确认"]
    report = dict(matched=[], unmatched=[])
    rows = []
    for it, b, cands, why in res:
        l = by_id[it["no"]]
        if why == "确认":
            report["matched"].append(dict(line=l["name"] or l["who"], amount=it["amount"], bill_time=b["time"], bill_cp=b["cp"][:30]))
            if apply:
                tx = b["_tx"]
                rows.append(_row_for(tx, p, l, b["uid"], b["src"], b["time"], b["amount"], b["kind"], b["cp"]))
                with store.db() as c:
                    c.execute("update lines set uid=? where id=?", (b["uid"], l["id"]))
        else:
            report["unmatched"].append(dict(line=l["name"] or l["who"], sec=l["sec"], amount=it["amount"], pay=l["pay"], why=why))
    if apply and rows:
        push_rows(ezb(), rows, log=lambda *_: None)
        invalidate()
    report["n_matched"], report["n_unmatched"] = len(report["matched"]), len(report["unmatched"])
    report["n_linked"] = linked
    return report


@app.post("/api/projects/{pid}/sync-cash")
def sync_cash(pid: int):
    """成本单里没有对上账单的：『备用金垫付』的行 → 备用金账户的工作支出；备用金入款 → 备用金账户的收入（项目备用金入款）。"""
    d = project_detail(pid)
    p, lines = d["project"], d["lines"]
    if any(l["sec"] == "备用金" and "【同事经手】" in (l["vendor"] or "") for l in lines):
        # 备用金在同事那里、不是我的钱：不往我的记账本里记，只在项目成本单里体现
        return dict(added=0, skipped=0, updated=0, total=0, note="这个项目的备用金在同事那里，备用金垫付的支出不记入你的记账本")
    when_day = p["start"] or date.today().isoformat()
    rows, ids = [], []
    for l in lines:
        if l["sec"] == "备用金" and not l["uid"] and line_amount(l) > 0:
            # 成本单里的备用金、账单里没有对应入款（打到别处了）→ 作为「备用金」账户的入款记进记账本，备用金账户才不会只有支出
            uid = f"成本单:{pid}:{l['id']}"
            d_ = (l["date"] or "")[:10].replace(".", "-") or when_day
            r_ = _row_for(None, p, l, uid, "备用金", f"{d_} 12:00:00", line_amount(l), "收入", f"{l['who'] or l['name']} | 成本单备用金")
            r_["Sub Category"] = "工作·项目备用金入款"
            rows.append(r_)
            ids.append((uid, l["id"]))
            continue
        if l["sec"] == "备用金" or l["pay"] != "备用金垫付" or l["uid"]:
            continue
        uid = f"成本单:{pid}:{l['id']}"
        desc = " | ".join(x for x in (l["name"], l["spec"], l["vendor"][:60]) if x)
        rows.append(_row_for(None, p, l, uid, "备用金", f"{when_day} 12:00:00", line_amount(l), "支出", desc))
        ids.append((uid, l["id"]))
    if rows:
        res = push_rows(ezb(), rows, log=lambda *_: None)
        invalidate()
        with store.db() as c:
            for uid, lid in ids:
                c.execute("update lines set uid=? where id=?", (uid, lid))
    else:
        res = dict(added=0, skipped=0, updated=0)
    return dict(res, total=len(rows))


# ---------------------------------------------------------------- 导出
class ExportFiles(BaseModel):
    month: str = ""
    dest: str = ""          # 留空 = 弹出 Mac 的「选择文件夹」窗口


def _safe(t, n=40):
    t = re.sub(r'[\\/:*?"<>|\n\r\t]+', " ", str(t or "")).strip()
    return t[:n] or "未命名"


@app.post("/api/projects/{pid}/export-files")
def export_files(pid: int, b: ExportFiles):
    """把项目的发票 / 行程单 / 支付截图「原件」导出到你选的文件夹：
    项目名-发票与截图/发票、行程单、支付截图/序号-板块-名称-金额元.pdf|png（PDF 发票导出原 PDF）。"""
    d = project_detail(pid)
    p = d["project"]
    lines = d["lines"]
    if b.month:
        mk = "" if b.month == "未标日期" else b.month
        lines = [l for l in lines if l["month"] == mk]
    ids = [l["id"] for l in lines]
    if not ids:
        raise HTTPException(400, "这个项目（月份）还没有成本行")
    with store.db() as c:
        fs = [dict(r) for r in c.execute("select * from files where line_id in (%s) order by id" % ",".join("?" * len(ids)), ids)]
    if not fs:
        raise HTTPException(400, "这个项目还没有上传过发票 / 行程单 / 支付截图")
    dest = b.dest.strip()
    if not dest:
        r = subprocess.run(["osascript", "-e", 'POSIX path of (choose folder with prompt "选择发票原图导出到哪个文件夹")'],
                           capture_output=True, text=True, timeout=600)
        if r.returncode != 0:
            return dict(cancelled=True)
        dest = r.stdout.strip()
    if not os.path.isdir(dest):
        raise HTTPException(400, f"文件夹不存在：{dest}")
    root = os.path.join(dest, _safe(p["name"] + (f"-{b.month}" if b.month else ""), 60) + "-发票与截图")
    sub = {"invoice": "发票", "trip": "行程单", "pay": "支付截图"}
    seq = {l["id"]: i + 1 for i, l in enumerate(lines)}
    by_line = {l["id"]: l for l in lines}
    done, n, used = set(), 0, set()
    for f in fs:
        l = by_line[f["line_id"]]
        src = f["orig"] if f.get("orig") and os.path.exists(f["orig"]) else f["path"]
        if src in done or not os.path.exists(src):
            continue                                           # 多页 PDF 只导出一份原 PDF
        done.add(src)
        folder = os.path.join(root, sub.get(f["kind"], "其他"))
        os.makedirs(folder, exist_ok=True)
        base = f"{seq[l['id']]:02d}-{_safe(l['sec'], 8)}-{_safe(l['name'] or l['cat'] or l['who'], 24)}-{round((l['qty'] or 0) * (l['price'] or 0), 2):g}元"
        ext = os.path.splitext(src)[1].lower() or ".png"
        nm, k = base + ext, 2
        while os.path.join(folder, nm) in used or os.path.exists(os.path.join(folder, nm)):
            nm = f"{base}-{k}{ext}"; k += 1
        used.add(os.path.join(folder, nm))
        shutil.copy2(src, os.path.join(folder, nm))
        n += 1
    subprocess.run(["open", root])
    cnt = {sub[k]: len([1 for f in fs if f["kind"] == k]) for k in sub}
    return dict(ok=True, n=n, folder=root, counts=cnt)


@app.get("/api/projects/{pid}/export")
def export_xlsx(pid: int, month: str = ""):
    d = project_detail(pid)
    if month:                                         # 只导出某个月（同一项目不同月份分开结算）
        mk = "" if month == "未标日期" else month
        bm = d["by_month"].get(month)
        d["lines"] = [l for l in d["lines"] if l["month"] == mk]
        d["income"] = [v for v in d["income"] if v["month"] == mk]
        if bm:
            d["summary"], d["profit"] = bm["summary"], bm["profit"]
    p = d["project"]
    with store.db() as c:
        files = {}
        for f in c.execute("select * from files where line_id in (select id from lines where project_id=?) order by id", (pid,)):
            files.setdefault(f["line_id"], []).append(dict(kind=f["kind"], path=f["path"], name=f["name"]))
    outdir = os.path.join(store.DATA, "exports")
    os.makedirs(outdir, exist_ok=True)
    fname = f"{p['name']}{'-' + month if month else ''}内部成本单.xlsx"
    out = os.path.join(outdir, fname)
    exporter.export_project(p, p["params"], d["lines"], files, out, reimbs=d.get("reimbs") or [])
    return FileResponse(out, filename=fname, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# ---------------------------------------------------------------- 账单上传 / 待确认
def _public_row(d):
    return dict(uid=d["uid"], time=d["time"], src=d["src"], kind=d["kind"], amount=d["amount"], cp=d["cp"], item=d["item"],
                scope=d["scope"], sub=d["sub"], project=d["project"], purpose=d.get("purpose", ""), why=d["why"])


def _batch_view(bid):
    with store.db() as c:
        b = c.execute("select * from batches where id=?", (bid,)).fetchone()
    if not b:
        raise HTTPException(404, "没有这个批次")
    rows = json.loads(b["rows"])
    stats = json.loads(b["stats"])
    groups, allg = {}, {}
    for r in rows:
        if r["status"] == "exists":
            continue
        k = r["cp"] or "(无对方)"
        a = allg.setdefault(k, dict(cp=k, n=0, total=0.0, kinds=set(), example=r["item"], why=r["why"], sc={}, sub={}, pj={}, pu={}))
        a["n"] += 1
        a["total"] += r["amount"]
        a["kinds"].add(r["kind"])
        for f, key in (("sc", "scope"), ("sub", "sub"), ("pj", "project"), ("pu", "purpose")):
            v_ = r.get(key) or ""
            a[f][v_] = a[f].get(v_, 0) + 1
        if r["scope"] == "待确认":
            g = groups.setdefault(r["cp"] or "(无对方)", dict(cp=r["cp"] or "(无对方)", n=0, total=0.0, kinds=set(), example=r["item"], why=r["why"]))
            g["n"] += 1
            g["total"] += r["amount"]
            g["kinds"].add(r["kind"])
    def top_(d):
        return max(d, key=d.get) if d else ""
    all_groups = sorted((dict(cp=g["cp"], n=g["n"], total=round(g["total"], 2), kinds=sorted(g["kinds"]), example=g["example"], why=g["why"],
                              scope=top_(g["sc"]), sub=top_(g["sub"]), project=top_(g["pj"]), purpose=top_(g["pu"]), mixed=len(g["sc"]) > 1)
                         for g in allg.values()), key=lambda x: -x["total"])
    pend = sorted(({**g, "kinds": sorted(g["kinds"]), "total": round(g["total"], 2)} for g in groups.values()), key=lambda x: -x["total"])
    new = [r for r in rows if r["status"] != "exists"]
    by = {}
    for r in new:
        if r["kind"] == "支出":
            by[r["scope"]] = round(by.get(r["scope"], 0) + r["amount"], 2)
    with store.db() as c:
        projects = [r["name"] for r in c.execute("select name from projects order by id desc")]
    return dict(id=bid, status=b["status"], names=b["names"], stats=stats, n_total=len(rows), n_new=len(new),
                n_exists=len(rows) - len(new), by_scope=by, pending=pend, groups=all_groups, projects=projects,
                sample=[_public_row(r) for r in new[:200]])


@app.post("/api/bills/upload")
async def upload_bills(files: List[UploadFile] = File(...)):
    tmp = tempfile.mkdtemp()
    paths, names = [], []
    for f in files:
        p = os.path.join(tmp, f.filename)
        open(p, "wb").write(await f.read())
        paths.append(p)
        names.append(f.filename)
    try:
        recs, stats, _ = bt.process(paths, ignore_seen=True)
    except SystemExit as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"读不懂这个账单：{e}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    try:
        existing = ezb_existing_ids()
    except HTTPException:
        existing = set()
    rows = []
    for d in recs:
        r = {k: d[k] for k in ("uid", "time", "src", "kind", "amount", "cp", "item", "note", "typ", "id", "status", "method", "refund", "scope", "sub", "project", "why")}
        r["purpose"] = d.get("purpose", "")
        r["status"] = "exists" if d["uid"] in existing else "new"
        rows.append(r)
    with store.db() as c:
        bid = c.execute("insert into batches(names,stats,rows) values(?,?,?)", ("、".join(names), json.dumps(stats), json.dumps(rows, ensure_ascii=False))).lastrowid
    return _batch_view(bid)


@app.get("/api/bills/batches/{bid}")
def get_batch(bid: int):
    return _batch_view(bid)


@app.get("/api/bills/batches")
def list_batches():
    with store.db() as c:
        return [dict(id=r["id"], created=r["created"], names=r["names"], status=r["status"]) for r in c.execute("select * from batches order by id desc limit 20")]


class Decision(BaseModel):
    cp: str
    scope: str                 # 工作 / 生活
    project: str = ""          # 已有项目名
    new_project: str = ""      # 新项目名（优先）
    purpose: str = ""
    sub: str = ""


class Decisions(BaseModel):
    decisions: List[Decision]


@app.post("/api/bills/batches/{bid}/decide")
def decide(bid: int, body: Decisions):
    learned = bt.load_json(bt.LEARNED, {})
    created = []
    for d in body.decisions:
        if d.scope not in ("工作", "生活"):
            continue
        proj = (d.new_project or d.project or "").strip()
        if HOOKS.get("norm_project"):
            proj = HOOKS["norm_project"](proj)
        if HOOKS.get("fix_sub") and d.scope in ("工作", "生活"):
            v = dict(scope=d.scope, type="exp", sub=d.sub, project="" if proj == "(无项目)" else proj, purpose=d.purpose)
            HOOKS["fix_sub"](v, any_type=True)
            d.scope, d.sub, d.purpose = v["scope"], v["sub"], v["purpose"]
            proj = v["project"] or proj
        if proj in ("(无项目)",) or d.scope != "工作":
            proj = ""
        if proj:
            with store.db() as c:
                if not c.execute("select 1 from projects where name=?", (proj,)).fetchone():
                    c.execute("insert into projects(name,params) values(?, '{}')", (proj,))
                    created.append(proj)
        key = d.cp.strip().lower()
        if key and key != "(无对方)":
            learned[key] = dict(scope=d.scope, sub=d.sub.strip(), project=proj, purpose=d.purpose.strip())
    json.dump(learned, open(bt.LEARNED, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    sync_projects_json()
    # 重新按最新规则分类这一批
    with store.db() as c:
        b = c.execute("select * from batches where id=?", (bid,)).fetchone()
        rows = json.loads(b["rows"])
        rules = bt.load_json(bt.RULES, None)
        rules["项目周期"] = bt.load_projects(rules)
        ann = bt.load_json(bt.ANN, {})
        for r in rows:
            r["purpose"] = ""
            r.update(bt.classify(r, rules, learned, ann))
        c.execute("update batches set rows=? where id=?", (json.dumps(rows, ensure_ascii=False), bid))
    v = _batch_view(bid)
    v["created_projects"] = created
    return v


@app.post("/api/bills/batches/{bid}/commit")
def commit(bid: int):
    with store.db() as c:
        b = c.execute("select * from batches where id=?", (bid,)).fetchone()
    if not b:
        raise HTTPException(404, "没有这个批次")
    rows = json.loads(b["rows"])
    out = []
    for d in rows:
        if d["status"] == "exists":
            continue
        d.setdefault("purpose", "")
        tags = [d["scope"]] + ([f"项目:{d['project']}"] if d["project"] else [])
        out.append({"Time": d["time"], "Type": "Income" if d["kind"] == "收入" else "Expense", "Category": d["scope"],
                    "Sub Category": f"{d['scope']}·{d['sub']}", "Account": bt.account_of(d["src"], d.get("method", "")), "Amount": f"{d['amount']:.2f}",
                    "Tags": ";".join(tags), "Description": bt.rec_description(d)})
    res = push_rows(ezb(), out, log=lambda *_: None) if out else dict(skipped=0, updated=0, added=0)
    invalidate()
    with store.db() as c:
        c.execute("update batches set status='done' where id=?", (bid,))
    res = dict(res, merged=0)
    if HOOKS.get("auto_merge"):          # 之前手记过的账：和刚导入的账单合并，不重复
        try:
            res["merged"] = HOOKS["auto_merge"]()
        except Exception as e:
            print("手记合并失败：", e)
    return res



# ---------------------------------------------------------------- 总览（个人生活收支 / 预算 / 攒钱目标）
def _scope_of(t):
    """以记账本里的分类为准（「工作·xxx」「生活·xxx」「待确认·xxx」）；不是我们的分类时再看标签。"""
    cat = (t.get("category") or {}).get("name", "")
    if "·" in cat:
        pre = cat.split("·", 1)[0]
        if pre in ("工作", "生活", "待确认"):
            return pre
    names = {x["name"] for x in (t.get("tags") or [])}
    if "工作" in names:
        return "工作"
    if "待确认" in names:
        return "待确认"
    return "生活"


_catname = {"t": 0, "m": {}}


def _cat_names():
    """记账本分类 id → 名称（判断『项目·xx』大类用），30 秒缓存。"""
    if time.time() - _catname["t"] > 30 or not _catname["m"]:
        try:
            from api_import import _flat_categories
            _catname["m"] = {str(c["id"]): c["name"] for c in _flat_categories(ezb())}
            _catname["t"] = time.time()
        except Exception:
            pass
    return _catname["m"]


def _project_of(t):
    """项目：先看分类大类（记账本里选的『项目·xx』），再看标签『项目:xx』，最后看备注【xx】。"""
    pid = str((t.get("category") or {}).get("parentId") or "")
    if pid and pid != "0":
        pn = _cat_names().get(pid, "")
        if pn.startswith("项目·"):
            return pn[3:]
    for x in (t.get("tags") or []):
        if x["name"].startswith("项目:"):
            return x["name"][3:]
    m = re.match(r"^【([^｜】]+)", t.get("comment") or "")
    return m.group(1) if m else ""


def _sub_name(t):
    n = (t.get("category") or {}).get("name", "未分类")
    return n.split("·", 1)[1] if "·" in n else n


def _months_of(txs):
    """有账的月份 + 当前月份（没账也要能选当月，默认落在当月）。"""
    ms = {_month_of(t) for t in txs}
    if ms:
        ms.add(date.today().strftime("%Y-%m"))
    return sorted(ms)


def _month_of(t):
    return datetime.fromtimestamp(t["time"]).strftime("%Y-%m")


@app.get("/api/overview")
def overview(month: str = ""):
    txs = [t for t in ezb_transactions() if t["type"] in (2, 3)]
    months = _months_of(txs)
    if not months:
        return dict(months=[], month="", empty=True)
    if month != "all":
        month = month if month in months else months[-1]
    Z = lambda: dict(inc_life=0.0, inc_work=0.0, inc_pend=0.0, inc_div=0.0, inc_adv=0.0, exp_life=0.0, exp_work=0.0, exp_pend=0.0, loan_in=0.0, loan_out=0.0)
    agg = {m: Z() for m in months}
    for t in txs:
        m = _month_of(t)
        a = agg.setdefault(m, Z())
        sc = _scope_of(t)
        if sc == "生活" and _sub_name(t) == "借款往来":        # 借进借出、还款：不是收入也不是支出
            a["loan_" + ("in" if t["type"] == 2 else "out")] = a.get("loan_" + ("in" if t["type"] == 2 else "out"), 0) + t["sourceAmount"] / 100
            continue
        key = ("inc_" if t["type"] == 2 else "exp_") + {"生活": "life", "工作": "work", "待确认": "pend"}[sc]
        a[key] += t["sourceAmount"] / 100
        if t["type"] == 2 and sc == "工作":
            sn = _sub_name(t)
            if sn == "项目分红":
                a["inc_div"] += t["sourceAmount"] / 100        # 分红：算我的收入
            elif sn == "项目备用金入款":
                a["inc_adv"] += t["sourceAmount"] / 100
    if month == "all":
        cur = {k: round(sum(a[k] for a in agg.values()), 2) for k in next(iter(agg.values()))}
    else:
        cur = {k: round(v, 2) for k, v in agg[month].items()}
    cur["inc_total"] = round(cur["inc_life"] + cur["inc_work"] + cur["inc_pend"], 2)
    cur["exp_total"] = round(cur["exp_life"] + cur["exp_work"] + cur["exp_pend"], 2)
    # 三本账分开：我的收支（生活 + 项目分红）／ 项目资金（备用金入款、客户回款 vs 工作支出）／ 待确认（不计入）
    cur["my_inc"] = round(cur["inc_life"] + cur["inc_div"], 2)
    cur["my_exp"] = round(cur["exp_life"], 2)
    cur["proj_in"] = round(cur["inc_work"] - cur["inc_div"], 2)
    cur["proj_back"] = round(cur["proj_in"] - cur["inc_adv"], 2)
    cur["proj_out"] = round(cur["exp_work"], 2)
    cats, merchants = {}, {}
    wcats, wproj, pend = {}, {}, {}
    for t in txs:
        if (month != "all" and _month_of(t) != month) or t["type"] != 3:
            continue
        sc_ = _scope_of(t)
        if sc_ == "生活" and _sub_name(t) == "借款往来":
            continue
        a_ = t["sourceAmount"] / 100
        if sc_ == "工作":
            wcats[_sub_name(t)] = wcats.get(_sub_name(t), 0) + a_
            pn_ = _project_of(t) or "(没归项目)"
            wproj[pn_] = wproj.get(pn_, 0) + a_
            continue
        if sc_ == "待确认":
            cp_ = _strip_prefix(t.get("comment", "")).split(" | ")[0].strip() or "(无对方)"
            e_ = pend.setdefault(cp_, [0.0, 0])
            e_[0] += a_
            e_[1] += 1
            continue
        amt = t["sourceAmount"] / 100
        cats[_sub_name(t)] = cats.get(_sub_name(t), 0) + amt
        cp = _strip_prefix(t.get("comment", "")).split(" | ")[0].strip() or "(无对方)"
        merchants[cp] = merchants.get(cp, 0) + amt
    tot = sum(cats.values()) or 1
    cat_rows = [dict(name=k, amount=round(v, 2), pct=round(v / tot * 100, 1)) for k, v in sorted(cats.items(), key=lambda x: -x[1])]
    top = [dict(name=k, amount=round(v, 2)) for k, v in sorted(merchants.items(), key=lambda x: -x[1])[:10]]
    wt = sum(wcats.values()) or 1
    cats_work = [dict(name=k, amount=round(v, 2), pct=round(v / wt * 100, 1)) for k, v in sorted(wcats.items(), key=lambda x: -x[1])]
    proj_rows = [dict(name=k, amount=round(v, 2), pct=round(v / wt * 100, 1)) for k, v in sorted(wproj.items(), key=lambda x: -x[1])]
    pend_rows = [dict(name=k, amount=round(v[0], 2), n=v[1]) for k, v in sorted(pend.items(), key=lambda x: -x[1][0])]
    idx = len(months) - 1 if month == "all" else months.index(month)
    trend = []
    for m in months[max(0, idx - 11): idx + 1]:
        a = agg[m]
        trend.append(dict(month=m, inc=round(a["inc_life"] + a["inc_div"], 2), exp=round(a["exp_life"], 2), work=round(a["exp_work"], 2)))
    cfg = store.load_config()
    return dict(months=months, month=month, cur=cur, cats=cat_rows, top=top, trend=trend, cats_work=cats_work, projects=proj_rows,
                pend=pend_rows[:12], n_pend=len(pend_rows),
                surplus=round(cur["my_inc"] - cur["my_exp"], 2), budget=float(cfg.get("monthly_budget", 0) or 0))


class BudgetIn(BaseModel):
    monthly_budget: float


@app.put("/api/budget")
def set_budget(b: BudgetIn):
    cfg = store.load_config()
    cfg["monthly_budget"] = b.monthly_budget
    store.save_config(cfg)
    return dict(ok=True)


class GoalIn(BaseModel):
    name: str
    target: float = 0
    deadline: str = ""
    saved0: float = 0
    note: str = ""


class DepositIn(BaseModel):
    date: str = ""
    amount: float
    note: str = ""


def _goal_view(g, deps):
    saved = round(g["saved0"] + sum(d["amount"] for d in deps), 2)
    left = round(max(g["target"] - saved, 0), 2)
    months_left, per_month = None, None
    if g["deadline"]:
        try:
            dl = datetime.strptime(g["deadline"], "%Y-%m-%d").date()
            today = date.today()
            months_left = max((dl.year - today.year) * 12 + dl.month - today.month, 0)
            per_month = round(left / months_left, 2) if months_left else left
        except ValueError:
            pass
    return dict(**g, saved=saved, left=left, pct=round(min(saved / g["target"], 1) * 100, 1) if g["target"] else 0,
                months_left=months_left, per_month=per_month, deposits=deps)


@app.get("/api/goals")
def list_goals():
    with store.db() as c:
        gs = [row(r) for r in c.execute("select * from goals order by id")]
        out = []
        for g in gs:
            deps = [row(r) for r in c.execute("select * from deposits where goal_id=? order by date desc, id desc", (g["id"],))]
            out.append(_goal_view(g, deps))
    return out


@app.post("/api/goals")
def add_goal(g: GoalIn):
    with store.db() as c:
        c.execute("insert into goals(name,target,deadline,saved0,note) values(?,?,?,?,?)", (g.name.strip(), g.target, g.deadline, g.saved0, g.note))
    return list_goals()


@app.put("/api/goals/{gid}")
def edit_goal(gid: int, g: GoalIn):
    with store.db() as c:
        c.execute("update goals set name=?,target=?,deadline=?,saved0=?,note=? where id=?", (g.name.strip(), g.target, g.deadline, g.saved0, g.note, gid))
    return list_goals()


@app.delete("/api/goals/{gid}")
def del_goal(gid: int):
    with store.db() as c:
        c.execute("delete from deposits where goal_id=?", (gid,))
        c.execute("delete from goals where id=?", (gid,))
    return list_goals()


@app.post("/api/goals/{gid}/deposits")
def add_deposit(gid: int, d: DepositIn):
    with store.db() as c:
        c.execute("insert into deposits(goal_id,date,amount,note) values(?,?,?,?)", (gid, d.date or date.today().isoformat(), d.amount, d.note))
    return list_goals()


@app.delete("/api/deposits/{did}")
def del_deposit(did: int):
    with store.db() as c:
        c.execute("delete from deposits where id=?", (did,))
    return list_goals()



@app.get("/api/dashboard")
def dashboard(range: str = "12m"):
    txs = [t for t in ezb_transactions() if t["type"] in (2, 3)]
    months = _months_of(txs)
    if not months:
        return dict(empty=True)
    if range == "12m":
        keep = set(months[-12:])
    elif range == "year":
        keep = {m for m in months if m[:4] == months[-1][:4]}
    else:
        keep = set(months)
    series = {m: dict(month=m, inc=0.0, exp=0.0, inc_life=0.0, inc_work=0.0, inc_div=0.0, exp_life=0.0, exp_work=0.0, exp_pend=0.0) for m in months if m in keep}
    cl, cw, ml, mw = {}, {}, {}, {}
    meta = {}
    tot = dict(inc_life=0.0, inc_work=0.0, inc_pend=0.0, inc_div=0.0, inc_adv=0.0, exp_life=0.0, exp_work=0.0, exp_pend=0.0)
    for t in txs:
        m = _month_of(t)
        if m not in keep:
            continue
        a = t["sourceAmount"] / 100
        sc = _scope_of(t)
        if sc == "生活" and _sub_name(t) == "借款往来":        # 借款往来不算收支
            continue
        k = {"生活": "life", "工作": "work", "待确认": "pend"}[sc]
        tot[("inc_" if t["type"] == 2 else "exp_") + k] += a
        if t["type"] == 2 and k == "work":
            if _sub_name(t) == "项目分红":
                tot["inc_div"] += a
                series[m]["inc_div"] += a
            elif _sub_name(t) == "项目备用金入款":
                tot["inc_adv"] += a
        series[m]["inc" if t["type"] == 2 else "exp"] += a
        if t["type"] == 2 and k in ("life", "work"):
            series[m]["inc_" + k] += a
        if t["type"] == 3:
            series[m]["exp_" + k] += a
            cp = _strip_prefix(t.get("comment", "")).split(" | ")[0].strip() or "(无对方)"
            if k in ("life", "work"):
                pm = re.match(r"^【([^｜】]*)(?:｜([^】]*))?】", t.get("comment") or "")
                mm = meta.setdefault((k, cp), dict(pj={}, pu={}, sub={}, n=0))
                mm["n"] += 1
                mm["sub"][_sub_name(t)] = mm["sub"].get(_sub_name(t), 0) + a
                pn_ = _project_of(t)
                if pn_:
                    mm["pj"][pn_] = mm["pj"].get(pn_, 0) + a
                if pm and (pm.group(2) or "").strip():
                    mm["pu"][pm.group(2).strip()] = mm["pu"].get(pm.group(2).strip(), 0) + a
            if k == "life":
                cl[_sub_name(t)] = cl.get(_sub_name(t), 0) + a
                ml[cp] = ml.get(cp, 0) + a
            elif k == "work":
                cw[_sub_name(t)] = cw.get(_sub_name(t), 0) + a
                mw[cp] = mw.get(cp, 0) + a
    def top(d, n=10, scope=None):
        out = []
        for k, v in sorted(d.items(), key=lambda x: -x[1])[:n]:
            it = dict(name=k, amount=round(v, 2))
            if scope:
                mm = meta.get((scope, k), {})
                it["project"] = max(mm.get("pj", {}), key=mm["pj"].get) if mm.get("pj") else ""
                it["n_projects"] = len(mm.get("pj", {}))
                it["purpose"] = max(mm.get("pu", {}), key=mm["pu"].get) if mm.get("pu") else ""
                it["sub"] = max(mm.get("sub", {}), key=mm["sub"].get) if mm.get("sub") else ""
                it["n"] = mm.get("n", 0)
            out.append(it)
        return out
    pj, pjn, ppay = {}, {}, {}
    for t in txs:
        if t["type"] == 3 and _month_of(t) in keep:
            pn = _project_of(t)
            if pn:
                pj[pn] = pj.get(pn, 0) + t["sourceAmount"] / 100
                pjn[pn] = pjn.get(pn, 0) + 1
                who_ = re.sub(r"〔ID:.*?〕", "", _strip_prefix(t.get("comment", ""))).split(" | ")[0].strip() or "(无对方)"
                pp_ = ppay.setdefault(who_, dict(amount=0.0, n=0, pj={}))
                pp_["amount"] += t["sourceAmount"] / 100
                pp_["n"] += 1
                pp_["pj"][pn] = pp_["pj"].get(pn, 0) + t["sourceAmount"] / 100
                pm_ = re.match(r"^【([^｜】]*)(?:｜([^】]*))?】", t.get("comment") or "")
                if pm_ and (pm_.group(2) or "").strip():
                    pu_ = pp_.setdefault("pu", {})
                    pu_[pm_.group(2).strip()] = pu_.get(pm_.group(2).strip(), 0) + t["sourceAmount"] / 100
    projects = []
    with store.db() as c:
        ps = [row(r) for r in c.execute("select id,name from projects")]
    for p in ps:
        d = project_detail(p["id"])
        if d["summary"]["total"] > 0:
            projects.append(dict(name=p["name"], total=d["summary"]["total"], paid=d["summary"]["paid"], profit=d["profit"]["profit"], rate=d["profit"]["rate"], quote=d["project"]["params"].get("quote", 0)))
    projects.sort(key=lambda x: -x["total"])
    n_m = max(len(series), 1)
    tot["inc_total"] = tot["inc_life"] + tot["inc_work"] + tot["inc_pend"]
    tot["exp_total"] = tot["exp_life"] + tot["exp_work"] + tot["exp_pend"]
    return dict(range=range, months=[{k: (round(v, 2) if k != "month" else v) for k, v in series[m].items()} for m in sorted(series)],
                tot={k: round(v, 2) for k, v in tot.items()}, avg_life=round(tot["exp_life"] / n_m, 2),
                cats_life=top(cl, 12), cats_work=top(cw, 12), top_life=top(ml, 10, 'life'), top_work=top(mw, 10, 'work'),
                top_proj_pay=[dict(name=k, amount=round(v['amount'], 2), n=v['n'], project=max(v['pj'], key=v['pj'].get), n_projects=len(v['pj']), purpose=(max(v['pu'], key=v['pu'].get) if v.get('pu') else '')) for k, v in sorted(ppay.items(), key=lambda x: -x[1]['amount'])[:10]], projects=projects,
                top_projects=[dict(name=k, amount=round(v, 2), n=pjn[k]) for k, v in sorted(pj.items(), key=lambda x: -x[1])[:10]])



@app.get("/api/drill")
def drill(range: str = "12m", month: str = "", scope: str = "生活", type: str = "exp", cat: str = "", project: str = ""):
    """看板点击某个月/某个分类后的金额明细。"""
    txs = [t for t in ezb_transactions() if t["type"] in (2, 3)]
    months = _months_of(txs)
    keep = set(months[-12:]) if range == "12m" else ({m for m in months if m[:4] == months[-1][:4]} if range == "year" else set(months))
    want = 2 if type == "inc" else 3
    rows, total = [], 0.0
    for t in txs:
        m = _month_of(t)
        if t["type"] != want or (scope != "全部" and not project and _scope_of(t) != scope) or (month and m != month) or (not month and m not in keep):
            continue
        if cat and _sub_name(t) != cat:
            continue
        if project and _project_of(t) != project:
            continue
        a = t["sourceAmount"] / 100
        total += a
        rows.append(dict(time=datetime.fromtimestamp(t["time"]).strftime("%Y-%m-%d %H:%M"), amount=round(a, 2), cat=_sub_name(t),
                         name=_strip_prefix(t.get("comment", "")).strip()[:60], uid=rid(t.get("comment")) or "", tx_id=str(t["id"]), scope=_scope_of(t), project=_project_of(t), account=(t.get("sourceAccount") or {}).get("name", "")))
    rows.sort(key=lambda r: -r["amount"])
    return dict(total=round(total, 2), n=len(rows), rows=rows[:200])



class Reclass(BaseModel):
    cp: str = ""            # 按交易对方：该对象所有账单一起改，并记住以后自动归类
    uid: str = ""           # 或按单笔账单
    tx_id: str = ""         # 记账本里手动记的账（没有账单编号）用它
    scope: str              # 工作 / 生活
    project: str = ""
    new_project: str = ""
    purpose: str = ""
    sub: str = ""


@app.post("/api/reclassify")
def reclassify(b: Reclass):
    if b.scope not in ("工作", "生活"):
        raise HTTPException(400, "请选择工作或生活")
    if not b.cp and not b.uid and not b.tx_id:
        raise HTTPException(400, "没有指定对象")
    proj = (b.new_project or b.project or "").strip()
    if HOOKS.get("norm_project"):
        proj = HOOKS["norm_project"](proj)
    note = ""
    if HOOKS.get("fix_sub"):                        # 子类防填错（按对象改：收入/支出子类都算合法）
        v = dict(scope=b.scope, type="exp", sub=b.sub, project="" if proj == "(无项目)" else proj, purpose=b.purpose)
        note = HOOKS["fix_sub"](v, any_type=True)
        b.scope, b.sub, b.purpose = v["scope"], v["sub"], v["purpose"]
        proj = v["project"] or proj
    if proj == "(无项目)" or b.scope != "工作":
        proj = ""
    if proj:
        with store.db() as c:
            if not c.execute("select 1 from projects where name=?", (proj,)).fetchone():
                c.execute("insert into projects(name,params) values(?,?)", (proj, json.dumps(store.MODE_DEFAULTS[store.detect_mode(dict(name=proj))])))
        sync_projects_json()
    if b.cp.strip() and b.cp.strip() != "(无对方)":
        learned = bt.load_json(bt.LEARNED, {})
        learned[b.cp.strip().lower()] = dict(scope=b.scope, sub=b.sub.strip(), project=proj, purpose=b.purpose.strip())
        json.dump(learned, open(bt.LEARNED, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    if b.tx_id and not b.uid:      # 手动记的账：先给它补一个编号，之后和其它账单一样处理
        api = ezb()
        for t in ezb_transactions(force=True):
            if str(t["id"]) == b.tx_id and not rid(t.get("comment")):
                nid = f"手动:{t['id']}"
                api.call("POST", "/api/v1/transactions/modify.json", dict(
                    id=str(t["id"]), type=t["type"], categoryId=str(t["categoryId"]), time=t["time"], utcOffset=t["utcOffset"],
                    sourceAccountId=str(t["sourceAccountId"]), destinationAccountId=str(t.get("destinationAccountId") or 0),
                    sourceAmount=t["sourceAmount"], destinationAmount=t.get("destinationAmount", 0), hideAmount=t.get("hideAmount", False),
                    tagIds=[str(x) for x in (t.get("tagIds") or [])], pictureIds=[p["pictureId"] for p in (t.get("pictures") or [])],
                    comment=((t.get("comment") or "").strip() + f"〔ID:{nid}〕")[:255]))
                b.uid = nid
                break
        invalidate()
    rows = []
    for t in ezb_transactions(force=True):
        i = rid(t.get("comment"))
        if not i or t["type"] not in (2, 3):
            continue
        core = _strip_prefix(t["comment"]).strip()
        who = core.split(" | ")[0].strip()
        if not ((b.uid and i == b.uid) or (b.cp and who.lower() == b.cp.strip().lower())):
            continue
        cur_scope, cur_sub = _scope_of(t), _sub_name(t)
        sub = b.sub.strip()
        if not sub:
            if cur_scope == b.scope:
                sub = cur_sub
            else:
                sub = ("项目回款" if t["type"] == 2 else "项目支出") if b.scope == "工作" else ("红包转账" if t["type"] == 2 else "其他")
        pre = f"【{proj}｜{b.purpose.strip()}】" if proj and b.purpose.strip() else (f"【{proj}】" if proj else (f"【｜{b.purpose.strip()}】" if b.purpose.strip() else ""))
        suf = f"〔ID:{i}〕"
        desc = pre + core[:max(0, 250 - len(pre) - len(suf))] + suf
        rows.append({"Time": datetime.fromtimestamp(t["time"]).strftime("%Y-%m-%d %H:%M:%S"), "Type": "Income" if t["type"] == 2 else "Expense",
                     "Category": b.scope, "Sub Category": f"{b.scope}·{sub}", "Account": (t.get("sourceAccount") or {}).get("name", "微信"),
                     "Amount": f"{t['sourceAmount'] / 100:.2f}", "Tags": b.scope + (f";项目:{proj}" if proj else ""), "Description": desc})
    if not rows:
        raise HTTPException(404, "没找到对应的账单")
    res = push_rows(ezb(), rows, log=lambda *_: None)
    invalidate()
    return dict(n=len(rows), note=note, **res)



# ---------------------------------------------------------------- 借款 / 还款 / 到期提醒
import subprocess, threading


class DebtIn(BaseModel):
    name: str
    direction: str = "owe"          # owe=我欠别人（需要我还） / lent=别人欠我（等对方还）
    amount: float = 0
    borrow_date: str = ""
    due_date: str = ""
    remind_days: int = 3
    note: str = ""
    mac_reminder: int = 1           # 同时加入 macOS「提醒事项」（App 没开也会提醒）


class RepayIn(BaseModel):
    date: str = ""
    amount: float
    note: str = ""


def _debt_view(d, reps):
    paid = round(sum(r["amount"] for r in reps), 2)
    remain = round(max(d["amount"] - paid, 0), 2)
    days = None
    status = "done" if remain <= 0.005 else "normal"
    if d["due_date"]:
        try:
            days = (datetime.strptime(d["due_date"], "%Y-%m-%d").date() - date.today()).days
            if status != "done":
                status = "overdue" if days < 0 else ("soon" if days <= (d["remind_days"] or 3) else "normal")
        except ValueError:
            pass
    return dict(d, paid=paid, remain=remain, pct=round(min(paid / d["amount"], 1) * 100, 1) if d["amount"] else 0,
                days_to_due=days, status=status, repayments=reps)


def _mac_run(script, timeout=15):
    try:
        r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, (r.stdout or r.stderr).strip()
    except Exception as e:
        return False, str(e)


def _as_date(d, hour=9):
    y, m, dd = [int(x) for x in d.split("-")]
    return f"set d to (current date)\nset day of d to 1\nset year of d to {y}\nset month of d to {m}\nset day of d to {dd}\nset time of d to {hour * 3600}"


def _reminders_add(debt):
    """在 macOS『提醒事项』里建「还款提醒」列表，并在到期前 N 天和到期当天各加一条。返回 id 列表。"""
    if not debt["due_date"]:
        return []
    ids = []
    who = "还给" if debt["direction"] == "owe" else "向对方收款："
    title = f"还款：{who}{debt['name']} ¥{debt['amount']:,.2f}" if debt["direction"] == "owe" else f"收款提醒：{debt['name']} 应还我 ¥{debt['amount']:,.2f}"
    when = [(debt["due_date"], f"{title}（今天到期）")]
    if debt["remind_days"]:
        dt = datetime.strptime(debt["due_date"], "%Y-%m-%d").date() - timedelta(days=debt["remind_days"])
        if dt >= date.today():
            when.insert(0, (dt.isoformat(), f"{title}（{debt['remind_days']}天后到期）"))
    for d, name in when:
        script = f'''{_as_date(d)}
tell application "Reminders"
  if not (exists list "还款提醒") then make new list with properties {{name:"还款提醒"}}
  set r to make new reminder at end of reminders of list "还款提醒" with properties {{name:"{name}", due date:d, remind me date:d, body:"{debt['note'].replace('"', ' ')}"}}
  return id of r
end tell'''
        ok, out = _mac_run(script)
        if ok and out:
            ids.append(out)
    return ids


def _reminders_delete(ids):
    for i in ids:
        _mac_run(f'tell application "Reminders" to delete (first reminder whose id is "{i}")')


@app.get("/api/debts")
def list_debts():
    with store.db() as c:
        ds = [row(r) for r in c.execute("select * from debts order by (due_date='' ), due_date, id")]
        out = []
        for d in ds:
            reps = [row(r) for r in c.execute("select * from repayments where debt_id=? order by date desc, id desc", (d["id"],))]
            out.append(_debt_view(d, reps))
    return out


@app.get("/api/debts/summary")
def debts_summary():
    ds = list_debts()
    open_ = [d for d in ds if d["status"] != "done"]
    owe = [d for d in open_ if d["direction"] == "owe"]
    lent = [d for d in open_ if d["direction"] == "lent"]
    alerts = [dict(id=d["id"], name=d["name"], direction=d["direction"], remain=d["remain"], due_date=d["due_date"], days=d["days_to_due"], status=d["status"])
              for d in open_ if d["status"] in ("overdue", "soon")]
    # 按月的待还/待收时间线
    tl = {}
    for d in open_:
        if d["due_date"]:
            m = d["due_date"][:7]
            t = tl.setdefault(m, dict(month=m, owe=0.0, lent=0.0))
            t["owe" if d["direction"] == "owe" else "lent"] += d["remain"]
    return dict(owe_total=round(sum(d["remain"] for d in owe), 2), lent_total=round(sum(d["remain"] for d in lent), 2),
                n_owe=len(owe), n_lent=len(lent), alerts=sorted(alerts, key=lambda a: (a["days"] if a["days"] is not None else 9999)),
                timeline=[dict(v, owe=round(v["owe"], 2), lent=round(v["lent"], 2)) for _, v in sorted(tl.items())])


@app.post("/api/debts")
def add_debt(b: DebtIn):
    if not b.name.strip() or b.amount <= 0:
        raise HTTPException(400, "请填对方和金额")
    with store.db() as c:
        did = c.execute("insert into debts(name,direction,amount,borrow_date,due_date,remind_days,note,mac_reminder) values(?,?,?,?,?,?,?,?)",
                        (b.name.strip(), b.direction, b.amount, b.borrow_date or date.today().isoformat(), b.due_date, b.remind_days, b.note, b.mac_reminder)).lastrowid
    msg = ""
    if b.mac_reminder and b.due_date:
        with store.db() as c:
            d = row(c.execute("select * from debts where id=?", (did,)).fetchone())
        ids = _reminders_add(d)
        with store.db() as c:
            c.execute("update debts set reminder_ids=? where id=?", (json.dumps(ids), did))
        msg = "已加入「提醒事项」" if ids else "（没能写入「提醒事项」，App 内仍会提醒）"
    return dict(debts=list_debts(), msg=msg)


@app.put("/api/debts/{did}")
def edit_debt(did: int, b: DebtIn):
    with store.db() as c:
        r = c.execute("select * from debts where id=?", (did,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这笔")
        _reminders_delete(json.loads(r["reminder_ids"] or "[]"))
        c.execute("update debts set name=?,direction=?,amount=?,borrow_date=?,due_date=?,remind_days=?,note=?,mac_reminder=?,reminder_ids='[]',last_notified='' where id=?",
                  (b.name.strip(), b.direction, b.amount, b.borrow_date, b.due_date, b.remind_days, b.note, b.mac_reminder, did))
    if b.mac_reminder and b.due_date:
        with store.db() as c:
            d = row(c.execute("select * from debts where id=?", (did,)).fetchone())
        ids = _reminders_add(d)
        with store.db() as c:
            c.execute("update debts set reminder_ids=? where id=?", (json.dumps(ids), did))
    return dict(debts=list_debts(), msg="")


@app.delete("/api/debts/{did}")
def del_debt(did: int):
    with store.db() as c:
        r = c.execute("select reminder_ids from debts where id=?", (did,)).fetchone()
        if r:
            _reminders_delete(json.loads(r["reminder_ids"] or "[]"))
        links = [r_[0] for r_ in c.execute("select tx_uid from repayments where debt_id=? and tx_uid<>''", (did,))]
        dtx = c.execute("select tx_uid from debts where id=?", (did,)).fetchone()
        c.execute("delete from repayments where debt_id=?", (did,))
        c.execute("delete from debts where id=?", (did,))
    if HOOKS.get("drop_loan_tx"):                          # 账单那边跟着改
        for u in links + ([dtx[0]] if dtx and dtx[0] else []):
            try:
                HOOKS["drop_loan_tx"](u)
            except Exception as e:
                print("借款关联账单处理失败：", e)
    return list_debts()


@app.post("/api/debts/{did}/repay")
def repay(did: int, b: RepayIn):
    if b.amount <= 0:
        raise HTTPException(400, "金额要大于 0")
    with store.db() as c:
        c.execute("insert into repayments(debt_id,date,amount,note) values(?,?,?,?)", (did, b.date or date.today().isoformat(), b.amount, b.note))
        r = c.execute("select * from debts where id=?", (did,)).fetchone()
        paid = c.execute("select coalesce(sum(amount),0) from repayments where debt_id=?", (did,)).fetchone()[0]
        if r and paid >= r["amount"] - 0.005:           # 还清了：撤掉还没到点的提醒
            _reminders_delete(json.loads(r["reminder_ids"] or "[]"))
            c.execute("update debts set reminder_ids='[]' where id=?", (did,))
    return list_debts()


@app.delete("/api/repayments/{rid_}")
def del_repay(rid_: int):
    with store.db() as c:
        r_ = c.execute("select tx_uid from repayments where id=?", (rid_,)).fetchone()
        c.execute("delete from repayments where id=?", (rid_,))
    if r_ and r_[0] and HOOKS.get("drop_loan_tx"):
        try:
            HOOKS["drop_loan_tx"](r_[0])
        except Exception as e:
            print("还款关联账单处理失败：", e)
    return list_debts()


def _notify_loop():
    """App 开着时，每 30 分钟检查一次：到提醒日/已逾期的未还款项，发 macOS 通知（每笔每天一次）。"""
    while True:
        try:
            today = date.today().isoformat()
            for d in list_debts():
                if d["status"] in ("overdue", "soon") and d["last_notified"] != today:
                    who = "还给" if d["direction"] == "owe" else "向"
                    if d["status"] == "overdue":
                        txt = f"{who}{d['name']}的 ¥{d['remain']:,.2f} 已逾期 {-d['days_to_due']} 天"
                    else:
                        txt = f"{who}{d['name']}的 ¥{d['remain']:,.2f}，{d['days_to_due']} 天后（{d['due_date']}）到期" if d["days_to_due"] else f"{who}{d['name']}的 ¥{d['remain']:,.2f} 今天到期"
                    _mac_run(f'display notification "{txt}" with title "CD的记账本 · {"还款" if d["direction"] == "owe" else "收款"}提醒" sound name "Glass"')
                    with store.db() as c:
                        c.execute("update debts set last_notified=? where id=?", (today, d["id"]))
        except Exception:
            pass
        time.sleep(1800)


threading.Thread(target=_notify_loop, daemon=True).start()



# ---------------------------------------------------------------- 下拉选项（常用项 + 你以前填过的）
DEFAULT_CATS = {"搭建部分": ["场地搭建", "展台搭建", "灯光音响", "舞台", "道具"],
                "第三方人员": ["兼职运营", "督导", "安保", "设计费", "摄影摄像", "项目助理"],
                "物料部分": ["物料采购", "快印", "物流"],
                "执行人员杂费": ["交通费", "餐补", "住宿", "业务招待"]}
DEFAULT_NAMES = ["货拉拉", "顺丰/快递", "打车费", "酒店住宿", "执行 交通费（高铁/飞机）", "客户咖啡等", "兼职奶茶饮品费用", "KT板", "物料打印", "喷绘写真", "工作牌", "矿泉水", "安保", "兼职运营人员", "督导", "设计费", "施工入场保险", "帐篷租赁", "仓储货车费用"]
UNITS = ["项", "个", "套", "趟", "人天", "天", "人", "件", "张", "米", "平米", "箱", "次"]
WORK_SUBS = ["物料搭建", "第三方人员", "设计费", "餐补", "场地费", "礼品采购", "办公用品", "税费手续费", "人员劳务", "供应商执行", "快递物流", "差旅住宿", "软件工具", "打印复印", "招待", "交通", "项目支出", "项目回款"]
LIFE_SUBS = ["餐饮", "买菜超市", "日用百货", "服饰美妆", "休闲护理", "交通出行", "购物", "居家", "房租", "水电燃气", "通讯网络", "旅行度假", "运动健身", "学习教育", "保险", "宠物", "家人孝敬", "数码NAS网络", "娱乐订阅", "医疗健康", "烟酒", "人情往来", "红包转账", "工资薪酬", "其他", "借款往来"]
DEFAULT_PURPOSES = ["KT板制作", "物料打印", "物料采购", "货拉拉运输", "快递物流", "场地搭建", "兼职费用", "设计费", "打车", "差旅交通", "住宿", "客户招待", "备用金", "押金", "项目回款", "劳务费"]


# ---------------------------------------------------------------- 自定义子类（你自己新增的，和内置的一样能选，防填错不会拦）
CUSTOM_SUBS = os.path.join(bt.STATE, "自定义子类.json")


def custom_subs():
    d = bt.load_json(CUSTOM_SUBS, {}) or {}
    return {"工作": list(d.get("工作", [])), "生活": list(d.get("生活", []))}


def all_subs(scope):
    base = [x for x in WORK_SUBS if x != "项目回款"] if scope == "工作" else LIFE_SUBS
    return base + [x for x in custom_subs()[scope] if x not in base]


class SubIn(BaseModel):
    scope: str
    name: str


def _sub_usage():
    from collections import Counter
    return Counter((_scope_of(t), _sub_name(t)) for t in ezb_transactions() if t["type"] in (2, 3))


@app.get("/api/subs")
def list_subs():
    use, cs = _sub_usage(), custom_subs()
    return {sc: [dict(name=x, custom=x in cs[sc], n=use.get((sc, x), 0)) for x in all_subs(sc)] for sc in ("工作", "生活")}


@app.post("/api/subs")
def add_sub(b: SubIn):
    name = re.sub(r"\s+", "", b.name or "").replace("·", "").strip()
    if b.scope not in ("工作", "生活"):
        raise HTTPException(400, "只能给「工作」或「生活」加子类")
    if not name or len(name) > 12:
        raise HTTPException(400, "子类名称 1–12 个字")
    if name in all_subs(b.scope):
        return list_subs()
    with store.db() as c:
        if c.execute("select 1 from projects where name=?", (name,)).fetchone():
            raise HTTPException(400, f"「{name}」是项目名，请在「项目」里选，不要当子类")
    d = custom_subs()
    d[b.scope].append(name)
    json.dump(d, open(CUSTOM_SUBS, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    from api_import import ensure_project_categories, ensure_base_categories
    api = ezb()
    ensure_base_categories(api, {b.scope: [name]})
    if b.scope == "工作":
        with store.db() as c:
            names = [r["name"] for r in c.execute("select name from projects")]
        ensure_project_categories(api, names, [name])
    invalidate()
    return list_subs()


@app.delete("/api/subs")
def del_sub(scope: str, name: str):
    d = custom_subs()
    if name not in d.get(scope, []):
        raise HTTPException(400, "只能删除你自己新增的子类")
    n = _sub_usage().get((scope, name), 0)
    if n:
        raise HTTPException(400, f"还有 {n} 笔账在用「{name}」，先在账单明细里把它们改到别的子类")
    from api_import import _flat_categories
    api = ezb()
    for cat in _flat_categories(api):
        if cat["name"] == f"{scope}·{name}" and str(cat.get("parentId", "0")) != "0":
            try:
                api.call("POST", "/api/v1/transaction/categories/delete.json", {"id": str(cat["id"])})
            except Exception:
                pass
    d[scope].remove(name)
    json.dump(d, open(CUSTOM_SUBS, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    invalidate()
    return list_subs()


@app.get("/api/suggest")
def suggest():
    from collections import Counter
    with store.db() as c:
        ls = [row(r) for r in c.execute("select sec,cat,name,spec,vendor,unit from lines")]
        who = [r["name"] for r in c.execute("select name from debts")]
    def top(seq, extra=(), n=40):
        cnt = Counter(x for x in seq if x)
        out = [k for k, _ in cnt.most_common(n)]
        return out + [e for e in extra if e not in out]
    cats = {sec: top([l["cat"] for l in ls if l["sec"] == sec], DEFAULT_CATS.get(sec, [])) for sec in store.SECTIONS if sec != "备用金"}
    learned = bt.load_json(bt.LEARNED, {})
    purposes = top([v.get("purpose", "") for v in learned.values()], DEFAULT_PURPOSES)
    return dict(cats=cats, names=top([l["name"] for l in ls], DEFAULT_NAMES, 60), specs=top([l["spec"] for l in ls], (), 60),
                vendors=top([l["vendor"][:30] for l in ls], (), 40), units=top([l["unit"] for l in ls], UNITS, 20),
                purposes=purposes, work_subs=all_subs("工作") + ["项目备用金入款", "项目分红", "项目回款"], life_subs=all_subs("生活"), debt_names=top(who))


# ---------------------------------------------------------------- 自动备份
AS_DIR = os.path.dirname(store.DATA)                      # ~/Library/Application Support/CD的记账本
BACKUP_DIR = os.path.join(AS_DIR, "备份")
KEEP_BACKUPS = 14


def _sqlite_copy(src, dst):
    import sqlite3
    if not os.path.exists(src):
        return False
    a, b = sqlite3.connect(src), sqlite3.connect(dst)
    with b:
        a.backup(b)
    a.close(); b.close()
    return True


def do_backup(reason="自动"):
    """记账本数据库 + 项目台数据库 + 发票图片 + 分类规则/记住的判断，打包到「备份/日期时间」。保留最近 14 份。"""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    name = datetime.now().strftime("%Y-%m-%d_%H%M") + ("_手动" if reason == "手动" else "")
    dst = os.path.join(BACKUP_DIR, name)
    os.makedirs(dst, exist_ok=True)
    _sqlite_copy(os.path.join(AS_DIR, "记账本", "data", "ezbookkeeping.db"), os.path.join(dst, "记账本.db"))
    _sqlite_copy(store.DB, os.path.join(dst, "项目台.db"))
    for sub in ("状态",):
        p = os.path.join(AS_DIR, sub)
        if os.path.isdir(p):
            shutil.copytree(p, os.path.join(dst, sub), dirs_exist_ok=True)
    if os.path.exists(store.CONFIG):
        shutil.copy2(store.CONFIG, dst)
    # 发票图片：只增不减，放在共用的 files 目录（省空间），每份备份记一个清单
    fdst = os.path.join(BACKUP_DIR, "发票图片")
    if os.path.isdir(store.FILES):
        for root, _, fs in os.walk(store.FILES):
            for f in fs:
                s_ = os.path.join(root, f)
                d_ = os.path.join(fdst, os.path.relpath(s_, store.FILES))
                if not os.path.exists(d_) or os.path.getsize(d_) != os.path.getsize(s_):
                    os.makedirs(os.path.dirname(d_), exist_ok=True)
                    shutil.copy2(s_, d_)
    olds = sorted(d for d in os.listdir(BACKUP_DIR) if d[:4].isdigit() and os.path.isdir(os.path.join(BACKUP_DIR, d)))
    for d in olds[:-KEEP_BACKUPS]:
        shutil.rmtree(os.path.join(BACKUP_DIR, d), ignore_errors=True)
    mirror = (store.load_config().get("backup_mirror") or "").strip()
    mirrored = ""
    if mirror:
        try:
            if os.path.isdir(mirror):
                tgt = os.path.join(os.path.expanduser(mirror), "CD的记账本备份")
                shutil.copytree(dst, os.path.join(tgt, name), dirs_exist_ok=True)
                if os.path.isdir(fdst):
                    shutil.copytree(fdst, os.path.join(tgt, "发票图片"), dirs_exist_ok=True)
                mirrored = tgt
        except Exception as e:
            mirrored = f"失败：{e}"
    return dict(name=name, path=dst, mirrored=mirrored)


def _backup_list():
    if not os.path.isdir(BACKUP_DIR):
        return []
    out = []
    for d in sorted(os.listdir(BACKUP_DIR), reverse=True):
        p = os.path.join(BACKUP_DIR, d)
        if d[:4].isdigit() and os.path.isdir(p):
            size = sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(p) for f in fs)
            out.append(dict(name=d, size_mb=round(size / 1048576, 1)))
    return out


def _backup_loop():
    time.sleep(20)
    while True:
        try:
            bl = _backup_list()
            last = bl[0]["name"][:15] if bl else ""
            if not last or datetime.now() - datetime.strptime(last, "%Y-%m-%d_%H%M") > timedelta(hours=20):
                do_backup()
        except Exception:
            pass
        time.sleep(3600)


threading.Thread(target=_backup_loop, daemon=True).start()


@app.get("/api/backups")
def list_backups():
    return dict(dir=BACKUP_DIR, keep=KEEP_BACKUPS, mirror=store.load_config().get("backup_mirror", ""), items=_backup_list())


@app.post("/api/backups")
def backup_now():
    r = do_backup("手动")
    return dict(r, items=_backup_list())


class MirrorIn(BaseModel):
    path: str = ""


@app.put("/api/backups/mirror")
def set_mirror(b: MirrorIn):
    p = os.path.expanduser(b.path.strip())
    if p and not os.path.isdir(p):
        raise HTTPException(400, f"找不到这个文件夹：{p}（NAS 要先挂载）")
    cfg = store.load_config()
    cfg["backup_mirror"] = p
    store.save_config(cfg)
    return dict(ok=True, mirror=p)


@app.post("/api/open-folder")
def open_folder(b: MirrorIn):
    import subprocess as _sp
    p = os.path.expanduser(b.path or BACKUP_DIR)
    if not p.startswith(AS_DIR) and p != store.load_config().get("backup_mirror"):
        raise HTTPException(400, "只能打开备份文件夹")
    os.makedirs(p, exist_ok=True)
    _sp.run(["open", p])
    return dict(ok=True)


@app.get("/api/pending-objects")
def pending_objects(month: str = ""):
    """还没分工作/生活的账，按对象（交易对方）合并，方便一个对象一次判断完。"""
    g = {}
    for t in ezb_transactions():
        if t["type"] not in (2, 3) or _scope_of(t) != "待确认":
            continue
        if month and _month_of(t) != month:
            continue
        cp = _strip_prefix(t.get("comment", "")).split(" | ")[0].strip() or "(无对方)"
        e = g.setdefault(cp, dict(name=cp, exp=0.0, inc=0.0, n=0, last="", subs={}, note=""))
        a = t["sourceAmount"] / 100
        e["exp" if t["type"] == 3 else "inc"] += a
        e["n"] += 1
        d = datetime.fromtimestamp(t["time"]).strftime("%Y-%m-%d")
        if d > e["last"]:
            e["last"] = d
            rest = _strip_prefix(t.get("comment", "")).split(" | ")
            e["note"] = " | ".join(rest[1:])[:60]
        e["subs"][_sub_name(t)] = e["subs"].get(_sub_name(t), 0) + 1
    rows = []
    for e in g.values():
        e["why"] = max(e["subs"], key=e["subs"].get)
        del e["subs"]
        e["exp"], e["inc"] = round(e["exp"], 2), round(e["inc"], 2)
        rows.append(e)
    rows.sort(key=lambda e: -(e["exp"] + e["inc"]))
    return dict(n=len(rows), total_exp=round(sum(e["exp"] for e in rows), 2), total_inc=round(sum(e["inc"] for e in rows), 2), rows=rows)


@app.post("/api/admin/project-categories")
def migrate_project_categories():
    """一次性整理：已归项目的工作账，移到记账本『项目·项目名』大类下。"""
    with store.db() as c:
        names = [r[0] for r in c.execute("select name from projects")]
    txs = ezb_transactions(force=True)
    names += sorted({_project_of(t) for t in txs if _project_of(t)} - set(names))
    from api_import import ensure_project_categories
    created = ensure_project_categories(ezb(), names)
    invalidate()
    cats = _cat_names()
    todo = []
    for t in ezb_transactions(force=True):
        if t["type"] not in (2, 3) or _scope_of(t) != "工作" or not _project_of(t):
            continue
        parent = cats.get(str((t.get("category") or {}).get("parentId") or ""), "")
        if parent != "项目·" + _project_of(t):
            todo.append(t)
    n = txedit_apply([(t, {"project": _project_of(t)}) for t in todo]) if todo else 0
    return dict(categories_created=created, moved=n, projects=len(names))


@app.get("/api/ping")
def ping():
    return dict(ok=True)



# ---------------------------------------------------------------- 账单明细（直接改记账本）
import txedit                              # noqa: E402
txedit_apply = txedit.setup(app, dict(ezb=ezb, ezb_transactions=ezb_transactions, invalidate=invalidate, _scope_of=_scope_of, _project_of=_project_of,
                       _sub_name=_sub_name, _month_of=_month_of, push_rows=push_rows, rid=rid, bt=bt, store=store,
                       sync_projects_json=sync_projects_json, hooks=HOOKS, WORK_SUBS=WORK_SUBS, LIFE_SUBS=LIFE_SUBS, all_subs=lambda sc: all_subs(sc),
                       add_debt=lambda b: add_debt(b), repay=lambda did, b: repay(did, b), list_debts=lambda: list_debts()))

import invoices                            # noqa: E402
def _ensure_project(name):
    """按名字找项目；「项目 · 分期名」按项目算；没有就新建（和「新建项目」按钮一样）。返回 (pid, 是否新建)。"""
    name = (name or "").strip()
    if HOOKS.get("norm_project"):
        name = HOOKS["norm_project"](name)
    if not name:
        raise HTTPException(400, "请填项目名")
    with store.db() as c:
        r = c.execute("select id from projects where name=?", (name,)).fetchone()
    if r:
        return r["id"], False
    return create_project(ProjectIn(name=name))["project"]["id"], True


INV = dict(store=store, project_detail=project_detail, bt=bt, hooks=HOOKS, ensure_project=_ensure_project)
invoices.setup(app, INV)
import reimb                               # noqa: E402
reimb.setup(app, INV)
import updater                             # noqa: E402
updater.setup(app, dict(store=store))
import accounts as _accounts                 # noqa: E402
_accounts.setup(app, dict(store=store, ezb=ezb, ezb_transactions=ezb_transactions, invalidate=invalidate, view=None,
                          _project_of=_project_of, _sub_name=_sub_name, _scope_of=_scope_of, rid=rid))

sync_projects_json()
@app.middleware("http")
async def _no_cache_pages(request, call_next):
    """页面本身不缓存：改了功能后刷新就能看到最新版（图片/脚本库照常缓存）。"""
    resp = await call_next(request)
    p = request.url.path
    if p == "/" or p.endswith(".html"):
        resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return resp


app.mount("/", StaticFiles(directory=os.path.join(HERE, "static"), html=True), name="static")
