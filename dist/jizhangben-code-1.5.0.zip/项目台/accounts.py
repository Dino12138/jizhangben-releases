"""账户余额：记账本只允许在账户还没有账的时候录起始余额，所以余额校准放在项目台：
你填「现在这个账户里有多少钱」+ 填写时间 → 以后显示的余额 = 你填的数 + 这之后这个账户的每一笔（收入加、支出减、转账两边一加一减）。
之后补导入的旧账单（时间早于校准时间）不影响余额。记账本的账户页通过入口代理（ledger_proxy）显示同一个数。
"""
import json
import re
import time
from typing import Optional

from fastapi import HTTPException
from pydantic import BaseModel

LIAB = (3, 5)            # 记账本账户类型（ezb 编号）：3 信用卡 5 负债；4 是虚拟账户（零钱/支付宝）


def setup(app, h):
    store, ezb, ezb_transactions, invalidate = h["store"], h["ezb"], h["ezb_transactions"], h["invalidate"]
    from api_import import acc_name, acc_category, ACC_COLORS

    with store.db() as c:
        c.execute("create table if not exists acc_cal(name text primary key, balance real, as_of integer, note text default '', hidden integer default 0)")
        cols = [r[1] for r in c.execute("pragma table_info(acc_cal)")]
        if "currency" not in cols:                      # 外币账户（如美元卡）：币种 + 你自己填的汇率（不填用记账本的汇率）
            c.execute("alter table acc_cal add column currency text default ''")
            c.execute("alter table acc_cal add column rate real default 0")

    SYM = {"CNY": "¥", "USD": "$", "HKD": "HK$", "EUR": "€", "JPY": "JP¥", "GBP": "£", "SGD": "S$", "MOP": "MOP$", "TWD": "NT$", "KRW": "₩", "AUD": "A$", "CAD": "C$"}
    _rt = {"t": 0, "v": {}, "src": ""}

    def rates():
        """1 单位外币 = 多少人民币（用记账本自带的汇率源，6 小时取一次）"""
        if time.time() - _rt["t"] > 6 * 3600 or not _rt["v"]:
            try:
                d = ezb().call("GET", "/api/v1/exchange_rates/latest.json")
                base = {r["currency"]: float(r["rate"]) for r in d.get("exchangeRates", [])}
                base[d.get("baseCurrency", "EUR")] = 1.0
                cny = base.get("CNY")
                if cny:
                    _rt["v"] = {k: cny / v for k, v in base.items() if v}
                    _rt["src"] = (d.get("dataSource") or "") + " " + time.strftime("%Y-%m-%d", time.localtime(int(d.get("updateTime") or time.time())))
                _rt["t"] = time.time()
            except Exception:
                _rt["t"] = time.time() - 6 * 3600 + 600          # 取不到：10 分钟后再试
        return _rt["v"]

    def cals():
        with store.db() as c:
            return {r["name"]: dict(r) for r in c.execute("select * from acc_cal")}

    def kind_of(a):
        n, cat = a["name"], a.get("category", 1)
        if n == "备用金":
            return "备用金"
        if "亲属卡" in n:
            return "亲属卡"
        if cat in LIAB or "信用卡" in n or n == "花呗":
            return "负债"
        return "资产"

    fixed_cat = {"done": False}

    def fix_categories(api, accs):
        """旧版把零钱/支付宝/外币卡建成了 5（记账本里是「负债账户」），改成 4「虚拟账户」；只改程序自己按名字判断的那几类，每次启动查一次"""
        if fixed_cat["done"]:
            return accs
        fixed_cat["done"] = True
        changed = False
        for a in accs:
            want = acc_category(a["name"])
            if a.get("category") == 5 and want == 4 and not a.get("subAccounts") and not re.search(r"贷|欠|借|负债|花呗|白条|分期", a["name"]):
                try:
                    api.call("POST", "/api/v1/accounts/modify.json", dict(
                        id=a["id"], name=a["name"], category=4, type=a["type"], icon=a["icon"], iconType=a.get("iconType", 0),
                        color=a["color"], currency=a["currency"], comment=a.get("comment", ""), hidden=a.get("hidden", False), subAccounts=[]))
                    changed = True
                except Exception:
                    pass
        return api.call("GET", "/api/v1/accounts/list.json") if changed else accs

    def compute():
        """每个账户：记账本里的原始余额、校准后的余额、偏移（给记账本页面用）"""
        api = ezb()
        accs = fix_categories(api, api.call("GET", "/api/v1/accounts/list.json"))     # 记账本里收起的也拿：项目台「收起的账户」里能看到、能恢复
        txs = ezb_transactions()
        cal = cals()
        net_all, net_after, last = {}, {}, {}
        for t in txs:
            ty, sid, did = t["type"], str(t.get("sourceAccountId")), str(t.get("destinationAccountId") or 0)
            amt, damt, tm = t.get("sourceAmount", 0), t.get("destinationAmount", 0), t.get("time", 0)
            moves = []
            if ty == 1 or ty == 2:             # 余额调整 / 收入
                moves.append((sid, amt))
            elif ty == 3:
                moves.append((sid, -amt))
            elif ty == 4:
                moves += [(sid, -amt), (did, damt)]
            for aid, v in moves:
                net_all[aid] = net_all.get(aid, 0) + v
                last[aid] = max(last.get(aid, 0), tm)
                net_after.setdefault(aid, []).append((tm, v))
        out = []
        for a in accs:
            aid = str(a["id"])
            raw = net_all.get(aid, 0) / 100
            c = cal.get(a["name"])
            hid = bool(c["hidden"]) if c else bool(a.get("hidden"))
            if c and bool(a.get("hidden")) != hid:      # 项目台「收起/显示」同步到记账本：收起的账户在记账本选账户时也不出现（撤回后下次刷新自动改回）
                try:
                    api.call("POST", "/api/v1/accounts/hide.json", dict(id=a["id"], hidden=hid))
                except Exception:
                    pass
            c = c if c and c["as_of"] > 0 else None
            if c:
                after = sum(v for tm, v in net_after.get(aid, []) if tm > c["as_of"]) / 100
                bal = round(c["balance"] + after, 2)
            else:
                bal = round(raw, 2)
            k = kind_of(a)
            c0 = cal.get(a["name"]) or {}
            cur = (c0.get("currency") or a.get("currency") or "CNY").upper()
            rate = 1.0 if cur == "CNY" else (float(c0.get("rate") or 0) or rates().get(cur) or 0)
            out.append(dict(id=aid, name=a["name"], category=a.get("category"), kind=k, raw=round(raw, 2), balance=bal,
                            currency=cur, sym=SYM.get(cur, cur + " "), rate=round(rate, 4), my_rate=bool(c0.get("rate")), note=c0.get("note") or "",
                            cny=round(bal * rate, 2) if rate else None,
                            calibrated=bool(c), as_of=time.strftime("%Y-%m-%d %H:%M", time.localtime(c["as_of"])) if c else "",
                            cal_value=c["balance"] if c else None, hidden=hid,
                            offset_cents=int(round((bal - raw) * 100)), last=time.strftime("%Y-%m-%d", time.localtime(last[aid])) if aid in last else "",
                            n=len(net_after.get(aid, []))))
        order = {"资产": 0, "负债": 1, "备用金": 2, "亲属卡": 3}
        out.sort(key=lambda x: (order.get(x["kind"], 9), -abs(x["balance"])))
        vis = [x for x in out if not x["hidden"]]
        ok = [x for x in vis if x["calibrated"]]                                           # 只算录过余额的账户，没录的原始收支差没有意义
        avail = round(sum(x["cny"] or 0 for x in ok if x["kind"] == "资产"), 2)          # 外币按汇率折成人民币再加
        debt = round(sum(x["cny"] or 0 for x in ok if x["kind"] == "负债"), 2)           # 信用卡/花呗：负数 = 欠的钱
        funds = project_funds(txs)
        company = round(sum(f["net"] for f in funds if f["net"] > 0 and not f["unassigned"] and f["sure"]), 2)
        owed = round(sum(-f["net"] for f in funds if f["net"] < 0 and not f["unassigned"]), 2)
        unsure = round(sum(f["net"] for f in funds if f["net"] > 0 and not f["unassigned"] and not f["sure"]), 2)
        return dict(accounts=out, available=avail, debt=debt, net=round(avail + debt, 2),
                    funds=funds, company=company, owed=owed, unsure=unsure, mine=round(avail - company, 2), rate_src=_rt["src"],
                    cash=round(sum(x["balance"] for x in vis if x["kind"] == "备用金"), 2),
                    uncal=[x["name"] for x in vis if not x["calibrated"] and x["kind"] in ("资产", "负债") and (x["n"] or x["name"] != "现金")])

    def project_funds(txs, all_=False):
        """每个项目「在我手上的公司的钱」：
        · 有成本单备用金的项目：照成本单算——备用金总额（成本单备用金 + 账单里没对上成本单的备用金入款）− 备用金垫付的支出，
          和成本单抬头「备用金剩余」一样（杭马 = 3,409.72）。
        · 没有成本单的项目：照账单算——收到的备用金入款 / 客户回款 − 归到这个项目的工作支出。
        · 备用金在同事那里的（【同事经手】）不算；还没归项目的工作收支单独列，不计入合计。
        · 「项目报销」到账 = 公司把我垫的钱还回来，抵掉垫付；「项目款转出」= 客户款先到我这、我再转给公司，抵掉手上的钱；
          「分红转出」「项目分红」是我自己和别人之间的钱，和公司往来无关，不算。
        正数 = 手上还有公司的钱；负数 = 我垫付的，公司欠我。"""
        pj, sub, rid = h["_project_of"], h["_sub_name"], h["rid"]
        holders = {}                                   # 备用金在助理手里的项目：{项目名: 助理名字}
        with store.db() as c:
            for r in c.execute("select name, params from projects"):
                try:
                    hd = (json.loads(r["params"] or "{}").get("cash_holder") or "").strip()
                except Exception:
                    hd = ""
                if hd:
                    holders[r["name"]] = hd
        hold = {}                                      # 助理转给我的（从备用金里报销 / 给我的）、我自己付出去的
        led = {}
        for t in txs:
            if t["type"] not in (2, 3) or h["_scope_of"](t) != "工作":
                continue
            p = pj(t) or "(没归项目)"
            e = led.setdefault(p, dict(inflow=0.0, outflow=0.0, adv_tx=[], back=0.0, reimb=0.0, adv_in=0.0, client_in=0.0))
            a = t.get("_cny", t["sourceAmount"]) / 100
            hd = holders.get(p)
            if hd:
                x = hold.setdefault(p, dict(to_me=0.0, other_in=0.0, paid=0.0, misc=[], adv_bill=[]))
                who = (t.get("comment") or "")
                if t["type"] == 2 and sub(t) in ("项目备用金入款", "项目回款", "项目报销"):
                    if hd in who:
                        x["to_me"] += a                # 助理从她手上的备用金转给我的（报销我垫的钱）
                        if sub(t) == "项目回款":
                            x["misc"].append(str(t["id"]))   # 助理转的却标成了「项目回款」：多半应该是报销
                    elif sub(t) == "项目备用金入款":
                        x["adv_bill"].append((rid(t.get("comment")) or f"手动:{t['id']}", a))   # 公司直接打给我的备用金：在我手上
                    else:
                        x["other_in"] += a
                elif t["type"] == 3 and sub(t) not in ("分红转出", "分红提成", "项目款转出"):
                    x["paid"] += a                     # 我自己付出去的项目支出（等她报销）
            if t["type"] == 2:
                if sub(t) in ("项目备用金入款", "项目回款", "项目报销"):
                    e["inflow"] += a
                    e["adv_tx"].append((rid(t.get("comment")) or f"手动:{t['id']}", a))
                    e[{"项目备用金入款": "adv_in", "项目回款": "client_in", "项目报销": "reimb"}[sub(t)]] += a
            elif sub(t) in ("分红转出", "分红提成"):
                continue
            elif sub(t) == "项目款转出":
                e["back"] += a
            else:
                e["outflow"] += a
        sheet = {}
        with store.db() as c:
            for r in c.execute("select p.name, l.sec, l.qty*l.price amt, l.uid, l.vendor, l.pay from lines l join projects p on p.id=l.project_id "
                               "where coalesce(l.hold,0)=0 and (l.sec='备用金' or l.pay in ('备用金垫付','已付'))"):
                e = sheet.setdefault(r["name"], dict(adv=0.0, used=0.0, mine=0.0, uids=set(), colleague=False, adv_h=0.0, used_h=0.0))
                bill = (r["uid"] or "").startswith(("微信:", "支付宝:", "快记:", "手动:", "ezb:", "还款:"))   # 对得上我账单 = 经过我账户
                if r["sec"] != "备用金" and r["pay"] == "已付":
                    # 「已付」只算我自己垫的：对上我账单（微信/支付宝/手记）的行；没对上的多半是公司或别人直接付的
                    if (r["uid"] or "").startswith(("微信:", "支付宝:", "快记:", "手动:", "ezb:", "还款:")):
                        e["mine"] += r["amt"] or 0
                    continue
                if r["sec"] == "备用金":
                    if "【同事经手】" in (r["vendor"] or ""):
                        e["colleague"] = True
                        continue
                    e["adv"] += r["amt"] or 0
                    if r["uid"]:
                        e["uids"].add(r["uid"])
                    if not bill:
                        e["adv_h"] += r["amt"] or 0         # 没进我账户的备用金：在助理手上
                else:
                    e["used"] += r["amt"] or 0
                    if not bill:
                        e["used_h"] += r["amt"] or 0        # 不是从我账户付的「备用金垫付」：助理直接付的
        out = []
        for name in set(led) | set(sheet) | set(holders):
            sh, lg = sheet.get(name), led.get(name, dict(inflow=0.0, outflow=0.0, adv_tx=[], back=0.0, reimb=0.0, adv_in=0.0, client_in=0.0))
            if name in holders:
                # 备用金在助理手里：公司 → 助理（成本单备用金）；助理直接付（成本单「备用金垫付」）；助理转给我（报销我垫的）
                # 对得上我账单的备用金在我手上；对不上的在助理手上
                x = hold.get(name, dict(to_me=0.0, other_in=0.0, paid=0.0, misc=[], adv_bill=[]))
                adv_h = sh["adv_h"] if sh else 0.0
                used_h = sh["used_h"] if sh else 0.0
                my_adv = ((sh["adv"] - sh["adv_h"]) if sh else 0.0) + sum(a for u, a in x["adv_bill"] if not sh or u not in sh["uids"])
                net = my_adv + x["to_me"] + x["other_in"] - x["paid"] - lg["back"]     # 我和公司之间：正数 = 我手上还有公司的钱；负数 = 我垫的还没报完
                if not (adv_h or used_h or my_adv or x["to_me"] or x["paid"] or x["other_in"] or all_):
                    continue
                out.append(dict(how="助理", holder=holders[name], name=name, adv=round(adv_h, 2), used=round(used_h, 2), to_me=round(x["to_me"], 2),
                                my_adv=round(my_adv, 2), h_left=round(adv_h - used_h - x["to_me"], 2), paid=round(x["paid"], 2), other_in=round(x["other_in"], 2), misc=x["misc"],
                                left=0.0, extra=round(x["to_me"] + x["other_in"], 2), mine=round(x["paid"], 2), back=round(lg["back"], 2),
                                reimb=round(lg["reimb"], 2), adv_in=round(lg["adv_in"], 2), client_in=round(lg["client_in"], 2),
                                inflow=round(x["to_me"] + x["other_in"], 2), outflow=round(x["paid"], 2), net=round(net, 2),
                                sure=net <= 0.005 or x["paid"] >= x["to_me"] - 0.005, unassigned=False))   # 她报销的比我归到项目的支出还多：多半有支出没归项目
                continue
            if sh and sh["colleague"] and not sh["adv"]:
                continue                                       # 备用金在同事那里：钱没经过我
            if sh and sh["adv"] > 0:
                # 有成本单备用金：备用金剩余（成本单抬头那个数）＋ 账单里另外收到的备用金/报销 − 我自己垫付的「已付」
                extra = round(sum(a for u, a in lg["adv_tx"] if u not in sh["uids"]), 2)
                row = dict(adv=sh["adv"], used=sh["used"], left=round(sh["adv"] - sh["used"], 2), mine=sh["mine"], extra=extra, how="成本单")
            else:
                # 没有成本单备用金：照账单——收到的备用金入款/回款 − 归到这个项目的工作支出（都是从我账户出的）
                row = dict(adv=0.0, used=0.0, left=0.0, mine=lg["outflow"], extra=lg["inflow"], how="账单")
            net = row["left"] + row["extra"] - row["mine"] - lg["back"]
            # 算不算进合计：欠我的（负数）算；手上公司的钱（正数）只认成本单里记了备用金垫付的项目——
            # 按账单算出来「收到比支出多」，多半是支出还没归到这个项目，标「待核实」不计入
            sure = net < 0 or (row["how"] == "成本单" and row["used"] > 0)
            out.append(dict(row, sure=sure, name=name, back=round(lg["back"], 2), reimb=round(lg["reimb"], 2), adv_in=round(lg["adv_in"], 2), client_in=round(lg["client_in"], 2), inflow=round(row["adv"] + row["extra"], 2), outflow=round(row["used"] + row["mine"], 2),
                            mine=round(row["mine"], 2), net=round(net, 2), unassigned=name == "(没归项目)"))
        return sorted([x for x in out if all_ or abs(x["net"]) > 0.005], key=lambda x: (x["unassigned"], x["net"]))

    if h.get("hooks") is not None:
        h["hooks"]["project_funds"] = project_funds

    class AccDel(BaseModel):
        name: str
        move_to: str = ""

    @app.post("/api/accounts/delete")
    def acc_delete(b: AccDel):
        """删除账户：账户里有账要先挪到别的账户（move_to），账不会丢；记账本里一起删。"""
        api = ezb()
        accs = {a["name"]: a for a in api.call("GET", "/api/v1/accounts/list.json")}
        a = accs.get(b.name)
        if not a:
            raise HTTPException(404, "没有这个账户")
        ts = [t for t in ezb_transactions(force=True) if str(t.get("sourceAccountId")) == str(a["id"]) or str(t.get("destinationAccountId") or 0) == str(a["id"])]
        if ts:
            if not b.move_to or b.move_to == b.name or b.move_to not in accs:
                raise HTTPException(400, f"这个账户里有 {len(ts)} 笔账，先选一个账户把它们挪过去")
            to = str(accs[b.move_to]["id"])
            for t in ts:
                body = dict(id=str(t["id"]), type=t["type"], categoryId=str(t["categoryId"]), time=t["time"], utcOffset=t["utcOffset"],
                            sourceAccountId=to if str(t["sourceAccountId"]) == str(a["id"]) else str(t["sourceAccountId"]),
                            destinationAccountId=(to if str(t.get("destinationAccountId") or 0) == str(a["id"]) else str(t.get("destinationAccountId") or 0)),
                            sourceAmount=t["sourceAmount"], destinationAmount=t.get("destinationAmount", 0), hideAmount=t.get("hideAmount", False),
                            tagIds=[str(x) for x in (t.get("tagIds") or [])], pictureIds=[p_["pictureId"] for p_ in (t.get("pictures") or [])],
                            comment=t.get("comment") or "")
                h["ezb_modify_tx"](api, body)
        api.call("POST", "/api/v1/accounts/delete.json", dict(id=str(a["id"])))
        with store.db() as c:
            c.execute("delete from acc_cal where name=?", (b.name,))
        invalidate()
        return compute()

    @app.get("/api/accounts")
    def accounts():
        return compute()

    @app.get("/api/accounts/offsets")
    def offsets():
        """记账本页面显示余额用：账户 id → 要加上的分"""
        try:
            return {x["id"]: x["offset_cents"] for x in compute()["accounts"] if x["offset_cents"]}
        except Exception:
            return {}

    class AccSet(BaseModel):
        name: str
        balance: float
        note: str = ""
        hidden: Optional[bool] = None
        currency: str = ""
        rate: float = 0
        as_of: str = ""             # 这个余额是几点看的（不填 = 现在）：这之前的账不动余额，之后的账加减

    @app.post("/api/accounts/set")
    def set_balance(b: AccSet):
        """录入「现在这个账户里有多少钱」。没有这个账户就新建（例如新的银行卡）。信用卡/花呗填欠款时用负数。"""
        name = acc_name(b.name.strip())
        if not name:
            raise HTTPException(400, "账户名不能为空")
        api = ezb()
        cur = (b.currency or "").upper().strip()
        ts = int(time.time())
        if b.as_of:
            try:
                from datetime import datetime as _dt
                ts = int(_dt.strptime(b.as_of.replace("T", " ")[:16], "%Y-%m-%d %H:%M").timestamp())
            except ValueError:
                raise HTTPException(400, "时间格式不对")
        if name not in {a["name"] for a in api.call("GET", "/api/v1/accounts/list.json")}:
            api.call("POST", "/api/v1/accounts/add.json", dict(name=name, category=acc_category(name), type=1, icon="1", iconType=0,
                                                               color=ACC_COLORS.get(name, "888888"), currency=cur or "CNY", balance="0", comment=""))
            invalidate()
        with store.db() as c:
            c.execute("insert into acc_cal(name,balance,as_of,note,hidden,currency,rate) values(?,?,?,?,0,?,?) on conflict(name) do update set "
                      "balance=excluded.balance, as_of=excluded.as_of, note=excluded.note, currency=case when excluded.currency<>'' then excluded.currency else acc_cal.currency end, rate=excluded.rate",
                      (name, round(b.balance, 2), ts, b.note, cur, float(b.rate or 0)))
        return compute()

    @app.post("/api/accounts/hide")
    def hide(b: AccSet):
        with store.db() as c:
            if not c.execute("select 1 from acc_cal where name=?", (b.name,)).fetchone():
                c.execute("insert into acc_cal(name,balance,as_of,hidden) values(?,?,?,?)", (b.name, 0, 0, 0))
                # 没校准过：用记账本原始余额（as_of=0 → 所有账都算在后面，等于原始余额）
            old = c.execute("select hidden from acc_cal where name=?", (b.name,)).fetchone()
            c.execute("update acc_cal set hidden=? where name=?", (1 if b.hidden else 0, b.name))
        hk = h.get("hooks") or {}
        if hk.get("undo_begin"):                           # 误点「收起」可以撤回
            hk["undo_begin"](("收起账户「" if b.hidden else "显示账户「") + b.name + "」")
            hk["undo_sql"]("update acc_cal set hidden=? where name=?", ((old[0] if old else 0), b.name))
            hk["undo_commit"]()
        with store.db() as c:
            pass
        return compute()

    @app.delete("/api/accounts/cal")
    def uncal(name: str):
        with store.db() as c:
            c.execute("delete from acc_cal where name=?", (name,))
        return compute()

    @app.get("/api/accounts/rates")
    def acc_rates():
        return dict(rates={k: round(v, 4) for k, v in rates().items() if k in SYM}, src=_rt["src"], sym=SYM)

    @app.get("/api/accounts/names")
    def names():
        try:
            return [a["name"] for a in ezb().call("GET", "/api/v1/accounts/list.json") if not a.get("hidden")]
        except Exception:
            return []
