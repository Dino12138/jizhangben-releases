#!/usr/bin/env python3
"""成本单 ↔ 微信/支付宝账单 匹配器。
读「内部成本单.xlsx」的每一行(名称/金额/备注/日期)，到账单里找 金额一致 + 日期/对象吻合 的那一笔，
把「项目名 + 用途」写进 工具/项目标注.json（按交易单号），转换/导入时自动带进记账软件。

用法：
  python3 cost_match.py 成本单.xlsx 账单1.xlsx [账单2.csv ...] --project 项目名称 [--apply]
不加 --apply 只出报告(试跑)，确认没问题再加 --apply 写入。
"""
import argparse, json, os, re, sys
from datetime import datetime, date, timedelta
import openpyxl

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import bill_tool as bt  # noqa

ANN = bt.ANN
SECTIONS = ["备用金", "搭建部分", "第三方人员", "物料部分", "执行人员杂费"]


def num(x):
    return float(x) if isinstance(x, (int, float)) else None


def read_cost(path):
    ws = openpyxl.load_workbook(path, data_only=True)["成本汇总"]
    sec, items = None, []
    for r in ws.iter_rows(min_row=1, values_only=True):
        r = list(r) + [None] * 15
        a = str(r[0]).strip() if r[0] is not None else ""
        if a in SECTIONS and r[1] is None:
            sec = a
            continue
        if a == "总成本" or a.startswith("客户报价"):
            sec = None
        if sec == "备用金":
            if isinstance(r[1], int) and isinstance(r[2], datetime) and num(r[8]):
                items.append(dict(sec="备用金", no=r[1], name="备用金", spec=str(r[3] or "").strip(),
                                  remark="", amount=num(r[8]), date=r[2].date(), kind="收入"))
            continue
        if sec and isinstance(r[1], int) and num(r[8]) is not None and r[8] > 0:
            paid = num(r[11]) or 0
            if str(r[10] or "") == "无需付款" or paid <= 0:
                items.append(dict(sec=sec, no=r[1], name=str(r[2] or ""), spec=str(r[3] or ""),
                                  remark=str(r[9] or ""), amount=num(r[8]), date=None, kind="支出", skip="未付/无需付款"))
                continue
            cat = a or None
            if str(r[10] or "").strip() == "已付" and "微信" not in str(r[9] or ""):
                items.append(dict(sec=sec, no=r[1], name=str(r[2] or ""), spec="", remark="", amount=num(r[8]),
                                  date=None, kind="支出", skip="他人支付/非微信，账单里不会有"))
                continue
            items.append(dict(sec=sec, no=r[1], name=str(r[2] or ""), spec=str(r[3] or "") + " " + str(r[4] or ""),
                              remark=str(r[9] or ""), amount=num(r[8]), paid=paid, date=None, kind="支出", cat=cat))
    return items


def hint_dates(text, year=2026):
    out = set()
    for m in re.finditer(r"(\d{1,2})\s*[月./\-]\s*(\d{1,2})", text):
        mo, d = int(m.group(1)), int(m.group(2))
        if 1 <= mo <= 12 and 1 <= d <= 31:
            try:
                out.add(date(year, mo, d))
            except ValueError:
                pass
    return out


STOP = {"微信", "转账", "备注", "费用", "项目", "报销", "有发票", "无发票", "备用金垫付", "垫付", "已付", "结算单", "美团", "配送", "待确认", "需补开", "北京", "上海", "付款"}


def hint_tokens(text):
    toks = set(re.findall(r"[一-鿿]{2,6}|[A-Za-z0-9]{3,}", text))
    return {t for t in toks if t not in STOP and not t.isdigit()}


def load_bills(files, start, end):
    rows = []
    for f in files:
        for d in bt.parse_bill(f):
            if d["kind"] not in ("支出", "收入"):
                continue
            if any(k in d["status"] for k in ("关闭", "失败", "全额退款", "对方已退还")):
                continue
            day = datetime.strptime(d["time"][:10], "%Y-%m-%d").date()
            if start <= day <= end:
                d["day"] = day
                d["uid"] = f"{d['src']}:{d['id']}" if d["id"] else f"{d['src']}:{d['time']}:{d['amount']}:{d['cp']}"
                rows.append(d)
    return rows


def match(items, bills, window):
    used, results = set(), []
    for it in sorted(items, key=lambda x: -x["amount"]):
        if it.get("skip"):
            results.append((it, None, [], it["skip"]))
            continue
        want_dates = hint_dates(it["remark"] + " " + it["spec"] + " " + it["name"]) if it["kind"] == "支出" else {it["date"]}
        toks = hint_tokens(it["spec"] if it["sec"] == "备用金" else it["name"] + " " + it["spec"] + " " + it["remark"])
        cands = []
        for b in bills:
            if b["uid"] in used or b["kind"] != it["kind"]:
                continue
            if abs(b["amount"] - it["amount"]) > 0.005:
                # 备用金：允许微信里多笔拼不上就算了；其余必须金额一致
                continue
            score = 0
            if want_dates:
                near = min(abs((b["day"] - d).days) for d in want_dates)
                score += 4 if near == 0 else (2 if near <= 1 else 0)
            if window[0] <= b["day"] <= window[1]:
                score += 1
            blob = f"{b['cp']} {b['item']} {b['note']}"
            hits = [t for t in toks if t in blob]
            score += 2 * len(hits)
            cands.append((score, b, hits))
        cands.sort(key=lambda x: -x[0])
        if not cands:
            results.append((it, None, [], "账单里没有同金额的笔"))
            continue
        top = cands[0]
        tied = [c for c in cands if c[0] == top[0]]
        # 判定：有日期吻合或对象吻合 → 确认；否则只算候选
        solid = top[0] >= 3 or bool(top[2])
        twins = sum(1 for x in items if not x.get("skip") and x["kind"] == it["kind"] and abs(x["amount"] - it["amount"]) < 0.005
                    and hint_dates(x["remark"] + " " + x["spec"] + " " + x["name"]) == hint_dates(it["remark"] + " " + it["spec"] + " " + it["name"]))
        if len(tied) > 1 and not top[2] and top[0] >= 3 and twins <= len(tied):
            # 同金额同日期的几笔成本行 ↔ 同样多的账单：谁对谁不影响结果，按时间顺序配
            pick = sorted(tied, key=lambda c: c[1]["time"])[0]
            used.add(pick[1]["uid"])
            results.append((it, pick[1], [], "确认"))
        elif len(tied) > 1 and not top[2]:
            results.append((it, None, cands[:3], "同金额多笔，无法唯一确定"))
        elif solid:
            used.add(top[1]["uid"])
            results.append((it, top[1], cands[1:3], "确认"))
        else:
            results.append((it, None, cands[:3], "只有金额相同，日期/对象对不上"))
    return results


def sub_of(it):
    """成本单板块 → 记账软件里的『工作·子类』"""
    n = it["name"] + it["spec"]
    if it["kind"] == "收入":
        return "项目回款"
    if any(k in n for k in ("货拉拉", "仓储", "快递", "物流", "寄送", "木架", "货车")):
        return "快递物流"
    if it["sec"] == "搭建部分":
        return "物料搭建"
    if it["sec"] == "第三方人员":
        return "供应商执行"
    if it["sec"] == "物料部分":
        return "物料搭建"
    if "打车" in n or "交通" in n:
        return "交通"
    if "酒店" in n or "住宿" in n:
        return "差旅住宿"
    return "招待"


def purpose_of(it):
    base = it["name"].strip()
    if it["sec"] == "备用金":
        return "备用金"
    spec = re.sub(r"\s+", " ", it["spec"]).strip()
    spec = "" if spec in ("", "/", base) else spec
    s = f"{it['sec'].replace('部分', '')}-{base}"
    return (s + (f"（{spec[:20]}）" if spec else ""))[:40]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cost")
    ap.add_argument("bills", nargs="+")
    ap.add_argument("--project", required=True)
    ap.add_argument("--start", default="2026-04-01")
    ap.add_argument("--end", default="2026-06-30")
    ap.add_argument("--apply", action="store_true")
    a = ap.parse_args()
    start = datetime.strptime(a.start, "%Y-%m-%d").date()
    end = datetime.strptime(a.end, "%Y-%m-%d").date()
    items = read_cost(a.cost)
    bills = load_bills(a.bills, start, end)
    print(f"成本单 {len(items)} 行，账单窗口内 {len(bills)} 笔")
    res = match(items, bills, (start, end))
    ok = [r for r in res if r[3] == "确认"]
    bad = [r for r in res if r[3] != "确认"]
    ann = json.load(open(ANN, encoding="utf-8")) if os.path.exists(ANN) else {}
    print(f"\n=== 匹配成功 {len(ok)} 条 ===")
    for it, b, _, _ in sorted(ok, key=lambda r: r[1]["time"]):
        print(f"{b['time'][:16]} {b['src']} {b['kind']} ¥{b['amount']:<9} {b['cp'][:14]:<14}| 成本单:{purpose_of(it)}")
        if a.apply:
            ann[b["uid"]] = dict(project=a.project, purpose=purpose_of(it), scope="工作",
                                 sub=sub_of(it), source="成本单:" + os.path.basename(a.cost))
    print(f"\n=== 没匹配上 {len(bad)} 条（需要你看）===")
    for it, b, cands, why in bad:
        print(f"- {it['sec']}#{it['no']} {it['name'][:16]} ¥{it['amount']} → {why}")
        for sc, cb, hits in cands[:2]:
            print(f"     候选 {cb['time'][:16]} ¥{cb['amount']} {cb['cp'][:12]} {cb['item'][:20]} (分{sc})")
    tot_ok = sum(r[0]["amount"] for r in ok if r[0]["kind"] == "支出")
    tot_all = sum(r[0]["amount"] for r in res if r[0]["kind"] == "支出" and not r[0].get("skip"))
    print(f"\n已匹配支出 ¥{tot_ok:,.2f} / 成本单已付支出合计 ¥{tot_all:,.2f}")
    if a.apply:
        json.dump(ann, open(ANN, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        print(f"已写入 {len(ok)} 条 → {ANN}")


if __name__ == "__main__":
    main()
