"""账单明细：在项目台里直接改记账本（单笔改 / 批量改 / 删除 / 快速记账）。"""
import re, uuid
from datetime import datetime, date, timedelta, timezone
from typing import List, Optional
from fastapi import HTTPException
from pydantic import BaseModel

TZ = timezone(timedelta(hours=8))
PRE_RE = re.compile(r"^【([^｜】]*)(?:｜([^】]*))?】")


def setup(app, h):
    """h: app.py 里的工具函数集合（避免循环 import）。"""
    ezb, ezb_transactions, invalidate = h["ezb"], h["ezb_transactions"], h["invalidate"]
    _scope_of, _project_of, _sub_name, _month_of = h["_scope_of"], h["_project_of"], h["_sub_name"], h["_month_of"]
    push_rows, rid, bt, store, sync_projects_json = h["push_rows"], h["rid"], h["bt"], h["store"], h["sync_projects_json"]

    def view(t):
        c = t.get("comment") or ""
        proj = _project_of(t)
        purpose = ""
        m = PRE_RE.match(c)
        if m:
            if m.group(2) is not None:
                purpose = m.group(2).strip()
            elif m.group(1).strip() != proj:
                purpose = m.group(1).strip()
        core = re.sub(r"〔ID:.*?〕", "", PRE_RE.sub("", c, count=1)).strip()
        dt = datetime.fromtimestamp(t["time"], TZ)
        return dict(id=str(t["id"]), uid=rid(c) or "", date=dt.strftime("%Y-%m-%d"), hm=dt.strftime("%H:%M"),
                    type="inc" if t["type"] == 2 else "exp", amount=round(t["sourceAmount"] / 100, 2),
                    scope=_scope_of(t), sub=_sub_name(t), project=proj, purpose=purpose, who=core,
                    account=(t.get("sourceAccount") or {}).get("name", ""))

    SEP = " · "

    def norm_project(name):
        """「项目 · 分期名」→「项目」（分期名只是同一项目不同月份的叫法）。"""
        name = (name or "").strip()
        if SEP in name:
            head = name.split(SEP, 1)[0].strip()
            with store.db() as c:
                if c.execute("select 1 from projects where name=?", (head,)).fetchone():
                    return head
        return name

    h["hooks"]["norm_project"] = norm_project

    def ensure_project(name):
        if not name:
            return
        with store.db() as c:
            if not c.execute("select 1 from projects where name=?", (name,)).fetchone():
                import json
                c.execute("insert into projects(name,params) values(?,?)",
                          (name, json.dumps(store.MODE_DEFAULTS[store.detect_mode(dict(name=name))])))
        sync_projects_json()

    def account_id(api, name):
        for a in api.call("GET", "/api/v1/accounts/list.json"):
            if a["name"] == name:
                return str(a["id"])
        return str(api.call("POST", "/api/v1/accounts/add.json", dict(
            name=name, category=1, type=1, icon="1", iconType=0, color="888888", currency="CNY", balance="0", comment=""))["id"])

    def modify(api, t, **kw):
        body = dict(id=str(t["id"]), type=t["type"], categoryId=str(t["categoryId"]), time=t["time"], utcOffset=t["utcOffset"],
                    sourceAccountId=str(t["sourceAccountId"]), destinationAccountId=str(t.get("destinationAccountId") or 0),
                    sourceAmount=t["sourceAmount"], destinationAmount=t.get("destinationAmount", 0), hideAmount=t.get("hideAmount", False),
                    tagIds=[str(x) for x in (t.get("tagIds") or [])], pictureIds=[p["pictureId"] for p in (t.get("pictures") or [])],
                    comment=t.get("comment") or "")
        body.update(kw)
        api.call("POST", "/api/v1/transactions/modify.json", body)

    def default_sub(old_scope, old_sub, scope, typ):
        if scope == old_scope:
            return old_sub
        if scope == "工作":
            return "项目回款" if typ == "inc" else "项目支出"
        if scope == "生活":
            return "红包转账" if typ == "inc" else "其他"
        return "收入" if typ == "inc" else "其他"

    # ---------------- 子类防填错：子类只能是列表里的；填成项目名的挪到「项目」，乱写的挪到「用途」
    INC_SUBS = {"工作": ["项目回款", "其他工作收入"], "生活": ["工资薪酬", "红包转账", "还款退款", "理财利息", "其他收入"]}

    def allowed_subs(scope, typ):
        if typ == "inc":
            return INC_SUBS.get(scope, [])
        return h["all_subs"](scope) if scope in ("工作", "生活") else []

    def match_project(text):
        t = (text or "").strip().lower()
        if len(t) < 2:
            return ""
        with store.db() as c:
            names = [r["name"] for r in c.execute("select name from projects")]
        for n in sorted(names, key=len, reverse=True):          # 整个项目名
            if n.lower() == t or (len(n) >= 2 and n.lower() in t):
                return n
        for n in names:                                          # 项目名里的关键词（如「某品牌-ABC」里的 ABC）
            for tok in re.split(r"[-·_\s/｜|（）()]+", n):
                if len(tok) >= 3 and not tok.isdigit() and tok.lower() in t:
                    return n
        return ""

    def fix_sub(v, user=True, any_type=False):
        """v: 含 scope/type/sub/project/purpose 的 dict，原地修正。返回说明（没改返回空串）。
        user=False：子类不是用户填的（比如只改了收支方向），不合法就换成默认，不挪到用途。
        any_type=True：一个对象下收支都有时（按对象改归类），收入/支出子类都算合法。"""
        sc, typ, sub = v.get("scope"), v.get("type", "exp"), (v.get("sub") or "").strip()
        if sc not in ("工作", "生活"):
            return ""
        ok = allowed_subs(sc, typ) + (allowed_subs(sc, "inc" if typ == "exp" else "exp") if any_type else [])
        if any_type and not sub:
            return ""
        if sub in ok:
            return ""
        dflt = ("项目回款" if typ == "inc" else "项目支出") if sc == "工作" else ("其他收入" if typ == "inc" else "其他")
        if not sub or not user:
            v["sub"] = "" if any_type else dflt
            return ""
        pj = match_project(sub)
        if pj:
            v["scope"], v["project"] = "工作", v.get("project") or pj
            v["sub"] = "" if any_type else ("项目回款" if typ == "inc" else "项目支出")
            if not (v.get("purpose") or "").strip():
                v["purpose"] = sub[:40]
            return f"「{sub}」像是项目，已放到项目「{v['project']}」，子类改为{v['sub'] or '默认'}"
        v["sub"] = "" if any_type else dflt
        dflt = v["sub"] or "默认"
        if not (v.get("purpose") or "").strip():
            v["purpose"] = sub[:40]
            return f"子类只能从列表里选，「{sub}」已放到用途，子类改为{dflt}"
        return f"子类只能从列表里选，「{sub}」不在列表里，已改为{dflt}"

    h["hooks"]["fix_sub"] = fix_sub

    def build_row(v, uid):
        pre = (f"【{v['project']}｜{v['purpose']}】" if v["project"] and v["purpose"]
               else f"【{v['project']}】" if v["project"] else f"【｜{v['purpose']}】" if v["purpose"] else "")
        suf = f"〔ID:{uid}〕"
        desc = pre + v["who"][:max(0, 250 - len(pre) - len(suf))] + suf
        tags = v["scope"] + (f";项目:{v['project']}" if v["project"] else "")
        return {"Time": f"{v['date']} {v.get('hm', '12:00')}:00", "Type": "Income" if v["type"] == "inc" else "Expense",
                "Category": v["scope"], "Sub Category": f"{v['scope']}·{v['sub'] or '其他'}", "Account": v["account"] or "微信",
                "Amount": f"{float(v['amount']):.2f}", "Tags": tags, "Description": desc}

    notes = []

    def apply(changes):
        """changes: list of (t, dict)。返回改了几笔。"""
        api = ezb()
        rows, after = [], []
        notes.clear()
        for t, ch in changes:
            v = view(t)
            uid = v["uid"]
            if not uid:                                 # 记账本里手动记的：先补编号
                uid = f"手动:{t['id']}"
                modify(api, t, comment=((t.get("comment") or "").strip() + f"〔ID:{uid}〕")[:255])
            new = dict(v)
            for k in ("scope", "sub", "project", "purpose", "who", "amount", "date", "account", "type"):
                if ch.get(k) is not None:
                    new[k] = ch[k].strip() if isinstance(ch[k], str) else ch[k]
            if new["project"] == "(无项目)":
                new["project"] = ""
            new["project"] = norm_project(new["project"])
            if ch.get("sub") is None and (new["scope"] != v["scope"] or new["type"] != v["type"]):
                new["sub"] = default_sub(v["scope"], v["sub"], new["scope"], new["type"])
            if new["project"] and ch.get("scope") is None and new["scope"] != "工作" and ch.get("project"):
                new["scope"] = "工作"                     # 选了项目却没说工作/生活：默认工作
                if ch.get("sub") is None:
                    new["sub"] = default_sub(v["scope"], v["sub"], "工作", new["type"])
            if ch.get("sub") is not None or ch.get("scope") is not None or ch.get("type") is not None:
                note = fix_sub(new, user=ch.get("sub") is not None)
                if note:
                    notes.append(note)
            if new["scope"] != "工作":                  # 只有工作才有项目；生活/待确认清掉项目，用途保留
                new["project"] = ""
            ensure_project(new["project"])
            if new["type"] != v["type"]:                # 收支方向变了：删掉重记（同一个编号，不会重复）
                api.call("POST", "/api/v1/transactions/delete.json", {"id": str(t["id"])})
                invalidate()
            rows.append(build_row(new, uid))
            if new["type"] == v["type"] and (new["date"] != v["date"] or new["account"] != v["account"]):
                after.append((str(t["id"]), new))
        if rows:
            push_rows(api, rows, log=lambda *_: None)
        invalidate()
        if after:
            byid = {str(t["id"]): t for t in ezb_transactions(force=True)}
            for i, new in after:
                t = byid.get(i)
                if not t:
                    continue
                kw = {}
                v = view(t)
                if new["date"] != v["date"]:
                    hm = v["hm"]
                    kw["time"] = int(datetime.strptime(f"{new['date']} {hm}", "%Y-%m-%d %H:%M").replace(tzinfo=TZ).timestamp())
                if new["account"] != v["account"]:
                    kw["sourceAccountId"] = account_id(api, new["account"])
                if kw:
                    modify(api, t, **kw)
            invalidate()
        return len(rows)

    def find(ids):
        ids = set(str(i) for i in ids)
        ts = [t for t in ezb_transactions(force=True) if str(t["id"]) in ids]
        if not ts:
            raise HTTPException(404, "没找到这些账单（可能已被删除），请刷新")
        return ts

    # ---------------- 最近删除（可恢复）
    with store.db() as c:
        c.execute("create table if not exists trash(id integer primary key autoincrement, deleted text default (datetime('now','localtime')), view text, row text)")

    def to_trash(ts):
        import json as _j
        with store.db() as c:
            for t in ts:
                v = view(t)
                uid = v["uid"] or f"手动:{t['id']}"
                c.execute("insert into trash(view,row) values(?,?)", (_j.dumps(v, ensure_ascii=False), _j.dumps(build_row(v, uid), ensure_ascii=False)))
            c.execute("delete from trash where deleted < datetime('now','localtime','-90 days')")

    def delete_txs(ts):
        to_trash(ts)
        api = ezb()
        for t in ts:
            api.call("POST", "/api/v1/transactions/delete.json", {"id": str(t["id"])})
        invalidate()

    @app.get("/api/tx/trash")
    def list_trash():
        import json as _j
        with store.db() as c:
            rows = [dict(tid=r["id"], deleted=r["deleted"], **_j.loads(r["view"])) for r in c.execute("select * from trash order by id desc limit 300")]
        return dict(rows=rows)

    class TrashIds(BaseModel):
        ids: List[int]

    @app.post("/api/tx/trash/restore")
    def restore_trash(b: TrashIds):
        import json as _j
        with store.db() as c:
            rs = [r for r in c.execute("select * from trash where id in (%s)" % ",".join("?" * len(b.ids)), b.ids)] if b.ids else []
        if not rs:
            raise HTTPException(404, "没找到要恢复的账")
        push_rows(ezb(), [_j.loads(r["row"]) for r in rs], log=lambda *_: None)
        with store.db() as c:
            c.execute("delete from trash where id in (%s)" % ",".join("?" * len(b.ids)), b.ids)
        invalidate()
        return dict(n=len(rs))

    # ---------------- 可能重复：手动/快速记的账 和 导入的微信/支付宝账单 金额相同、日期相差不超过 1 天
    @app.get("/api/tx/dupes")
    def dupes():
        cfg = store.load_config()
        ign = set(cfg.get("dupe_ignore", []))
        vs = [view(t) for t in ezb_transactions() if t["type"] in (2, 3)]
        manual = [v for v in vs if not v["uid"] or v["uid"].startswith(("快记:", "手动:"))]
        imported = {}
        for v in vs:
            if v["uid"].startswith(("微信:", "支付宝:")):
                imported.setdefault((v["type"], round(v["amount"] * 100)), []).append(v)
        pairs = []
        for m in manual:
            if m["id"] in ign:
                continue
            md = datetime.strptime(m["date"], "%Y-%m-%d").date()
            for v in imported.get((m["type"], round(m["amount"] * 100)), []):
                if abs((datetime.strptime(v["date"], "%Y-%m-%d").date() - md).days) <= 1:
                    pairs.append(dict(manual=m, imported=v))
                    break
        return dict(n=len(pairs), pairs=pairs)

    class Ign(BaseModel):
        id: str

    @app.post("/api/tx/dupes/ignore")
    def dupes_ignore(b: Ign):
        cfg = store.load_config()
        cfg["dupe_ignore"] = sorted(set(cfg.get("dupe_ignore", [])) | {b.id})
        store.save_config(cfg)
        return dict(ok=True)

    # ---------------- 手记的账 ↔ 导入的账单：自动合并（不重复记）
    def merge_pair(m, v):
        """m=手记的，v=导入的。保留导入那笔（有微信/支付宝编号），把手记时填的 工作/生活、子类、项目、用途 搬过去；
        项目台里引用手记那笔的地方（成本行、分红到账、发票）改指向导入那笔；手记那笔进「最近删除」。"""
        tm, tv = find([m["id"]])[0], find([v["id"]])[0]
        ch = {}
        if m["scope"] in ("工作", "生活"):
            ch.update(scope=m["scope"], sub=m["sub"], project=m["project"] or "(无项目)", purpose=m["purpose"] or v["purpose"])
            if not ch["purpose"] and m["who"] and m["who"] not in (v["who"] or ""):
                ch["purpose"] = m["who"][:30]
        if ch:
            apply([(tv, ch)])
        mu = m["uid"] or f"手动:{m['id']}"
        with store.db() as c:
            for tb, col in (("lines", "uid"), ("divs", "uid"), ("inv", "tx_uid")):
                c.execute(f"update {tb} set {col}=? where {col}=?", (v["uid"], mu))
        delete_txs([tm])

    def auto_merge():
        """只合并有把握的：同收/支、金额一样、日期差 ≤1 天、手记的账户和账单来源一致（微信对微信、支付宝对支付宝），且一对一。"""
        d = dupes()
        cnt = {}
        for p in d["pairs"]:
            cnt[p["imported"]["id"]] = cnt.get(p["imported"]["id"], 0) + 1
        n = 0
        for p in d["pairs"]:
            m, v = p["manual"], p["imported"]
            src = v["uid"].split(":", 1)[0]
            if cnt[v["id"]] != 1 or (m["account"] or "微信") != src:
                continue
            try:
                merge_pair(m, v)
                n += 1
            except Exception as e:
                print("自动合并失败：", e)
        return n

    h["hooks"]["auto_merge"] = auto_merge

    class Pair(BaseModel):
        manual: str
        imported: str

    @app.post("/api/tx/dupes/merge")
    def dupes_merge(b: Pair):
        vs = {str(t["id"]): view(t) for t in find([b.manual, b.imported])}
        if b.manual not in vs or b.imported not in vs:
            raise HTTPException(404, "没找到这两笔账，请刷新")
        merge_pair(vs[b.manual], vs[b.imported])
        return dict(ok=True)

    # ---------------- 导出 Excel（按当前筛选）
    @app.get("/api/tx/export")
    def export_tx(month: str = "", scope: str = "", q: str = "", project: str = "", type: str = "", sub: str = "", batch: int = 0):
        import openpyxl, os, tempfile
        from openpyxl.styles import Font, PatternFill, Alignment
        from fastapi.responses import FileResponse
        d = list_tx(month=month, scope=scope, q=q, project=project, type=type, sub=sub, batch=batch, limit=100000)
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "账单明细"
        head = ["日期", "时间", "收/支", "金额", "工作/生活", "子类", "项目", "用途", "对象 / 备注", "账户"]
        ws.append(head)
        for r in sorted(d["rows"], key=lambda v: (v["date"], v["hm"])):
            ws.append([r["date"], r["hm"], "收入" if r["type"] == "inc" else "支出", r["amount"], r["scope"], r["sub"], r["project"], r["purpose"], r["who"], r["account"]])
        bold, fill = Font(bold=True), PatternFill("solid", fgColor="F3E6D3")
        for c in ws[1]:
            c.font, c.fill = bold, fill
        for col, w in zip("ABCDEFGHIJ", (12, 7, 7, 12, 10, 12, 26, 16, 60, 9)):
            ws.column_dimensions[col].width = w
        for row in ws.iter_rows(min_row=2, min_col=4, max_col=4):
            for c in row:
                c.number_format = "#,##0.00"
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = f"A1:J{ws.max_row}"
        s2 = wb.create_sheet("汇总")
        def block(title, keyf):
            agg = {}
            for r in d["rows"]:
                if r["type"] != "exp":
                    continue
                k = keyf(r)
                agg[k] = agg.get(k, 0) + r["amount"]
            s2.append([title, "支出合计"])
            for c in s2[s2.max_row]:
                c.font, c.fill = bold, fill
            for k, v in sorted(agg.items(), key=lambda x: -x[1]):
                s2.append([k, round(v, 2)])
            s2.append([])
        s2.append(["筛选条件", " ".join(f"{k}={v}" for k, v in dict(month=month, scope=scope, type=type, project=project, sub=sub, q=q).items() if v) or "全部"])
        s2.append(["支出合计", d["tot"]["exp"]]); s2.append(["收入合计", d["tot"]["inc"]]); s2.append([])
        block("工作/生活", lambda r: r["scope"])
        block("工作/生活 · 子类", lambda r: f"{r['scope']} · {r['sub']}")
        block("项目", lambda r: r["project"] or "(没归项目)")
        s2.column_dimensions["A"].width = 34
        s2.column_dimensions["B"].width = 14
        for row in s2.iter_rows(min_col=2, max_col=2):
            for c in row:
                if isinstance(c.value, (int, float)):
                    c.number_format = "#,##0.00"
        name = "账单明细" + (f"-{month}" if month else "") + (f"-{scope}" if scope else "") + (f"-{project}" if project and project != "(无项目)" else "") + f"-{datetime.now():%Y%m%d%H%M}.xlsx"
        p = os.path.join(tempfile.mkdtemp(), name)
        wb.save(p)
        return FileResponse(p, filename=name, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

    # ---------------- 接口
    # ---------------- 账单 → 成本单：这个项目在记账本里有、成本单里还没有的支出
    SEC_OF_SUB = {"物料搭建": ("物料部分", "物料采购"), "快递物流": ("物料部分", "物流"), "打印复印": ("物料部分", "快印"),
                  "礼品采购": ("物料部分", "物料采购"), "办公用品": ("物料部分", "物料采购"), "场地费": ("搭建部分", ""),
                  "第三方人员": ("第三方人员", ""), "设计费": ("第三方人员", "设计费"), "人员劳务": ("第三方人员", ""),
                  "供应商执行": ("第三方人员", ""), "交通": ("执行人员杂费", "交通费"), "差旅住宿": ("执行人员杂费", "住宿"),
                  "餐补": ("执行人员杂费", "餐补"), "招待": ("执行人员杂费", "业务招待")}

    def _uid_of(v):
        return v["uid"] or f"手动:{v['id']}"

    def _project_name(pid):
        with store.db() as c:
            p = c.execute("select name from projects where id=?", (pid,)).fetchone()
        if not p:
            raise HTTPException(404, "项目不存在")
        return p["name"]

    _sync_state = {"key": None, "t": 0.0}

    def cost_sync(force=False):
        """账单明细 → 成本单自动同步（只管 auto=1 的行，导入/手填的成本行一律不动）：
        账单归到某项目的支出 → 自动加一行；账单金额变 → 跟着变；改到别的项目 → 行跟着搬；
        移出项目/删掉 → 撤掉这一行（这一行上过发票图的保留，转成普通行）。"""
        import time
        txs = ezb_transactions()
        key = id(txs)
        if not force and key == _sync_state["key"] and time.time() - _sync_state["t"] < 3:
            return
        _sync_state.update(key=key, t=time.time())
        with store.db() as c:
            c.execute("create table if not exists cost_ignore(uid text primary key)")
            pid_of = {r["name"]: r["id"] for r in c.execute("select id,name from projects")}
            ignored = {r["uid"] for r in c.execute("select uid from cost_ignore")}
            lines = {}
            for r in c.execute("select id,project_id,uid,price,qty,auto,date from lines where uid<>''"):
                lines.setdefault(r["uid"], dict(r))
            nfiles = {r[0]: r[1] for r in c.execute("select line_id,count(*) from files group by line_id")}
            seen = set()
            for t in txs:
                if t["type"] != 3:
                    continue
                proj = _project_of(t)
                pid = pid_of.get(proj) if proj else None
                if not pid:
                    continue
                v = view(t)
                uid = _uid_of(v)
                seen.add(uid)
                l = lines.get(uid)
                if l:
                    if l["auto"]:
                        if l["project_id"] != pid:
                            c.execute("update lines set project_id=? where id=?", (pid, l["id"]))
                        if abs((l["price"] or 0) * (l["qty"] or 1) - v["amount"]) > 0.001:
                            c.execute("update lines set qty=1, price=? where id=?", (v["amount"], l["id"]))
                        if (l.get("date") or "") != v["date"]:          # 成本行日期跟账单走（按月份区分要用）
                            c.execute("update lines set date=? where id=?", (v["date"], l["id"]))
                    continue
                if uid in ignored:
                    continue
                pay = "备用金垫付" if v["account"] == "备用金" else "已付"
                # 之前记成「待支付」的成本行（同项目、同金额、还没对上账单）：这笔钱付出去了 → 直接对上那一行，不另加
                pend = c.execute("select id,date from lines where project_id=? and auto=0 and uid='' and pay in ('未付','预付') "
                                 "and abs(qty*price-?)<0.011 and sec<>'备用金' order by date, id limit 1", (pid, v["amount"])).fetchone()
                if pend:
                    c.execute("update lines set uid=?, pay=?, date=case when date='' then ? else date end where id=?",
                              (uid, pay, v["date"], pend["id"]))
                    lines[uid] = dict(id=pend["id"], project_id=pid, uid=uid, price=v["amount"], qty=1, auto=0)
                    continue
                sec, cat = SEC_OF_SUB.get(v["sub"], ("执行人员杂费", ""))
                seq = c.execute("select coalesce(max(seq),0)+1 from lines where project_id=? and sec=?", (pid, sec)).fetchone()[0]
                vendor = f"{v['account']}{v['date'][5:]} {v['hm']} {v['who']}"[:200]
                c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,uid,date,who,auto) "
                          "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)",
                          (pid, sec, cat, seq, v["purpose"] or v["sub"] or "项目支出", "", "", 1, "项", v["amount"], vendor,
                           pay, uid, v["date"], ""))
                lines[uid] = dict(id=0, project_id=pid, uid=uid, price=v["amount"], qty=1, auto=1)
            for uid, l in lines.items():
                if l["auto"] and l["id"] and uid not in seen:
                    if nfiles.get(l["id"]):
                        c.execute("update lines set auto=0 where id=?", (l["id"],))
                    else:
                        c.execute("delete from lines where id=?", (l["id"],))

    def cost_ignore(uid):
        with store.db() as c:
            c.execute("create table if not exists cost_ignore(uid text primary key)")
            c.execute("insert or ignore into cost_ignore(uid) values(?)", (uid,))

    def _line_uids():
        """已经记成「备用金」或「分红到账」的账单：不算项目收入。"""
        with store.db() as c:
            return {r["uid"] for r in c.execute("select uid from lines where uid<>'' union select uid from divs where uid<>''")}

    def project_income(name):
        used = _line_uids()                 # 记成「备用金」的收入不算项目收入
        out = [v for v in (view(t) for t in ezb_transactions() if t["type"] == 2 and _project_of(t) == name) if _uid_of(v) not in used]
        out.sort(key=lambda v: (v["date"], v["hm"]))
        return out

    def tx_dates():
        out = {}
        for t in ezb_transactions():
            u = rid(t.get("comment")) or f"手动:{t['id']}"
            out[u] = datetime.fromtimestamp(t["time"], TZ).strftime("%Y-%m-%d")
        return out

    h["hooks"]["tx_dates"] = tx_dates
    h["hooks"]["project_income"] = project_income
    h["hooks"]["cost_sync"] = cost_sync
    h["hooks"]["cost_ignore"] = cost_ignore

    @app.get("/api/projects/{pid}/income-candidates")
    def income_candidates(pid: int, q: str = "", all: int = 0):
        """还没归到项目的收入（微信/支付宝账单里的），供「从账单里选」。all=1 时也列出已归到别的项目的。"""
        _project_name(pid)
        used = _line_uids()
        out = []
        for t in ezb_transactions():
            if t["type"] != 2:
                continue
            v = view(t)
            if _uid_of(v) in used or (v["project"] and not all):
                continue
            if q and q.lower() not in (v["who"] + " " + v["purpose"] + " " + str(v["amount"]) + " " + v["date"]).lower():
                continue
            out.append(v)
        out.sort(key=lambda v: (v["date"], v["hm"]), reverse=True)
        return dict(rows=out[:500], n=len(out))

    class PickIn(BaseModel):
        ids: List[str]
        mode: str = "income"          # income=归为项目收入 / advance=记为备用金 / dividend=记为我的分红到账

    @app.post("/api/projects/{pid}/pick-income")
    def pick_income(pid: int, b: PickIn):
        name = _project_name(pid)
        ts = find(b.ids)
        if b.mode == "advance":
            with store.db() as c:
                used = {r["uid"] for r in c.execute("select uid from lines where uid<>''")}
                for t in ts:
                    v = view(t)
                    uid = _uid_of(v)
                    if uid in used:
                        continue
                    seq = c.execute("select coalesce(max(seq),0)+1 from lines where project_id=? and sec='备用金'", (pid,)).fetchone()[0]
                    c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,uid,date,who) "
                              "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                              (pid, "备用金", "", seq, "备用金", "", "", 1, "项", v["amount"], v["who"][:200], "已付", uid, v["date"],
                               v["who"].split(" | ")[0][:40]))
            n = apply([(t, dict(scope="工作", sub="其他工作收入", project=name, purpose="备用金")) for t in ts])
        elif b.mode == "dividend":
            with store.db() as c:
                used = {r["uid"] for r in c.execute("select uid from divs where uid<>''")}
                for t in ts:
                    v = view(t)
                    uid = _uid_of(v)
                    if uid not in used:
                        c.execute("insert into divs(project_id,date,amount,note,uid) values(?,?,?,?,?)",
                                  (pid, v["date"], v["amount"], v["who"].split(" | ")[0][:60], uid))
            n = apply([(t, dict(scope="工作", sub="其他工作收入", project=name, purpose="分红")) for t in ts])
        else:
            n = apply([(t, dict(scope="工作", sub="项目回款", project=name)) for t in ts])
        return dict(n=n)

    @app.get("/api/projects/{pid}/ledger-missing")
    def ledger_missing(pid: int):
        name = _project_name(pid)
        cost_sync(force=True)
        with store.db() as c:
            used = {r["uid"] for r in c.execute("select uid from lines where uid<>''")}
        out = []
        for t in ezb_transactions():
            if t["type"] != 3 or _project_of(t) != name:
                continue
            v = view(t)
            if _uid_of(v) in used:
                continue
            sec, cat = SEC_OF_SUB.get(v["sub"], ("执行人员杂费", ""))
            v.update(sec=sec, cat=cat, name=v["purpose"] or v["sub"] or "项目支出")
            out.append(v)
        out.sort(key=lambda v: (v["date"], v["hm"]))
        return dict(rows=out, total=round(sum(v["amount"] for v in out), 2))

    class MissItem(BaseModel):
        id: str
        sec: str
        name: str = ""
        cat: str = ""

    class MissItems(BaseModel):
        items: List[MissItem]

    @app.post("/api/projects/{pid}/ledger-missing")
    def add_missing(pid: int, b: MissItems):
        name = _project_name(pid)
        want = {i.id: i for i in b.items}
        added = 0
        with store.db() as c:
            used = {r["uid"] for r in c.execute("select uid from lines where uid<>''")}
            for t in ezb_transactions():
                if str(t["id"]) not in want or _project_of(t) != name:
                    continue
                v, it = view(t), want[str(t["id"])]
                uid = _uid_of(v)
                if uid in used or it.sec not in store.SECTIONS or it.sec == "备用金":
                    continue
                seq = c.execute("select coalesce(max(seq),0)+1 from lines where project_id=? and sec=?", (pid, it.sec)).fetchone()[0]
                vendor = f"{v['account']}{v['date'][5:]} {v['hm']} {v['who']}"[:200]
                c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,uid,date,who,auto) "
                          "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)",
                          (pid, it.sec, it.cat, seq, it.name or v["sub"] or "项目支出", "", "", 1, "项", v["amount"], vendor,
                           "已付", uid, "", ""))
                c.execute("create table if not exists cost_ignore(uid text primary key)")
                c.execute("delete from cost_ignore where uid=?", (uid,))
                used.add(uid)
                added += 1
        return dict(added=added)

    @app.get("/api/project-names")
    def project_names():
        with store.db() as c:
            names = [r[0] for r in c.execute("select name from projects order by id desc")]
        rules = bt.load_json(bt.RULES, None) or {}
        for p in list(rules.get("项目", {})) + sorted({_project_of(t) for t in ezb_transactions() if _project_of(t)}):
            if p and p not in names:
                names.append(p)
        with store.db() as c:                       # 各项目给月份起的名字，也能直接选
            for r in c.execute("select p.name pn, s.name sn from segs s join projects p on p.id=s.project_id where s.name<>'' order by s.month desc"):
                x = f"{r['pn']}{SEP}{r['sn']}"
                if x not in names:
                    names.append(x)
        return names

    class SegIn(BaseModel):
        month: str
        name: str = ""

    @app.put("/api/projects/{pid}/segs")
    def set_seg(pid: int, b: SegIn):
        nm = (b.name or "").strip().replace(SEP, " ")[:30]
        with store.db() as c:
            if nm:
                c.execute("insert into segs(project_id,month,name) values(?,?,?) on conflict(project_id,month) do update set name=excluded.name", (pid, b.month, nm))
            else:
                c.execute("delete from segs where project_id=? and month=?", (pid, b.month))
        return dict(ok=True)

    @app.get("/api/tx")
    def list_tx(month: str = "", scope: str = "", q: str = "", project: str = "", type: str = "", sub: str = "", batch: int = 0, limit: int = 2000):
        out = []
        only = None
        if batch:
            import json as _j
            with store.db() as c:
                b = c.execute("select rows from batches where id=?", (batch,)).fetchone()
            only = {r["uid"] for r in _j.loads(b["rows"]) if r.get("status") != "exists"} if b else set()
        for t in ezb_transactions():
            if t["type"] not in (2, 3):
                continue
            v = view(t)
            if only is not None and v["uid"] not in only:
                continue
            if month and v["date"][:7] != month:
                continue
            if scope and v["scope"] != scope:
                continue
            if type and v["type"] != type:
                continue
            if sub and v["sub"] != sub:
                continue
            if project == "(无项目)" and v["project"]:
                continue
            if project and project != "(无项目)" and v["project"] != project:
                continue
            if q and q.lower() not in (v["who"] + " " + v["purpose"] + " " + v["sub"] + " " + v["project"]).lower() and q not in str(v["amount"]):
                continue
            out.append(v)
        out.sort(key=lambda v: (v["date"], v["hm"]), reverse=True)
        tot = dict(exp=round(sum(v["amount"] for v in out if v["type"] == "exp"), 2), inc=round(sum(v["amount"] for v in out if v["type"] == "inc"), 2))
        months = sorted({_month_of(t) for t in ezb_transactions() if t["type"] in (2, 3)} | {date.today().strftime("%Y-%m")}, reverse=True)
        return dict(n=len(out), tot=tot, rows=out[:limit], months=months, truncated=len(out) > limit)

    class TxEdit(BaseModel):
        scope: Optional[str] = None
        sub: Optional[str] = None
        project: Optional[str] = None
        purpose: Optional[str] = None
        who: Optional[str] = None
        amount: Optional[float] = None
        date: Optional[str] = None
        account: Optional[str] = None
        type: Optional[str] = None

    @app.get("/api/tx/one/{tid}")
    def one_tx(tid: str):
        return view(find([tid])[0])

    @app.put("/api/tx/{tid}")
    def edit_tx(tid: str, b: TxEdit):
        t = find([tid])[0]
        apply([(t, b.dict())])
        nt = [x for x in ezb_transactions(force=True) if str(x["id"]) == tid] or \
             [x for x in ezb_transactions() if rid(x.get("comment")) == (rid(t.get("comment")) or f"手动:{tid}")]
        out = view(nt[0]) if nt else dict(ok=True)
        if notes:
            out["note"] = "；".join(notes)
        return out

    class Batch(BaseModel):
        ids: List[str]
        scope: Optional[str] = None
        sub: Optional[str] = None
        project: Optional[str] = None
        purpose: Optional[str] = None
        account: Optional[str] = None
        remember: bool = False
        delete: bool = False

    @app.post("/api/tx/batch")
    def batch_tx(b: Batch):
        ts = find(b.ids)
        if b.delete:
            delete_txs(ts)
            return dict(n=len(ts), deleted=True)
        ch = {k: v for k, v in b.dict().items() if k in ("scope", "sub", "project", "purpose", "account") and v not in (None, "")}
        if not ch:
            raise HTTPException(400, "请至少选一项要改的内容")
        n = apply([(t, ch) for t in ts])
        if b.remember:                                # 记住：以后同一个对象自动这样归
            import json
            learned = bt.load_json(bt.LEARNED, {})
            for t in ts:
                v = view(t)
                cp = v["who"].split(" | ")[0].strip().lower()
                if cp:
                    L = learned.get(cp, {})
                    learned[cp] = dict(scope=ch.get("scope") or L.get("scope") or v["scope"], sub=ch.get("sub") or L.get("sub") or "",
                                       project="" if ch.get("project") == "(无项目)" else (ch.get("project") or L.get("project", "")),
                                       purpose=ch.get("purpose") or L.get("purpose", ""))
            json.dump(learned, open(bt.LEARNED, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        return dict(n=n, note="；".join(sorted(set(notes))))

    @app.delete("/api/tx/{tid}")
    def del_tx(tid: str):
        delete_txs(find([tid]))
        return dict(ok=True)

    # ---------------- 快速记账：一行一笔，「午饭 35」「打车 48 哈尔滨」「+5000 回款 抖音」「昨天 超市 126.5 支付宝」
    QUICK_WORDS = {
        ("生活", "餐饮"): ("早饭", "午饭", "晚饭", "早餐", "午餐", "晚餐", "夜宵", "外卖", "吃饭", "饭", "咖啡", "奶茶", "水果", "零食", "买菜", "饮料", "面包"),
        ("生活", "交通出行"): ("打车", "地铁", "公交", "停车", "加油", "高铁", "火车", "机票", "单车"),
        ("生活", "居家"): ("房租", "水费", "电费", "燃气", "物业", "话费", "宽带", "日用"),
        ("生活", "购物"): ("衣服", "鞋", "淘宝", "京东", "拼多多", "网购"),
        ("生活", "娱乐订阅"): ("电影", "游戏", "会员", "ktv", "网吧", "网咖"),
        ("生活", "医疗健康"): ("药", "医院", "看病", "体检", "健身"),
        ("生活", "人情往来"): ("红包", "礼物", "请客", "份子"),
        ("生活", "烟酒"): ("烟", "酒"),
        ("生活", "休闲护理"): ("理发", "按摩", "足疗", "洗澡", "美发"),
    }
    ACCOUNTS = ("微信", "支付宝", "现金", "备用金", "银行卡", "信用卡")
    INCOME_WORDS = ("收入", "收到", "回款", "工资", "报销到账", "退款", "进账")

    def parse_line(line, base_day, projects, rules, learned):
        s = line.strip()
        if not s:
            return None
        typ = "inc" if s.startswith("+") or any(w in s for w in INCOME_WORDS) else "exp"
        day = base_day
        rest = s
        for pat, delta in (("前天", -2), ("昨天", -1), ("今天", 0)):
            if pat in rest:
                day = base_day + timedelta(days=delta)
                rest = rest.replace(pat, " ")
        m = re.search(r"(?:(20\d\d)[-/年])?(?<![\d.])(\d{1,2})[-/月](\d{1,2})日?(?![\d.])", rest)
        if m:
            try:
                day = date(int(m.group(1) or base_day.year), int(m.group(2)), int(m.group(3)))
                rest = rest.replace(m.group(0), " ")
            except ValueError:
                pass
        nums = list(re.finditer(r"[+-]?\d+(?:\.\d{1,2})?", rest))
        if not nums:
            return dict(raw=line, error="没找到金额")
        n = nums[-1]
        amount = abs(float(n.group(0)))
        rest = (rest[:n.start()] + " " + rest[n.end():]).replace("元", " ").replace("块", " ")
        account = ""
        for a in ACCOUNTS:
            if a in rest:
                account = a
                rest = rest.replace(a, " ")
                break
        scope = ""
        for w in ("工作", "生活"):
            if re.search(rf"(^|\s){w}(\s|$)", rest):
                scope = w
                rest = re.sub(rf"(^|\s){w}(\s|$)", " ", rest)
        project = ""
        toks = [x for x in re.split(r"\s+", rest) if x]
        for tok in toks:
            hit = [p for p in projects if tok == p] or ([p for p in projects if len(tok) >= 2 and tok in p] if len(tok) >= 2 else [])
            if len(hit) == 1 or (hit and tok in hit):
                project = tok if tok in hit else hit[0]
                toks.remove(tok)
                break
        who = " ".join(toks).strip(" +-") or ("收入" if typ == "inc" else "支出")
        d = dict(cp=who, item="", note="", typ="", kind="收入" if typ == "inc" else "支出", time=f"{day} 12:00:00", uid="")
        try:
            c = bt.classify(d, rules, learned, {}) if rules else {}
        except Exception:
            c = {}
        if c.get("scope") in (None, "待确认") and not project:
            low = who.lower()
            for (fs, fsub), ws in QUICK_WORDS.items():
                if any(w in low for w in ws):
                    c = dict(scope=fs, sub=fsub, project="", purpose="", why="常用词")
                    break
        sc = scope or ("工作" if project else c.get("scope", "待确认"))
        sub = c.get("sub", "") if c.get("scope") == sc else ""
        if not sub:
            sub = default_sub("", "", sc, typ)
        if not project and sc == "工作":
            project = c.get("project", "")
        return dict(raw=line, date=day.isoformat(), hm="12:00", type=typ, amount=amount, who=who, scope=sc, sub=sub.replace("工作-", ""),
                    project=project, purpose=c.get("purpose", ""), account=account or "微信", why=c.get("why", ""))

    class Quick(BaseModel):
        text: str
        date: str = ""

    @app.post("/api/tx/quick/parse")
    def quick_parse(b: Quick):
        base = datetime.strptime(b.date, "%Y-%m-%d").date() if b.date else date.today()
        with store.db() as c:
            projects = [r[0] for r in c.execute("select name from projects")]
        rules = bt.load_json(bt.RULES, None)
        projects += [p for p in (rules or {}).get("项目", {}) if p not in projects]
        projects += sorted({_project_of(t) for t in ezb_transactions() if _project_of(t)} - set(projects))
        learned = bt.load_json(bt.LEARNED, {})
        rows = [r for r in (parse_line(x, base, projects, rules, learned) for x in b.text.splitlines()) if r]
        return dict(rows=rows)

    class QuickRows(BaseModel):
        rows: List[dict]

    @app.post("/api/tx/quick/save")
    def quick_save(b: QuickRows):
        rows, pending = [], 0
        for v in b.rows:
            if v.get("error") or not v.get("amount"):
                continue
            v = dict(v)
            if v.get("project") == "(无项目)":
                v["project"] = ""
            v["project"] = norm_project(v.get("project"))
            for k in ("who", "scope", "sub", "project", "purpose", "account"):
                v[k] = (v.get(k) or "").strip()
            v["scope"] = v["scope"] or "待确认"
            v.setdefault("type", "exp")
            fix_sub(v)
            if v["scope"] != "工作":
                v["project"] = ""
            ensure_project(v["project"])
            pay = v.get("pay") or "已付"
            if v["scope"] == "工作" and v["project"] and v["type"] == "exp" and pay == "待支付":
                # 还没付出去：只记进项目成本单（付款情况「未付」），不进记账本；以后真付了、账单归到这个项目时自动对上这一行
                with store.db() as c:
                    r = c.execute("select id from projects where name=?", (v["project"],)).fetchone()
                    if not r:
                        sync_projects_json()
                        r = c.execute("select id from projects where name=?", (v["project"],)).fetchone()
                    if r:
                        sec, cat = SEC_OF_SUB.get(v["sub"], ("执行人员杂费", ""))
                        seq = c.execute("select coalesce(max(seq),0)+1 from lines where project_id=? and sec=?", (r["id"], sec)).fetchone()[0]
                        c.execute("insert into lines(project_id,sec,cat,seq,name,qty,unit,price,vendor,pay,date,who) values(?,?,?,?,?,?,?,?,?,?,?,?)",
                                  (r["id"], sec, cat, seq, v["purpose"] or v["who"] or v["sub"] or "项目支出", 1, "项", float(v["amount"]),
                                   f"待支付 · {v['who']}"[:200], "未付", v.get("date") or "", ""))
                        pending += 1
                        continue
            if v["scope"] == "工作" and v["project"] and pay == "备用金支付":
                v["account"] = "备用金"                       # 从备用金里付：记在备用金账户，成本单自动标「备用金垫付」
            rows.append(build_row(v, f"快记:{uuid.uuid4().hex[:12]}"))
        if not rows and not pending:
            raise HTTPException(400, "没有可保存的账")
        if rows:
            push_rows(ezb(), rows, log=lambda *_: None)
        invalidate()
        return dict(n=len(rows), pending=pending)

    return apply
