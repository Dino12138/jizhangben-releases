"""账单明细：在项目台里直接改记账本（单笔改 / 批量改 / 删除 / 快速记账）。"""
import re, uuid, json, os
from datetime import datetime, date, timedelta, timezone
from typing import List, Optional
from fastapi import HTTPException
from pydantic import BaseModel

TZ = timezone(timedelta(hours=8))
PRE_RE = re.compile(r"^【([^｜】]*)(?:｜([^】]*))?】")


def setup(app, h):
    """h: app.py 里的工具函数集合（避免循环 import）。"""
    ezb, ezb_transactions, invalidate = h["ezb"], h["ezb_transactions"], h["invalidate"]
    _scope_of, _project_of, _sub_name, _month_of = h["_scope_of"], h["_project_of"], h["_sub_name"], h["_month_of"]
    push_rows, rid, bt, store, sync_projects_json = h["push_rows"], h["rid"], h["bt"], h["store"], h["sync_projects_json"]

    def view(t):
        c = t.get("comment") or ""
        proj = _project_of(t)
        purpose = ""
        m = PRE_RE.match(c)
        if m:
            if m.group(2) is not None:
                purpose = m.group(2).strip()
            elif m.group(1).strip() != proj:
                purpose = m.group(1).strip()
        core = re.sub(r"〔ID:.*?〕", "", PRE_RE.sub("", c, count=1)).strip()
        dt = datetime.fromtimestamp(t["time"], TZ)
        out_ = dict(id=str(t["id"]), uid=rid(c) or "", date=dt.strftime("%Y-%m-%d"), hm=dt.strftime("%H:%M"),
                    type="inc" if t["type"] == 2 else "exp", amount=round(t["sourceAmount"] / 100, 2),
                    currency=t.get("_cur", "CNY"), amount_cny=round(t.get("_cny", t["sourceAmount"]) / 100, 2),
                    scope=_scope_of(t), sub=_sub_name(t), project=proj, purpose=purpose, who=core,
                    account=(t.get("sourceAccount") or {}).get("name", ""))
        if t["type"] == 4:                                  # 自己账户之间转账
            out_.update(type="tr", scope="转账", sub="账户互转", to_account=(t.get("destinationAccount") or {}).get("name", ""),
                        to_amount=round((t.get("destinationAmount") or 0) / 100, 2), to_currency=t.get("_dcur", "CNY"))
            # 软件自动写的「转账 A → B」：永远按这笔实际的转出 / 转入账户显示（在哪里改了账户，文字都跟着对）
            if re.fullmatch(r"转账 .+ → .+", out_.get("who") or "") and out_.get("account") and out_["to_account"]:
                out_["who"] = f"转账 {out_['account']} → {out_['to_account']}"
        return out_

    SEP = " · "

    def norm_project(name):
        """「项目 · 分期名」→「项目」（分期名只是同一项目不同月份的叫法）。"""
        name = (name or "").strip()
        if SEP in name:
            head = name.split(SEP, 1)[0].strip()
            with store.db() as c:
                if c.execute("select 1 from projects where name=?", (head,)).fetchone():
                    return head
        return name

    h["hooks"]["norm_project"] = norm_project

    def ensure_project(name):
        if not name:
            return
        with store.db() as c:
            if not c.execute("select 1 from projects where name=?", (name,)).fetchone():
                import json
                c.execute("insert into projects(name,params) values(?,?)",
                          (name, json.dumps(store.mode_defaults(store.detect_mode(dict(name=name))))))
        sync_projects_json()

    def account_id(api, name):
        from api_import import acc_name, acc_category, ACC_COLORS
        name = acc_name(name)
        for a in api.call("GET", "/api/v1/accounts/list.json"):
            if a["name"] == name:
                return str(a["id"])
        return str(api.call("POST", "/api/v1/accounts/add.json", dict(
            name=name, category=acc_category(name), type=1, icon="1", iconType=0, color=ACC_COLORS.get(name, "888888"), currency="CNY", balance="0", comment=""))["id"])

    # ---------------- 撤回：每次改账前把要改的那几笔原样存下来；点「撤回」就改回去（连带生成的借款/还款/补记的账一起撤）
    import threading as _th
    _U = _th.local()
    with store.db() as c:
        c.execute("create table if not exists undo_log(id integer primary key autoincrement, created text default (datetime('now','localtime')), "
                  "label text, snaps text, created_uids text, sqls text, done integer default 0)")
    SNAPK = ("id", "type", "categoryId", "time", "utcOffset", "sourceAccountId", "destinationAccountId", "sourceAmount", "destinationAmount", "hideAmount", "comment")

    def undo_begin(label):
        _U.op = dict(label=label, snaps={}, created=[], sql=[])

    def undo_snap(t):
        op = getattr(_U, "op", None)
        if op is not None and str(t["id"]) not in op["snaps"]:
            d = {k: t.get(k) for k in SNAPK}
            d["tagIds"] = [str(x) for x in (t.get("tagIds") or [])]
            d["pictureIds"] = [p_["pictureId"] for p_ in (t.get("pictures") or [])]
            op["snaps"][str(t["id"])] = d

    def undo_created(uid):
        op = getattr(_U, "op", None)
        if op is not None:
            op["created"].append(uid)

    def undo_sql(sql, params=()):
        op = getattr(_U, "op", None)
        if op is not None:
            op["sql"].append([sql, list(params)])

    def undo_commit():
        op = getattr(_U, "op", None)
        _U.op = None
        if not op or not (op["snaps"] or op["created"] or op["sql"]):
            return 0
        with store.db() as c:
            return c.execute("insert into undo_log(label,snaps,created_uids,sqls) values(?,?,?,?)",
                             (op["label"][:80], json.dumps(list(op["snaps"].values()), ensure_ascii=False), json.dumps(op["created"]),
                              json.dumps(op["sql"], ensure_ascii=False))).lastrowid

    for k_, f_ in (("undo_begin", undo_begin), ("undo_snap", undo_snap), ("undo_created", undo_created), ("undo_sql", undo_sql), ("undo_commit", undo_commit)):
        h["hooks"][k_] = f_

    @app.get("/api/undo/last")
    def undo_last():
        with store.db() as c:
            r = c.execute("select id,label,created from undo_log where done=0 and created>=datetime('now','localtime','-2 hours') order by id desc limit 1").fetchone()
        return dict(r) if r else {}

    @app.get("/api/undo/list")
    def undo_list():
        with store.db() as c:
            return [dict(r) for r in c.execute("select id,label,created,done from undo_log order by id desc limit 15")]

    @app.post("/api/undo/{uid_}")
    def undo_do(uid_: int):
        with store.db() as c:
            r = c.execute("select * from undo_log where id=?", (uid_,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这一步")
        if r["done"]:
            raise HTTPException(400, "这一步已经撤回过了")
        api = ezb()
        txs = {str(t["id"]): t for t in ezb_transactions(force=True)}
        for u in json.loads(r["created_uids"] or "[]"):          # 这一步新建的账：删掉
            for t in [t for t in txs.values() if rid(t.get("comment")) == u]:
                api.call("POST", "/api/v1/transactions/delete.json", {"id": str(t["id"])})
        n = 0
        for snp in json.loads(r["snaps"] or "[]"):               # 改过的账：改回原样
            if snp["id"] and str(snp["id"]) in txs:
                body = dict(snp, id=str(snp["id"]), categoryId=str(snp["categoryId"]), sourceAccountId=str(snp["sourceAccountId"]),
                            destinationAccountId=str(snp.get("destinationAccountId") or 0), destinationAmount=snp.get("destinationAmount") or 0)
                h["ezb_modify_tx"](api, body)
                n += 1
        with store.db() as c:
            for sql, params in json.loads(r["sqls"] or "[]"):
                c.execute(sql, params)
            c.execute("update undo_log set done=1 where id=?", (uid_,))
        invalidate()
        try:
            cost_sync(force=True)
        except Exception:
            pass
        return dict(ok=True, label=r["label"], n=n)

    def modify(api, t, **kw):
        undo_snap(t)
        body = dict(id=str(t["id"]), type=t["type"], categoryId=str(t["categoryId"]), time=t["time"], utcOffset=t["utcOffset"],
                    sourceAccountId=str(t["sourceAccountId"]), destinationAccountId=str(t.get("destinationAccountId") or 0),
                    sourceAmount=t["sourceAmount"], destinationAmount=t.get("destinationAmount", 0), hideAmount=t.get("hideAmount", False),
                    tagIds=[str(x) for x in (t.get("tagIds") or [])], pictureIds=[p["pictureId"] for p in (t.get("pictures") or [])],
                    comment=t.get("comment") or "")
        body.update(kw)
        h["ezb_modify_tx"](api, body)

    def default_sub(old_scope, old_sub, scope, typ):
        if scope == old_scope:
            return old_sub
        if scope == "工作":
            return "项目回款" if typ == "inc" else "项目支出"
        if scope == "生活":
            return "红包转账" if typ == "inc" else "其他"
        return "收入" if typ == "inc" else "其他"

    # ---------------- 子类防填错：子类只能是列表里的；填成项目名的挪到「项目」，乱写的挪到「用途」
    PASS_SUBS = tuple(h["PASS_SUBS"])
    INC_SUBS = {"工作": list(h["WORK_INC_SUBS"]), "生活": ["工资薪酬", "红包转账", "还款退款", "理财利息", "其他收入", "借款往来"]}

    def allowed_subs(scope, typ):
        if typ == "inc":
            return INC_SUBS.get(scope, [])
        return h["all_subs"](scope) if scope in ("工作", "生活") else []

    def match_project(text):
        t = (text or "").strip().lower()
        if len(t) < 2:
            return ""
        with store.db() as c:
            names = [r["name"] for r in c.execute("select name from projects")]
        for n in sorted(names, key=len, reverse=True):          # 整个项目名
            if n.lower() == t or (len(n) >= 2 and n.lower() in t):
                return n
        for n in names:                                          # 项目名里的关键词（如「某品牌-ABC」里的 ABC）
            for tok in re.split(r"[-·_\s/｜|（）()]+", n):
                if len(tok) >= 3 and not tok.isdigit() and tok.lower() in t:
                    return n
        return ""

    def fix_sub(v, user=True, any_type=False):
        """v: 含 scope/type/sub/project/purpose 的 dict，原地修正。返回说明（没改返回空串）。
        user=False：子类不是用户填的（比如只改了收支方向），不合法就换成默认，不挪到用途。
        any_type=True：一个对象下收支都有时（按对象改归类），收入/支出子类都算合法。"""
        sc, typ, sub = v.get("scope"), v.get("type", "exp"), (v.get("sub") or "").strip()
        if sc not in ("工作", "生活"):
            return ""
        ok = allowed_subs(sc, typ) + (allowed_subs(sc, "inc" if typ == "exp" else "exp") if any_type else [])
        if any_type and not sub:
            return ""
        if sub in ok:
            return ""
        dflt = ("项目回款" if typ == "inc" else "项目支出") if sc == "工作" else ("其他收入" if typ == "inc" else "其他")
        if sc == "工作" and typ == "exp" and not any_type and sub in ("项目分红", "项目回款"):
            # 支出不能叫「项目分红 / 项目回款」：分红里转给别人的 = 分红转出；客户款转给公司的 = 项目款转出
            v["sub"] = "分红转出" if sub == "项目分红" else "项目款转出"
            return (f"这是一笔支出，不能叫「{sub}」，已改成「{v['sub']}」：" +
                    ("会从你到账的分红里扣掉，不算项目成本" if sub == "项目分红" else "算你把客户的钱转给公司，不算项目成本")) if user else ""
        if not sub or not user:
            v["sub"] = "" if any_type else dflt
            return ""
        pj = match_project(sub)
        if pj:
            v["scope"], v["project"] = "工作", v.get("project") or pj
            v["sub"] = "" if any_type else ("项目回款" if typ == "inc" else "项目支出")
            if not (v.get("purpose") or "").strip():
                v["purpose"] = sub[:40]
            return f"「{sub}」像是项目，已放到项目「{v['project']}」，子类改为{v['sub'] or '默认'}"
        if user and (typ == "exp" or any_type) and h.get("remember_sub"):
            try:                    # 自己输入的新子类：加进「我的子类」，以后下拉里直接能选
                v["sub"] = h["remember_sub"](sc, sub)
                return f"已新增子类「{v['sub']}」，以后可以直接选（不要了在下拉里点「删除」）"
            except Exception:
                pass
        v["sub"] = "" if any_type else dflt
        dflt = v["sub"] or "默认"
        if not (v.get("purpose") or "").strip():
            v["purpose"] = sub[:40]
            return f"子类只能从列表里选，「{sub}」已放到用途，子类改为{dflt}"
        return f"子类只能从列表里选，「{sub}」不在列表里，已改为{dflt}"

    h["hooks"]["fix_sub"] = fix_sub

    def build_row(v, uid):
        pre = (f"【{v['project']}｜{v['purpose']}】" if v["project"] and v["purpose"]
               else f"【{v['project']}】" if v["project"] else f"【｜{v['purpose']}】" if v["purpose"] else "")
        suf = f"〔ID:{uid}〕"
        desc = pre + v["who"][:max(0, 250 - len(pre) - len(suf))] + suf
        tags = v["scope"] + (f";项目:{v['project']}" if v["project"] else "")
        return {"Time": f"{v['date']} {v.get('hm', '12:00')}:00", "Type": "Income" if v["type"] == "inc" else "Expense",
                "Category": v["scope"], "Sub Category": f"{v['scope']}·{v['sub'] or '其他'}", "Account": v["account"] or "微信",
                "Amount": f"{float(v['amount']):.2f}", "Tags": tags, "Description": desc}

    notes = []

    def apply(changes):
        """changes: list of (t, dict)。返回改了几笔。"""
        api = ezb()
        rows, after = [], []
        notes.clear()
        for t, ch in changes:
            undo_snap(t)
            v = view(t)
            uid = v["uid"]
            if not uid:                                 # 记账本里手动记的：先补编号
                uid = f"手动:{t['id']}"
                modify(api, t, comment=((t.get("comment") or "").strip() + f"〔ID:{uid}〕")[:255])
            new = dict(v)
            for k in ("scope", "sub", "project", "purpose", "who", "amount", "date", "hm", "account", "type"):
                if ch.get(k) is not None:
                    new[k] = ch[k].strip() if isinstance(ch[k], str) else ch[k]
            if new["project"] == "(无项目)":
                new["project"] = ""
            new["project"] = norm_project(new["project"])
            if ch.get("sub") is None and (new["scope"] != v["scope"] or new["type"] != v["type"]):
                new["sub"] = default_sub(v["scope"], v["sub"], new["scope"], new["type"])
            if new["project"] and ch.get("scope") is None and new["scope"] != "工作" and ch.get("project"):
                new["scope"] = "工作"                     # 选了项目却没说工作/生活：默认工作
                if ch.get("sub") is None:
                    new["sub"] = default_sub(v["scope"], v["sub"], "工作", new["type"])
            if ch.get("sub") is not None or ch.get("scope") is not None or ch.get("type") is not None:
                note = fix_sub(new, user=ch.get("sub") is not None)
                if note:
                    notes.append(note)
            if new["scope"] != "工作":                  # 只有工作才有项目；生活/待确认清掉项目，用途保留
                new["project"] = ""
            ensure_project(new["project"])
            rows.append(build_row(new, uid))            # 收支方向变了也是原地改（不删不重建：编号、图片都保留，能撤回）
            if (new["date"] != v["date"] or new.get("hm") != v["hm"] or new["account"] != v["account"]):
                after.append((str(t["id"]), new))
        if rows:
            push_rows(api, rows, log=lambda *_: None)
        invalidate()
        if after:
            byid = {str(t["id"]): t for t in ezb_transactions(force=True)}
            for i, new in after:
                t = byid.get(i)
                if not t:
                    continue
                kw = {}
                v = view(t)
                if new["date"] != v["date"] or (new.get("hm") or v["hm"]) != v["hm"]:     # 改日期或几点几分（余额按这个时间判断算不算）
                    hm = (new.get("hm") or v["hm"])[:5]
                    kw["time"] = int(datetime.strptime(f"{new['date']} {hm}", "%Y-%m-%d %H:%M").replace(tzinfo=TZ).timestamp())
                if new["account"] != v["account"]:
                    kw["sourceAccountId"] = account_id(api, new["account"])
                if kw:
                    modify(api, t, **kw)
            invalidate()
        return len(rows)

    def find(ids):
        ids = set(str(i) for i in ids)
        ts = [t for t in ezb_transactions(force=True) if str(t["id"]) in ids]
        if not ts:
            raise HTTPException(404, "没找到这些账单（可能已被删除），请刷新")
        return ts

    # ---------------- 项目改名 / 删项目：记账本里的分类大类、标签、每笔账备注里的【项目名】一起跟着变
    def _state_rename(old, new):
        """分类器记住的「这个对象→这个项目」也跟着改名（不然下次导入账单又归回旧名字）。"""
        def walk(x):
            n = 0
            if isinstance(x, dict):
                for k, v in x.items():
                    if k == "project" and v == old:
                        x[k] = new
                        n += 1
                    else:
                        n += walk(v)
            elif isinstance(x, list):
                for v in x:
                    n += walk(v)
            return n
        for p_ in (bt.LEARNED, os.path.join(bt.STATE, "项目标注.json"), os.path.join(bt.STATE, "快速记账记忆.json")):
            try:
                d = bt.load_json(p_, None)
                if d and walk(d):
                    store.write_json(p_, d)
            except Exception as e:
                store.log_err("项目改名·更新记忆 " + os.path.basename(p_), e)

    def rename_project(old, new):
        api = ezb()
        from api_import import _flat_categories
        flat = _flat_categories(api)
        tops = {(c_["type"], c_["name"]): c_ for c_ in flat if str(c_.get("parentId", "0")) == "0"}
        tags = {t_["name"]: t_ for t_ in api.call("GET", "/api/v1/transaction/tags/list.json")}
        clash = any((ct, f"项目·{new}") in tops for ct in (1, 2)) or f"项目:{new}" in tags
        txs = [t for t in ezb_transactions(force=True) if _project_of(t) == old]
        if clash:                                   # 记账本里已有新名字的分类/标签（以前删过同名项目留下的）：把账一笔笔挪过去
            n = apply([(t, {"project": new}) for t in txs]) if txs else 0
            _drop_project_cats(api, old)
        else:                                       # 正常情况：分类大类和标签直接改名，账自动跟过去；再把备注里的【旧名】换成新名
            for ct in (1, 2):
                c_ = tops.get((ct, f"项目·{old}"))
                if c_:
                    api.call("POST", "/api/v1/transaction/categories/modify.json", dict(
                        id=str(c_["id"]), name=f"项目·{new}", parentId="0", icon=str(c_.get("icon") or "1"), color=c_.get("color") or "999999",
                        comment=c_.get("comment") or "", hidden=bool(c_.get("hidden"))))
            tg = tags.get(f"项目:{old}")
            if tg:
                api.call("POST", "/api/v1/transaction/tags/modify.json", dict(id=str(tg["id"]), name=f"项目:{new}", groupId=str(tg.get("groupId") or "0")))
            n = 0
            for t in txs:
                c0 = t.get("comment") or ""
                m = PRE_RE.match(c0)
                if m and m.group(1).strip() == old:
                    rest = c0[m.end():]
                    pre = f"【{new}｜{m.group(2)}】" if m.group(2) is not None else f"【{new}】"
                    keep = re.search(r"〔ID:.*?〕\s*$", rest)              # 编号必须留全；太长就截正文
                    if keep and len(pre + rest) > 255:
                        rest = rest[:keep.start()][:max(0, 255 - len(pre) - len(keep.group(0)))] + keep.group(0)
                    modify(api, t, comment=(pre + rest)[:255])
                n += 1
        invalidate()
        _state_rename(old, new)
        return dict(n=n)

    def _drop_project_cats(api, name):
        """项目没了：记账本里『项目·名』这个大类如果已经空了就删掉（还有账在用就留着）。"""
        from api_import import _flat_categories
        used = {str(t["categoryId"]) for t in ezb_transactions(force=True)}
        flat = _flat_categories(api)
        for top in [c_ for c_ in flat if str(c_.get("parentId", "0")) == "0" and c_["name"] == f"项目·{name}"]:
            subs = [c_ for c_ in flat if str(c_.get("parentId")) == str(top["id"])]
            if any(str(c_["id"]) in used for c_ in subs):
                continue
            try:
                api.call("POST", "/api/v1/transaction/categories/delete.json", {"id": str(top["id"])})
            except Exception as e:
                store.log_err("删空的项目分类", e)
        for t_ in api.call("GET", "/api/v1/transaction/tags/list.json"):
            if t_["name"] == f"项目:{name}":
                try:
                    api.call("POST", "/api/v1/transaction/tags/delete.json", {"id": str(t_["id"])})
                except Exception as e:
                    store.log_err("删项目标签", e)

    def detach_project(name):
        """删项目时把它名下的账改成「工作·无项目」（账本身不删）。"""
        txs = [t for t in ezb_transactions(force=True) if _project_of(t) == name]
        undo_begin(f"删除项目「{name}」：{len(txs)} 笔账改成无项目")
        try:
            n = apply([(t, {"project": "(无项目)"}) for t in txs]) if txs else 0
        finally:
            undo_commit()
        _drop_project_cats(ezb(), name)
        invalidate()
        return n

    h["hooks"]["rename_project"], h["hooks"]["detach_project"] = rename_project, detach_project

    # ---------------- 最近删除（可恢复）
    with store.db() as c:
        c.execute("create table if not exists trash(id integer primary key autoincrement, deleted text default (datetime('now','localtime')), view text, row text)")

    def to_trash(ts):
        import json as _j
        with store.db() as c:
            for t in ts:
                v = view(t)
                uid = v["uid"] or f"手动:{t['id']}"
                rw = build_row(v, uid)
                rw["_raw"] = dict({k: t.get(k) for k in SNAPK}, tagIds=[str(x) for x in (t.get("tagIds") or [])])     # 原样留一份：恢复时账户/时间/转账都不走样
                c.execute("insert into trash(view,row) values(?,?)", (_j.dumps(v, ensure_ascii=False), _j.dumps(rw, ensure_ascii=False)))
            c.execute("delete from trash where deleted < datetime('now','localtime','-90 days')")

    def delete_txs(ts):
        to_trash(ts)
        api = ezb()
        for t in ts:
            api.call("POST", "/api/v1/transactions/delete.json", {"id": str(t["id"])})
        invalidate()

    @app.get("/api/tx/trash")
    def list_trash():
        import json as _j
        with store.db() as c:
            rows = [dict(tid=r["id"], deleted=r["deleted"], **_j.loads(r["view"])) for r in c.execute("select * from trash order by id desc limit 300")]
        return dict(rows=rows)

    class TrashIds(BaseModel):
        ids: List[int]

    @app.post("/api/tx/trash/restore")
    def restore_trash(b: TrashIds):
        import json as _j
        with store.db() as c:
            rs = [r for r in c.execute("select * from trash where id in (%s)" % ",".join("?" * len(b.ids)), b.ids)] if b.ids else []
        if not rs:
            raise HTTPException(404, "没找到要恢复的账")
        api = ezb()
        accs = {str(a["id"]) for a in api.call("GET", "/api/v1/accounts/list.json")}
        from api_import import _flat_categories
        cats = {str(c_["id"]) for c_ in _flat_categories(api)}
        tags = {str(t_["id"]) for t_ in api.call("GET", "/api/v1/transaction/tags/list.json")}
        have = {rid(t.get("comment")) for t in ezb_transactions(force=True)} - {None, ""}
        raws, rows, done, bad = [], [], [], []
        for r in rs:
            rw = _j.loads(r["row"])
            raw = rw.pop("_raw", None)
            vw = _j.loads(r["view"])
            if rid(rw.get("Description")) in have:              # 账本里已经有这笔了（比如撤回过）：不重复加
                done.append(r["id"])
                continue
            tr = (raw or {}).get("type") == 4 or vw.get("type") == "tr"
            ok = raw and str(raw.get("sourceAccountId")) in accs and (
                (str(raw.get("destinationAccountId")) in accs) if tr else (str(raw.get("categoryId")) in cats))
            if ok:                                              # 原样放回去（转账还是转账，账户、时间、标签都不变）
                raws.append(dict(type=raw["type"], categoryId=str(raw.get("categoryId") or 0), time=raw["time"], utcOffset=raw.get("utcOffset") or 480,
                                 sourceAccountId=str(raw["sourceAccountId"]), destinationAccountId=str(raw.get("destinationAccountId") or 0),
                                 sourceAmount=raw["sourceAmount"], destinationAmount=raw.get("destinationAmount") or 0, hideAmount=bool(raw.get("hideAmount")),
                                 tagIds=[x for x in raw.get("tagIds", []) if x in tags], pictureIds=[], comment=raw.get("comment") or rw["Description"]))
                done.append(r["id"])
            elif tr:                                            # 转账但账户已经没了 / 老版本删的：没法原样恢复，不硬恢复成支出
                bad.append(f"{vw.get('date', '')} {vw.get('account', '')}→{vw.get('to_account', '')} ¥{vw.get('amount', '')}")
            else:
                rows.append(rw)
                done.append(r["id"])
        import uuid as _uuid
        for i in range(0, len(raws), 200):
            api.call("POST", "/api/v1/transactions/import.json", dict(transactions=raws[i:i + 200], clientSessionId=str(_uuid.uuid4())))
        if rows:
            push_rows(api, rows, log=lambda *_: None)
        if done:
            with store.db() as c:
                c.execute("delete from trash where id in (%s)" % ",".join("?" * len(done)), done)
        invalidate()
        if bad and not done:
            raise HTTPException(400, "这几笔是账户互转，原来的账户已经找不到了，没法原样恢复：" + "；".join(bad[:5]) + "。请在「转账」里重新记一笔")
        return dict(n=len(done), skipped=bad)

    # ---------------- 可能重复：手动/快速记的账 和 导入的微信/支付宝账单 金额相同、日期相差不超过 1 天
    @app.get("/api/tx/dupes")
    def dupes():
        cfg = store.load_config()
        ign = set(cfg.get("dupe_ignore", []))
        vs = [view(t) for t in ezb_transactions() if t["type"] in (2, 3)]
        manual = [v for v in vs if not v["uid"] or v["uid"].startswith(("快记:", "手动:", "还款:"))]
        imported = {}
        for v in vs:
            if v["uid"].startswith(("微信:", "支付宝:")):
                imported.setdefault((v["type"], round(v["amount"] * 100)), []).append(v)
        pairs = []
        for m in manual:
            if m["id"] in ign:
                continue
            md = datetime.strptime(m["date"], "%Y-%m-%d").date()
            for v in imported.get((m["type"], round(m["amount"] * 100)), []):
                if abs((datetime.strptime(v["date"], "%Y-%m-%d").date() - md).days) <= 1:
                    pairs.append(dict(manual=m, imported=v))
                    break
        cnt = {}
        for p in pairs:
            cnt[p["imported"]["id"]] = cnt.get(p["imported"]["id"], 0) + 1
        for p in pairs:                                     # sure=有把握是同一笔：一对一，且手记的账户和账单来源一致（微信对微信、支付宝对支付宝）
            src = p["imported"]["uid"].split(":", 1)[0]
            p["sure"] = cnt[p["imported"]["id"]] == 1 and bt.account_family(p["manual"]["account"]) in (src, "银行卡")
        return dict(n=len(pairs), pairs=pairs)

    h["hooks"]["dupes"] = dupes

    class Ign(BaseModel):
        id: str

    @app.post("/api/tx/dupes/ignore")
    def dupes_ignore(b: Ign):
        cfg = store.load_config()
        cfg["dupe_ignore"] = sorted(set(cfg.get("dupe_ignore", [])) | {b.id})
        store.save_config(cfg)
        return dict(ok=True)

    # ---------------- 手记的账 ↔ 导入的账单：自动合并（不重复记）
    def merge_pair(m, v):
        """m=手记的，v=导入的。保留导入那笔（有微信/支付宝编号），把手记时填的 工作/生活、子类、项目、用途 搬过去；
        项目台里引用手记那笔的地方（成本行、分红到账、发票）改指向导入那笔；手记那笔进「最近删除」。"""
        tm, tv = find([m["id"]])[0], find([v["id"]])[0]
        ch = {}
        if m["scope"] in ("工作", "生活"):
            ch.update(scope=m["scope"], sub=m["sub"], project=m["project"] or "(无项目)", purpose=m["purpose"] or v["purpose"])
            if not ch["purpose"] and m["who"] and m["who"] not in (v["who"] or ""):
                ch["purpose"] = m["who"][:30]
        if ch:
            apply([(tv, ch)])
        mu = m["uid"] or f"手动:{m['id']}"
        with store.db() as c:
            for tb, col in (("lines", "uid"), ("divs", "uid"), ("inv", "tx_uid"), ("debts", "tx_uid"), ("repayments", "tx_uid")):
                c.execute(f"update {tb} set {col}=? where {col}=?", (v["uid"], mu))
        delete_txs([tm])

    def auto_merge():
        """只合并有把握的：同收/支、金额一样、日期差 ≤1 天、手记的账户和账单来源一致（微信对微信、支付宝对支付宝），且一对一。"""
        d = dupes()
        cnt = {}
        for p in d["pairs"]:
            cnt[p["imported"]["id"]] = cnt.get(p["imported"]["id"], 0) + 1
        n = 0
        for p in d["pairs"]:
            m, v = p["manual"], p["imported"]
            src = v["uid"].split(":", 1)[0]
            fam = bt.account_family(m["account"])
            if cnt[v["id"]] != 1 or fam not in (src, "银行卡"):
                continue
            try:
                merge_pair(m, v)
                n += 1
            except Exception as e:
                print("自动合并失败：", e)
        return n

    h["hooks"]["auto_merge"] = auto_merge
    h["hooks"]["cab_refresh"] = lambda: cost_sync(force=True)

    class Pair(BaseModel):
        manual: str
        imported: str

    @app.post("/api/tx/dupes/merge")
    def dupes_merge(b: Pair):
        vs = {str(t["id"]): view(t) for t in find([b.manual, b.imported])}
        if b.manual not in vs or b.imported not in vs:
            raise HTTPException(404, "没找到这两笔账，请刷新")
        merge_pair(vs[b.manual], vs[b.imported])
        return dict(ok=True)

    # ---------------- 导出 Excel（按当前筛选）
    @app.get("/api/tx/export")
    def export_tx(month: str = "", scope: str = "", q: str = "", project: str = "", type: str = "", sub: str = "", batch: int = 0,
                  d1: str = "", d2: str = "", account: str = ""):
        import openpyxl, os, tempfile
        from openpyxl.styles import Font, PatternFill, Alignment
        from fastapi.responses import FileResponse
        d = list_tx(month=month, scope=scope, q=q, project=project, type=type, sub=sub, batch=batch, limit=100000, d1=d1, d2=d2, account=account)
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "账单明细"
        head = ["日期", "时间", "收/支", "金额", "工作/生活", "子类", "项目", "用途", "对象 / 备注", "账户"]
        ws.append(head)
        for r in sorted(d["rows"], key=lambda v: (v["date"], v["hm"])):
            ws.append([r["date"], r["hm"], "收入" if r["type"] == "inc" else "支出", r["amount"], r["scope"], r["sub"], r["project"], r["purpose"], r["who"], r["account"]])
        bold, fill = Font(bold=True), PatternFill("solid", fgColor="F3E6D3")
        for c in ws[1]:
            c.font, c.fill = bold, fill
        for col, w in zip("ABCDEFGHIJ", (12, 7, 7, 12, 10, 12, 26, 16, 60, 9)):
            ws.column_dimensions[col].width = w
        for row in ws.iter_rows(min_row=2, min_col=4, max_col=4):
            for c in row:
                c.number_format = "#,##0.00"
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = f"A1:J{ws.max_row}"
        s2 = wb.create_sheet("汇总")
        def block(title, keyf):
            agg = {}
            for r in d["rows"]:
                if r["type"] != "exp":
                    continue
                k = keyf(r)
                agg[k] = agg.get(k, 0) + r["amount"]
            s2.append([title, "支出合计"])
            for c in s2[s2.max_row]:
                c.font, c.fill = bold, fill
            for k, v in sorted(agg.items(), key=lambda x: -x[1]):
                s2.append([k, round(v, 2)])
            s2.append([])
        s2.append(["筛选条件", " ".join(f"{k}={v}" for k, v in dict(month=month, scope=scope, type=type, project=project, sub=sub, q=q).items() if v) or "全部"])
        s2.append(["支出合计", d["tot"]["exp"]]); s2.append(["收入合计", d["tot"]["inc"]]); s2.append([])
        block("工作/生活", lambda r: r["scope"])
        block("工作/生活 · 子类", lambda r: f"{r['scope']} · {r['sub']}")
        block("项目", lambda r: r["project"] or "(没归项目)")
        s2.column_dimensions["A"].width = 34
        s2.column_dimensions["B"].width = 14
        for row in s2.iter_rows(min_col=2, max_col=2):
            for c in row:
                if isinstance(c.value, (int, float)):
                    c.number_format = "#,##0.00"
        name = "账单明细" + (f"-{month}" if month else "") + (f"-{scope}" if scope else "") + (f"-{project}" if project and project != "(无项目)" else "") + f"-{datetime.now():%Y%m%d%H%M}.xlsx"
        p = os.path.join(tempfile.mkdtemp(), name)
        wb.save(p)
        return FileResponse(p, filename=name, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

    # ---------------- 接口
    # ---------------- 账单 → 成本单：这个项目在记账本里有、成本单里还没有的支出
    SEC_OF_SUB = {"物料搭建": ("物料部分", "物料采购"), "快递物流": ("物料部分", "物流"), "打印复印": ("物料部分", "快印"),
                  "礼品采购": ("物料部分", "物料采购"), "办公用品": ("物料部分", "物料采购"), "场地费": ("搭建部分", ""),
                  "第三方人员": ("第三方人员", ""), "设计费": ("第三方人员", "设计费"), "人员劳务": ("第三方人员", ""),
                  "供应商执行": ("第三方人员", ""), "交通": ("执行人员杂费", "交通费"), "差旅住宿": ("执行人员杂费", "住宿"),
                  "餐补": ("执行人员杂费", "餐补"), "招待": ("执行人员杂费", "业务招待")}

    def _uid_of(v):
        return v["uid"] or f"手动:{v['id']}"

    def _project_name(pid):
        with store.db() as c:
            p = c.execute("select name from projects where id=?", (pid,)).fetchone()
        if not p:
            raise HTTPException(404, "项目不存在")
        return p["name"]

    _sync_state = {"key": None, "t": 0.0}

    ROUTE_RE = re.compile(r"^(.*?)（([^（）]*?)→([^（）]*?)）$")
    CAB_WORDS = re.compile(r"打车|出租|滴滴|网约车|曹操|花小猪|首汽|如祺|享道|嘀嗒|快车|专车|车费|的士|T3出行|高德打车")

    SHIP_WORDS = re.compile(r"快递|物流|顺丰|货拉拉|快狗|运费|寄件|邮寄|闪送|德邦|中通|圆通|韵达|申通|极兔|邮政|货运|搬运|托运|运输", re.I)
    TRUCK_WORDS = re.compile(r"货拉拉|快狗|货运|搬运")

    def ship_fields(v, m):
        """快递物流的账在成本单里的写法：名称 = 你写的用途（没写：对方的名字，如 顺丰 / 货拉拉）、规格 = 日期、工艺说明 = 「起点-终点」。"""
        pu, who = v.get("purpose") or "", v.get("who") or ""
        base = (m.group(1) if m else pu).strip()
        d = v.get("date") or ""
        spec = f"{d[:4]}.{int(d[5:7])}.{int(d[8:10])}" if len(d) >= 10 else ""
        if base in ("", "快递物流"):                      # 没另写用途：用对方的名字（顺丰、货拉拉…），认不出就按成本单预设叫法
            mm = re.search(r"顺丰|货拉拉|快狗|闪送|德邦|中通|圆通|韵达|申通|极兔|邮政", who)
            base = mm.group(0) if mm else ("货拉拉" if TRUCK_WORDS.search(who) else "顺丰/快递")
        name = base
        return dict(name=name, spec=spec, craft=f"{m.group(2).strip()}-{m.group(3).strip()}" if m else "", ship=True)

    def cab_fields(v):
        """打车的账在成本单里的写法（照内部成本单）：名称「打车费」、规格 = 日期（2026.10.25）、
        工艺说明 = 「乘车人 起点-终点」。不是打车返回 None。"""
        pu, who = v.get("purpose") or "", v.get("who") or ""
        m = ROUTE_RE.match(pu)
        base = m.group(1) if m else pu
        if m and (SHIP_WORDS.search(base) or (SHIP_WORDS.search(who) and not CAB_WORDS.search(base))):
            return ship_fields(v, m)                    # 快递物流填了起点终点：不叫「打车费」、不写乘车人（没填路线的照旧，不动）
        if not (m or CAB_WORDS.search(pu) or (CAB_WORDS.search(who) and not pu)):
            return None
        d = v.get("date") or ""
        spec = f"{d[:4]}.{int(d[5:7])}.{int(d[8:10])}" if len(d) >= 10 else ""
        me = (store.load_config().get("my_name") or "").strip()
        route = f"{m.group(2).strip()}-{m.group(3).strip()}" if m else ""
        craft = " ".join(x for x in (me, route) if x)
        return dict(name="打车费", spec=spec, craft=craft)

    def cost_sync(force=False):
        """账单明细 → 成本单自动同步（只管 auto=1 的行，导入/手填的成本行一律不动）：
        账单归到某项目的支出 → 自动加一行；账单金额变 → 跟着变；改到别的项目 → 行跟着搬；
        移出项目/删掉 → 撤掉这一行（这一行上过发票图的保留，转成普通行）。"""
        import time
        txs = ezb_transactions()
        key = id(txs)
        if not force and key == _sync_state["key"] and time.time() - _sync_state["t"] < 3:
            return
        _sync_state.update(key=key, t=time.time())
        with store.db() as c:
            c.execute("create table if not exists cost_ignore(uid text primary key)")
            pid_of = {r["name"]: r["id"] for r in c.execute("select id,name from projects")}
            ignored = {r["uid"] for r in c.execute("select uid from cost_ignore")}
            lines = {}
            for r in c.execute("select id,project_id,uid,price,qty,auto,date,name,spec,craft from lines where uid<>''"):
                lines.setdefault(r["uid"], dict(r))
            nfiles = {r[0]: r[1] for r in c.execute("select line_id,count(*) from files group by line_id")}
            c.execute("create table if not exists tx_pay(uid text primary key, pay text)")
            want_pay = {r[0]: r[1] for r in c.execute("select uid,pay from tx_pay")}
            has_adv = {r[0] for r in c.execute("select distinct project_id from lines where sec='备用金'")}
            has_adv |= {pid_of.get(_project_of(t)) for t in txs if t["type"] == 2 and _project_of(t) and view(t)["sub"] == "项目备用金入款"} - {None}
            seen = set()
            for t in txs:
                if t["type"] != 3 or (_scope_of(t) == "工作" and _sub_name(t) in PASS_SUBS):   # 分红转出/项目款转出：过手的钱，不是成本，不进成本单
                    continue
                proj = _project_of(t)
                pid = pid_of.get(proj) if proj else None
                if not pid:
                    continue
                v = view(t)
                uid = _uid_of(v)
                seen.add(uid)
                l = lines.get(uid)
                if l:
                    cf = cab_fields(v) if l.get("id") else None
                    if cf:                              # 打车：跟着账单的路线/日期改；你在成本单里手动加过字的（如「… 另加的备注」）不覆盖
                        gen = dict(name=(lambda x: not x or bool(ROUTE_RE.match(x)) or x in ("项目支出", "快递物流", "顺丰/快递", "货拉拉", "货拉拉运输")) if cf.get("ship")
                                   else (lambda x: not x or x.startswith("打车") or x in ("项目支出", "交通")),
                                   spec=lambda x: not x or re.fullmatch(r"\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2}", x),
                                   craft=lambda x: not x or re.fullmatch(r"(\S+ )?[^\s]*-[^\s]*|\S+", x))
                        cur = {k: (l.get(k) or "") for k in ("name", "spec", "craft")}
                        want = dict(cur)
                        for k in ("name", "spec"):          # 空着就补；自动同步来的行跟着账单变
                            if cf[k] and (not cur[k] or (l["auto"] and gen[k](cur[k]))):
                                want[k] = cf[k]
                        if cf["craft"] and (not cur["craft"] or ("-" in cf["craft"] and gen["craft"](cur["craft"]))):
                            want["craft"] = cf["craft"]     # 有起点终点才覆盖（导入的「小王 家-公司」不会被改成只有名字）
                        if any((l.get(k) or "") != want[k] for k in ("name", "spec", "craft")):
                            c.execute("update lines set name=?, spec=?, craft=? where id=?", (want["name"], want["spec"], want["craft"], l["id"]))
                    if l["auto"]:
                        if l["project_id"] != pid:
                            c.execute("update lines set project_id=? where id=?", (pid, l["id"]))
                        if abs((l["price"] or 0) * (l["qty"] or 1) - v["amount_cny"]) > 0.001:
                            c.execute("update lines set qty=1, price=? where id=?", (v["amount_cny"], l["id"]))
                        if (l.get("date") or "") != v["date"]:          # 成本行日期跟账单走（按月份区分要用）
                            c.execute("update lines set date=? where id=?", (v["date"], l["id"]))
                    continue
                if uid in ignored:
                    continue
                # 付款情况：你选过的（记一笔/编辑里选「备用金垫付」）优先；没选过：项目有备用金 → 备用金垫付，否则 → 已付（你垫付）
                pay = want_pay.get(uid) or ("备用金垫付" if v["account"] == "备用金" or pid in has_adv else "已付")
                # 之前记成「待支付」的成本行（同项目、同金额、还没对上账单）：这笔钱付出去了 → 直接对上那一行，不另加
                pend = c.execute("select id,date from lines where project_id=? and auto=0 and uid='' and pay in ('未付','预付') "
                                 "and abs(qty*price-?)<0.011 and sec<>'备用金' order by date, id limit 1", (pid, v["amount_cny"])).fetchone()
                if pend:
                    c.execute("update lines set uid=?, pay=?, date=case when date='' then ? else date end where id=?",
                              (uid, pay, v["date"], pend["id"]))
                    cf = cab_fields(v)
                    if cf:
                        c.execute("update lines set spec=case when spec='' then ? else spec end, craft=case when craft='' then ? else craft end where id=?",
                                  (cf["spec"], cf["craft"], pend["id"]))
                    lines[uid] = dict(id=pend["id"], project_id=pid, uid=uid, price=v["amount"], qty=1, auto=0)
                    continue
                sec, cat = SEC_OF_SUB.get(v["sub"], ("执行人员杂费", ""))
                seq = c.execute("select coalesce(max(seq),0)+1 from lines where project_id=? and sec=?", (pid, sec)).fetchone()[0]
                vendor = f"{v['account']}{v['date'][5:]} {v['hm']} {v['who']}"[:200]
                c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,uid,date,who,auto) "
                          "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)",
                          (pid, sec, cat, seq, *((lambda cf: (cf["name"], cf["spec"], cf["craft"]) if cf else (v["purpose"] or v["sub"] or "项目支出", "", ""))(cab_fields(v))),
                           1, "项", v["amount_cny"], vendor + (f"（{v['currency']} {v['amount']:.2f}）" if v.get("currency", "CNY") != "CNY" else ""), pay, uid, v["date"], ""))
                lines[uid] = dict(id=0, project_id=pid, uid=uid, price=v["amount"], qty=1, auto=1)
            for uid, l in lines.items():
                if l["auto"] and l["id"] and uid not in seen:
                    if nfiles.get(l["id"]):
                        c.execute("update lines set auto=0 where id=?", (l["id"],))
                    else:
                        c.execute("delete from lines where id=?", (l["id"],))

    def cost_ignore(uid):
        with store.db() as c:
            c.execute("create table if not exists cost_ignore(uid text primary key)")
            c.execute("insert or ignore into cost_ignore(uid) values(?)", (uid,))

    def _line_uids():
        """已经记成成本单「备用金」行的账单：不算项目收入。"""
        with store.db() as c:
            return {r["uid"] for r in c.execute("select uid from lines where uid<>''")}

    NOT_REVENUE = ("项目备用金入款", "项目分红", "项目报销")     # 备用金、报销是和公司的往来，分红是我自己的收入：都不是项目收入

    def project_income(name):
        used = _line_uids()                 # 记成「备用金」的收入不算项目收入
        out = [v for v in (view(t) for t in ezb_transactions() if t["type"] == 2 and _project_of(t) == name)
               if _uid_of(v) not in used and v["sub"] not in NOT_REVENUE]
        out.sort(key=lambda v: (v["date"], v["hm"]))
        return out

    def project_div(name):
        """这个项目的分红流水（以账单为准）：收入「项目分红」记正数，支出「分红转出」记负数。"""
        out = []
        for t in ezb_transactions():
            if t["type"] not in (2, 3) or _project_of(t) != name or _scope_of(t) != "工作":
                continue
            sn = _sub_name(t)
            if (t["type"] == 2 and sn == "项目分红") or (t["type"] == 3 and sn in ("分红转出", "分红提成")):
                v = view(t)
                sign = 1 if t["type"] == 2 else -1
                out.append(dict(id=0, tx_id=v["id"], uid=_uid_of(v), date=v["date"], amount=round(sign * v["amount_cny"], 2),
                                note=(v["purpose"] + " " if v["purpose"] and v["purpose"] not in ("分红", "分红转出", "分红提成") else "") + v["who"].split(" | ")[0][:60],
                                out=sign < 0, fee=sn == "分红提成", account=v["account"]))
        out.sort(key=lambda d: d["date"])
        return out

    def project_pass(name):
        """这个项目和公司之间的往来流水：备用金入款、报销到账、项目款转出（给页面列明细用）。"""
        out = []
        for t in ezb_transactions():
            if t["type"] not in (2, 3) or _project_of(t) != name or _scope_of(t) != "工作":
                continue
            sn = _sub_name(t)
            if (t["type"] == 2 and sn in ("项目备用金入款", "项目报销")) or (t["type"] == 3 and sn == "项目款转出"):
                v = view(t)
                out.append(dict(tx_id=v["id"], date=v["date"], amount=v["amount_cny"], sub=sn, who=v["who"].split(" | ")[0][:60], purpose=v["purpose"], account=v["account"]))
        out.sort(key=lambda d: d["date"])
        return out

    h["hooks"]["project_div"] = project_div
    h["hooks"]["project_pass"] = project_pass

    def tx_dates():
        out = {}
        for t in ezb_transactions():
            u = rid(t.get("comment")) or f"手动:{t['id']}"
            out[u] = datetime.fromtimestamp(t["time"], TZ).strftime("%Y-%m-%d")
        return out

    h["hooks"]["tx_dates"] = tx_dates
    h["hooks"]["project_income"] = project_income
    h["hooks"]["cost_sync"] = cost_sync
    h["hooks"]["cost_ignore"] = cost_ignore

    @app.get("/api/projects/{pid}/income-candidates")
    def income_candidates(pid: int, q: str = "", all: int = 0, exp: int = 0, mode: str = ""):
        """还没归到项目的收入（微信/支付宝账单里的），供「从账单里选」。all=1 时也列出已归了项目的（含本项目，方便改归类）。
        exp=1：列支出（选「分红转出 / 项目款转出」用）：本项目的和还没归项目的，all=1 时全部。"""
        name = _project_name(pid)
        used = _line_uids()
        # 已经是「本项目 + 这次要归的那个子类」的不用再列；本项目里别的子类的照样列出来，方便改归类（比如把「项目分红」改回「项目回款」）
        tgt = dict(income="项目回款", advance="项目备用金入款", dividend="项目分红", reimb="项目报销",
                   divout="分红转出", divfee="分红提成", passout="项目款转出").get(mode, "")
        out = []
        for t in ezb_transactions():
            if t["type"] != (3 if exp else 2):
                continue
            v = view(t)
            mine = v["project"] == name
            if mine and tgt and v["scope"] == "工作" and v["sub"] == tgt:
                continue
            if v["scope"] == "生活" and v["sub"] == "借款往来":
                continue
            if exp:
                if v["project"] and not mine and not all:
                    continue
            elif _uid_of(v) in used or (v["project"] and not mine and not all):
                continue
            if q and q.lower() not in (v["who"] + " " + v["purpose"] + " " + str(v["amount"]) + " " + v["date"]).lower():
                continue
            out.append(v)
        out.sort(key=lambda v: (v["date"], v["hm"]), reverse=True)
        out.sort(key=lambda v: 0 if v["project"] == name else (1 if v["scope"] != "生活" else 2))     # 本项目的排最前，其次工作/待确认，生活的垫底
        return dict(rows=out[:500], n=len(out))

    class PickIn(BaseModel):
        ids: List[str]
        mode: str = "income"          # income=项目回款 / advance=备用金 / dividend=我的分红到账 / reimb=公司报销到账 / divout=分红转出 / passout=项目款转出（后两个选的是支出）

    @app.post("/api/projects/{pid}/pick-income")
    def pick_income(pid: int, b: PickIn):
        name = _project_name(pid)
        ts = find(b.ids)
        if b.mode == "advance":
            with store.db() as c:
                used = {r["uid"] for r in c.execute("select uid from lines where uid<>''")}
                for t in ts:
                    v = view(t)
                    uid = _uid_of(v)
                    if uid in used:
                        continue
                    seq = c.execute("select coalesce(max(seq),0)+1 from lines where project_id=? and sec='备用金'", (pid,)).fetchone()[0]
                    c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,uid,date,who) "
                              "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                              (pid, "备用金", "", seq, "备用金", "", "", 1, "项", v["amount"], v["who"][:200], "已付", uid, v["date"],
                               v["who"].split(" | ")[0][:40]))
            n = apply([(t, dict(scope="工作", sub="项目备用金入款", project=name, purpose="备用金")) for t in ts])
        elif b.mode == "dividend":            # 分红到账以账单为准：归成「项目分红」就算到账，不另存一份
            n = apply([(t, dict(scope="工作", sub="项目分红", project=name, purpose="分红")) for t in ts if t["type"] == 2])
        elif b.mode == "reimb":
            n = apply([(t, dict(scope="工作", sub="项目报销", project=name, purpose="报销")) for t in ts if t["type"] == 2])
        elif b.mode in ("divout", "divfee", "passout"):
            sub_ = dict(divout="分红转出", divfee="分红提成", passout="项目款转出")[b.mode]
            n = apply([(t, dict(scope="工作", sub=sub_, project=name)) for t in ts if t["type"] == 3])
        else:
            n = apply([(t, dict(scope="工作", sub="项目回款", project=name)) for t in ts if t["type"] == 2])
        if n:
            cost_sync(force=True)
        return dict(n=n)

    @app.get("/api/projects/{pid}/ledger-missing")
    def ledger_missing(pid: int):
        name = _project_name(pid)
        cost_sync(force=True)
        with store.db() as c:
            used = {r["uid"] for r in c.execute("select uid from lines where uid<>''")}
        out = []
        for t in ezb_transactions():
            if t["type"] != 3 or _project_of(t) != name:
                continue
            v = view(t)
            if _uid_of(v) in used or (v["scope"] == "工作" and v["sub"] in PASS_SUBS):
                continue
            sec, cat = SEC_OF_SUB.get(v["sub"], ("执行人员杂费", ""))
            v.update(sec=sec, cat=cat, name=v["purpose"] or v["sub"] or "项目支出")
            out.append(v)
        out.sort(key=lambda v: (v["date"], v["hm"]))
        return dict(rows=out, total=round(sum(v["amount"] for v in out), 2))

    class MissItem(BaseModel):
        id: str
        sec: str
        name: str = ""
        cat: str = ""

    class MissItems(BaseModel):
        items: List[MissItem]

    @app.post("/api/projects/{pid}/ledger-missing")
    def add_missing(pid: int, b: MissItems):
        name = _project_name(pid)
        want = {i.id: i for i in b.items}
        added = 0
        with store.db() as c:
            used = {r["uid"] for r in c.execute("select uid from lines where uid<>''")}
            for t in ezb_transactions():
                if str(t["id"]) not in want or _project_of(t) != name:
                    continue
                v, it = view(t), want[str(t["id"])]
                uid = _uid_of(v)
                if uid in used or it.sec not in store.SECTIONS or it.sec == "备用金":
                    continue
                seq = c.execute("select coalesce(max(seq),0)+1 from lines where project_id=? and sec=?", (pid, it.sec)).fetchone()[0]
                vendor = f"{v['account']}{v['date'][5:]} {v['hm']} {v['who']}"[:200]
                c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,uid,date,who,auto) "
                          "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)",
                          (pid, it.sec, it.cat, seq, it.name or v["sub"] or "项目支出", "", "", 1, "项", v["amount"], vendor,
                           "已付", uid, "", ""))
                c.execute("create table if not exists cost_ignore(uid text primary key)")
                c.execute("delete from cost_ignore where uid=?", (uid,))
                used.add(uid)
                added += 1
        return dict(added=added)

    @app.get("/api/project-names")
    def project_names():
        with store.db() as c:
            names = [r[0] for r in c.execute("select name from projects order by id desc")]
        rules = bt.load_json(bt.RULES, None) or {}
        for p in list(rules.get("项目", {})) + sorted({_project_of(t) for t in ezb_transactions() if _project_of(t)}):
            if p and p not in names:
                names.append(p)
        with store.db() as c:                       # 各项目给月份起的名字，也能直接选
            for r in c.execute("select p.name pn, s.name sn from segs s join projects p on p.id=s.project_id where s.name<>'' order by s.month desc"):
                x = f"{r['pn']}{SEP}{r['sn']}"
                if x not in names:
                    names.append(x)
        return h["dd_filter"]("projects", names) if h.get("dd_filter") else names

    class SegIn(BaseModel):
        month: str
        name: str = ""

    @app.put("/api/projects/{pid}/segs")
    def set_seg(pid: int, b: SegIn):
        nm = (b.name or "").strip().replace(SEP, " ")[:30]
        with store.db() as c:
            if nm:
                c.execute("insert into segs(project_id,month,name) values(?,?,?) on conflict(project_id,month) do update set name=excluded.name", (pid, b.month, nm))
            else:
                c.execute("delete from segs where project_id=? and month=?", (pid, b.month))
        return dict(ok=True)

    PAYS = ["未付", "预付", "已付", "备用金垫付", "无需付款"]       # 和成本单「付款情况」下拉一模一样

    def pay_map():
        with store.db() as c:
            return {r["uid"]: r["pay"] for r in c.execute("select uid,pay from lines where uid<>'' and sec<>'备用金'")}

    def with_pay(v, pm=None):
        pm = pm if pm is not None else pay_map()
        u = v["uid"] or f"手动:{v['id']}"
        if u in pm:
            v["pay"] = pm[u]
        return v

    @app.get("/api/tx")
    def list_tx(month: str = "", scope: str = "", q: str = "", project: str = "", type: str = "", sub: str = "", batch: int = 0, limit: int = 2000,
                d1: str = "", d2: str = "", account: str = ""):
        out = []
        only = None
        if batch:
            import json as _j
            with store.db() as c:
                b = c.execute("select rows from batches where id=?", (batch,)).fetchone()
            only = {r["uid"] for r in _j.loads(b["rows"]) if r.get("status") != "exists"} if b else set()
        for t in ezb_transactions():
            if t["type"] not in (2, 3, 4):
                continue
            v = view(t)
            if t["type"] == 4 and (scope not in ("", "转账") or type not in ("", "tr") or project or sub):
                continue
            if only is not None and v["uid"] not in only:
                continue
            if month and v["date"][:7] != month:
                continue
            if (d1 and v["date"] < d1) or (d2 and v["date"] > d2):          # 按日期段（交易日历点某一天、今天/本周…）
                continue
            if account and account not in (v["account"], v.get("to_account")):
                continue
            if scope == "我的":                            # 我的收入 = 生活收入 + 项目分红 − 分红转出；我的支出 = 生活支出（和总览的数一致）
                life = v["scope"] == "生活" and v["sub"] != "借款往来"
                if type == "exp":
                    ok = v["type"] == "exp" and life
                else:
                    ok = (v["type"] == "inc" and (life or (v["scope"] == "工作" and v["sub"] == "项目分红"))) or \
                         (v["type"] == "exp" and v["scope"] == "工作" and v["sub"] in ("分红转出", "分红提成"))
                if not ok:
                    continue
            else:
                if scope and v["scope"] != scope:
                    continue
                if type and v["type"] != type:
                    continue
            if sub and v["sub"] != sub:
                continue
            if project == "(无项目)" and v["project"]:
                continue
            if project and project != "(无项目)" and v["project"] != project:
                continue
            if q and q.lower() not in (v["who"] + " " + v["purpose"] + " " + v["sub"] + " " + v["project"]).lower() and q not in str(v["amount"]):
                continue
            out.append(v)
        out.sort(key=lambda v: (v["date"], v["hm"]), reverse=True)
        pm = pay_map()
        for v in out[:limit]:
            with_pay(v, pm)
        tot = dict(exp=round(sum(v["amount_cny"] for v in out if v["type"] == "exp"), 2), inc=round(sum(v["amount_cny"] for v in out if v["type"] == "inc"), 2))
        if scope == "我的" and type != "exp":               # 分红转出从我的收入里扣掉
            tot = dict(exp=0.0, inc=round(tot["inc"] - tot["exp"], 2), div_out=tot["exp"])
        months = sorted({_month_of(t) for t in ezb_transactions() if t["type"] in (2, 3)} | {date.today().strftime("%Y-%m")}, reverse=True)
        return dict(n=len(out), tot=tot, rows=out[:limit], months=months, truncated=len(out) > limit)

    class TxEdit(BaseModel):
        scope: Optional[str] = None
        sub: Optional[str] = None
        project: Optional[str] = None
        purpose: Optional[str] = None
        who: Optional[str] = None
        amount: Optional[float] = None
        date: Optional[str] = None
        hm: Optional[str] = None
        account: Optional[str] = None
        type: Optional[str] = None
        pay: Optional[str] = None

    class LoanIn(BaseModel):
        mode: str                  # lend 我借给别人（支出）/ borrow 别人借给我（收入）/ repay 还款（支出=我还别人；收入=别人还我）/ credit 我赊账（支出，钱还没付）
        name: str = ""
        due_date: str = ""
        note: str = ""
        debt_id: int = 0

    @app.post("/api/tx/{tid}/loan")
    def tx_loan(tid: str, b: LoanIn):
        """把一笔账记成借款 / 还款：在「借款 / 还款」里生成对应记录并关联这笔账；这笔账归到 生活·借款往来，不算收入也不算支出。"""
        from types import SimpleNamespace as NS
        t = find([tid])[0]
        v = view(t)
        uid = rid(t.get("comment")) or f"手动:{tid}"
        with store.db() as c:
            if c.execute("select 1 from debts where tx_uid=? union select 1 from repayments where tx_uid=?", (uid, uid)).fetchone():
                raise HTTPException(400, "这笔账已经关联过借款/还款了，到「数据看板 → 借款 / 还款」里改")
        name = (b.name or "").strip() or v["who"].split(" | ")[0][:20]
        undo_begin({"lend": "借出", "borrow": "借入", "repay": "还款", "credit": "赊账"}.get(b.mode, "借款") + "·" + name)
        try:
            return _tx_loan(t, tid, v, uid, name, b, NS)
        finally:
            undo_commit()

    CREDIT_ACC = "赊账"           # 赊账专用账户（负债）：赊账时消费记在这里，还钱时「我的账户 → 赊账」转账

    def credit_acc():
        """确保「赊账」账户存在，并从 0 开始算余额（项目台「我的钱」才会把它算进负债）。返回账户 id。"""
        aid = account_id(ezb(), CREDIT_ACC)
        with store.db() as c:
            c.execute("insert or ignore into acc_cal(name,balance,as_of,hidden) values(?,0,0,0)", (CREDIT_ACC,))
        invalidate()
        return aid

    def _to_credit_transfer(t, tid):
        """还赊账的那笔支出 → 改成「我的账户 → 赊账」转账：不再算支出（消费在赊账时已经算过），赊账账户的欠款减少。"""
        from types import SimpleNamespace as NS
        from api_import import _flat_categories, acc_name
        credit_acc()
        undo_snap(t)
        return _tx_transfer(t, tid, NS(to_account=CREDIT_ACC, to_amount=0, from_account="", amount=0), _flat_categories, acc_name)

    def _tx_loan(t, tid, v, uid, name, b, NS):
        if b.mode == "credit":
            if v["type"] != "exp":
                raise HTTPException(400, "赊账要选一笔「支出」（买了什么、花了多少）")
            h["add_debt"](NS(name=name, direction="owe", amount=v["amount"], borrow_date=v["date"],
                             due_date=b.due_date, remind_days=3, note=b.note, mac_reminder=1 if b.due_date else 0))
            with store.db() as c:
                did = h["last"].debt
                c.execute("update debts set tx_uid=?, kind='credit' where id=?", (uid, did))
            undo_sql("delete from repayments where debt_id=?", (did,))
            undo_sql("delete from debts where id=?", (did,))
            if v["account"] != CREDIT_ACC:              # 钱没从我账户出：这笔挪到「赊账」账户（分类照旧，照样算这次消费）
                credit_acc()
                apply([(t, dict(account=CREDIT_ACC))])
            nt = [x for x in ezb_transactions(force=True) if str(x["id"]) == tid]
            return with_pay(view(nt[0])) if nt else dict(ok=True)
        if b.mode in ("lend", "borrow"):
            if (b.mode == "lend") != (v["type"] == "exp"):
                raise HTTPException(400, "借给别人要选一笔「支出」，别人借给我要选一笔「收入」")
            h["add_debt"](NS(name=name, direction="lent" if b.mode == "lend" else "owe", amount=v["amount"], borrow_date=v["date"],
                             due_date=b.due_date, remind_days=3, note=b.note, mac_reminder=1 if b.due_date else 0))
            with store.db() as c:
                did = h["last"].debt
                c.execute("update debts set tx_uid=? where id=?", (uid, did))
            undo_sql("delete from repayments where debt_id=?", (did,))
            undo_sql("delete from debts where id=?", (did,))
            purpose = ("借出·" if b.mode == "lend" else "借入·") + name
        elif b.mode == "repay":
            with store.db() as c:
                d = c.execute("select * from debts where id=?", (b.debt_id,)).fetchone()
            if not d:
                raise HTTPException(400, "请选是还哪一笔借款")
            if (d["direction"] == "owe") != (v["type"] == "exp"):
                raise HTTPException(400, "我还别人的钱要选「支出」，别人还我的钱要选「收入」")
            h["repay"](b.debt_id, NS(date=v["date"], amount=v["amount"], note=b.note or "来自账单"))
            with store.db() as c:
                c.execute("update repayments set tx_uid=? where id=?", (uid, h["last"].repay))
            undo_sql("delete from repayments where tx_uid=?", (uid,))
            if (d["kind"] if "kind" in d.keys() else "") == "credit":      # 还赊账：记成转账到「赊账」账户，不重复算支出
                return with_pay(_to_credit_transfer(t, tid))
            purpose = "还款·" + d["name"]
        else:
            raise HTTPException(400, "mode 只能是 lend / borrow / repay / credit")
        apply([(t, dict(scope="生活", sub="借款往来", purpose=purpose, project=""))])
        nt = [x for x in ezb_transactions(force=True) if str(x["id"]) == tid]
        return with_pay(view(nt[0])) if nt else dict(ok=True)

    class SettleIn(BaseModel):
        date: str = ""
        account: str = ""
        amount: float = 0           # 还一部分：填多少就记多少；不填 = 剩下的全还
        note: str = ""

    @app.post("/api/debts/{did}/settle")
    def debt_settle(did: int, b: SettleIn):
        """「已还款」：把剩下的钱一次记成还款 → 借款变成「已还清」，记账本里补一笔「生活·借款往来」的还款（我还别人 = 支出；别人还我 = 收入）。
        以后导入的账单里有同一笔，会自动和这笔合并，不重复。"""
        with store.db() as c:
            d = c.execute("select * from debts where id=?", (did,)).fetchone()
            if not d:
                raise HTTPException(404, "没有这笔借款")
            paid = c.execute("select coalesce(sum(amount),0) from repayments where debt_id=?", (did,)).fetchone()[0]
        remain = round(d["amount"] - paid, 2)
        if remain <= 0.005:
            raise HTTPException(400, "这笔已经还清了")
        if b.amount and b.amount > 0:
            if b.amount > remain + 0.005:
                raise HTTPException(400, f"还款金额比还剩的 ¥{remain:.2f} 多")
            remain = round(b.amount, 2)
        partial = remain < round(d["amount"] - paid, 2) - 0.005
        day = b.date or date.today().isoformat()
        acc = b.account
        if not acc and d["tx_uid"]:                       # 默认用借款那笔账的账户
            hit = [x for x in ezb_transactions() if rid(x.get("comment")) == d["tx_uid"] or f"手动:{x['id']}" == d["tx_uid"]]
            acc = view(hit[0])["account"] if hit else ""
        if acc == CREDIT_ACC:                             # 赊账那笔记在「赊账」账户上：还钱要从你自己的账户出
            acc = ""
        acc = acc or "微信零钱"
        uid = f"还款:{uuid.uuid4().hex[:12]}"
        v = dict(date=day, hm=datetime.now(TZ).strftime("%H:%M"), type="exp" if d["direction"] == "owe" else "inc", amount=remain,
                 who=("还给 " if d["direction"] == "owe" else "收回 ") + d["name"], scope="生活", sub="借款往来",
                 project="", purpose="还款·" + d["name"], account=acc)
        undo_begin(("我还了 ¥%.2f·" % remain if d["direction"] == "owe" else "对方还了 ¥%.2f·" % remain) + d["name"])
        push_rows(ezb(), [build_row(v, uid)], log=lambda *_: None)
        undo_created(uid)
        invalidate()
        if (d["kind"] if "kind" in d.keys() else "") == "credit":          # 还赊账：补的这笔改成「我的账户 → 赊账」转账
            nt = [x for x in ezb_transactions(force=True) if rid(x.get("comment")) == uid]
            if nt:
                _to_credit_transfer(nt[0], str(nt[0]["id"]))
        from types import SimpleNamespace as NS
        h["repay"](did, NS(date=day, amount=remain, note=b.note or ("还一部分" if partial else "已还款（一键）")))
        with store.db() as c:
            c.execute("update repayments set tx_uid=? where id=?", (uid, h["last"].repay))
        undo_sql("delete from repayments where tx_uid=?", (uid,))
        undo_commit()
        return h["list_debts"]()

    def drop_loan_tx(uid, created_only=False):
        """借款/还款记录删掉时，账单这边跟着改：一键还款补的那笔直接删；来自账单的那笔改回「待确认」。"""
        if not uid:
            return
        ts = [x for x in ezb_transactions(force=True) if rid(x.get("comment")) == uid or f"手动:{x['id']}" == uid]
        if not ts:
            return
        t = ts[0]
        acc_to = (t.get("destinationAccount") or {}).get("name", "") if t["type"] == 4 else ""
        acc_from = (t.get("sourceAccount") or {}).get("name", "")
        if uid.startswith("还款:"):
            delete_txs(ts)
        elif created_only:
            return
        elif t["type"] == 4 and acc_to == CREDIT_ACC:      # 还赊账的转账：改回普通支出（放「待确认」）
            from types import SimpleNamespace as NS
            from api_import import _flat_categories, acc_name
            undo_snap(t)
            _tx_transfer(t, str(t["id"]), NS(to_account="", to_amount=0, from_account="", amount=0), _flat_categories, acc_name)
        elif t["type"] == 3 and acc_from == CREDIT_ACC:    # 赊账那笔消费：赊账记录删了，这笔也移到「最近删除」（可恢复）
            delete_txs(ts)
        else:
            apply([(t, dict(scope="待确认", sub="", purpose=""))])

    h["hooks"]["drop_loan_tx"] = drop_loan_tx

    class TrIn(BaseModel):
        to_account: str = ""        # 留空 = 改回普通支出
        to_amount: float = 0        # 到账金额（按转入账户的币种）
        from_account: str = ""      # 改转出账户（留空 = 不改）
        amount: float = 0           # 改转出金额（按转出账户的币种；0 = 不改）

    @app.post("/api/tx/{tid}/transfer")
    def tx_transfer(tid: str, b: TrIn):
        """自己账户之间挪钱（如微信零钱 → 美元卡充值）：改成「转账」，不算收入也不算支出；两边账户余额各自变化（可以跨币种）。"""
        from api_import import _flat_categories, acc_name
        t = find([tid])[0]
        undo_begin(("改回支出·" if not b.to_account else "改成转账·") + view(t)["who"][:20])
        undo_snap(t)
        try:
            return _tx_transfer(t, tid, b, _flat_categories, acc_name)
        finally:
            undo_commit()

    def _tx_transfer(t, tid, b, _flat_categories, acc_name):
        api = ezb()
        accs = {a["name"]: a for a in api.call("GET", "/api/v1/accounts/list.json")}
        base = dict(id=str(t["id"]), time=t["time"], utcOffset=t["utcOffset"], sourceAccountId=str(t["sourceAccountId"]),
                    sourceAmount=t["sourceAmount"], hideAmount=t.get("hideAmount", False), tagIds=[],
                    pictureIds=[p_["pictureId"] for p_ in (t.get("pictures") or [])], comment=t.get("comment") or "")
        flat = _flat_categories(api)
        if not b.to_account:                               # 改回支出：放到「待确认」，再自己归类
            if t["type"] != 4:
                raise HTTPException(400, "这笔不是转账")
            cid = next((c["id"] for c in flat if c["type"] == 2 and c.get("parentId") not in (None, "0", 0) and c["name"].endswith("未分类")), None) \
                or next(c["id"] for c in flat if c["type"] == 2 and c.get("parentId") not in (None, "0", 0))
            h["ezb_modify_tx"](api, dict(base, type=3, categoryId=str(cid), destinationAccountId="0", destinationAmount=0))
        else:
            to = accs.get(acc_name(b.to_account))
            if not to:
                raise HTTPException(400, "没有这个账户")
            if b.from_account:                              # 改转出账户
                fr = accs.get(acc_name(b.from_account))
                if not fr:
                    raise HTTPException(400, "没有这个转出账户")
                base["sourceAccountId"] = str(fr["id"])
            if b.amount and b.amount > 0:                   # 改转出金额
                base["sourceAmount"] = int(round(b.amount * 100))
            if str(to["id"]) == str(base["sourceAccountId"]):
                raise HTTPException(400, "转出和转入不能是同一个账户")
            if t["type"] == 2:                              # 收入那一笔：对方账户转进来的 → 方向反过来
                raise HTTPException(400, "请在「转出」的那一笔（支出）上改成转账")
            cid = next((c["id"] for c in flat if c["type"] == 3 and c["name"] == "账户互转"), None)
            if not cid:
                par = next((c["id"] for c in flat if c["type"] == 3 and str(c.get("parentId", "0")) in ("0", "None")), None)
                if not par:
                    par = api.call("POST", "/api/v1/transaction/categories/add.json", dict(name="转账", type=3, parentId="0", icon="1", iconType=0, color="888888", comment=""))["id"]
                cid = api.call("POST", "/api/v1/transaction/categories/add.json", dict(name="账户互转", type=3, parentId=str(par), icon="1", iconType=0, color="888888", comment=""))["id"]
            amt_to = int(round((b.to_amount or base["sourceAmount"] / 100) * 100))
            # 软件自动写的「转账 A → B」备注：账户改了就跟着改（你自己写的备注不动）
            byid = {str(a["id"]): n_ for n_, a in accs.items()}
            o_from, o_to = byid.get(str(t["sourceAccountId"]), ""), byid.get(str(t.get("destinationAccountId") or 0), "")
            n_from = byid.get(str(base["sourceAccountId"]), "")
            if n_from and re.search(r"转账 [^〔】|]+? → [^〔】|]+", base["comment"]):
                base["comment"] = re.sub(r"转账 [^〔】|]+? → [^〔】|]+", f"转账 {n_from} → {to['name']}", base["comment"], count=1)
            h["ezb_modify_tx"](api, dict(base, type=4, categoryId=str(cid), destinationAccountId=str(to["id"]), destinationAmount=amt_to))
        invalidate()
        nt = [x for x in ezb_transactions(force=True) if str(x["id"]) == tid]
        return view(nt[0]) if nt else dict(ok=True)

    @app.get("/api/tx/one/{tid}")
    def one_tx(tid: str):
        return with_pay(view(find([tid])[0]))

    @app.put("/api/tx/{tid}")
    def edit_tx(tid: str, b: TxEdit):
        t = find([tid])[0]
        undo_begin("改了「" + view(t)["who"][:20] + "」")
        try:
            return _edit_tx(t, tid, b)
        finally:
            undo_commit()

    def _edit_tx(t, tid, b):
        ch = b.dict()
        pay = ch.pop("pay", None)
        if pay and pay not in PAYS:
            raise HTTPException(400, "付款情况只能是：" + "、".join(PAYS))
        apply([(t, ch)])
        if pay:                                     # 付款情况跟着改到对应的成本行
            cost_sync(force=True)
            u = rid(t.get("comment")) or f"手动:{tid}"
            with store.db() as c:
                for r_ in c.execute("select id,pay from lines where uid=? and sec<>'备用金'", (u,)).fetchall():
                    undo_sql("update lines set pay=? where id=?", (r_["pay"], r_["id"]))
                c.execute("update lines set pay=? where uid=? and sec<>'备用金'", (pay, u))
                c.execute("create table if not exists tx_pay(uid text primary key, pay text)")
                c.execute("insert or replace into tx_pay(uid,pay) values(?,?)", (u, pay))
        nt = [x for x in ezb_transactions(force=True) if str(x["id"]) == tid] or \
             [x for x in ezb_transactions() if rid(x.get("comment")) == (rid(t.get("comment")) or f"手动:{tid}")]
        out = with_pay(view(nt[0])) if nt else dict(ok=True)
        if notes:
            out["note"] = "；".join(notes)
        return out

    class Batch(BaseModel):
        ids: List[str]
        scope: Optional[str] = None
        sub: Optional[str] = None
        project: Optional[str] = None
        purpose: Optional[str] = None
        account: Optional[str] = None
        remember: bool = False
        delete: bool = False

    @app.post("/api/tx/batch")
    def batch_tx(b: Batch):
        ts = find(b.ids)
        if b.delete:
            delete_txs(ts)
            return dict(n=len(ts), deleted=True)
        ch = {k: v for k, v in b.dict().items() if k in ("scope", "sub", "project", "purpose", "account") and v not in (None, "")}
        if not ch:
            raise HTTPException(400, "请至少选一项要改的内容")
        n = apply([(t, ch) for t in ts])
        if b.remember:                                # 记住：以后同一个对象自动这样归
            import json
            learned = bt.load_json(bt.LEARNED, {})
            for t in ts:
                v = view(t)
                cp = v["who"].split(" | ")[0].strip().lower()
                if cp:
                    L = learned.get(cp, {})
                    learned[cp] = dict(scope=ch.get("scope") or L.get("scope") or v["scope"], sub=ch.get("sub") or L.get("sub") or "",
                                       project="" if ch.get("project") == "(无项目)" else (ch.get("project") or L.get("project", "")),
                                       purpose=ch.get("purpose") or L.get("purpose", ""))
            store.write_json(bt.LEARNED, learned)
        return dict(n=n, note="；".join(sorted(set(notes))))

    @app.delete("/api/tx/{tid}")
    def del_tx(tid: str):
        delete_txs(find([tid]))
        return dict(ok=True)

    # ---------------- 快速记账：一行一笔，「午饭 35」「打车 48 项目A」「+5000 回款 项目A」「昨天 超市 126.5 支付宝」
    QUICK_WORDS = {
        ("生活", "餐饮"): ("早饭", "午饭", "晚饭", "早餐", "午餐", "晚餐", "夜宵", "外卖", "吃饭", "饭", "咖啡", "奶茶", "水果", "零食", "买菜", "饮料", "面包"),
        ("生活", "交通出行"): ("打车", "地铁", "公交", "停车", "加油", "高铁", "火车", "机票", "单车"),
        ("生活", "居家"): ("房租", "水费", "电费", "燃气", "物业", "话费", "宽带", "日用"),
        ("生活", "购物"): ("衣服", "鞋", "淘宝", "京东", "拼多多", "网购"),
        ("生活", "娱乐订阅"): ("电影", "游戏", "会员", "ktv", "网吧", "网咖"),
        ("生活", "医疗健康"): ("药", "医院", "看病", "体检", "健身"),
        ("生活", "人情往来"): ("红包", "礼物", "请客", "份子"),
        ("生活", "烟酒"): ("烟", "酒"),
        ("生活", "休闲护理"): ("理发", "按摩", "足疗", "洗澡", "美发"),
    }
    ACCOUNTS = ("微信零钱通", "零钱通", "微信零钱", "零钱", "微信", "支付宝", "余额宝", "花呗", "现金", "备用金", "银行卡", "信用卡")
    INCOME_WORDS = ("收入", "收到", "回款", "工资", "报销到账", "退款", "进账")

    _banks = {"t": 0, "v": []}

    def bank_accounts():
        import time as _t
        if _t.time() - _banks["t"] > 60:
            try:
                _banks["v"] = [x["name"] for x in ezb().call("GET", "/api/v1/accounts/list.json") if re.search(r"银行|储蓄卡|信用卡|借记卡", x["name"])]
            except Exception:
                pass
            _banks["t"] = _t.time()
        return _banks["v"]

    CAB = re.compile(r"打车|出租车?|滴滴|网约车|曹操|花小猪|首汽|如祺|享道|嘀嗒|快车|专车|车费|的士")
    SHIP_Q = re.compile(r"快递|物流|顺丰|货拉拉|快狗|运费|寄件|邮寄|闪送|德邦|中通|圆通|韵达|申通|极兔|邮政|货运|搬运|托运|运输", re.I)

    def acc_name_(n):
        from api_import import acc_name
        return acc_name(n)

    def default_hm(day):
        """没写时间：一律用记账时的当前时间（几点几分）"""
        return datetime.now(TZ).strftime("%H:%M")

    def acc_cur_map():
        try:
            return {x["name"]: (x.get("currency") or "CNY").upper() for x in ezb().call("GET", "/api/v1/accounts/list.json")}
        except Exception:
            return {}

    def acc_for_cur(cur):
        """外币的账默认记到同币种的账户（比如美元 → 你的美元卡）；没有就记微信零钱（保存时按汇率折成人民币）"""
        if cur and cur != "CNY":
            hit = [n for n, c in acc_cur_map().items() if c == cur]
            if hit:
                return hit[0]
        return "微信零钱"

    def acc_fix(a):
        """记一笔里写的账户简称 → 账户名（零钱通→微信零钱通；「工行」→ 工商银行储蓄卡(1234) 这种已有账户）"""
        a = {"零钱通": "微信零钱通", "零钱": "微信零钱", "微信": "微信零钱"}.get(a, a)
        if a in ("银行卡", "信用卡"):
            try:
                hit = [x["name"] for x in ezb().call("GET", "/api/v1/accounts/list.json") if (("信用卡" if a == "信用卡" else "储蓄卡") in x["name"])]
                if len(hit) == 1:
                    return hit[0]
            except Exception:
                pass
        return a

    def parse_line(line, base_day, projects, rules, learned):
        s = line.strip()
        if not s:
            return None
        typ = "inc" if s.startswith("+") or any(w in s for w in INCOME_WORDS) else "exp"
        day = base_day
        rest = s
        for pat, delta in (("前天", -2), ("昨天", -1), ("今天", 0)):
            if pat in rest:
                day = base_day + timedelta(days=delta)
                rest = rest.replace(pat, " ")
        hm = ""
        mt = re.search(r"(?<![\d.])([01]?\d|2[0-3])(?::|：|点)([0-5]\d)(?:分)?(?![\d.])", rest)     # 「14:30」「9点05」
        if mt:
            hm = f"{int(mt.group(1)):02d}:{mt.group(2)}"
            rest = rest.replace(mt.group(0), " ")
        m = re.search(r"(?:(20\d\d)[-/年])?(?<![\d.])(\d{1,2})[-/月](\d{1,2})日?(?![\d.])", rest)
        if m:
            try:
                day = date(int(m.group(1) or base_day.year), int(m.group(2)), int(m.group(3)))
                rest = rest.replace(m.group(0), " ")
            except ValueError:
                pass
        currency = "CNY"
        for cur_, pat_ in (("USD", r"(?i)us\$|usd|美元|美金|\$"), ("HKD", r"(?i)hk\$|hkd|港币|港元"), ("EUR", r"(?i)eur|欧元|€"),
                           ("JPY", r"(?i)jpy|日元|円"), ("GBP", r"(?i)gbp|英镑|£")):
            if re.search(pat_, rest):
                currency = cur_
                rest = re.sub(pat_, " ", rest)
                break
        nums = list(re.finditer(r"[+-]?\d+(?:\.\d{1,2})?", rest))
        if not nums:
            return dict(raw=line, error="没找到金额")
        n = nums[-1]
        amount = abs(float(n.group(0)))
        rest = (rest[:n.start()] + " " + rest[n.end():]).replace("元", " ").replace("块", " ")
        account = "备用金" if "备用金" in rest else ""
        rest = re.sub(r"备用金(垫付|支付)|无需付款|不用付|待支付|待付|未付|没付|已付|预付", " ", rest)   # 付款情况前端另外识别
        for a in ACCOUNTS:
            if a in rest:
                account = account or a
                rest = rest.replace(a, " ")
                break
        if not account:                                   # 银行卡简称：「工行」「建行」「交通」→ 已有的那张卡
            for n in bank_accounts():
                short = re.sub(r"(银行)?(储蓄卡|信用卡|借记卡).*$", "", n)
                for k in {short, short[:2]}:
                    if len(k) >= 2 and re.search(rf"(^|\s){re.escape(k)}(银行|卡)?(\s|$)", rest):
                        account = n
                        rest = re.sub(rf"(^|\s){re.escape(k)}(银行|卡)?(\s|$)", " ", rest)
                        break
                if account:
                    break
        scope = ""
        for w in ("工作", "生活"):
            if re.search(rf"(^|\s){w}(\s|$)", rest):
                scope = w
                rest = re.sub(rf"(^|\s){w}(\s|$)", " ", rest)
        project, why_pj = "", ""
        toks = [x for x in re.split(r"\s+", rest) if x]
        for tok in toks:
            hit = [p for p in projects if tok == p] or ([p for p in projects if len(tok) >= 2 and tok in p] if len(tok) >= 2 else [])
            if len(hit) == 1 or (hit and tok in hit):
                project = tok if tok in hit else hit[0]
                toks.remove(tok)
                break
        if not project:                                   # 没空格也能认：「运动会项目打车」→ 春季运动会项目
            joined = "".join(toks)
            project, span = fuzzy_project(joined, projects, rules or {})
            if project:
                why_pj = f"关键词「{span}」→ 项目"
                left = re.sub(r"^(项目|活动)", "", joined.replace(span, " ", 1).strip()).strip()
                left = re.sub(r"(项目|活动)$", "", left).strip()
                toks = [x for x in re.split(r"\s+", left) if x]
        who = " ".join(toks).strip(" +-") or ("收入" if typ == "inc" else "支出")
        rfrom = rto = ""
        if CAB.search(who) or SHIP_Q.search(who):         # 「打车 公司到场馆」「滴滴 公司→场馆」「顺丰 公司到场馆」：起点/终点单独拿出来
            is_ship = not CAB.search(who)
            m = re.search(r"(?:从)?([^\s到→\-—至]{1,20}?)\s*(?:到|→|->|—|-|至)\s*([^\s到→\-—至]{1,20})", (SHIP_Q if is_ship else CAB).sub(" ", who))
            if m:
                rfrom, rto = m.group(1).strip(), m.group(2).strip()
                who = re.sub(r"\s+", " ", who.replace(m.group(0), " ")).strip() or ("快递物流" if is_ship else "打车")
        key = re.sub(r"\s+", "", who)
        mem = quick_memory(key)
        if mem:                                           # 你之前改过同样写法的分配：直接照你的来
            return dict(raw=line, key=key, date=day.isoformat(), hm=hm or default_hm(day), type=typ, amount=amount, who=who,
                        scope=scope or mem.get("scope") or "待确认", sub=mem.get("sub", ""),
                        project=project or mem.get("project", ""), purpose=mem.get("purpose", ""),
                        account=acc_fix(account or mem.get("account") or acc_for_cur(currency)), currency=currency, **{"from": rfrom, "to": rto}, why=f"按你上次的改法（「{mem['_k']}」）")
        d = dict(cp=who, item="", note="", typ="", kind="收入" if typ == "inc" else "支出", time=f"{day} 12:00:00", uid="")
        try:
            c = bt.classify(d, rules, learned, {}) if rules else {}
        except Exception:
            c = {}
        if c.get("scope") in (None, "待确认") and not project:
            low = who.lower()
            for (fs, fsub), ws in QUICK_WORDS.items():
                if any(w in low for w in ws):
                    c = dict(scope=fs, sub=fsub, project="", purpose="", why="常用词")
                    break
        sc = scope or ("工作" if project else c.get("scope", "待确认"))
        sub = c.get("sub", "") if c.get("scope") == sc else ""
        if not sub:
            sub = default_sub("", "", sc, typ)
        if not project and sc == "工作":
            project = c.get("project", "")
        purpose = c.get("purpose", "")
        if sc == "工作" and project and not purpose:
            purpose = next((w for ws in QUICK_WORDS.values() for w in ws if len(w) >= 2 and w in who), "") or who[:20]
        return dict(raw=line, key=key, date=day.isoformat(), hm=hm or default_hm(day), type=typ, amount=amount, who=who, scope=sc, sub=sub.replace("工作-", ""),
                    project=project, purpose=purpose, account=acc_fix(account or acc_for_cur(currency)), currency=currency, **{"from": rfrom, "to": rto},
                    why="；".join(x for x in (why_pj, c.get("why", "") if not why_pj else "") if x))

    GENERIC = r"20\d\d|项目|活动|马拉松|半程|全程|全国|锦标赛|庆典|两周年|周年|站|大会|女子|\d+KM|\d+"

    def fuzzy_project(text, projects, rules):
        """在一整句里找项目：别名 > 项目全名 > 项目名里的特征词（去掉年份/项目/活动/马拉松等通用词后，连续 ≥3 个字一样）。
        品牌总称要原样出现才算。返回 (项目, 句子里命中的那段)。"""
        if not text:
            return "", ""
        low = text.lower()
        alias = {k.lower(): v for k, v in (rules.get("项目别名") or {}).items() if not k.startswith("说明")}
        for k in sorted(alias, key=len, reverse=True):
            if len(k) >= 2 and k in low:
                i = low.index(k)
                return alias[k], text[i:i + len(k)]
        for p in sorted(projects, key=len, reverse=True):
            if len(p) >= 2 and p.lower() in low:
                i = low.index(p.lower())
                return p, text[i:i + len(p)]
        best, bp, bspan = 0, "", ""
        for p in projects:
            for core in re.split(GENERIC, p, flags=re.I):
                core = core.strip(" -_·").lower()
                if len(core) < 2:
                    continue
                n = _lcs(core, low)                        # (长度, 在 text 里的起点)
                need = 3 if len(core) >= 3 else 2
                if re.fullmatch(r"[a-z0-9 ]+", core) and not re.search(rf"(?<![a-z]){re.escape(core)}(?![a-z])", low):
                    continue                                    # 英文项目名要整个词对上（abc 不能从 abcd 里认出来）
                if n[0] == 2 and core[:2] in low and len(core) >= 3 and re.fullmatch(r"[\u4e00-\u9fa5]{2}", core[:2]):   # 开头两个汉字（多是城市名）也算；英文不算（claude ≠ CLC）
                    n = (2.5, low.index(core[:2]))
                    need = 2.5
                if n[0] >= need and n[0] > best:
                    best, bp, bspan = n[0], p, text[n[1]:n[1] + int(n[0])]
                elif n[0] >= need and n[0] == best and bp != p:
                    bp = bp if len(bp) <= len(p) else p   # 同分：取名字短的（更像具体项目）
        return (bp, bspan) if bp else ("", "")

    def _lcs(a, b):
        best, pos = 0, 0
        for i in range(len(a)):
            for j in range(len(b)):
                k = 0
                while i + k < len(a) and j + k < len(b) and a[i + k] == b[j + k]:
                    k += 1
                if k > best:
                    best, pos = k, j
        return best, pos

    QUICK_MEM = os.path.join(os.path.dirname(bt.LEARNED), "快速记账记忆.json")

    def quick_memory(key):
        if not key:
            return None
        mem = bt.load_json(QUICK_MEM, {})
        if key in mem:
            return dict(mem[key], _k=key)
        for k in sorted(mem, key=len, reverse=True):      # 写法里包含你记住过的词（≥2 字）
            if len(k) >= 2 and k in key:
                return dict(mem[k], _k=k)
        return None

    def quick_learn(rows):
        """保存时：你改过的识别结果记下来，下次同样的写法直接按你的改。"""
        mem = bt.load_json(QUICK_MEM, {})
        n = 0
        for v in rows:
            o, k = v.get("orig") or {}, (v.get("key") or "").strip()
            if not o or not k or k in ("支出", "收入"):
                continue
            keys = ("scope", "sub", "project", "purpose")
            if any((v.get(x) or "") != (o.get(x) or "") for x in keys):
                mem[k] = {x: (v.get(x) or "") for x in keys}
                if mem[k]["project"] == "(无项目)":
                    mem[k]["project"] = ""
                n += 1
        if n:
            store.write_json(QUICK_MEM, mem)

    class Quick(BaseModel):
        text: str
        date: str = ""

    @app.post("/api/tx/quick/parse")
    def quick_parse(b: Quick):
        base = datetime.strptime(b.date, "%Y-%m-%d").date() if b.date else date.today()
        with store.db() as c:
            projects = [r[0] for r in c.execute("select name from projects")]
        rules = bt.load_json(bt.RULES, None)
        projects += [p for p in (rules or {}).get("项目", {}) if p not in projects]
        projects += sorted({_project_of(t) for t in ezb_transactions() if _project_of(t)} - set(projects))
        learned = bt.load_json(bt.LEARNED, {})
        rows = [r for r in (parse_line(x, base, projects, rules, learned) for x in b.text.splitlines()) if r]
        return dict(rows=rows)

    class QuickRows(BaseModel):
        rows: List[dict]
        ids: bool = False           # True：把每一笔在记账本里的 id 一起回传（表单记借款 / 转账时要接着用）

    @app.post("/api/tx/quick/save")
    def quick_save(b: QuickRows):
        undo_begin(f"记一笔（{len(b.rows)} 笔）")
        try:
            return _quick_save(b)
        finally:
            undo_commit()

    def _quick_save(b):
        rows, pending, refs = [], 0, []      # refs：每一笔存到哪了（记账本的 uid 或成本行 id），前端用它把这笔带的发票 / 行程单挂上去
        try:
            quick_learn(b.rows)
        except Exception:
            pass
        for i_, v in enumerate(b.rows):
            if v.get("error") or not v.get("amount"):
                continue
            v = dict(v)
            if v.get("project") == "(无项目)":
                v["project"] = ""
            v["project"] = norm_project(v.get("project"))
            for k in ("who", "scope", "sub", "project", "purpose", "account"):
                v[k] = (v.get(k) or "").strip()
            v["scope"] = v["scope"] or "待确认"
            v.setdefault("type", "exp")
            fix_sub(v)
            if v["scope"] != "工作":
                v["project"] = ""
            ensure_project(v["project"])
            pay = v.get("pay") or "已付"
            pay = {"待支付": "未付", "备用金支付": "备用金垫付"}.get(pay, pay)
            if v["scope"] == "工作" and v["project"] and v["type"] == "exp" and pay in ("未付", "预付", "无需付款"):
                # 还没付出去：只记进项目成本单（付款情况「未付」），不进记账本；以后真付了、账单归到这个项目时自动对上这一行
                with store.db() as c:
                    r = c.execute("select id from projects where name=?", (v["project"],)).fetchone()
                    if not r:
                        sync_projects_json()
                        r = c.execute("select id from projects where name=?", (v["project"],)).fetchone()
                    if r:
                        sec, cat = SEC_OF_SUB.get(v["sub"], ("执行人员杂费", ""))
                        seq = c.execute("select coalesce(max(seq),0)+1 from lines where project_id=? and sec=?", (r["id"], sec)).fetchone()[0]
                        cf = cab_fields(v) or dict(name=v["purpose"] or v["who"] or v["sub"] or "项目支出", spec="", craft="")
                        cur0 = (v.get("currency") or "CNY").upper()
                        if cur0 != "CNY":                     # 成本单一律人民币
                            r0 = h["fx_info"]()["rate"].get(cur0)
                            if not r0:
                                raise HTTPException(400, f"没有 {cur0} 的汇率，先在「我的钱」里给外币账户填汇率")
                            v["who"] = f"{v['who']}（{cur0} {float(v['amount']):.2f}）"
                            v["amount"] = round(float(v["amount"]) * r0, 2)
                        lid_ = c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,date,who) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                                  (r["id"], sec, cat, seq, cf["name"], cf["spec"], cf["craft"], 1, "项", float(v["amount"]),
                                   f"{pay} · {v['who']}"[:200], pay, v.get("date") or "", "")).lastrowid
                        undo_sql("delete from lines where id=?", (lid_,))
                        refs.append(dict(i=i_, line_id=lid_))
                        pending += 1
                        continue
            cur = (v.get("currency") or "CNY").upper()
            acur = acc_cur_map().get(acc_name_(v.get("account")), "CNY")
            if cur != acur:                                   # 用别的币种的账户付：按汇率折成这个账户的币种，备注里写明原币
                rt = h["fx_info"]()["rate"]
                r1, r2 = (1.0 if cur == "CNY" else rt.get(cur)), (1.0 if acur == "CNY" else rt.get(acur))
                if not (r1 and r2):
                    raise HTTPException(400, f"没有 {cur}/{acur} 的汇率，换成同币种账户，或先在「我的钱」里给外币账户填汇率")
                v["who"] = f"{v['who']}（{cur} {float(v['amount']):.2f}）"
                v["amount"] = round(float(v["amount"]) * r1 / r2, 2)
            qid = f"快记:{uuid.uuid4().hex[:12]}"
            if v["scope"] == "工作" and v["project"] and v["type"] == "exp" and pay in ("已付", "备用金垫付"):
                with store.db() as c:                         # 记下付款情况：成本单同步这一笔时用（账户照实记，钱是从哪个账户出的就记哪个）
                    c.execute("create table if not exists tx_pay(uid text primary key, pay text)")
                    c.execute("insert or replace into tx_pay(uid,pay) values(?,?)", (qid, pay))
            rows.append(build_row(v, qid))
            refs.append(dict(i=i_, uid=qid, amount=v["amount"], date=v.get("date") or "", who=v["who"]))
            undo_created(qid)
        if not rows and not pending:
            raise HTTPException(400, "没有可保存的账")
        if rows:
            push_rows(ezb(), rows, log=lambda *_: None)
        invalidate()
        if rows and getattr(b, "ids", False):
            by = {rid(x.get("comment")): str(x["id"]) for x in ezb_transactions(force=True)}
            for r_ in refs:
                if r_.get("uid") in by:
                    r_["id"] = by[r_["uid"]]
        return dict(n=len(rows), pending=pending, refs=refs)

    return apply
