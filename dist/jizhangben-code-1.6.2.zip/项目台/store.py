"""项目台的本地数据库（SQLite 单文件）和成本单读取。"""
import copy, json, os, re, sqlite3, zipfile
import xml.etree.ElementTree as ET
from contextlib import contextmanager

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get("CHAIMI_DATA", os.path.join(HERE, "data"))
DB = os.path.join(DATA, "xiangmu.db")
FILES = os.path.join(DATA, "files")
CONFIG = os.path.join(DATA, "config.json")
from datetime import timezone as _tz, timedelta as _td
TZ = _tz(_td(hours=8))                         # 账目一律按北京时间算日期（电脑改了时区也不串天）
DEV = os.environ.get("CHAIMI_DEV") == "1"      # 开发沙盒：不发系统通知、不自动备份、不收邮件、不检查更新

# 出错记录：写进日志（~/Library/Logs/CD的记账本/项目台.log），最近 50 条留在内存里给「设置」页看
ERRORS = []


def safe_rm(path):
    """删文件只删本程序数据文件夹里的：数据库里记的路径万一指向别处（比如测试副本里存的是真实目录），一律不删。"""
    if not path:
        return False
    try:
        base = os.path.realpath(DATA) + os.sep
        if not os.path.realpath(path).startswith(base):
            print("不在本程序数据文件夹里，不删：", path, flush=True)
            return False
        os.remove(path)
        return True
    except OSError:
        return False


def log_err(where, e):
    import time, traceback
    msg = f"{type(e).__name__}: {e}" if isinstance(e, BaseException) else str(e)
    ERRORS.append(dict(time=time.strftime("%m-%d %H:%M:%S"), where=where, msg=msg[:300]))
    del ERRORS[:-50]
    print(time.strftime("[%Y-%m-%d %H:%M:%S]"), "出错", where, msg, flush=True)
    if isinstance(e, BaseException) and e.__traceback__:
        traceback.print_exception(type(e), e, e.__traceback__)

SECTIONS = ["备用金", "搭建部分", "第三方人员", "物料部分", "执行人员杂费"]
PAY_OPTIONS = ["未付", "预付", "已付", "备用金垫付", "无需付款"]
# 模板底部「利润测算」的可填参数及默认值（与内部成本单模板一致）
DEFAULT_PARAMS = dict(mode="standard", quote=0, contract=0, adv_daifu=0, ch_daifu=0, r_adv_fee=0, r_ch_fee=0, r_ch_tax=0,
                      r_channel=0, r_mid=0, r_tax=0.06, r_income_tax=0.0566,
                      reimb=0, r_reimb_fee=0, r_rebate=0)
PARAM_KEYS = [k for k in DEFAULT_PARAMS if k != "mode"]


def base_params():
    """新项目 / 缺项时的默认参数：程序里是通用值，本机设置（config.json 的 mode_defaults._base）里存了你自己的就用你的。"""
    d = dict(DEFAULT_PARAMS)
    d.update({k: v for k, v in ((load_config().get("mode_defaults") or {}).get("_base") or {}).items() if k in DEFAULT_PARAMS})
    return d
# 合作方 / 结算模式的名字：程序里只放通用叫法；你自己的叫法存在本机设置（config.json 的 names），不随程序发出去
NAME_DEFAULTS = dict(mid="中间方", adv="代垫方", ch="渠道方", rb="返点", mode_a="模式A（中间方分成）", mode_b="模式B（渠道代垫）")


def names():
    d = dict(NAME_DEFAULTS)
    d.update({k: v for k, v in ((load_config().get("names") or {}).items()) if isinstance(v, str) and v.strip()})
    return d


def name_kw(key):
    """本机设置里「哪些字样算这个模式 / 这个合作方」（导入成本单、认结算模式用）；程序里不写死。"""
    v = (load_config().get("name_kw") or {}).get(key) or []
    return [x for x in v if isinstance(x, str) and x.strip()]


def param_labels():
    n = names()
    return dict(quote="客户报价", contract="项目金额", adv_daifu=f"{n['adv']}代垫付", ch_daifu=f"{n['ch']} 代垫付", r_adv_fee=f"{n['adv']}服务费",
                r_ch_fee=f"{n['ch']} 服务费", r_ch_tax=f"{n['ch']} 税点", r_channel="渠道返点", r_mid=f"{n['mid']}收款", r_tax="税费",
                r_income_tax="所得税", reimb="实报实销返还", r_reimb_fee="实报实销服务费", r_rebate="返点+公关费")


def _is_mid(label):
    """成本单里「中间方收款」那一行（你成本单上写的是本机设置里的名字，如「XX收款 4%」）"""
    return any(label.startswith(w + "收款") for w in ["中间方"] + name_kw("mid"))
# 三种结算逻辑（按项目区分）
def mode_names():
    n = names()
    return {"mode_b": n["mode_b"], "mode_a": n["mode_a"], "standard": "通用模板", "custom": "自定义公式"}
MODE_DEFAULTS = {
    # 模式B：渠道方代垫付（含服务费、税），再扣渠道返点、中间方收款；各点数在项目里填（本机设置可存默认值）
    "mode_b": dict(mode="mode_b", r_ch_fee=0, r_ch_tax=0, r_channel=0, r_mid=0, r_tax=0.06, r_income_tax=0.0566),
    # 模式A：实报实销返还及其服务费是我方收入、不分成；返点+公关费；中间方收款（闭式公式）
    "mode_a": dict(mode="mode_a", r_reimb_fee=0, r_rebate=0, r_mid=0, r_tax=0.06, r_income_tax=0.0566),
    "standard": dict(mode="standard", r_ch_fee=0, r_ch_tax=0, r_channel=0, r_mid=0, r_tax=0.06, r_income_tax=0.0566),
    # 自定义：从客户报价开始，一项一项往下扣（按报价的 % / 按上一步剩下的 % / 固定金额 / 成本单合计），剩下的就是利润
    "custom": dict(mode="custom"),
}
def mode_defaults(mode):
    """某个结算模式的默认点数：程序里是通用值，本机设置（config.json 的 mode_defaults）里存了你自己的默认点数就用你的。"""
    d = dict(MODE_DEFAULTS.get(mode) or {})
    d.update({k: v for k, v in ((load_config().get("mode_defaults") or {}).get(mode) or {}).items() if k != "mode"})
    return d


def detect_mode(info, labels_text=""):
    blob = f"{info.get('name','')} {info.get('customer','')} {info.get('source','')}"
    if "实报实销返还" in labels_text:
        return "mode_a"
    if any(w in blob for w in name_kw("mode_a")):
        return "mode_a"
    if any(w in blob or w.upper() in labels_text.upper() for w in name_kw("mode_b")):
        return "mode_b"
    return "standard"

SCHEMA = """
create table if not exists projects(
  id integer primary key autoincrement, name text unique not null, leader text default '', time_text text default '',
  location text default '', customer text default '', source text default '', start text default '', end text default '',
  params text default '{}', created text default (datetime('now','localtime')));
create table if not exists lines(
  id integer primary key autoincrement, project_id integer not null, sec text not null, cat text default '', seq integer default 0,
  name text default '', spec text default '', craft text default '', qty real default 1, unit text default '项', price real default 0,
  vendor text default '', pay text default '未付', uid text default '', date text default '', who text default '');
create table if not exists files(
  id integer primary key autoincrement, line_id integer not null, kind text not null, path text not null, name text default '',
  w integer default 0, h integer default 0, created text default (datetime('now','localtime')));
create table if not exists goals(
  id integer primary key autoincrement, name text not null, target real default 0, deadline text default '',
  saved0 real default 0, note text default '', created text default (datetime('now','localtime')));
create table if not exists deposits(
  id integer primary key autoincrement, goal_id integer not null, date text not null, amount real not null, note text default '');
create table if not exists debts(
  id integer primary key autoincrement, name text not null, direction text default 'owe', amount real default 0,
  borrow_date text default '', due_date text default '', remind_days integer default 3, note text default '',
  mac_reminder integer default 1, reminder_ids text default '[]', last_notified text default '',
  created text default (datetime('now','localtime')));
create table if not exists repayments(
  id integer primary key autoincrement, debt_id integer not null, date text not null, amount real not null, note text default '');
create table if not exists batches(
  id integer primary key autoincrement, created text default (datetime('now','localtime')), names text default '',
  stats text default '{}', rows text default '[]', status text default 'open');
"""


_OLD_KEYS = {          # 旧字段名的指纹（sha1 前 12 位）→ 新名字
    "b92b3cfdb3aa": "r_mid", "9388ca270b5a": "mid_fee", "32539a7db6fd": "ch_daifu", "09676f953c5d": "r_ch_fee",
    "1832343b096d": "r_ch_tax", "2a92a2a15e3e": "adv_daifu", "4ad833074d91": "r_adv_fee", "9332e331aa00": "mode_a", "ea6ade59844e": "mode_b"}


def _new_name(x):
    if not isinstance(x, str) or not x or len(x) > 20:
        return x
    import hashlib
    return _OLD_KEYS.get(hashlib.sha1(x.encode()).hexdigest()[:12], x)


def _rename_keys(v):
    """把参数里旧的字段名（字典的键）和旧的模式名（字符串值）换成新名字，数值原样保留。"""
    if isinstance(v, dict):
        return {_new_name(k): _rename_keys(x) for k, x in v.items()}
    if isinstance(v, list):
        return [_rename_keys(x) for x in v]
    return _new_name(v)


def init():
    os.makedirs(FILES, exist_ok=True)
    with db() as c:
        try:
            c.execute("pragma journal_mode=WAL")           # 读和写互不卡；写到一半断电也不坏库
            c.execute("pragma synchronous=NORMAL")
        except sqlite3.Error:
            pass
        c.executescript(SCHEMA)
        # 1.3.1：auto=1 表示这一行是从账单明细自动同步进成本单的（跟着账单改金额、移出项目就撤掉）
        # 1.3.1：同一项目不同月份可以各自起名（如「第一站」「第二站」），名字也会出现在项目下拉里
        c.execute("create table if not exists segs(project_id integer, month text, name text, primary key(project_id, month))")
        if "auto" not in [r[1] for r in c.execute("pragma table_info(lines)")]:
            c.execute("alter table lines add column auto integer default 0")
        # 1.4.3：和内部成本单一致——「发票」格里的文字（开票方 + 状态，如「待开，某某公司」）、表格最右边的其他备注（如「待退回」）
        lcols = [r[1] for r in c.execute("pragma table_info(lines)")]
        if "inv_note" not in lcols:
            c.execute("alter table lines add column inv_note text default ''")
        if "memo" not in lcols:
            c.execute("alter table lines add column memo text default ''")
        # 1.4.7：上传正式成本单后，账单同步来、对不上成本单任何一行的 → 「待核对」（hold=1）：不算合计、不导出，等你逐笔决定
        if "hold" not in lcols:
            c.execute("alter table lines add column hold integer default 0")
        # 1.4.7：借款 / 还款可以从账单里来（编辑一笔账 → 借款），记住是哪笔账
        for t_ in ("debts", "repayments"):
            if c.execute(f"select count(*) from sqlite_master where name='{t_}'").fetchone()[0] and "tx_uid" not in [r[1] for r in c.execute(f"pragma table_info({t_})")]:
                c.execute(f"alter table {t_} add column tx_uid text default ''")
        # 1.6.1：赊账（先消费、钱没进我账户，欠着对方）：kind='credit'
        if "kind" not in [r[1] for r in c.execute("pragma table_info(debts)")]:
            c.execute("alter table debts add column kind text default ''")
        # 1.6.1：项目参数里旧的字段名 / 结算模式名换成通用叫法（老名字用指纹认，程序里不出现合作方名字）；数值一个不动
        for pid, raw in c.execute("select id, params from projects").fetchall():
            try:
                old = json.loads(raw or "{}")
            except Exception:
                continue
            new = _rename_keys(old)
            if new != old:
                c.execute("update projects set params=? where id=?", (json.dumps(new, ensure_ascii=False), pid))
        # 1.3.2：发票保留原始 PDF（orig），记发票号码防重复；发票夹（邮箱/批量上传进来、还没放进成本行的发票）
        fcols = [r[1] for r in c.execute("pragma table_info(files)")]
        if "orig" not in fcols:
            c.execute("alter table files add column orig text default ''")
        if "inv_no" not in fcols:
            c.execute("alter table files add column inv_no text default ''")
        c.execute("""create table if not exists inv(
          id integer primary key autoincrement, src text default 'upload', mail_key text default '', subject text default '',
          sender text default '', mdate text default '', name text default '', path text default '', pages text default '[]',
          sha text default '', amount real default 0, seller text default '', buyer text default '', inv_no text default '',
          inv_date text default '', item text default '', status text default 'new', line_id integer default 0,
          created text default (datetime('now','localtime')))""")
        if "tx_uid" not in [r[1] for r in c.execute("pragma table_info(inv)")]:
            c.execute("alter table inv add column tx_uid text default ''")
        # 1.3.2：我的分红。div_set：分红比例/手填金额（month='' 是整个项目，填了月份就是那个月单独设）；divs：实际到账记录
        c.execute("create table if not exists div_set(project_id integer, month text default '', rate real, amount real, primary key(project_id, month))")
        # 1.5：settle = 没到账但不用再等的差额（转账手续费等），算结清
        if "settle" not in [r[1] for r in c.execute("pragma table_info(div_set)")]:
            c.execute("alter table div_set add column settle real")
        c.execute("""create table if not exists divs(id integer primary key autoincrement, project_id integer not null, date text default '',
          amount real default 0, note text default '', uid text default '', created text default (datetime('now','localtime')))""")
        # 开给甲方的发票（项目收入这边）：甲方打款前要先开票。status：待开 / 已开 / 已回款
        c.execute("""create table if not exists out_inv(id integer primary key autoincrement, project_id integer not null, date text default '',
          amount real default 0, no text default '', title text default '', status text default '已开', note text default '',
          path text default '', fname text default '', created text default (datetime('now','localtime')))""")
        # 1.5：开出去的发票不只开给甲方——每一段转款各有一张（如 中间方开给甲方、执行方开给中间方）。issuer=开票方，hop=对应哪一段转款（h1=甲方那段）
        ocols = [r[1] for r in c.execute("pragma table_info(out_inv)")]
        if "issuer" not in ocols:
            c.execute("alter table out_inv add column issuer text default ''")
        if "hop" not in ocols:
            c.execute("alter table out_inv add column hop text default 'h1'")
        if "kind" not in [r[1] for r in c.execute("pragma table_info(inv)")]:
            c.execute("alter table inv add column kind text default 'invoice'")   # invoice=发票 trip=打车行程单   # 在记账本某笔账上传的发票：等这笔进了成本单自动放进去
        for ix, tb, col in (("ix_lines_pid", "lines", "project_id"), ("ix_lines_uid", "lines", "uid"), ("ix_files_line", "files", "line_id"),
                            ("ix_inv_line", "inv", "line_id"), ("ix_inv_status", "inv", "status"), ("ix_divs_pid", "divs", "project_id"),
                            ("ix_rep_debt", "repayments", "debt_id"), ("ix_dep_goal", "deposits", "goal_id")):
            c.execute(f"create index if not exists {ix} on {tb}({col})")      # 账多了以后查得快
        # 数据搬家(例如从开发目录迁到「应用支持」)后，修正图片记录里的绝对路径
        for r in c.execute("select id,path from files").fetchall():
            if not os.path.exists(r["path"]):
                i = r["path"].rfind("/files/")
                if i >= 0:
                    new = os.path.join(FILES, r["path"][i + 7:])
                    if os.path.exists(new):
                        c.execute("update files set path=? where id=?", (new, r["id"]))


@contextmanager
def db():
    c = sqlite3.connect(DB, timeout=15)          # 别的操作正在写时最多等 15 秒，不直接报「数据库被锁」
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    finally:
        c.close()


_cfg_cache = {"key": None, "v": None}


def load_config():
    """设置文件：文件没变就用上次读到的（打开项目列表时会读几十次）；每次给一份拷贝，改了也不影响缓存。"""
    try:
        st = os.stat(CONFIG)
    except OSError:
        return dict(ezb_url="http://localhost:8080", ezb_user="", ezb_pass="")
    key = (st.st_mtime_ns, st.st_size)
    if _cfg_cache["key"] != key:
        _private(CONFIG)
        with open(CONFIG, encoding="utf-8") as f:
            _cfg_cache["v"] = json.load(f)
        _cfg_cache["key"] = key
    return copy.deepcopy(_cfg_cache["v"])


def save_config(cfg):
    os.makedirs(DATA, exist_ok=True)
    write_json(CONFIG, cfg, private=True)


def _private(path):
    """里面有密码的文件：只有本机这个用户能读（600）。"""
    try:
        if os.stat(path).st_mode & 0o077:
            os.chmod(path, 0o600)
    except OSError:
        pass


def write_json(path, obj, private=False):
    """先写临时文件再整体替换：写到一半断电/崩溃不会留下半截文件。"""
    tmp = f"{path}.tmp{os.getpid()}"
    fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600 if private else 0o644)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


# ---------------- 读已有成本单 ----------------
def _num(x):
    return float(x) if isinstance(x, (int, float)) and not isinstance(x, bool) else None


def _cell_images(path):
    """WPS 把图嵌在单元格里（=DISPIMG("ID_xxx")），这里取出 ID → (扩展名, 字节)。"""
    out = {}
    try:
        z = zipfile.ZipFile(path)
        names = set(z.namelist())
        if "xl/cellimages.xml" not in names:
            return out
        rels = {}
        for m in re.finditer(r'<Relationship [^>]*?Id="([^"]+)"[^>]*?Target="([^"]+)"', z.read("xl/_rels/cellimages.xml.rels").decode("utf8")):
            rels[m.group(1)] = m.group(2)
        for m in re.finditer(r'name="(ID_[0-9A-F]+)".*?r:embed="([^"]+)"', z.read("xl/cellimages.xml").decode("utf8"), re.S):
            t = rels.get(m.group(2))
            if t:
                p = "xl/" + t if not t.startswith("/") else t[1:]
                if p in names:
                    out[m.group(1)] = (os.path.splitext(p)[1].lstrip(".") or "png", z.read(p))
    except Exception:
        pass
    return out


def parse_cost_xlsx(path):
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb["成本汇总"] if "成本汇总" in wb.sheetnames else wb.worksheets[0]
    # 公式单元格：用程序（不是 Excel）保存的文件没有算好的值，data_only 读出来是空，所以再读一遍公式本身，自己算
    wf = openpyxl.load_workbook(path, data_only=False)
    fs = wf[ws.title]
    raw_rows = list(fs.iter_rows(min_row=1, values_only=True))
    imgs = _cell_images(path)
    info = dict(name="", leader="", time_text="", location="", customer="", source="")
    lines, sec, cat = [], None, ""
    params = base_params()
    labels = {}
    for ri, r in enumerate(ws.iter_rows(min_row=1, values_only=True)):
        r = list(r) + [None] * 16
        f = list(raw_rows[ri]) + [None] * 16 if ri < len(raw_rows) else [None] * 30
        isf = lambda v: isinstance(v, str) and v.startswith("=")
        if r[1] is None and isf(f[1]) and "ROW" in f[1].upper():          # 序号是 =ROW()-… 公式
            r[1] = 1
        if r[8] is None and isf(f[8]) and _num(r[7]) is not None:          # 金额是 =F*H 公式：数量 × 单价
            r[8] = round((_num(r[5]) if _num(r[5]) is not None else 1) * _num(r[7]), 2)
        a = str(r[0]).strip() if r[0] is not None else ""
        # 抬头
        for lab, key, col in (("项目名称", "name", 1), ("项目时间", "time_text", 1), ("客户名称", "customer", 1)):
            if a == lab:
                info[key] = str(r[col] or "").strip()
        if str(r[3] or "").strip() == "项目负责人":
            info["leader"] = str(r[4] or "").strip()
        if str(r[3] or "").strip() == "项目地点":
            info["location"] = str(r[4] or "").strip()
        if str(r[3] or "").strip() == "客户来源":
            info["source"] = str(r[4] or "").strip()
        if a in SECTIONS and r[1] is None:
            sec, cat = a, ""
            continue
        if a == "总成本" or str(r[7] or "").strip() == "总成本":
            sec = None
        if a and sec is None:
            labels[a] = r
        if sec == "备用金":
            if isinstance(r[1], (int, float)) and _num(r[8]) and (r[2] is not None or r[3]):     # 没写申请时间也算（如「转款人：小王 5000」）
                d = r[2].strftime("%Y-%m-%d") if hasattr(r[2], "strftime") else str(r[2] or "")
                lines.append(dict(sec="备用金", cat="备用金", name=str(r[3] or "").strip(), spec="", craft="", qty=1, unit="项",
                                  price=_num(r[8]), vendor="", pay="已付", date=d, who=str(r[3] or "").strip()))
            continue
        if sec and isinstance(r[1], (int, float)) and _num(r[8]) is not None and (r[2] or r[3] or r[4] or a or _num(r[8])):
            if a:
                cat = a
            qty = _num(r[5]) or 1
            amount = _num(r[8]) or 0
            def img_id(v):
                m = re.search(r'DISPIMG\("(ID_[0-9A-F]+)"', str(v or ""))
                return m.group(1) if m else None
            # 供应商/付款/图片列：不同版本的成本单图片会落在 J~N 任意列，按内容识别
            pay, vendor, ids, extra, inv_note = "", "", [], [], ""
            for ci, v in enumerate(r[9:14]):
                if v is None or str(v).strip() == "":
                    continue
                t = str(v).strip()
                if isinstance(v, (int, float)) or re.fullmatch(r"=?IF\(.*|[\d.]+", t):
                    continue                                  # 「已付金额」列（公式算出来的数），不是备注
                if img_id(t):
                    ids.append(img_id(t))
                elif t in PAY_OPTIONS:
                    pay = t
                elif ci >= 2 and len(t) <= 20 and (re.search(r"待开|已开|开票|发票|专票|普票|无票|不开", t) or any(w in t for w in name_kw("issuers"))):
                    inv_note = t                              # 「发票」格里写的开票方 / 状态
                elif t == "公对公":
                    pay, extra = pay or "已付", extra + ["公对公"]
                elif not vendor:
                    vendor = t
                else:
                    extra.append(t)
            if extra:
                vendor = "；".join(([vendor] if vendor else []) + extra)
            if pay not in PAY_OPTIONS:
                pay = "未付"
            m0 = re.search(r"原金额[¥￥]([\d,]+(?:\.\d+)?)", vendor)
            if m0 and not amount:                       # 导出时「无需付款」的行金额写 0、原金额写在备注里：读回原金额
                amount = float(m0.group(1).replace(",", ""))
                vendor = re.sub(r"；?原金额[¥￥][\d,.]+，无需付款，不计入成本", "", vendor).strip("；")
            lines.append(dict(sec=sec, cat=cat, name=str(r[2] or "").strip(), spec=str(r[3] or "").strip(), craft=str(r[4] or "").strip(),
                              qty=qty, unit=str(r[6] or "项"), price=round(amount / qty, 6), vendor=vendor, pay=pay,
                              date="", who="", _inv=ids[0] if ids else None, _pay=ids[1] if len(ids) > 1 else None,
                              _inv_text="", inv_note=inv_note, memo=str(r[14] or "").strip() if not img_id(r[14]) else ""))
    # 模式A（带「实报实销返还」行）：按标签读
    if any(k.startswith("实报实销返还") for k in labels):
        params.update(mode_defaults("mode_a"))
        for k, r in labels.items():
            if k == "客户报价":
                params["quote"] = _num(r[8]) or 0
            elif k.startswith("实报实销返还"):
                params["reimb"] = _num(r[8]) or 0
            elif k.startswith("实报实销服务费"):
                params["r_reimb_fee"] = _num(r[6]) if _num(r[6]) is not None else params.get("r_reimb_fee", 0)
            elif "返点" in k and "公关" in k:
                params["r_rebate"] = _num(r[6]) if _num(r[6]) is not None else params.get("r_rebate", 0)
            elif _is_mid(k):
                params["r_mid"] = _num(r[6]) if _num(r[6]) is not None else params.get("r_mid", 0)
            elif k.startswith("税费"):
                params["r_tax"] = _num(r[6]) if _num(r[6]) is not None else 0.06
            elif k.startswith("企业所得税"):
                params["r_income_tax"] = _num(r[6]) if _num(r[6]) is not None else 0.0566
        return info, params, lines, imgs
    # 利润测算参数（按标签找，兼容不同版本）
    def val(label_starts, col):
        for k, r in labels.items():
            if any(k.startswith(s) for s in label_starts):
                return _num(r[col])
        return None
    params["mode"] = detect_mode(info, " ".join(labels.keys()))
    if params["mode"] == "mode_a":
        params.update({k: v for k, v in mode_defaults("mode_a").items() if k != "mode"})
    adv_w = [f"{w}代垫付" for w in ["代垫方"] + name_kw("adv")]
    ch_w = [f"{w}代垫付" for w in ["渠道方"] + name_kw("ch")]
    mapping = [("quote", ("客户报价",), 8), ("adv_daifu", tuple(adv_w), 8), ("ch_daifu", tuple(ch_w), 8)]
    for key, ls, col in mapping:
        v = None
        for k, r in labels.items():
            if any(k == s for s in ls):
                v = _num(r[col])
        if v is not None:
            params[key] = v
    for key, labs in (("r_ch_fee", tuple(w + "含服务费" for w in ch_w)), ("r_ch_tax", tuple(w + "含税" for w in ch_w)),
                      ("r_channel", ("渠道返点",) + tuple(f"{w}返点" for w in name_kw("ch"))), ("r_tax", ("税费",)), ("r_income_tax", ("企业所得税",))):
        for k, r in labels.items():
            if k in labs and _num(r[6]) is not None:
                params[key] = _num(r[6])
    for k, r in labels.items():
        if _is_mid(k):
            m = re.search(r"(\d+(?:\.\d+)?)%", k)
            params["r_mid"] = _num(r[6]) if _num(r[6]) is not None else (float(m.group(1)) / 100 if m else params["r_mid"])
    return info, params, lines, imgs
