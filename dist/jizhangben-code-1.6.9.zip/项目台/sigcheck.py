"""更新包签名校验（Ed25519，纯 Python，不依赖额外的库）。

发版时用只存在发版电脑上的私钥给 update.json 签名；App 里只带公钥。
update.json 里写着安装包的 sha256，所以「签名对 + sha256 对」= 这个包确实是作者发的、没被改过。
算法照 RFC 8032 的参考实现写，只用于验证一份几百字节的清单，速度足够。
"""
import base64, hashlib, json

# 公钥（可以公开）。对应的私钥只在发版电脑的 ~/.config/cd-jizhangben/ 里，不进安装包、不进代码仓库。
PUBKEY = "164a532d536b68752782711305c6fa028455ec6ec95a0123071c398cdac665c0"

_p = 2 ** 255 - 19
_q = 2 ** 252 + 27742317777372353535851937790883648493
_inv = lambda x: pow(x, _p - 2, _p)
_d = -121665 * _inv(121666) % _p
_sqrt_m1 = pow(2, (_p - 1) // 4, _p)


def _add(P, Q):
    A, B = (P[1] - P[0]) * (Q[1] - Q[0]) % _p, (P[1] + P[0]) * (Q[1] + Q[0]) % _p
    C, D = 2 * P[3] * Q[3] * _d % _p, 2 * P[2] * Q[2] % _p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F % _p, G * H % _p, F * G % _p, E * H % _p)


def _mul(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _eq(P, Q):
    return (P[0] * Q[2] - Q[0] * P[2]) % _p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % _p == 0


def _recover_x(y, sign):
    if y >= _p:
        return None
    x2 = (y * y - 1) * _inv(_d * y * y + 1) % _p
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (_p + 3) // 8, _p)
    if (x * x - x2) % _p != 0:
        x = x * _sqrt_m1 % _p
    if (x * x - x2) % _p != 0:
        return None
    if (x & 1) != sign:
        x = _p - x
    return x


_gy = 4 * _inv(5) % _p
_gx = _recover_x(_gy, 0)
_G = (_gx, _gy, 1, _gx * _gy % _p)


def _compress(P):
    zi = _inv(P[2])
    x, y = P[0] * zi % _p, P[1] * zi % _p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decompress(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % _p)


def _hq(b):
    return int.from_bytes(hashlib.sha512(b).digest(), "little") % _q


def _expand(seed):
    h = hashlib.sha512(seed).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def public_of(seed):
    return _compress(_mul(_expand(seed)[0], _G))


def sign(seed, msg):
    a, prefix = _expand(seed)
    A = _compress(_mul(a, _G))
    r = _hq(prefix + msg)
    Rs = _compress(_mul(r, _G))
    s = (r + _hq(Rs + A + msg) * a) % _q
    return Rs + int.to_bytes(s, 32, "little")


def verify(public, msg, sig):
    try:
        if len(public) != 32 or len(sig) != 64:
            return False
        A, R = _decompress(public), _decompress(sig[:32])
        if not A or not R:
            return False
        s = int.from_bytes(sig[32:], "little")
        if s >= _q:
            return False
        h = _hq(sig[:32] + public + msg)
        return _eq(_mul(s, _G), _add(R, _mul(h, A)))
    except Exception:
        return False


def canonical(info):
    """签名的对象：update.json 去掉 sig 字段后，按固定格式排好的文本。"""
    d = {k: v for k, v in info.items() if k != "sig"}
    return json.dumps(d, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def verify_manifest(info, pubkey=None):
    """update.json 是不是作者签的：没有签名、签名不对、内容被改过，都算不通过。"""
    try:
        sig = base64.b64decode(info.get("sig") or "", validate=True)
        return verify(bytes.fromhex(pubkey or PUBKEY), canonical(info), sig)
    except Exception:
        return False
