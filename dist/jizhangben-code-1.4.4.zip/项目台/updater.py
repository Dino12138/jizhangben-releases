"""在线更新（和「拾光猫」一样的思路：GitHub 发版仓库 + 国内 jsDelivr 镜像）。

两种更新：
- 热更新（code）：只换项目台/工具的程序文件，几 MB，下载后自动重启服务，不用重新安装。
  新程序放在「应用支持/CD的记账本/程序更新/当前」，启动脚本发现它比 App 自带的新就用它。
- 完整更新（full）：换整个 App（自带 Python、记账本程序有变化时才需要），下载 dmg 后自动替换并重新打开。
update.json 例：
{"version":"1.4.1","notes":"……","code":{"url":…,"mirrors":[…],"sha256":…,"size":…},
 "full":{"url":…,"mirrors":[…],"sha256":…,"size":…},"min_full":"1.4.0"}
min_full：低于这个版本的 App 必须先完整更新一次（热更新包依赖新的启动脚本等）。
"""
import hashlib, json, os, plistlib, shutil, subprocess, threading, time, urllib.request, zipfile

from fastapi import HTTPException

REPO = "Dino12138/jizhangben-releases"
FEEDS = [f"https://github.com/{REPO}/releases/latest/download/update.json"] + \
        [f"https://{h}.jsdelivr.net/gh/{REPO}@main/update.json" for h in ("gcore", "fastly", "cdn")]
UA = {"User-Agent": "CDJizhangben-Updater"}


def vtuple(v):
    try:
        return tuple(int(x) for x in str(v).strip().lstrip("v").split("."))
    except Exception:
        return (0,)


def setup(app, h):
    store = h["store"]
    HERE = os.path.dirname(os.path.abspath(__file__))            # …/项目台（App 自带的，或「程序更新/当前/项目台」）
    AS = os.path.dirname(store.DATA)                             # ~/Library/Application Support/CD的记账本
    UPD = os.path.join(AS, "程序更新")
    os.makedirs(UPD, exist_ok=True)
    PAYLOAD = os.environ.get("CHAIMI_PAYLOAD", "")               # App 里的 payload 目录（launch.sh 传进来）
    APP = os.path.abspath(os.path.join(PAYLOAD, "..", "..", "..")) if PAYLOAD else ""

    def app_version():
        try:
            return plistlib.load(open(os.path.join(APP, "Contents", "Info.plist"), "rb")).get("CFBundleShortVersionString", "0")
        except Exception:
            return "0"

    def code_version():
        """正在运行的程序版本：热更新过就是热更新包的版本，否则是 App 自带的。"""
        f = os.path.join(os.path.dirname(HERE), "VERSION")
        try:
            return open(f).read().strip() or app_version()
        except OSError:
            return app_version()

    ST = dict(checking=False, info=None, err="", last="", busy=False, msg="", pct=0, done="")

    def fetch(urls, timeout=20):
        last = None
        for u in urls:
            try:
                with urllib.request.urlopen(urllib.request.Request(u, headers=UA), timeout=timeout) as r:
                    return r.read()
            except Exception as e:
                last = e
        raise HTTPException(502, f"连不上更新服务器（{str(last)[:80]}），稍后再试")

    def check():
        ST["checking"] = True
        try:
            info = None
            for u in FEEDS:                                       # 取版本最高的那份（镜像可能有缓存）
                try:
                    d = json.loads(fetch([u + f"?t={int(time.time())}"], 12))
                    if not info or vtuple(d.get("version")) > vtuple(info.get("version")):
                        info = d
                except Exception:
                    continue
            if not info:
                raise HTTPException(502, "连不上更新服务器，稍后再试")
            ST["info"], ST["err"] = info, ""
        except HTTPException as e:
            ST["err"] = e.detail
        finally:
            ST["checking"] = False
            ST["last"] = time.strftime("%Y-%m-%d %H:%M")

    def status():
        cur = code_version()
        info = ST["info"] or {}
        newer = bool(info) and vtuple(info.get("version")) > vtuple(cur)
        need_full = newer and (vtuple(app_version()) < vtuple(info.get("min_full", "0")) or not info.get("code"))
        return dict(current=cur, app_version=app_version(), latest=info.get("version", ""), notes=info.get("notes", ""),
                    changelog=info.get("changelog", []), newer=newer, need_full=need_full, checking=ST["checking"],
                    err=ST["err"], last=ST["last"], busy=ST["busy"], msg=ST["msg"], pct=ST["pct"], done=ST["done"],
                    can_install=bool(APP and APP.endswith(".app")))

    def download(pkg, dest):
        """先试完整文件（GitHub）；不通再按分片从国内镜像拼（每片 < 50MB，jsDelivr 的上限）。最后整体校验。"""
        try:
            return _download_one([pkg["url"]], dest, pkg)
        except Exception as e:
            if not pkg.get("parts"):
                if pkg.get("mirrors"):
                    return _download_one(list(pkg["mirrors"]), dest, pkg)
                raise
        ST["msg"] = "GitHub 不通，改走国内镜像…"
        tmp = dest + ".part"
        with open(dest, "wb") as out:
            for i, urls in enumerate(pkg["parts"]):
                _download_one(list(urls), tmp, None, label=f"第 {i + 1}/{len(pkg['parts'])} 段 ")
                with open(tmp, "rb") as f:
                    shutil.copyfileobj(f, out)
        os.remove(tmp)
        if pkg.get("sha256") and hashlib.sha256(open(dest, "rb").read()).hexdigest() != pkg["sha256"]:
            raise RuntimeError("文件校验不对（可能没下完整），请再试一次")

    def _download_one(urls, dest, pkg, label=""):
        last = None
        for u in urls:
            try:
                h_ = hashlib.sha256()
                with urllib.request.urlopen(urllib.request.Request(u, headers=UA), timeout=30) as r, open(dest, "wb") as f:
                    total, got = int(r.headers.get("Content-Length") or (pkg or {}).get("size") or 0), 0
                    while True:
                        b = r.read(256 * 1024)
                        if not b:
                            break
                        f.write(b)
                        h_.update(b)
                        got += len(b)
                        ST["pct"] = int(got * 100 / total) if total else 0
                        ST["msg"] = f"下载中 {label}{got / 1e6:.1f} MB" + (f" / {total / 1e6:.1f} MB" if total else "")
                if pkg and pkg.get("sha256") and h_.hexdigest() != pkg["sha256"]:
                    raise ValueError("文件校验不对（可能没下完整）")
                return
            except Exception as e:
                last = e
                ST["msg"] = "这条线路不通，换一条…"
        raise RuntimeError(f"下载失败：{last}")

    def restart_services():
        """新开一个独立进程：停掉服务 → 用新程序重新启动（页面会自动重连）。"""
        launch = os.path.join(PAYLOAD, "launch.sh")
        subprocess.Popen(["/bin/bash", "-c", f'sleep 1; "{launch}" stop; sleep 1; "{launch}"'],
                         start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def do_code(info):
        pkg = info["code"]
        z = os.path.join(UPD, "下载中.zip")
        download(pkg, z)
        ST["msg"] = "安装中…"
        new = os.path.join(UPD, "新版")
        shutil.rmtree(new, ignore_errors=True)
        with zipfile.ZipFile(z) as zf:
            for info in zf.infolist():
                n = info.filename
                if not info.flag_bits & 0x800:                    # 没标 UTF-8 的中文文件名：按 UTF-8 重新认
                    try:
                        n = n.encode("cp437").decode("utf-8")
                    except (UnicodeEncodeError, UnicodeDecodeError):
                        pass
                if n.startswith("/") or ".." in n.split("/"):     # 只允许解到「新版」目录里
                    raise RuntimeError("更新包格式不对")
                dst = os.path.join(new, n)
                if n.endswith("/"):
                    os.makedirs(dst, exist_ok=True)
                    continue
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with zf.open(info) as src_, open(dst, "wb") as out_:
                    shutil.copyfileobj(src_, out_)
        if not os.path.exists(os.path.join(new, "项目台", "app.py")):
            raise RuntimeError("更新包缺文件")
        open(os.path.join(new, "VERSION"), "w").write(info["version"])
        cur, old = os.path.join(UPD, "当前"), os.path.join(UPD, "上一版")
        shutil.rmtree(old, ignore_errors=True)
        if os.path.exists(cur):
            os.rename(cur, old)
        os.rename(new, cur)
        os.remove(z)
        ST["done"] = info["version"]
        ST["msg"] = f"已更新到 {info['version']}，正在重启…"
        restart_services()

    def do_full(info):
        if not (APP and APP.endswith(".app")):
            raise RuntimeError("找不到 App 的位置，请手动下载安装")
        pkg = info["full"]
        dmg = os.path.join(UPD, "下载中.dmg")
        download(pkg, dmg)
        ST["msg"] = "安装中…"
        mnt = os.path.join(UPD, "挂载")
        os.makedirs(mnt, exist_ok=True)
        subprocess.run(["hdiutil", "attach", "-nobrowse", "-noverify", "-mountpoint", mnt, dmg], check=True, capture_output=True)
        try:
            src = next((os.path.join(mnt, x) for x in os.listdir(mnt) if x.endswith(".app")), None)
            if not src:
                raise RuntimeError("安装包里没有 App")
            staged = APP + ".new"
            shutil.rmtree(staged, ignore_errors=True)
            subprocess.run(["ditto", src, staged], check=True)
        finally:
            subprocess.run(["hdiutil", "detach", mnt, "-force"], capture_output=True)
        os.remove(dmg)
        shutil.rmtree(os.path.join(UPD, "当前"), ignore_errors=True)   # 完整更新后用 App 自带的新程序
        ST["done"] = info["version"]
        ST["msg"] = f"已下载 {info['version']}，App 马上自动重新打开…"
        bid = "com.cd.jizhangben"
        script = (f'sleep 2; osascript -e \'tell application id "{bid}" to quit\'; sleep 4; "{PAYLOAD}/launch.sh" stop; '
                  f'rm -rf "{APP}.old"; mv "{APP}" "{APP}.old" && mv "{APP}.new" "{APP}" && xattr -dr com.apple.quarantine "{APP}"; '
                  f'rm -rf "{APP}.old"; open "{APP}"')
        subprocess.Popen(["/bin/bash", "-c", script], start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def run_update(full):
        if ST["busy"]:
            return
        ST.update(busy=True, pct=0, msg="准备下载…", done="")
        try:
            if not ST["info"]:
                check()
            info = ST["info"]
            if not info or vtuple(info.get("version")) <= vtuple(code_version()):
                ST["msg"] = "已经是最新版"
                return
            st = status()
            (do_full if (full or st["need_full"]) else do_code)(info)
        except Exception as e:
            ST["msg"] = f"⚠ 更新没成功：{e}"
        finally:
            ST["busy"] = False

    @app.get("/api/update/status")
    def update_status(check_now: int = 0):
        if check_now and not ST["checking"]:
            check()
        return status()

    @app.post("/api/update/apply")
    def update_apply(full: int = 0):
        threading.Thread(target=run_update, args=(bool(full),), daemon=True).start()
        time.sleep(0.3)
        return status()

    @app.post("/api/update/rollback")
    def update_rollback():
        """热更新后有问题：退回上一版（或 App 自带版本）。"""
        cur, old = os.path.join(UPD, "当前"), os.path.join(UPD, "上一版")
        shutil.rmtree(cur, ignore_errors=True)
        if os.path.exists(old):
            os.rename(old, cur)
        restart_services()
        return dict(ok=True)

    def loop():
        time.sleep(20)
        while True:
            check()
            time.sleep(6 * 3600)

    if os.environ.get("CHAIMI_NO_UPDATE") != "1":
        threading.Thread(target=loop, daemon=True).start()
    h["code_version"] = code_version
