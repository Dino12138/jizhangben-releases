"""报销申请单：和项目成本单放在一起（处理方式同发票 / 行程单：上传 → 自动认 → 配对成本行）。

上传一份「费用报销申请单」.xlsx：
- 读出 申请人、日期、报销总额、备用金（含「已退回」「余」「超出」）、每一项（费用类型/明细/金额/发票图）；
- 备用金记进项目的「备用金」（标明在谁那里、不经过我的账户，不会记进我的个人账）；
- 每一项按金额配对成本行，付款情况改成「备用金垫付」；成本单里没有的项会自动加一行；
- 报销单里贴的发票图，放进对上那一行的「发票」格（那一行已经有发票就不重复放）；
- 删掉报销单 = 以上全部撤回。导出成本单时多一个「报销申请单」表。
"""
import json, os, re, shutil, uuid
from typing import List, Optional

from fastapi import File, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

SEC_OF = {"物料": "物料部分", "运输": "物料部分", "快递": "物料部分", "交通费": "执行人员杂费", "交通": "执行人员杂费",
          "住宿费": "执行人员杂费", "住宿": "执行人员杂费", "餐费": "执行人员杂费", "第三方人员": "第三方人员", "保险费": "搭建部分"}


def _num(v):
    try:
        return round(float(str(v).replace(",", "").replace("¥", "").replace("￥", "")), 2)
    except (TypeError, ValueError):
        return None


def is_reimb_xlsx(path):
    try:
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True)
        names = wb.sheetnames
        if "项目组支出" in names or "费用报销单" in names:
            return True
        ws = wb.worksheets[0]
        for r in ws.iter_rows(max_row=8, values_only=True):
            if any(isinstance(v, str) and "报销申请单" in v for v in r):
                return True
    except Exception:
        pass
    return False


def parse_reimb(path, cell_images):
    """返回 dict(applicant, date, total, advance, refund, note, project, items=[{type,detail,amount,inv_amount,img}])"""
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True)
    out = dict(applicant="", date="", total=0.0, advance=0.0, refund=0.0, note="", project="", items=[], group="")
    imgs = cell_images(path)
    ws = wb.worksheets[0]
    LABELS = {"申请人姓名", "项目组别", "项目负责人", "类型：", "币种", "金额（大写）"}
    leader = ""
    for r in ws.iter_rows(values_only=True):
        r = list(r)
        for i, v in enumerate(r):
            if not isinstance(v, str):
                continue
            nxt = next((x for x in r[i + 1:] if x not in (None, "")), None)
            if isinstance(nxt, str) and nxt.strip() in LABELS:      # 这格是空的，下一个是别的标签
                nxt = None
            if v.strip() == "申请人姓名" and nxt:
                out["applicant"] = str(nxt).strip()
            elif v.strip() == "项目负责人" and nxt:
                leader = str(nxt).strip()
            elif v.strip() == "项目组别" and nxt:
                out["group"] = str(nxt).strip()
            elif v.strip().startswith("报销总金额") and nxt is not None:
                out["total"] = _num(nxt) or 0
            elif v.startswith("日期"):
                m = re.search(r"(20\d{2})\D+(\d{1,2})\D+(\d{1,2})", v)
                if m:
                    out["date"] = "%s-%02d-%02d" % (m[1], int(m[2]), int(m[3]))
    if not out["applicant"] and leader:                 # 申请人没写：按项目负责人（页面上能改）
        out["applicant"] = f"{leader}（负责人）"
    def img_of(v):
        m = re.search(r'DISPIMG\("(ID_[0-9A-F]+)"', str(v or ""))
        return m.group(1) if m and m.group(1) in imgs else None
    if "项目组支出" in wb.sheetnames:
        hdr = None
        for r in wb["项目组支出"].iter_rows(values_only=True):
            r = list(r) + [None] * 8
            a = str(r[0] or "").strip()
            if a.startswith("项目名称"):
                out["project"] = str(r[1] or "").strip()
            if a == "费用类型":
                hdr = True
                continue
            if not hdr:
                continue
            if a == "合计":
                out["note"] = " ".join(str(x).strip() for x in (r[1], r[4]) if x not in (None, ""))
                if not out["total"]:
                    out["total"] = _num(r[3]) or 0
                break
            amt = _num(r[3]) if _num(r[3]) is not None else _num(r[2])
            if (a or r[1]) and amt:
                out["items"].append(dict(type=a, detail=str(r[1] or "").strip(), amount=amt, inv_amount=_num(r[2]),
                                         img=img_of(r[4]) or img_of(r[5])))
    if "加班报销" in wb.sheetnames:                       # 加班打车/餐费（附件1）
        for r in wb["加班报销"].iter_rows(min_row=4, values_only=True):
            r = list(r) + [None] * 8
            amt = _num(r[5])
            if r[1] and amt and str(r[1]).strip() not in ("项目名称",):
                out["items"].append(dict(type="交通费", detail=f"加班 {r[2] or ''} {r[1]}".strip(), amount=amt, inv_amount=None, img=None))
    if "设计费用" in wb.sheetnames:
        for r in wb["设计费用"].iter_rows(min_row=4, values_only=True):
            r = list(r) + [None] * 8
            amt = _num(r[3])
            if amt and str(r[1] or "").strip() != "合计":
                out["items"].append(dict(type="第三方人员", detail="设计费用", amount=amt, inv_amount=_num(r[2]), img=img_of(r[1])))
    n = out["note"]
    m = re.search(r"备用金\s*([\d.]+)", n)
    out["advance"] = float(m.group(1)) if m else 0.0
    m = re.search(r"退回\s*([\d.]+)", n)
    out["refund"] = float(m.group(1)) if m else 0.0
    if not out["total"]:
        out["total"] = round(sum(i["amount"] for i in out["items"]), 2)
    out["_imgs"] = imgs
    return out


def setup(app, h):
    store, project_detail = h["store"], h["project_detail"]
    save_to_line = h["save_to_line"]
    DOCS = os.path.join(store.FILES, "报销单")
    os.makedirs(DOCS, exist_ok=True)
    with store.db() as c:
        c.execute("""create table if not exists reimbs(id integer primary key autoincrement, project_id integer not null,
          name text default '', path text default '', applicant text default '', date text default '', total real default 0,
          advance real default 0, refund real default 0, note text default '', items text default '[]',
          created text default (datetime('now','localtime')))""")

    def tag(rid):
        return f"【报销单#{rid}】"

    def undo(c, r):
        """撤回这份报销单之前做的事：备用金行、新加的行、改过的付款情况、放进去的发票图。"""
        c.execute("delete from lines where sec='备用金' and vendor like ?", (f"%{tag(r['id'])}%",))
        for it in json.loads(r["items"] or "[]"):
            for fid in it.get("files", []):
                f = c.execute("select * from files where id=?", (fid,)).fetchone()
                if f:
                    for p in (f["path"], f["path"] + ".t.jpg", f["orig"] or ""):
                        if p:
                            try:
                                os.remove(p)
                            except OSError:
                                pass
                    c.execute("delete from files where id=?", (fid,))
            if it.get("line_id"):
                if it.get("created"):
                    c.execute("delete from files where line_id=?", (it["line_id"],))
                    c.execute("delete from lines where id=?", (it["line_id"],))
                elif it.get("prev_pay"):
                    c.execute("update lines set pay=? where id=? and pay='备用金垫付'", (it["prev_pay"], it["line_id"]))

    def apply(c, rid, parsed=None):
        r = c.execute("select * from reimbs where id=?", (rid,)).fetchone()
        pid = r["project_id"]
        undo(c, r)
        items = json.loads(r["items"] or "[]")
        imgs = (parsed or {}).get("_imgs") or store._cell_images(r["path"])
        who = r["applicant"] or "同事"
        # 以前手动补的「同事经手」备用金（没挂报销单的）：由报销单接管
        c.execute("delete from lines where project_id=? and sec='备用金' and vendor like '%【同事经手】%' and vendor not like '%【报销单#%'", (pid,))
        adv = round((r["advance"] or 0) - (r["refund"] or 0), 2)
        if adv:
            c.execute("insert into lines(project_id,sec,cat,seq,name,qty,unit,price,vendor,pay,date,who) values(?,?,?,?,?,?,?,?,?,?,?,?)",
                      (pid, "备用金", "备用金", 1, "备用金", 1, "项", adv,
                       f"【同事经手】{tag(rid)}备用金在{who}处，没经过我的账户；报销申请单：{r['note']}", "已付", r["date"] or "", who))
        used = {it["line_id"] for it in items if it.get("line_id")}
        used = set()
        lines = [dict(x) for x in c.execute("select * from lines where project_id=? and sec<>'备用金'", (pid,))]
        for it in items:
            it.update(line_id=0, created=False, prev_pay="", files=[])
            cand = [l for l in lines if l["id"] not in used and abs(round((l["qty"] or 0) * (l["price"] or 0), 2) - it["amount"]) < 0.011]
            if cand:
                det = it["detail"] or ""
                cand.sort(key=lambda l: (-sum(1 for ch in set(det) if ch in (l["name"] or "") + (l["spec"] or "")), l["pay"] == "备用金垫付"))
                l = cand[0]
                used.add(l["id"])
                it.update(line_id=l["id"], prev_pay=l["pay"], line_name=l["name"] or l["cat"] or "")
                if l["pay"] != "备用金垫付":
                    c.execute("update lines set pay='备用金垫付' where id=?", (l["id"],))
            else:
                sec = SEC_OF.get(it["type"], "执行人员杂费")
                seq = c.execute("select coalesce(max(seq),0)+1 from lines where project_id=? and sec=?", (pid, sec)).fetchone()[0]
                lid = c.execute("insert into lines(project_id,sec,cat,seq,name,qty,unit,price,vendor,pay,date,who) values(?,?,?,?,?,?,?,?,?,?,?,?)",
                                (pid, sec, it["type"] or "", seq, it["detail"] or it["type"] or "报销项", 1, "项", it["amount"],
                                 f"来自报销申请单（{who}）", "备用金垫付", r["date"] or "", who)).lastrowid
                it.update(line_id=lid, created=True, line_name=it["detail"])
            if it.get("img") and it["img"] in imgs:
                has = c.execute("select count(*) from files where line_id=? and kind='invoice'", (it["line_id"],)).fetchone()[0]
                if not has:
                    ext, b = imgs[it["img"]]
                    it["files"] = save_to_line(c, it["line_id"], "invoice", f"报销单发票-{it['detail'] or it['type']}.{ext}", b)
        c.execute("update reimbs set items=? where id=?", (json.dumps(items, ensure_ascii=False), rid))
        return items

    def add_reimb(pid, name, data):
        tmp = os.path.join(DOCS, uuid.uuid4().hex[:10] + ".xlsx")
        open(tmp, "wb").write(data)
        if not is_reimb_xlsx(tmp):
            os.remove(tmp)
            raise HTTPException(400, f"「{name}」看起来不是费用报销申请单")
        try:
            p = parse_reimb(tmp, store._cell_images)
        except Exception as e:
            os.remove(tmp)
            raise HTTPException(400, f"读不懂这份报销申请单：{e}")
        if not p["items"] and not p["advance"]:
            os.remove(tmp)
            raise HTTPException(400, "这份报销申请单里没有读到报销项目和备用金")
        items = [{k: v for k, v in it.items()} for it in p["items"]]
        with store.db() as c:
            old = c.execute("select * from reimbs where project_id=? and name=?", (pid, name)).fetchone()
            if old:                                           # 同名再传 = 替换
                undo(c, old)
                c.execute("delete from reimbs where id=?", (old["id"],))
                try:
                    os.remove(old["path"])
                except OSError:
                    pass
            rid = c.execute("insert into reimbs(project_id,name,path,applicant,date,total,advance,refund,note,items) values(?,?,?,?,?,?,?,?,?,?)",
                            (pid, name, tmp, p["applicant"], p["date"], p["total"], p["advance"], p["refund"], p["note"],
                             json.dumps(items, ensure_ascii=False))).lastrowid
            apply(c, rid, p)
        return rid, p

    h["add_reimb"] = add_reimb
    h["is_reimb_xlsx"] = is_reimb_xlsx

    def reimb_list(pid):
        with store.db() as c:
            rows = [dict(r) for r in c.execute("select * from reimbs where project_id=? order by date, id", (pid,))]
        for r in rows:
            r["items"] = json.loads(r["items"] or "[]")
            for it in r["items"]:
                it.pop("img", None)
            r["spent"] = round(sum(i["amount"] for i in r["items"]), 2)
            net = round((r["advance"] or 0) - (r["refund"] or 0), 2)
            r["net_advance"] = net
            r["balance"] = round(net - (r["total"] or r["spent"]), 2) if net else None
            r.pop("path", None)
        return rows

    h["hooks"]["reimbs"] = reimb_list

    @app.post("/api/projects/{pid}/reimb")
    async def upload_reimb(pid: int, files: List[UploadFile] = File(...)):
        n = 0
        for f in files:
            add_reimb(pid, f.filename or "报销申请单.xlsx", await f.read())
            n += 1
        d = project_detail(pid)
        d["reimb_added"] = n
        return d

    class ReimbEdit(BaseModel):
        applicant: Optional[str] = None
        advance: Optional[float] = None
        refund: Optional[float] = None

    @app.put("/api/reimb/{rid}")
    def edit_reimb(rid: int, b: ReimbEdit):
        sets = {k: v for k, v in b.dict().items() if v is not None}
        with store.db() as c:
            r = c.execute("select project_id from reimbs where id=?", (rid,)).fetchone()
            if not r:
                raise HTTPException(404, "没有这份报销申请单")
            if sets:
                c.execute("update reimbs set " + ",".join(f"{k}=?" for k in sets) + " where id=?", (*sets.values(), rid))
                apply(c, rid)
        return project_detail(r["project_id"])

    @app.delete("/api/reimb/{rid}")
    def del_reimb(rid: int):
        with store.db() as c:
            r = c.execute("select * from reimbs where id=?", (rid,)).fetchone()
            if not r:
                raise HTTPException(404, "没有这份报销申请单")
            undo(c, r)
            c.execute("delete from reimbs where id=?", (rid,))
        try:
            os.remove(r["path"])
        except OSError:
            pass
        return project_detail(r["project_id"])

    @app.get("/api/reimb/{rid}/file")
    def reimb_file(rid: int):
        with store.db() as c:
            r = c.execute("select name,path from reimbs where id=?", (rid,)).fetchone()
        if not r or not os.path.exists(r["path"]):
            raise HTTPException(404, "文件不存在")
        return FileResponse(r["path"], filename=r["name"])

    def match_project(name):
        """报销单里的「项目名称」→ 项目台里的项目（名字互相包含，或去掉年份 / 品牌总称 /「展位」后包含）。"""
        try:
            import bill_tool
            UMB = list(bill_tool.UMBRELLA)               # 品牌总称存在本机 rules.json 里
        except Exception:
            UMB = []

        def _strip_brand(x):
            x = re.sub(r"^20\d{2}|展位|项目|活动|\s", "", x)
            for b in UMB:
                x = x.replace(b, "")
            return x
        if not name:
            return None
        key = _strip_brand(name)
        with store.db() as c:
            ps = [dict(r) for r in c.execute("select id,name from projects")]
        hits = [p for p in ps if p["name"] in name or name in p["name"] or
                (len(key) >= 4 and key in _strip_brand(p["name"]))]
        return hits[0] if len(hits) == 1 else None

    h["reimb_match_project"] = match_project
