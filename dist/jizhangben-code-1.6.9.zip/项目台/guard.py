"""本机访问保护：只接受从本机地址（localhost / 127.0.0.1）打开的页面发来的请求。
挡两种情况：① 别的网站在浏览器里偷偷调用本机接口；② 把外部域名解析到 127.0.0.1 再来访问（DNS 重绑定）。"""
from urllib.parse import urlsplit
from fastapi.responses import JSONResponse

LOCAL = {"localhost", "127.0.0.1", "[::1]", "::1"}


def _hostname(v):
    v = (v or "").strip().lower()
    if v.startswith("["):
        return v.split("]")[0] + "]"
    return v.rsplit(":", 1)[0] if ":" in v else v


def reason(request):
    """返回拒绝原因；允许则返回空串。"""
    h = request.headers
    if _hostname(h.get("host")) not in LOCAL:
        return "只能用 localhost 打开"
    origin = h.get("origin")
    if origin:                                   # 浏览器带了来源：必须是本机页面
        if origin == "null" or (urlsplit(origin).hostname or "") not in ("localhost", "127.0.0.1", "::1"):
            return "不接受别的网站发来的请求"
    if h.get("sec-fetch-site") == "cross-site" and not (request.method == "GET" and h.get("sec-fetch-mode") == "navigate"
                                                         and "/api/" not in request.url.path):
        return "不接受别的网站发来的请求"          # 别的网站里嵌的图片/表单/脚本请求；只放行「点链接打开页面」
    return ""


def install(app):
    @app.middleware("http")
    async def _local_only(request, call_next):
        why = reason(request)
        if why:
            return JSONResponse({"detail": why}, status_code=403)
        return await call_next(request)
