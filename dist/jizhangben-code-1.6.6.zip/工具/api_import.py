#!/usr/bin/env python3
"""写入柴米记账(ezBookkeeping)。既可命令行用，也被「项目台」app 直接调用。

命令行：
  CHAIMI_PASSWORD=密码 python3 api_import.py 导入柴米记账-xxx.csv --user 你的用户名 [--url http://localhost:8080]
"""
import argparse, csv, json, os, re, uuid, threading, urllib.request, urllib.error
from datetime import datetime, timezone, timedelta

TYPE_TX = {"Income": 2, "Expense": 3}
TYPE_CAT = {"Income": 1, "Expense": 2}
COLORS = {"工作": "4F86C6", "生活": "6BAF6B", "待确认": "E0A030"}
PROJECT_COLOR = "2F6FB0"
# 记账本里每个项目一个大类「项目·项目名」，下面是这些子分类（选了项目就能接着选子分类）
PROJECT_EXP_SUBS = ["物料搭建", "第三方人员", "供应商执行", "设计费", "快递物流", "交通", "差旅住宿", "餐补", "打印复印", "软件工具", "招待", "分红转出", "分红提成", "项目款转出", "项目支出"]
# 收入：回款=客户付的项目款；分红=我自己挣的；备用金入款=公司先打给我办事的钱；报销=我垫付后公司还给我的钱
PROJECT_INC_SUBS = ["项目回款", "项目分红", "项目备用金入款", "项目报销"]


def color_of(parent):
    return COLORS.get(parent) or (PROJECT_COLOR if parent.startswith("项目·") else "999999")


def project_parent(row):
    """工作类、带『项目:xx』标签的账 → 分类大类改成『项目·xx』（子类仍是『工作·xx』）。"""
    if row["Category"] == "工作":
        pj = [t[3:] for t in row["Tags"].split(";") if t.startswith("项目:") and t[3:]]
        if pj:
            return f"项目·{pj[0]}"
    return row["Category"]


CAT_LOCK = threading.RLock()      # 建分类必须排队：同时建会建出一堆同名的重复大类


def _flat_categories(api):
    flat = []
    def walk(x):
        if isinstance(x, list):
            for i in x:
                walk(i)
        elif isinstance(x, dict):
            if "name" in x and "type" in x:
                flat.append(x)
            for v in x.values():
                if isinstance(v, (list, dict)):
                    walk(v)
    walk(api.call("GET", "/api/v1/transaction/categories/list.json"))
    return flat


def _sub_ids(api, rows):
    flat = _flat_categories(api)
    have = {(c["type"], c["name"], str(c.get("parentId", "0"))): c["id"] for c in flat}
    sub_id = {}
    for typ, parent, sub in sorted({(r["Type"], r["Category"], r["Sub Category"]) for r in rows}):
        ct = TYPE_CAT[typ]
        pid = have.get((ct, parent, "0"))
        if not pid:
            pid = api.call("POST", "/api/v1/transaction/categories/add.json", dict(
                name=parent, type=ct, parentId="0", icon="1", iconType=0, color=color_of(parent), comment=""))["id"]
            have[(ct, parent, "0")] = pid
        cid = have.get((ct, sub, str(pid)))
        if not cid:
            cid = api.call("POST", "/api/v1/transaction/categories/add.json", dict(
                name=sub, type=ct, parentId=str(pid), icon="1", iconType=0, color=color_of(parent), comment=""))["id"]
            have[(ct, sub, str(pid))] = cid
        sub_id[(typ, parent, sub)] = cid
    return sub_id


def ensure_base_categories(api, base):
    """base: {"工作": [子类...], "生活": [...]}（支出）。记账本里没有的子分类补上，下拉里就能选全。"""
    with CAT_LOCK:
        return _ensure_base(api, base)


def _ensure_base(api, base):
    flat = _flat_categories(api)
    have = {(c["type"], c["name"], str(c.get("parentId", "0"))): c["id"] for c in flat}
    n = 0
    for parent, subs in base.items():
        pid = have.get((2, parent, "0"))
        if not pid:
            pid = api.call("POST", "/api/v1/transaction/categories/add.json", dict(
                name=parent, type=2, parentId="0", icon="1", iconType=0, color=color_of(parent), comment=""))["id"]
            n += 1
        for sub in subs:
            if not have.get((2, f"{parent}·{sub}", str(pid))):
                api.call("POST", "/api/v1/transaction/categories/add.json", dict(
                    name=f"{parent}·{sub}", type=2, parentId=str(pid), icon="1", iconType=0, color=color_of(parent), comment=""))
                n += 1
    return n


def ensure_project_categories(api, names, extra_exp=()):
    """保证每个项目在记账本里都有『项目·名称』大类和整套子分类。返回新建个数。"""
    with CAT_LOCK:
        return _ensure_project(api, names, extra_exp)


def _ensure_project(api, names, extra_exp=()):
    flat = _flat_categories(api)
    have = {(c["type"], c["name"], str(c.get("parentId", "0"))): c["id"] for c in flat}
    n = 0
    for name in names:
        if not name:
            continue
        parent = f"项目·{name}"
        for ct, subs in ((2, PROJECT_EXP_SUBS + [x for x in extra_exp if x not in PROJECT_EXP_SUBS]), (1, PROJECT_INC_SUBS)):
            pid = have.get((ct, parent, "0"))
            if not pid:
                pid = api.call("POST", "/api/v1/transaction/categories/add.json", dict(
                    name=parent, type=ct, parentId="0", icon="1", iconType=0, color=PROJECT_COLOR, comment=""))["id"]
                have[(ct, parent, "0")] = pid
                n += 1
            for sub in subs:
                if not have.get((ct, f"工作·{sub}", str(pid))):
                    have[(ct, f"工作·{sub}", str(pid))] = api.call("POST", "/api/v1/transaction/categories/add.json", dict(
                        name=f"工作·{sub}", type=ct, parentId=str(pid), icon="1", iconType=0, color=PROJECT_COLOR, comment=""))["id"]
                    n += 1
    return n
ACC_COLORS = {"微信零钱": "1AAD19", "微信零钱通": "07C160", "支付宝": "1677FF", "余额宝": "FF8C00", "花呗": "1E90FF", "备用金": "E0A030"}
ACC_ALIAS = {"微信": "微信零钱"}          # 旧写法「微信」= 微信零钱


def acc_name(n):
    return ACC_ALIAS.get(n or "微信", n or "微信零钱")


def acc_category(n):
    """记账本账户类型（ezb 编号）：1 现金 2 储蓄卡 3 信用卡 4 虚拟账户（零钱/支付宝/外币卡）；5 是「负债账户」，不能用"""
    if "信用卡" in n or n == "花呗" or "赊账" in n:      # 赊账：先消费、还没付钱，欠着的钱（负债）
        return 3
    if re.search(r"储蓄卡|借记卡|银行", n):
        return 2
    if n in ("现金", "备用金"):
        return 1
    return 4


class ApiError(Exception):
    pass


class Api:
    def __init__(self, base, user, pw):
        self.base = base.rstrip("/")
        self._cred = (user, pw)
        self.login()

    def login(self):
        # 几个程序同时登录时，记账本会报 database table is locked（生成不了登录凭证）：等一下再试，最多 6 次
        import time
        for i in range(6):
            try:
                r = self._call("POST", "/api/authorize.json", dict(loginName=self._cred[0], password=self._cred[1]), auth=False)
                break
            except ApiError as e:
                if i == 5 or ("locked" not in str(e) and "generate token" not in str(e)):
                    raise
                time.sleep(0.2 * (i + 1))
        self.token = r["token"]

    def call(self, method, path, body=None, auth=True, raw=None, headers=None):
        """记账本偶尔会报 database table is locked（同时有别的写入），写操作自动重试几次。"""
        import time
        for i in range(4):
            try:
                return self._call(method, path, body, auth, raw, headers)
            except ApiError as e:
                if auth and "token" in str(e).lower() and i < 3:      # 登录过期：重新登录再试
                    self.login()
                    continue
                if method == "GET" or i == 3 or "operation failed" not in str(e) and "locked" not in str(e):
                    raise
                time.sleep(0.6 * (i + 1))

    def _call(self, method, path, body=None, auth=True, raw=None, headers=None):
        data = raw if raw is not None else (json.dumps(body).encode() if body is not None else None)
        req = urllib.request.Request(self.base + path, method=method, data=data)
        if raw is None:
            req.add_header("Content-Type", "application/json")
        req.add_header("X-Timezone-Offset", "-480")  # 同浏览器 getTimezoneOffset()：东八区=-480
        if auth:
            req.add_header("Authorization", "Bearer " + self.token)
        for k, v in (headers or {}).items():
            req.add_header(k, v)
        try:
            raw_resp = urllib.request.urlopen(req, timeout=180).read()
        except urllib.error.HTTPError as e:
            raw_resp = e.read()
        except urllib.error.URLError as e:
            raise ApiError(f"连不上记账软件({self.base})：{e.reason}")
        j = json.loads(raw_resp)
        if not j.get("success"):
            raise ApiError(f"接口失败 {path}: {j.get('errorMessage')}")
        return j["result"]


def rid(comment):
    m = re.search(r"〔ID:(.+?)〕", comment or "")
    return m.group(1) if m else None


def push_rows(api, rows, log=print):
    """rows: 每笔含 Time/Type/Category/Sub Category/Account/Amount/Tags/Description。
    已存在(按备注里的〔ID:..〕)跳过；已存在但分类/标签/备注变了就原地更新；其余新增。"""
    accs = {x["name"]: x["id"] for x in api.call("GET", "/api/v1/accounts/list.json")}
    for r in rows:
        r["Account"] = acc_name(r["Account"])
    for n in sorted({r["Account"] for r in rows}):
        if n not in accs:
            accs[n] = api.call("POST", "/api/v1/accounts/add.json", dict(
                name=n, category=acc_category(n), type=1, icon="1", iconType=0, color=ACC_COLORS.get(n, "888888"),
                currency="CNY", balance="0", comment=""))["id"]
            log(f"已新建账户：{n}")

    for r in rows:
        r["Category"] = project_parent(r)
    with CAT_LOCK:
        sub_id = _sub_ids(api, rows)

    tags_all = {t for r in rows for t in r["Tags"].split(";") if t}
    existing = {t["name"]: t["id"] for t in api.call("GET", "/api/v1/transaction/tags/list.json")}
    for t in sorted(tags_all):
        if t not in existing:
            existing[t] = api.call("POST", "/api/v1/transaction/tags/add.json", dict(name=t, groupId="0"))["id"]

    exist = {}
    for t in api.call("GET", "/api/v1/transactions/list/all.json?start_time=0&end_time=9999999999999"):
        i = rid(t.get("comment"))
        if i:
            exist[i] = t
    tz = timezone(timedelta(hours=8))
    txs, skipped, updated = [], 0, 0
    for r in rows:
        i = rid(r["Description"])
        want_cat = str(sub_id[(r["Type"], r["Category"], r["Sub Category"])])
        want_tags = sorted(str(existing[x]) for x in r["Tags"].split(";") if x)
        if i and i in exist:
            t = exist[i]
            want_amt = int(round(float(r["Amount"]) * 100))
            want_type = TYPE_TX[r["Type"]] if t["type"] in (2, 3) else t["type"]     # 收入↔支出可以原地改（余额跟着变）；转账不动
            if (t["type"] == want_type and str(t["categoryId"]) == want_cat and sorted(t.get("tagIds") or []) == want_tags
                    and t.get("comment") == r["Description"][:255] and t["sourceAmount"] == want_amt):
                skipped += 1
                continue
            api.call("POST", "/api/v1/transactions/modify.json", dict(
                id=str(t["id"]), type=want_type, categoryId=want_cat, time=t["time"], utcOffset=t["utcOffset"],
                sourceAccountId=str(t["sourceAccountId"]), destinationAccountId=str(t.get("destinationAccountId") or 0),
                sourceAmount=want_amt, destinationAmount=t.get("destinationAmount", 0), hideAmount=t.get("hideAmount", False),
                tagIds=want_tags, pictureIds=[p["pictureId"] for p in (t.get("pictures") or [])],
                comment=r["Description"][:255]))
            updated += 1
            continue
        ts = int(datetime.strptime(r["Time"], "%Y-%m-%d %H:%M:%S").replace(tzinfo=tz).timestamp())
        txs.append(dict(
            type=TYPE_TX[r["Type"]], categoryId=want_cat, time=ts, utcOffset=480,
            sourceAccountId=str(accs[r["Account"]]), destinationAccountId="0",
            sourceAmount=int(round(float(r["Amount"]) * 100)), destinationAmount=0, hideAmount=False,
            tagIds=want_tags, pictureIds=[], comment=r["Description"][:255]))
    log(f"已存在跳过 {skipped} 笔；更新 {updated} 笔；新增 {len(txs)} 笔")
    for i in range(0, len(txs), 500):
        api.call("POST", "/api/v1/transactions/import.json", dict(transactions=txs[i:i + 500], clientSessionId=str(uuid.uuid4())))
    return dict(skipped=skipped, updated=updated, added=len(txs))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--url", default="http://localhost:8080")
    ap.add_argument("--user", required=True)
    a = ap.parse_args()
    pw = os.environ.get("CHAIMI_PASSWORD")
    if not pw:
        raise SystemExit("请先设置环境变量 CHAIMI_PASSWORD")
    rows = list(csv.DictReader(open(a.csv, encoding="utf-8-sig")))
    print(f"读入 {len(rows)} 笔")
    push_rows(Api(a.url, a.user, pw), rows)
    print("完成")


if __name__ == "__main__":
    main()
