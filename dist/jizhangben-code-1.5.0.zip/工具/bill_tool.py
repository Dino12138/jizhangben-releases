#!/usr/bin/env python3
"""柴米记账 · 账单转换器
微信 / 支付宝账单 -> ezBookkeeping 可直接导入的 CSV，并自动分「工作 / 生活」。

用法：
  python3 bill_tool.py convert 微信账单.xlsx 支付宝账单.csv [--out 输出目录] [--ignore-seen]
  python3 bill_tool.py learn   输出目录/待确认.csv        # 把你填好的判断记住，下次自动归类
"""
import argparse, csv, json, os, re, sys, glob
from datetime import datetime, timedelta

HERE = os.path.dirname(os.path.abspath(__file__))
# 用户自己的状态文件（学到的判断、项目登记、标注、规则副本）放 STATE；打包成 app 后在「应用支持」文件夹里
STATE = os.environ.get("CHAIMI_STATE", HERE)
os.makedirs(STATE, exist_ok=True)
RULES = os.path.join(STATE, "rules.json")
if not os.path.exists(RULES):
    RULES = os.path.join(HERE, "rules.json")
LEARNED = os.path.join(STATE, "learned.json")
SEEN = os.path.join(STATE, "seen_ids.json")
PROJECTS = os.path.join(STATE, "projects.json")
ANN = os.path.join(STATE, "项目标注.json")

OUT_COLS = ["Time", "Timezone", "Type", "Category", "Sub Category", "Account", "Account Currency",
            "Amount", "Account2", "Account2 Currency", "Account2 Amount", "Geographic Location",
            "Tags", "Description"]


# ---------- 读文件 ----------
def read_rows(path):
    """返回 (来源, 行列表[list])；自动识别编码和 csv/xlsx。"""
    if path.lower().endswith((".xlsx", ".xlsm")):
        import openpyxl
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
        ws = wb.active
        return [["" if c is None else str(c).strip() for c in r] for r in ws.iter_rows(values_only=True)]
    raw = open(path, "rb").read()
    for enc in ("utf-8-sig", "gb18030"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise SystemExit(f"无法识别编码：{path}")
    return [[c.strip() for c in r] for r in csv.reader(text.splitlines())]


def money(s):
    s = re.sub(r"[¥￥,\s]", "", str(s or ""))
    m = re.search(r"-?\d+(\.\d+)?", s)
    return float(m.group()) if m else 0.0


def norm_time(s):
    s = str(s).strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y/%m/%d %H:%M"):
        try:
            return datetime.strptime(s[:19] if len(s) > 16 else s, fmt).strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            pass
    return s


def parse_bill(path):
    rows = read_rows(path)
    hi = None
    for i, r in enumerate(rows):
        joined = ",".join(r)
        if ("交易时间" in joined or "交易创建时间" in joined or "付款时间" in joined) and ("收/支" in joined):
            hi = i
            break
    if hi is None:
        raise SystemExit(f"找不到表头（不像微信/支付宝账单）：{path}")
    head = [h.strip() for h in rows[hi]]
    is_wechat = "交易类型" in head and "支付方式" in head
    col = {h: i for i, h in enumerate(head)}

    def g(r, *names):
        for n in names:
            if n in col and col[n] < len(r) and r[col[n]].strip():
                return r[col[n]].strip()
        return ""

    out = []
    for r in rows[hi + 1:]:
        if len(r) < 5 or not any(r):
            continue
        t = g(r, "交易时间", "付款时间", "交易创建时间")
        if not re.match(r"\d{4}[-/]\d{1,2}[-/]\d{1,2}", t):
            continue
        d = dict(
            src="微信" if is_wechat else "支付宝",  # 来源；记到哪个账户看 account_of(src, method)
            time=norm_time(t),
            kind=g(r, "收/支"),
            amount=money(g(r, "金额(元)", "金额（元）", "金额")),
            cp=g(r, "交易对方"),
            item=g(r, "商品", "商品名称", "商品说明"),
            note=g(r, "备注"),
            status=g(r, "当前状态", "交易状态"),
            typ=g(r, "交易类型", "类型", "交易分类"),
            id=g(r, "交易单号", "交易号", "交易订单号"),
            method=g(r, "支付方式", "收/付款方式"),
            refund=money(g(r, "成功退款（元）", "成功退款(元)")),
        )
        out.append(d)
    return out


# ---------- 账户：按账单里的「支付方式」分到对应账户（零钱 / 零钱通 / 哪张银行卡 / 亲属卡…）----------
def account_of(src, method):
    m = (method or "").strip().split("\n")[0].split("&")[0].strip()
    m = re.sub(r"(付款)?[¥￥][\d.,]+$", "", m).strip()
    mm = re.match(r"(.+?(储蓄卡|信用卡|借记卡))\s*[（(](\d{4})[)）]", m)
    if mm:
        return f"{mm.group(1)}({mm.group(3)})"
    if src == "支付宝":
        if "余额宝" in m:
            return "余额宝"
        if "花呗" in m:
            return "花呗"
        if not m or m == "/" or "余额" in m or "账户" in m:
            return "支付宝"
    else:
        if "零钱通" in m:
            return "微信零钱通"
        if not m or m == "/" or "零钱" in m:
            return "微信零钱"
    if "亲属卡" in m:
        return m[:20]
    return m[:20] or ("微信零钱" if src == "微信" else src)


def account_family(name):
    """账户属于哪一边：微信 / 支付宝 / 银行卡 / 其他（现金、备用金…）"""
    n = name or "微信零钱"
    if n.startswith("微信") or n == "零钱通" or "亲属卡" in n:
        return "微信"
    if n in ("支付宝", "余额宝", "花呗"):
        return "支付宝"
    if re.search(r"银行|储蓄卡|信用卡|借记卡|银行卡", n):
        return "银行卡"
    return n


# ---------- 分类 ----------
def load_json(p, default):
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    return default


def load_projects(rules):
    """项目登记表。首次运行把 rules.json 里的『项目周期』迁移过来。"""
    if os.path.exists(PROJECTS):
        return load_json(PROJECTS, [])
    ps = [dict(name=p["name"], start=p["start"], end=p["end"], customer="众安") for p in rules.get("项目周期", [])]
    json.dump(ps, open(PROJECTS, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return ps


def add_project(name, start="", end="", customer=""):
    ps = load_projects(load_json(RULES, {}))
    for p in ps:
        if p["name"] == name:
            return False
    ps.append(dict(name=name, start=start, end=end, customer=customer))
    json.dump(ps, open(PROJECTS, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    return True


def hit(text, words):
    return next((w for w in words if w.lower() in text), None)


def project_window(day, rules, lead=30):
    """day: datetime.date。返回周期(含lead天前置)命中的项目名(取开始最早)，没有则''。"""
    best = None
    for p in rules.get("项目周期", []):
        if not p.get("start") or not p.get("end"):
            continue
        a = datetime.strptime(p["start"], "%Y-%m-%d").date()
        b = datetime.strptime(p["end"], "%Y-%m-%d").date()
        if (a - timedelta(days=lead)) <= day <= b and (best is None or a < best[0]):
            best = (a, p["name"])
    return best[1] if best else ""


def event_day_project(day, rules):
    return project_window(day, rules, lead=0)


# ---------- 转账备注优先 ----------
# 你在微信转账/收款时写的备注最能说明这笔钱是干什么的：备注里有信息时，它比「对方是谁」更优先。
DEFAULT_ALIAS = {}      # 备注里的简称 → 项目：写在 rules.json 的「项目别名」里（每个人自己的项目不同，不写死在程序里）
DEFAULT_REMARKS = {"", "/", "微信转账", "转账", "转账给你", "收款", "二维码收款", "红包", "恭喜发财，大吉大利", "恭喜发财,大吉大利"}
R_INC_BACK = r"回款|尾款|结算|项目款|货款|提成|设计费|服务费|费用结算"
R_INC_DIV = r"分红|提成|利润分配|奖金"
R_INC_REIMB = r"备用金|报销|垫付|垫的|打车|车费|车票|餐费|饭钱|酒店|住宿|运费|快递|顺丰|物料|采买|采购|剩余|返还|退回"
R_REPAY = r"^还|还欠|还差|还款|还钱|还你|现还|欠.{0,12}还|借款|借你|借给"
UMBRELLA = {"抖音", "安踏", "美团", "CLC", "众安", "银联"}      # 总称：已经归到具体项目的，不要被拉回总称
R_PERSONAL = r"个人消费|个人|私人|自己用|家用|房租|生活费|孝敬|爸|妈|宝宝|老婆|老公|生日|份子|随礼|红包"


def remark_of(d):
    """取你写的转账备注（微信放在「商品」里的『转账备注:xxx』，或「备注」列）；默认文字当没写。"""
    txt = ""
    m = re.search(r"转账备注[:：]\s*(.*)", d.get("item") or "")
    if m:
        txt = m.group(1).strip()
    note = (d.get("note") or "").strip()
    is_tr = any(k in (d.get("typ") or "") for k in ("转账", "红包", "二维码", "收款码"))
    if not txt and note and note != "/" and is_tr and not re.search(r"优惠|折扣|抵扣|立减", note):
        txt = note
    txt = re.sub(r"^(转账说明|备注|用途)[:：]\s*", "", txt)
    if txt in DEFAULT_REMARKS or re.fullmatch(r"(微信)?转账", txt):
        return ""
    return txt[:60]


def _project_names(rules):
    names = [p.get("name", "") for p in rules.get("项目周期", [])]
    try:
        names += [p.get("name", "") for p in load_json(PROJECTS, [])]
    except Exception:
        pass
    return sorted({n for n in names if n}, key=len, reverse=True)


def remark_project(rm, rules):
    """备注里提到的项目：项目全名 > 别名 > 项目名里 ≥3 个字母或 ≥4 个汉字的词。"""
    low = rm.lower()
    names = _project_names(rules)
    alias = dict(DEFAULT_ALIAS, **{k.lower(): v for k, v in (rules.get("项目别名") or {}).items() if not k.startswith("说明")})
    for n in names:                                     # 具体项目全名
        if n not in UMBRELLA and n.lower() in low:
            return n, n
    for k in sorted(alias, key=len, reverse=True):      # 简称（杭马、创大、cj展…）；只认已经存在的项目
        if k.lower() in low and alias[k] in names:
            return alias[k], k
    for n in names:                                     # 总称（抖音、安踏…）
        if n in UMBRELLA and n.lower() in low:
            return n, n
    for n in names:
        for tok in re.findall(r"[A-Za-z]{3,}|[\u4e00-\u9fa5]{4,}", n):
            if tok.lower() in low and tok not in ("活动", "项目", "众安", "抖音", "美团", "安踏"):
                return n, tok
    return "", ""


def remark_adjust(d, res, rules):
    """在常规判断（res）的基础上，用转账备注修正：用途 = 你写的备注；能看出项目/用途类型的，按备注改分类。"""
    rm = remark_of(d)
    if not rm or res.get("why") == "成本单标注":
        return res
    out = dict(res)
    pj, hitw = remark_project(rm, rules)
    cur_pj = res.get("project") if res.get("scope") == "工作" else ""
    if pj in UMBRELLA and cur_pj and cur_pj not in UMBRELLA:
        pj, hitw = cur_pj, ""                           # 已经在具体项目里：不拉回总称
    purpose = rm
    if hitw and hitw not in UMBRELLA and rm.lower().startswith(hitw.lower()):   # 「杭马打车」→「打车」
        p2 = rm[len(hitw):].strip(" -_—·,，、:：()（）【】[]")
        purpose = p2 or purpose
    out["purpose"] = purpose[:30]
    low = rm.lower()
    work_sub = next((s.replace("工作-", "") for s, ws in rules["工作"].items() if hit(low, ws)), "")
    life_sub = next((s for s, ws in rules["生活"].items() if hit(low, ws)), "")
    if "房租" in rm:
        life_sub = "房租"
    if d["kind"] == "收入":
        if re.search(r"工资|薪", rm) and not pj:             # 工资：分类照旧（规则里的「工资薪酬」），只填用途
            return out
        if re.search(R_REPAY, rm) or ("退款" in rm and not pj):
            out.update(scope="生活", sub="还款退款", project="")
        elif re.search(R_INC_REIMB, rm) and not re.search(R_INC_BACK, rm):
            # 备注写了「备用金」= 公司先打给我的钱；其余（报销/垫付/车费…）= 我先垫了、公司还给我的钱
            out.update(scope="工作", sub="项目备用金入款" if "备用金" in rm else "项目报销", project=pj or (res.get("project") if res.get("scope") == "工作" else ""))
        elif re.search(R_INC_BACK, rm) or pj or work_sub:
            out.update(scope="工作", sub="项目分红" if re.search(R_INC_DIV, rm) else ("项目回款" if re.search(R_INC_BACK, rm) else "项目备用金入款"),
                       project=pj or (res.get("project") if res.get("scope") == "工作" else ""))
        elif re.search(R_PERSONAL, rm):
            out.update(scope="生活", sub="红包转账", project="")
        out["why"] = f"转账备注:{rm[:20]}"
        return out
    # 支出
    if "房租" in rm:
        out.update(scope="生活", sub="房租", project="")
    elif re.search(R_REPAY, rm):
        out.update(scope="生活", sub="人情往来", project="", purpose=("还款 · " + purpose)[:30] if "还" not in purpose[:2] else purpose[:30])
    elif re.search(R_PERSONAL, rm) and not pj:
        out.update(scope="生活", sub=life_sub or ("日用百货" if "个人消费" in rm else "人情往来"), project="")
    elif pj or work_sub or re.search(r"采买|车票|物料|督导|摄影|摄像|执行|搭建|场地|设计|打印|运输|运费|兼职|教练|打样|定制|制作|客户", rm):
        keep = res.get("scope") == "工作" and res.get("sub") not in ("", "项目支出", "项目回款", "其他")
        sub = (res["sub"] if keep else work_sub) or ("交通" if re.search(r"打车|车费|车票|机票|高铁|交通", rm) else
                           "差旅住宿" if re.search(r"酒店|住宿", rm) else
                           "人员劳务" if re.search(r"督导|兼职|教练|劳务|人员", rm) else
                           "招待" if re.search(r"餐|饭|招待", rm) else
                           "物料搭建" if re.search(r"采买|采购|物料|画架", rm) else "项目支出")
        out.update(scope="工作", sub=sub, project=pj or (res.get("project") if res.get("scope") == "工作" else ""))
    elif life_sub:
        out.update(scope="生活", sub=life_sub, project="")
    else:
        return dict(out, why=res.get("why", ""))         # 备注看不出类型：分类照旧，只把用途换成你写的备注
    out["why"] = f"转账备注:{rm[:20]}"
    return out


def classify(d, rules, learned, ann=None):
    """常规判断 + 转账备注修正。返回 dict(scope, sub, project, purpose, why)"""
    res = _classify_base(d, rules, learned, ann)
    try:
        return remark_adjust(d, res, rules)
    except Exception:
        return res


def _classify_base(d, rules, learned, ann=None):
    """返回 dict(scope, sub, project, why)；scope ∈ 工作/生活/待确认"""
    text = f"{d['cp']} {d['item']} {d['note']} {d['typ']}".lower()
    key = d["cp"].strip().lower()
    # 0 成本单/手动按单号标注（最高优先级）
    A = (ann or {}).get(d.get("uid", ""))
    if A:
        return dict(scope=A.get("scope") or "工作", sub=A.get("sub") or ("项目回款" if d["kind"] == "收入" else "项目支出"),
                    project=A.get("project", ""), purpose=A.get("purpose", ""), why="成本单标注")
    # 1 你确认过的
    if key and key in learned:
        L = learned[key]
        return dict(scope=L["scope"], sub=L.get("sub") or "其他", project=L.get("project", ""),
                    purpose=L.get("purpose", ""), why="你确认过")
    project = ""
    for p, ws in rules["项目"].items():
        if hit(text, ws):
            project = p
            break
    # 2 收入
    if d["kind"] == "收入":
        for sub, ws in rules["收入分类"].items():
            if hit(text, ws):
                scope = "工作" if sub.startswith("工作-") else ("生活" if sub != "退款" else "待确认")
                return dict(scope=scope, sub=sub.replace("工作-", ""), project=project, why=f"收入词:{hit(text, ws)}")
        if project:
            return dict(scope="工作", sub="项目回款", project=project, why=f"项目词:{project}")
        for s_, ws in rules["工作"].items():
            w = hit(text, ws)
            if w:
                return dict(scope="待确认", sub="收入", project="", why=f"收入，含工作词:{w}，请判断")
        return dict(scope="待确认", sub="收入", project="", why="收入来源无法判断")
    # 2.5 打车：晚9点后归项目（你定的规则）
    nt = rules.get("夜间打车")
    if nt and d["kind"] == "支出" and hit(text, nt["关键词"]):
        dt = datetime.strptime(d["time"], "%Y-%m-%d %H:%M:%S")
        night = dt.hour >= nt["起始小时"] or dt.hour < nt["凌晨截止小时"]
        eff = (dt - timedelta(days=1)).date() if dt.hour < nt["凌晨截止小时"] else dt.date()
        if night:
            pj = project_window(eff, rules, nt["lead_days"])
            if pj:
                return dict(scope="工作", sub="交通", project=pj, why="夜间打车规则")
            return dict(scope="生活", sub="交通出行", project="", why="夜间打车但不在项目周期")
        pj = event_day_project(dt.date(), rules)
        if pj:
            return dict(scope="待确认", sub="项目期间打车", project="", why=f"项目期间白天打车，可能属于:{pj}")
        return dict(scope="生活", sub="交通出行", project="", why="白天打车")
    # 3 项目词直接算工作
    if project:
        sub = "项目支出"
        for s, ws in rules["工作"].items():
            if hit(text, ws):
                sub = s.replace("工作-", "")
                break
        return dict(scope="工作", sub=sub, project=project, why=f"项目词:{project}")
    # 4 工作词
    for s, ws in rules["工作"].items():
        w = hit(text, ws)
        if w:
            return dict(scope="工作", sub=s.replace("工作-", ""), project="", why=f"工作词:{w}")
    # 5 待确认词（出行等，工作生活都可能）
    for s, ws in rules["待确认词"].items():
        w = hit(text, ws)
        if w:
            return dict(scope="待确认", sub=s, project="", why=f"可能工作可能生活:{w}")
    # 6 生活词
    for s, ws in rules["生活"].items():
        w = hit(text, ws)
        if w:
            return dict(scope="生活", sub=s, project="", why=f"生活词:{w}")
    # 7 个人转账大额
    th = rules["待确认阈值"]["个人转账金额>="]
    is_transfer = any(k in (d["typ"] + d["item"]) for k in ("转账", "二维码收款", "收款码", "扫二维码付款"))
    if is_transfer and d["amount"] >= th:
        return dict(scope="待确认", sub="大额个人转账", project="", why=f"个人转账>={th}")
    if is_transfer or "红包" in d["typ"]:
        return dict(scope="生活", sub="人情往来", project="", why="小额个人转账")
    pj = event_day_project(datetime.strptime(d["time"][:10], "%Y-%m-%d").date(), rules)
    return dict(scope="待确认", sub="未分类", project="", why="没匹配到规则" + (f"，发生在项目期间:{pj}" if pj else ""))


# ---------- 转换 ----------
def process(files, ignore_seen=False):
    """解析+过滤+分类，返回 (记录列表, 统计, rules)。不写文件、不标记已导入。"""
    rules = load_json(RULES, None)
    if not rules:
        raise SystemExit(f"缺少规则文件：{RULES}")
    learned = load_json(LEARNED, {})
    seen = set(load_json(SEEN, []))
    ignore_words = rules["忽略"]["关键词"]
    rules["项目周期"] = load_projects(rules)
    ann = load_json(ANN, {})

    recs, stats = [], dict(总行数=0, 跳过_不计收支=0, 跳过_失败关闭=0, 跳过_退款抵消=0, 跳过_已导入过=0, 跳过_账户间转移=0)
    for f in files:
        for d in parse_bill(f):
            stats["总行数"] += 1
            if d["kind"] not in ("支出", "收入"):
                stats["跳过_不计收支"] += 1
                continue
            st = d["status"]
            if any(k in st for k in ("关闭", "失败", "已取消", "对方已退还")):
                stats["跳过_失败关闭"] += 1
                continue
            blob = f"{d['typ']} {d['cp']} {d['item']}"
            if "退款" in d["typ"] and d["kind"] == "收入":
                stats["跳过_退款抵消"] += 1  # 用「原支出扣减」处理，避免重复
                continue
            if "已全额退款" in st or "全额退款" in st:
                stats["跳过_退款抵消"] += 1
                continue
            m = re.search(r"退款.?[¥￥]?\s*(\d+(\.\d+)?)", st)
            if m and d["kind"] == "支出":
                d["amount"] = round(d["amount"] - float(m.group(1)), 2)
            if d["refund"] and d["kind"] == "支出":
                d["amount"] = round(d["amount"] - d["refund"], 2)
            if d["amount"] <= 0:
                stats["跳过_退款抵消"] += 1
                continue
            # 转账/红包的备注是你自己写的话（如「还款」「理财课」），不能拿来判断「账户间挪钱」，只看交易类型和对方
            is_tr = any(k in d["typ"] for k in ("转账", "红包", "二维码", "收款码"))
            if any(w in (f"{d['typ']} {d['cp']}" if is_tr else blob) for w in ignore_words):
                stats["跳过_账户间转移"] += 1
                continue
            uid = f"{d['src']}:{d['id']}" if d["id"] else f"{d['src']}:{d['time']}:{d['amount']}:{d['cp']}"
            if uid in seen and not ignore_seen:
                stats["跳过_已导入过"] += 1
                continue
            d["uid"] = uid
            d.update(classify(d, rules, learned, ann))
            recs.append(d)
    recs.sort(key=lambda x: x["time"])
    return recs, stats, rules


def rec_description(d):
    core = " | ".join(x for x in (d["cp"], d["item"], d["note"]) if x and x != "/")
    pre = f"【{d['project']}｜{d['purpose']}】" if d["project"] and d.get("purpose") else (f"【{d['project']}】" if d["project"] else (f"【｜{d['purpose']}】" if d.get("purpose") else ""))
    suf = f"〔ID:{d['uid']}〕"
    return pre + core[:max(0, 250 - len(pre) - len(suf))] + suf


def convert(files, outdir, ignore_seen):
    recs, stats, rules = process(files, ignore_seen)
    seen = set(load_json(SEEN, []))
    os.makedirs(outdir, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d-%H%M")
    out_csv = os.path.join(outdir, f"导入柴米记账-{ts}.csv")
    with open(out_csv, "w", newline="", encoding="utf-8") as fp:  # 无BOM：柴米记账导入器不认BOM
        w = csv.writer(fp)
        w.writerow(OUT_COLS)
        for d in recs:
            tags = [d["scope"]] + ([f"项目:{d['project']}"] if d["project"] else [])
            core = " | ".join(x for x in (d["cp"], d["item"], d["note"]) if x and x != "/")
            pre = f"【{d['project']}｜{d['purpose']}】" if d["project"] and d.get("purpose") else (f"【{d['project']}】" if d["project"] else (f"【｜{d['purpose']}】" if d.get("purpose") else ""))
            suf = f"〔ID:{d['uid']}〕"
            desc = pre + core[:max(0, 250 - len(pre) - len(suf))] + suf
            w.writerow([d["time"], "+08:00", "Income" if d["kind"] == "收入" else "Expense",
                        d["scope"], f"{d['scope']}·{d['sub']}", d["src"], "CNY", f"{d['amount']:.2f}", "", "", "", "",
                        ";".join(tags), desc])

    # 待确认清单（合并同一对方，方便一次判断一批）
    pend = {}
    for d in recs:
        if d["scope"] == "待确认":
            k = d["cp"].strip() or "(无对方)"
            e = pend.setdefault(k, dict(n=0, total=0.0, ex=d["item"], why=d["why"], kind=set()))
            e["kind"].add(d["kind"])
            e["n"] += 1
            e["total"] += d["amount"]
    review = os.path.join(outdir, f"待确认-{ts}.xlsx")
    write_review(review, pend, load_projects(rules))

    if not ignore_seen:
        seen.update(d["uid"] for d in recs)
        json.dump(sorted(seen), open(SEEN, "w", encoding="utf-8"), ensure_ascii=False)

    # 汇总
    by = {}
    for d in recs:
        if d["kind"] == "支出":
            by[d["scope"]] = by.get(d["scope"], 0) + d["amount"]
    print("—— 转换完成 ——")
    for k, v in stats.items():
        print(f"  {k}: {v}")
    print(f"  写入 {len(recs)} 笔 → {out_csv}")
    print("  支出合计：" + "，".join(f"{k} {v:,.2f}" for k, v in by.items()))
    print(f"  待确认对象 {len(pend)} 个 → {review}")
    return out_csv, review


NEW_PROJECT = "＋新项目(在右边一列填名称)"
COLS = ["交易对方", "收/支", "笔数", "合计(元)", "示例商品", "为什么没法判断",
        "我的判断(工作/生活)", "所属项目(下拉选)", "新项目名称(新项目才填)", "用途备注(可空)", "子类(可空)"]


def write_review(path, pend, projects):
    import openpyxl
    from openpyxl.worksheet.datavalidation import DataValidation
    from openpyxl.styles import Font, PatternFill
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "待确认"
    ws.append(COLS)
    for c in ws[1]:
        c.font = Font(bold=True)
    for k, e in sorted(pend.items(), key=lambda kv: -kv[1]["total"]):
        ws.append([k, "/".join(sorted(e["kind"])), e["n"], round(e["total"], 2), e["ex"], e["why"], None, None, None, None, None])
    opt = wb.create_sheet("选项")
    opt["A1"] = "项目"
    for i, pr in enumerate(["(无项目)"] + [p["name"] for p in projects] + [NEW_PROJECT], 2):
        opt.cell(row=i, column=1, value=pr)
    n = len(projects) + 3
    n_rows = max(ws.max_row, 2)
    dv1 = DataValidation(type="list", formula1='"工作,生活"', allow_blank=True)
    dv2 = DataValidation(type="list", formula1=f"=选项!$A$2:$A${n}", allow_blank=True)
    ws.add_data_validation(dv1); ws.add_data_validation(dv2)
    dv1.add(f"G2:G{n_rows}"); dv2.add(f"H2:H{n_rows}")
    for col, w in zip("ABCDEFGHIJK", (28, 8, 6, 12, 28, 26, 16, 30, 26, 24, 14)):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "B2"
    wb.save(path)


def read_review(path):
    if path.lower().endswith(".xlsx"):
        import openpyxl
        ws = openpyxl.load_workbook(path, data_only=True)["待确认"]
        rows = list(ws.iter_rows(values_only=True))
        head = [str(h) for h in rows[0]]
        return [dict(zip(head, ["" if v is None else str(v).strip() for v in r])) for r in rows[1:]]
    return list(csv.DictReader(open(path, encoding="utf-8-sig")))


def learn(path):
    learned = load_json(LEARNED, {})
    n = new_p = 0
    for r in read_review(path):
        scope = (r.get("我的判断(工作/生活)") or "").strip()
        if scope not in ("工作", "生活"):
            continue
        cp = r["交易对方"].strip().lower()
        if not cp or cp == "(无对方)":
            continue
        proj = (r.get("所属项目(下拉选)") or "").strip()
        newp = (r.get("新项目名称(新项目才填)") or "").strip()
        if proj == NEW_PROJECT or (newp and proj in ("", "(无项目)")):
            if not newp:
                print(f"  ! {r['交易对方']} 选了新项目但没填名称，已跳过项目")
                proj = ""
            else:
                proj = newp
        if proj == "(无项目)":
            proj = ""
        if proj and add_project(proj):
            new_p += 1
            print(f"  + 新项目已登记：{proj}（可在 工具/projects.json 补开始/结束日期，用于夜间打车自动归项目）")
        learned[cp] = dict(scope=scope, sub=(r.get("子类(可空)") or "").strip(), project=proj,
                           purpose=(r.get("用途备注(可空)") or "").strip())
        n += 1
    json.dump(learned, open(LEARNED, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"已记住 {n} 个对象的判断（新增项目 {new_p} 个），累计 {len(learned)} 个。下次转换会自动归类，并带上项目名和用途备注。")


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("convert")
    c.add_argument("files", nargs="+")
    c.add_argument("--out", default=os.path.join(HERE, "输出"))
    c.add_argument("--ignore-seen", action="store_true", help="不跳过已导入过的账单（重跑用）")
    l = sub.add_parser("learn")
    l.add_argument("review_file")
    pj = sub.add_parser("project", help="项目登记：project add 名称 --start 2026-05-01 --end 2026-05-03 | project list")
    pj.add_argument("action", choices=["add", "list"])
    pj.add_argument("name", nargs="?")
    pj.add_argument("--start", default="")
    pj.add_argument("--end", default="")
    pj.add_argument("--customer", default="")
    a = ap.parse_args()
    if a.cmd == "convert":
        files = [x for p in a.files for x in (glob.glob(p) or [p])]
        convert(files, a.out, a.ignore_seen)
    elif a.cmd == "learn":
        learn(a.review_file)
    else:
        if a.action == "add":
            if not a.name:
                raise SystemExit("请给项目名称")
            print("已新增" if add_project(a.name, a.start, a.end, a.customer) else "项目已存在")
        else:
            for p in load_json(PROJECTS, []):
                print(p["name"], p.get("start", ""), p.get("end", ""), p.get("customer", ""))


if __name__ == "__main__":
    main()
