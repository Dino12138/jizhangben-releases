"""读「不是我们模板」的成本单 / 报价单 / 预算表（同事自己做的各种格式）。

做法：在每张表里找「表头行」（名称、数量、单价、金额这类字），按表头认列；
表头上面一行有字的（两行表头）补进来；表里有好几段、每段自己一个表头的也行。
· 只有一格字、没有数字的行（如「Part1：物料采购」「一 设计部分」「结构搭建」）= 分类；
· 小计 / 合计 / 税金 / 服务费 / 优惠 这类汇总行跳过，不算成本行；
· 金额以表里的为准，金额格空着才用 数量 × 单价（× 天数）算；金额是 0 的行跳过；
· 一个文件里两张表内容基本一样（如「成本汇总」和「票据单」），只取一张，不会算两遍。
只在我们自己的模板一行都没读到时才用这里。"""
import re

# 汇总行：出现这些字、而且「名称」格是空的（或名称本身就是这些字），这一行不是成本行
TOTAL_RE = re.compile(r"小计|合计|总计|汇总|以上|共计|占比|比例|利润率|毛利率|#DIV|#REF|税金|税费|税点|^税|含税|不含税|优惠|折扣|利润|毛利|服务费[:：]|活动总价|报价总|"
                      r"subtotal|^total|grand ?total|cost summary", re.I)
# 总的合计：到这一行，这张表的成本明细就结束了（下面往往是报价、收款、利润这些测算，不是成本）
GRAND_RE = re.compile(r"总成本|成本合计|成本总计|^总计|以上总计|总合计|费用合计|活动总价|项目总价|grand ?total", re.I)
# 不读的表：说明、价目清单、费率、目录这类
SKIP_SHEET_RE = re.compile(r"说明|清单20|ratecard 清单|费率|目录|封面|模板使用|rundown|参数", re.I)

# 表头文字 → 这一列是什么（按顺序匹配，先到先得）
ROLE_RULES = [
    ("no", re.compile(r"^(序号|编号|no\.?|ref|项次|#)$", re.I)),
    ("price", re.compile(r"单价|unit ?cost|unit ?price|^price|[^总]价格$", re.I)),
    ("amount", re.compile(r"金额|总价|合计|小计|总计|total|amount|费用$|^成本$|价格合计|结算价|成本预算|预算金额|^预算$", re.I)),
    ("days", re.compile(r"天数|days?$|周期|次数|场次")),
    ("qty", re.compile(r"数量|qty|quantity|人数|^面积", re.I)),
    ("unit", re.compile(r"^(单位|unit)", re.I)),
    ("cat", re.compile(r"类别|分类|品类|区块|大类|报价一级项|费用类型|^类型|报价模块|一级区域|^城市$|^场次$|^站点$")),
    ("name", re.compile(r"名称|^项目$|^项目内容$|品名|^物料$|item|成本科目|费用项目|^内容$|服务内容|项目明细|^明细项?$|^物品", re.I)),
    ("spec", re.compile(r"规格|尺寸|描述|明细|内容|工艺|材质|款式|位置|说明|报价二级项|description|^remarks? ?备注$", re.I)),
    ("vendor", re.compile(r"供应商|收款方|收款人|商家|厂家|vendor|supplier", re.I)),
    ("who", re.compile(r"付款人|经手人|垫付人|报销人")),
    ("pay", re.compile(r"付款情况|付款状态|是否支付|是否付款|支付状态|付款方式|已付|^付款$")),
    ("inv", re.compile(r"发票|开票|票据")),
    ("date", re.compile(r"日期|时间|date", re.I)),
    ("memo", re.compile(r"备注|remark|note", re.I)),
]
# 同一种列出现多次时怎么选
NAME_ORDER = ["名称", "物品", "品名", "项目", "item", "成本科目", "费用项目", "项目明细", "内容", "明细"]
INFO_LABELS = {
    "name": ("项目名称", "项目名", "活动名称", "event name", "eventname"),
    "time_text": ("项目时间", "活动时间", "执行时间", "落地时间", "项目日期", "活动日期", "event date"),
    "customer": ("客户名称", "客户", "采购单位", "client"),
    "leader": ("项目负责人", "负责人", "项目负责", "项目经理"),
    "location": ("项目地点", "活动地点", "地点", "venue", "执行地点", "活动执行地点"),
    "source": ("客户来源",),
}


def _norm(v):
    s = str(v or "").strip().lower()
    s = re.sub(r"\s+", "", s)
    s = re.sub(r"[（(](元|rmb|￥|¥|含税|不含税)[)）]", "", s)
    return s.strip(":：")


def _num(v):
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    if isinstance(v, str):
        t = v.strip().replace(",", "").replace("，", "").lstrip("¥￥")
        if re.fullmatch(r"-?\d+(\.\d+)?", t):
            return float(t)
    return None


def _txt(v):
    if v is None:
        return ""
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    return str(v).strip()


def _role(h):
    """一个表头格是什么列；认不出返回 None。"""
    if not h or len(h) > 24:
        return None
    for role, rx in ROLE_RULES:
        if rx.search(h):
            if role == "amount" and re.search(r"已付|未付|差异|缺票|发票金额|占比|单价", h):
                return "paid" if "已付" in h else None
            if role == "qty" and "单价" in h:
                return "price"
            return role
    return None


def _header_map(row, above=None):
    """一行是不是表头；是的话返回 {角色: [列号…]}，不是返回 None。"""
    roles = {}
    for ci, v in enumerate(row):
        r = _role(_norm(v))
        if r:
            roles.setdefault(r, []).append(ci)
    has_money = "amount" in roles or "price" in roles
    has_what = any(k in roles for k in ("name", "cat", "spec"))
    cells = [v for v in row if _txt(v)]
    # 一般要认出 3 种列；只认出 2 种时，要求这一行全是短文字、至少 4 格（避免把「项目名称 xxx 成本金额 123」这种抬头当表头）
    if not (has_money and has_what and (len(roles) >= 3 or (len(cells) >= 4 and all(_num(v) is None and len(_txt(v)) <= 12 for v in cells)))):
        return None
    if above:                       # 两行表头：上一行有、这一行同一列是空的，补上
        for ci, v in enumerate(above):
            if ci < len(row) and _txt(row[ci]) == "":
                r = _role(_norm(v))
                if r and r not in ("amount", "price", "qty") and ci not in sum(roles.values(), []):
                    roles.setdefault(r, []).append(ci)
    return roles


def _pick(roles, headers):
    """每种列挑一列；数量出现两次时，第二个当倍数（天数/次数）。"""
    m = {}
    for r, cols in roles.items():
        m[r] = cols[0]
    names = roles.get("name", [])
    if len(names) > 1:
        best = min(names, key=lambda c: next((i for i, k in enumerate(NAME_ORDER) if k in headers[c]), 99))
        m["name"] = best
        roles["spec"] = sorted(set(roles.get("spec", []) + [c for c in names if c != best]))
    if len(roles.get("qty", [])) > 1 and "days" not in m:
        m["days"] = roles["qty"][1]
    amts = roles.get("amount", [])
    if len(amts) > 1:               # 好几列金额：优先「结算金额」，其次「金额/总价」，不选「总金额」这种分组合计
        def rank(c):
            h = headers[c]
            return (0 if "结算" in h else 1 if re.search(r"^(金额|总价|totalcost|合计|成本金额|付款金额|报价金额)$", h) else
                    3 if "总金额" in h else 2, c)
        m["amount"] = min(amts, key=rank)
        m["_amounts"] = sorted(amts, key=rank)
    return m


def _sec_of(group, name):
    """归到哪个板块：先看分类/小标题，认不出再看名称，都认不出算物料。"""
    for t in (group, name):
        s = _sec_match(t or "")
        if s:
            return s
    return "物料部分"


def _sec_match(t):
    if not t:
        return None
    if re.search(r"备用金", t):
        return "备用金"
    for sec, rx in (("执行人员杂费", r"差旅|交通|打车|住宿|酒店|餐费|餐饮|用餐|饭|机票|高铁|火车|快递|运输|物流|货拉拉|杂费|报销|实报实销|补贴|油费|停车|茶歇|用水"),
                    ("第三方人员", r"人员|人工|劳务|主持|礼仪|模特|演员|嘉宾|摄影|摄像|跟拍|化妆|npc|工作人员|安保|保洁|翻译|设计|导演|兼职|志愿者|讲师|艺人|策划|执行经理|执行人员|力工|电工|美工|达人|kol"),
                    ("搭建部分", r"搭建|舞台|灯光|音响|音视频|led|桁架|场地|帐篷|展位|展台|设备|租赁|视频|直播|电力|发电|布展|撤展|特装|喷绘|写真|安装|门头|结构|背景|av"),
                    ("物料部分", r"物料|印刷|制作|礼品|奖品|奖牌|道具|采购|定制|周边|kt|易拉宝|手册|海报|服装|t恤|横幅|花艺")):
        if re.search(rx, t, re.I):
            return sec
    return None


def _pay_of(t):
    if re.search(r"无需", t):
        return "无需付款"
    if re.search(r"备用金", t):
        return "备用金垫付"
    if re.search(r"预付|定金|订金", t):
        return "预付"
    if re.search(r"未付|未支付|待付|未打款", t):
        return "未付"
    if re.search(r"已付|已支付|已打款|已结|公对公|对公打款|已转", t):
        return "已付"
    return ""


def _info(rows):
    info = dict(name="", leader="", time_text="", location="", customer="", source="")
    title = ""
    for r in rows[:12]:
        cells = [(_txt(v), v) for v in r]
        texts = [c for c, _ in cells if c]
        if not title and len(texts) == 1 and len(texts[0]) <= 40 and not re.search(r"清单|核价|说明|模板|报价单$", texts[0]):
            title = texts[0]
        for i, (c, _) in enumerate(cells):
            if not c:
                continue
            lab = _norm(c.split("：")[0].split(":")[0])
            for key, labs in INFO_LABELS.items():
                if info[key] or lab not in labs:
                    continue
                m = re.split(r"[：:]", c, 1)
                val = m[1].strip() if len(m) > 1 and m[1].strip() else ""
                if not val:
                    val = next((x for x, _ in cells[i + 1:i + 4] if x and _norm(x) not in sum(INFO_LABELS.values(), ())), "")
                info[key] = val[:80]
    if not info["name"] and title:
        info["name"] = title
    return info


def _img_id(v):
    m = re.search(r'DISPIMG\("(ID_[0-9A-F]+)"', str(v or ""))
    return m.group(1) if m else None


def parse_sheet(vals, forms):
    """一张表 → 成本行列表。vals = 算好的值，forms = 公式（用来认出图片格）。"""
    lines = []
    m, headers, section, cat_carry = None, {}, "", ""
    prev = None
    for ri, row in enumerate(vals):
        row = list(row)
        frow = list(forms[ri]) if ri < len(forms) else []
        texts = [_txt(v) for v in row]
        if not any(texts):
            continue
        above = prev
        prev = row
        roles = _header_map(row, above)
        if roles:
            headers = {ci: _norm(v) for ci, v in enumerate(row)}
            for ci, v in enumerate(above or []):          # 两行表头：上一行补空着的列名
                if not headers.get(ci) and _role(_norm(v)) not in (None, "amount", "price", "qty"):
                    headers[ci] = _norm(v)
            m = _pick(roles, headers)
            cat_carry = ""
            continue
        if m is None:
            continue
        g = lambda k: row[m[k]] if k in m and m[k] < len(row) else None
        nums = [_num(v) for v in row if _num(v) is not None]
        strs = [t for v, t in zip(row, texts) if t and _num(v) is None and not _img_id(t) and not str(v).startswith("=")]
        name = _txt(g("name"))
        # 「名称」表头横跨两列（合并单元格）：右边那列没表头、有字 → 那才是名称，左边那格是分类
        if "name" in m:
            nc = m["name"] + 1
            while nc < len(row) and not headers.get(nc) and not _txt(row[nc]) and nc - m["name"] < 3:
                nc += 1
            if nc < len(row) and not headers.get(nc) and _txt(row[nc]) and _num(row[nc]) is None and not _img_id(_txt(row[nc])):
                if name and not TOTAL_RE.search(name):
                    cat_carry = name
                name = _txt(row[nc]) if not TOTAL_RE.search(name or "") else name
        # 总的合计：这张表的明细到此为止（下面是报价/收款/利润测算），直到下一个表头
        if any(GRAND_RE.search(t.replace(" ", "")) for t in strs) and (not name or GRAND_RE.search(name)):
            m = None
            continue
        # 汇总行
        if any(TOTAL_RE.search(t) for t in strs) and (not name or TOTAL_RE.search(name)):
            continue
        # 分类行：没有数字，只有一两格短字
        if not nums and 1 <= len(strs) <= 2 and len(strs[0]) <= 30 and not name.startswith("="):
            if len(strs[0]) > 1:
                section = re.sub(r"^(part\s*\d+[:：]?|[一二三四五六七八九十]+[、.\s]+|[a-z][、.]\s*|\d+[、.]\s*)", "", strs[0], flags=re.I).strip() or strs[0]
                cat_carry = ""
            continue
        if "cat" in m and _txt(g("cat")) and _num(g("cat")) is None and not _img_id(_txt(g("cat"))):
            cat_carry = _txt(g("cat"))
        amount = None
        for c in m.get("_amounts", [m["amount"]] if "amount" in m else []):
            a = _num(row[c]) if c < len(row) else None
            if a:
                amount = a
                break
        qty, price, days = _num(g("qty")), _num(g("price")), _num(g("days"))
        if amount is None and price is not None and qty is not None:
            amount = round(qty * price * (days if days else 1), 2)
        if not amount:
            continue
        spec_cols = [c for c in range(len(row)) if c != m.get("name") and (_role(headers.get(c, "")) == "spec" or
                     (_role(headers.get(c, "")) == "name" and c != m.get("name")))]
        spec = "；".join(t for t in (_txt(row[c]) for c in spec_cols) if t and not _img_id(t) and _num(t) is None)[:200]
        if not strs:                # 一格字都没有（只有数字）：多半是汇总区的数，不是成本行
            continue
        unit = _txt(g("unit"))
        if len(unit) > 6:           # 「单位」列里写的是长文字（如场地/单位名称），放进规格，单位记「项」
            spec = "；".join(x for x in (unit, spec) if x)[:200]
            unit = ""
        if not name:
            own_cat = _txt(g("cat")) if "cat" in m and _num(g("cat")) is None else ""
            if not spec and not own_cat and qty is None and price is None:
                continue            # 名称、规格、本行分类都没有，又没有数量/单价：不是成本行（多半是占比、汇总数）
            name = spec or own_cat or cat_carry
            if name == spec:
                spec = ""
            elif name == own_cat and 0 < len(_txt(g("memo"))) <= 20:
                name = f"{own_cat}·{_txt(g('memo'))}"     # 只有「开销类别」没有名称的表：名称 = 类别·备注（如「交通·杭州-北京」）
        if not name or _img_id(name) or _num(name) is not None or name.startswith("="):
            continue
        if not qty or qty <= 0:
            qty = 1
        craft = ""
        if days and days != 1:
            craft = f"×{days:g}" + ("天" if "天" in headers.get(m["days"], "") else "")
        pay_t = _txt(g("pay"))
        inv_t = _txt(g("inv"))
        memo = _txt(g("memo"))
        ids = [_img_id(t) for t in (_txt(v) for v in frow) if _img_id(t)] if frow else []
        ids += [i for i in (_img_id(t) for t in texts) if i and i not in ids]
        inv_id = pay_id = None
        for ci, v in enumerate(frow or row):
            i = _img_id(_txt(v))
            if not i:
                continue
            h = headers.get(ci, "")
            if re.search(r"发票|票据", h) and not inv_id:
                inv_id = i
            elif re.search(r"付款|截图|凭证|转账|支付", h) and not pay_id:
                pay_id = i
        if inv_t and _img_id(inv_t):
            inv_t = ""
        if pay_t and _img_id(pay_t):
            pay_t = ""
        cat = cat_carry or section
        lines.append(dict(
            sec=_sec_of(" ".join(x for x in (cat_carry, section) if x), name + " " + headers.get(m.get("price", -1), "") + " " + headers.get(m.get("amount", -1), "")), cat=cat[:30], name=name[:120], spec=spec, craft=craft,
            qty=qty, unit=unit or "项", price=round(amount / qty, 6),
            vendor=_txt(g("vendor"))[:60] if not _img_id(_txt(g("vendor"))) else "", pay=_pay_of(pay_t + inv_t) or "未付",
            date="", who=_txt(g("who"))[:20], _inv=inv_id, _pay=pay_id, _inv_text="",
            inv_note=inv_t[:30] if re.search(r"票", inv_t) else "", memo=memo[:200] if not _img_id(memo) else "",
            _amount=amount))
    return lines


def parse_workbook(wb, wf):
    """整本：每张表都读，内容基本重复的表只取一张；返回 (抬头信息, 成本行)。"""
    per = []
    info = None
    for ws in wb.worksheets:
        if SKIP_SHEET_RE.search(ws.title):
            continue
        vals = [list(r) for r in ws.iter_rows(values_only=True)]
        forms = [list(r) for r in wf[ws.title].iter_rows(values_only=True)] if ws.title in wf.sheetnames else []
        if info is None or not info["name"]:
            info = _info(vals)
        ls = parse_sheet(vals, forms)
        if ls:
            per.append((ws.title, ls))
    kept = []
    from collections import Counter
    for title, ls in per:
        am = Counter(round(l["_amount"], 2) for l in ls)      # 按金额比：两张表名字写法不同、金额一样，也算重复
        dup = False
        for _, k in kept:
            km = Counter(round(l["_amount"], 2) for l in k)
            if sum((am & km).values()) >= 0.85 * min(sum(am.values()), sum(km.values())):
                dup = True
                break
        if not dup:
            kept.append((title, ls))
    out = []
    for title, ls in kept:
        for l in ls:
            if len(kept) > 1:
                l["cat"] = (title + ("·" + l["cat"] if l["cat"] and l["cat"] != title else ""))[:30]
            l.pop("_amount", None)
            out.append(l)
    return info or dict(name="", leader="", time_text="", location="", customer="", source=""), out
