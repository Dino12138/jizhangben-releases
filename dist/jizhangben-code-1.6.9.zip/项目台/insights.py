"""从记账本并过来的几样统计：今天/本周/本月/今年、交易日历（按天）、收入分类、各账户进出。
口径和总览一致：自己账户互转不算；「借款往来」不算收入也不算支出；外币按汇率折成人民币。"""
from datetime import date, datetime, timedelta


def setup(app, h):
    ezb_transactions, _scope_of, _sub_name, store = h["ezb_transactions"], h["_scope_of"], h["_sub_name"], h["store"]
    _is_div_out = h["_is_div_out"]          # 分红转出 / 提成 / 没归项目的助理五险一金：从我的分红里扣（和总览同一条规则）

    def rows():
        """(日期, 是否收入, 金额元, 工作/生活/待确认, 子类, 账户名, 是否从我的分红里扣)，已去掉转账和借款往来。"""
        out = []
        for t in ezb_transactions():
            if t["type"] not in (2, 3):
                continue
            sc, sub = _scope_of(t), _sub_name(t)
            if sc == "生活" and sub == "借款往来":
                continue
            d = datetime.fromtimestamp(t["time"], store.TZ).strftime("%Y-%m-%d")
            out.append((d, t["type"] == 2, t.get("_cny", t["sourceAmount"]) / 100, sc, sub, (t.get("sourceAccount") or {}).get("name", "") or "(没填账户)", _is_div_out(t)))
        return out

    @app.get("/api/insights/periods")
    def periods():
        """今天 / 本周 / 本月 / 今年：我的支出（生活）、我的收入（生活 + 项目分红），另附工作支出。"""
        today = date.today()
        mon = today - timedelta(days=today.weekday())
        spans = [("today", "今天", today, today), ("week", "本周", mon, mon + timedelta(days=6)),
                 ("month", "本月", today.replace(day=1), (today.replace(day=28) + timedelta(days=4)).replace(day=1) - timedelta(days=1)),
                 ("year", "今年", today.replace(month=1, day=1), today.replace(month=12, day=31))]
        out = [dict(k=k, label=lb, d1=a.isoformat(), d2=b.isoformat(), exp=0.0, inc=0.0, work_exp=0.0, n=0) for k, lb, a, b in spans]
        for d, is_inc, amt, sc, sub, _, dv in rows():
            for p in out:
                if p["d1"] <= d <= p["d2"]:
                    p["n"] += 1
                    if is_inc:
                        if sc == "生活" or (sc == "工作" and sub == "项目分红"):
                            p["inc"] += amt
                    elif sc == "生活":
                        p["exp"] += amt
                    elif dv:
                        p["inc"] -= amt                        # 到账的分红里转给别人的那部分：从我的收入里扣掉
                    elif sc == "工作":
                        p["work_exp"] += amt
        for p in out:
            for k in ("exp", "inc", "work_exp"):
                p[k] = round(p[k], 2)
        return out

    @app.get("/api/insights/calendar")
    def calendar(year: int = 0, scope: str = "生活"):
        """某一年每天的支出 / 收入 / 笔数。scope：生活 / 工作 / 空=全部。"""
        rs = rows()
        years = sorted({int(r[0][:4]) for r in rs} | {date.today().year})
        year = year if year in years else date.today().year
        days, months = {}, {}
        for d, is_inc, amt, sc, sub, _, dv in rs:
            if int(d[:4]) != year or (scope and sc != scope):
                continue
            e = days.setdefault(d, [0.0, 0.0, 0])
            e[1 if is_inc else 0] += amt
            e[2] += 1
            m = months.setdefault(d[:7], [0.0, 0.0, 0])
            m[1 if is_inc else 0] += amt
            m[2] += 1
        rnd = lambda x: {k: [round(v[0], 2), round(v[1], 2), v[2]] for k, v in x.items()}
        days = rnd(days)
        return dict(year=year, years=years, scope=scope, today=date.today().isoformat(), days=days, months=rnd(months),
                    max_exp=max([v[0] for v in days.values()] or [0]))

    @app.get("/api/insights/breakdown")
    def breakdown(range: str = "12m"):
        """收入从哪来（按分类）、钱从哪个账户走（各账户收 / 支）。范围和数据看板一致。"""
        rs = rows()
        months = sorted({r[0][:7] for r in rs} | {date.today().strftime("%Y-%m")})
        if range == "12m":
            keep = months[-12:]
        elif range == "year":
            keep = [m for m in months if m[:4] == months[-1][:4]]
        else:
            keep = months
        ks = set(keep)
        inc, acc = {}, {}
        for d, is_inc, amt, sc, sub, an, dv in rs:
            if d[:7] not in ks:
                continue
            a = acc.setdefault(an, dict(name=an, exp=0.0, inc=0.0, n=0))
            a["inc" if is_inc else "exp"] += amt
            a["n"] += 1
            if is_inc:
                e = inc.setdefault((sc, sub), dict(scope=sc, sub=sub, amount=0.0, n=0))
                e["amount"] += amt
                e["n"] += 1
            elif dv:                                                 # 分红里转给别人的 / 从我分红里扣的：从「项目分红」里扣
                inc.setdefault(("工作", "项目分红"), dict(scope="工作", sub="项目分红", amount=0.0, n=0))["amount"] -= amt
        for e in inc.values():
            e["amount"] = round(e["amount"], 2)
        for a in acc.values():
            a["exp"], a["inc"] = round(a["exp"], 2), round(a["inc"], 2)
        whole = range == "all"
        return dict(d1="" if whole else keep[0] + "-01", d2="",
                    inc=sorted(inc.values(), key=lambda e: -e["amount"]), acc=sorted(acc.values(), key=lambda a: -(a["exp"] + a["inc"])))
