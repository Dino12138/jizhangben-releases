"""小工具：① 人民币大写金额  ② 实时汇率换算（人民币 / 美元 USD / 泰达币 USDT 互转）。
所有金额用十进制精确计算（Decimal），不用浮点数，避免 0.1+0.2 这类误差。"""
import json, re, threading, time, urllib.request
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation, getcontext

getcontext().prec = 40

DIG = "零壹贰叁肆伍陆柒捌玖"
MAX_RMB = Decimal("9999999999999999.99")          # 最大到 千万亿（16 位整数），再大就不处理了


def parse_amount(text):
    """把用户输入的金额文字变成 Decimal。接受：1,234.50 / ￥1234.5 / 1234元 / 全角数字 / 1.2万 / 3亿。"""
    s = str(text or "").strip()
    s = s.translate(str.maketrans("０１２３４５６７８９．，－＋", "0123456789.,-+"))
    s = re.sub(r"\s|_", "", s)
    s = re.sub(r"^(人民币|RMB|CNY|USDT|USD|[¥￥$＄])", "", s, flags=re.I)          # 只认开头的币种符号
    s = re.sub(r"(元整?|圆整?|块|RMB|CNY|USDT|USD)$", "", s, flags=re.I)          # 只认结尾的单位，中间夹字一律算输错
    if re.search(r"[,，]", s) and not re.fullmatch(r"[+-]?\d{1,3}([,，]\d{3})+(\.\d*)?", s.rstrip("万亿wWkK千")):
        raise ValueError("逗号位置不对，请检查金额（千分位应为 1,234,567.89）")
    s = re.sub(r"[,，]", "", s)
    mul = Decimal(1)
    m = re.search(r"(万亿|亿|万|[wW]|[kK千])$", s)
    if m:
        mul = {"万亿": Decimal(10) ** 12, "亿": Decimal(10) ** 8, "万": Decimal(10) ** 4, "w": Decimal(10) ** 4, "k": Decimal(1000), "千": Decimal(1000)}[m.group(1).lower()]
        s = s[:m.start()]
    if not re.fullmatch(r"[+-]?(\d+(\.\d*)?|\.\d+)", s or ""):
        raise ValueError("请输入数字金额，比如 12800.50")
    try:
        return Decimal(s) * mul
    except InvalidOperation:
        raise ValueError("请输入数字金额，比如 12800.50")


def _sect(n):
    """0~9999 的一段，写成 X仟X佰X拾X（段内的 0 按规则写「零」）。"""
    out, zero = "", False
    for i, u in enumerate(("仟", "佰", "拾", "")):
        d = n // (10 ** (3 - i)) % 10
        if d:
            out += ("零" if zero and out else "") + DIG[d] + u
            zero = False
        else:
            zero = True
    return out


def rmb_upper(amount):
    """人民币大写（按《支付结算办法》附一「正确填写票据和结算凭证的基本规定」）：
    · 到「元」或「角」为止，后面写「整」；有「分」不写「整」
    · 数字中间有 0 写「零」，连续几个 0 只写一个「零」
    · 角位是 0、分位不是 0：元后面写「零」（如 325.04 → 叁佰贰拾伍元零肆分）
    · 元位是 0、角位不是 0：元后面写「零」（如 1680.32 → 壹仟陆佰捌拾元零叁角贰分，规定里两种写法都对，这里固定用带「零」的）
    · 10 写「壹拾」，不省略「壹」"""
    a = Decimal(amount)
    neg = a < 0
    a = abs(a).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    if a > MAX_RMB:
        raise ValueError("金额太大了（超过 16 位整数）")
    fen = int(a * 100)
    yuan, jiao, fn = fen // 100, fen // 10 % 10, fen % 10
    if fen == 0:
        return "零元整"
    s = ""
    if yuan:
        groups, n = [], yuan
        while n:
            groups.append(n % 10000)
            n //= 10000
        units = ["", "万", "亿", "万亿"]
        need_zero = False
        for i in range(len(groups) - 1, -1, -1):
            g = groups[i]
            if g == 0:
                need_zero = True
                continue
            if s and (need_zero or g < 1000):
                s += "零"
            s += _sect(g) + units[i]
            need_zero = False
        s += "元"
    if jiao == 0 and fn == 0:
        s += "整"
    else:
        if yuan and (jiao == 0 or yuan % 10 == 0):
            s += "零"
        if jiao:
            s += DIG[jiao] + "角"
        s += (DIG[fn] + "分") if fn else "整"
    return ("负" if neg else "") + s


# ------------------------------------------------------------------ 实时汇率
CURS = ("CNY", "USD", "USDT")
NAMES = {"CNY": "人民币", "USD": "美元", "USDT": "USDT（泰达币）"}
SANE = {"USD_CNY": (Decimal(5), Decimal(10)), "USDT_CNY": (Decimal(5), Decimal(10)), "USDT_USD": (Decimal("0.9"), Decimal("1.1"))}
TTL = 30                                         # 秒：汇率缓存多久（页面每 30 秒自动刷新一次）
_fx = {"t": 0, "data": None, "err": ""}
_lock = threading.Lock()


def _get(url, timeout=6):
    req = urllib.request.Request(url, headers={"User-Agent": "cd-ledger/1.0", "Accept": "application/json"})
    return json.loads(urllib.request.urlopen(req, timeout=timeout).read().decode("utf-8"))


def _src_coinbase():
    usd = _get("https://api.coinbase.com/v2/exchange-rates?currency=USD")["data"]["rates"]
    usdt = _get("https://api.coinbase.com/v2/exchange-rates?currency=USDT")["data"]["rates"]
    return dict(USD_CNY=Decimal(usd["CNY"]), USDT_CNY=Decimal(usdt["CNY"]), USDT_USD=Decimal(usdt["USD"]))


def _src_coingecko():
    d = _get("https://api.coingecko.com/api/v3/simple/price?ids=tether,usd-coin&vs_currencies=cny,usd&precision=6")["tether"]
    cny, usd = Decimal(str(d["cny"])), Decimal(str(d["usd"]))
    return dict(USD_CNY=cny / usd, USDT_CNY=cny, USDT_USD=usd)


def _src_okx_er():
    u = Decimal(_get("https://www.okx.com/api/v5/market/exchange-rate")["data"][0]["usdCny"])
    t = Decimal(_get("https://www.okx.com/api/v5/market/ticker?instId=USDC-USDT")["data"][0]["last"])      # 1 USDC(≈1 美元) = t USDT
    usdt_usd = Decimal(1) / t
    return dict(USD_CNY=u, USDT_CNY=u * usdt_usd, USDT_USD=usdt_usd)


SOURCES = [("Coinbase", _src_coinbase), ("CoinGecko", _src_coingecko), ("OKX", _src_okx_er)]


def _sane(r):
    return all(SANE[k][0] <= r[k] <= SANE[k][1] for k in SANE)


def fetch_rates(force=False):
    """取三组汇率。主来源取不到或数值离谱就换下一个；同时用第二个来源交叉核对，差得多会提示。"""
    with _lock:
        if not force and _fx["data"] and time.time() - _fx["t"] < TTL:
            return _fx["data"]
        got, errs = [], []
        for name, fn in SOURCES:
            try:
                r = fn()
                if _sane(r):
                    got.append((name, r))
                else:
                    errs.append(f"{name} 数值不合理")
            except Exception as e:
                errs.append(f"{name} 取不到（{type(e).__name__}）")
            if len(got) == 2:
                break
        if not got:
            _fx["err"] = "；".join(errs)
            if _fx["data"]:                                   # 这次没取到：先用上一次的，并标明是旧的
                return dict(_fx["data"], stale=True, error=_fx["err"])
            raise RuntimeError("现在取不到汇率：" + _fx["err"] + "。请检查网络后再试")
        name, r = got[0]
        check = None
        if len(got) > 1:
            n2, r2 = got[1]
            diff = max(abs(r[k] - r2[k]) / r[k] for k in r)
            check = dict(src=n2, diff_pct=str((diff * 100).quantize(Decimal("0.01"))), ok=diff <= Decimal("0.01"),
                         rates={k: str(v.quantize(Decimal("0.000001"))) for k, v in r2.items()})
        data = dict(src=name, at=int(time.time()), at_text=time.strftime("%Y-%m-%d %H:%M:%S"), stale=False, error="", check=check,
                    rates={k: str(v.quantize(Decimal("0.000001"))) for k, v in r.items()}, _r=r)
        _fx.update(t=time.time(), data=data, err="")
        return data


def rate_of(r, a, b):
    """1 个 a = 多少 b"""
    if a == b:
        return Decimal(1)
    if f"{a}_{b}" in r:
        return r[f"{a}_{b}"]
    return Decimal(1) / r[f"{b}_{a}"]


def convert(amount, cur, data):
    r = data["_r"]
    out = {}
    for b in CURS:
        if b == cur:
            continue
        k = rate_of(r, cur, b)
        out[b] = dict(amount=str((amount * k).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)), rate=str(k.quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)))
    return out


def setup(app):
    from fastapi import HTTPException

    @app.get("/api/tools/rmb")
    def tool_rmb(amount: str = ""):
        try:
            a = parse_amount(amount)
            q = a.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            return dict(upper=rmb_upper(a), amount=f"{q:,.2f}", rounded=q != a)
        except ValueError as e:
            raise HTTPException(400, str(e))

    @app.get("/api/tools/fx")
    def tool_fx(amount: str = "", cur: str = "CNY", force: int = 0):
        cur = cur.upper()
        if cur not in CURS:
            raise HTTPException(400, "币种只能是 CNY / USD / USDT")
        try:
            d = fetch_rates(bool(force))
        except RuntimeError as e:
            raise HTTPException(400, str(e))
        out = {k: v for k, v in d.items() if k != "_r"}
        out.update(names=NAMES, ttl=TTL, table=[dict(a=a, b=b, rate=str(rate_of(d["_r"], a, b).quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)))
                                               for a, b in (("USD", "CNY"), ("USDT", "CNY"), ("USDT", "USD"), ("CNY", "USD"), ("CNY", "USDT"), ("USD", "USDT"))])
        if amount.strip():
            try:
                a = parse_amount(amount)
            except ValueError as e:
                raise HTTPException(400, str(e))
            if a < 0 or a > MAX_RMB:
                raise HTTPException(400, "金额要在 0 到 16 位整数之间")
            out.update(cur=cur, amount=f"{a:,f}", result=convert(a, cur, d))
        return out
