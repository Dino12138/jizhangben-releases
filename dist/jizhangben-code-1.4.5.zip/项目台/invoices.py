"""发票：截图/PDF 上传、发票夹（批量上传 + QQ 邮箱自动拉取）、按金额配对成本行。

- PDF 发票：原文件保留（可随时打开原 PDF），每页另存成 PNG 用于缩略图和导出成本单。
- 发票夹：还没放进具体成本行的发票。读 PDF 里的文字拿到 金额 / 销售方 / 购买方 / 发票号码 / 开票日期，
  按金额推荐对应的成本行，一点就放进去。
- QQ 邮箱：IMAP（imap.qq.com:993）+ 授权码。授权码存在 macOS 钥匙串，不写进任何文件。
"""
import email, hashlib, imaplib, io, json, os, re, subprocess, threading, time, uuid, zipfile
from datetime import datetime, timedelta
from email.header import decode_header, make_header
from email.utils import parsedate_to_datetime
from typing import List, Optional

from fastapi import File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse
from pydantic import BaseModel

IMG_EXT = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".heic")
KC_SERVICE = "CD的记账本-QQ邮箱"
SUBJ_RE = re.compile(r"发票|开票|票据|invoice|fapiao|电子票|数电票|全电|行程单|行程报销", re.I)
KINDS = ("invoice", "pay", "trip")
TAXI_RE = re.compile(r"打车|出租|滴滴|网约车|曹操|高德|T3|花小猪|首汽|如祺|享道|嘀嗒|快车|专车|车费|用车|交通|货拉拉|快狗")   # 发票 / 支付截图 / 打车行程单


# ---------------------------------------------------------------- 解析 PDF 发票
ORG_RE = re.compile(r"^[一-龥（）()A-Za-z0-9·]{4,40}(有限公司|公司|分公司|酒店|饭店|宾馆|店|中心|事务所|工作室|厂|部|医院|学校|大学|研究院|合作社|个体工商户|商行|旅行社)$")


def parse_pdf_text(text):
    """从发票 PDF 文字里取 金额(价税合计) / 发票号码 / 开票日期 / 购买方 / 销售方 / 项目名称。取不到的留空。"""
    t = text.replace("　", " ")
    info = dict(amount=0.0, inv_no="", inv_date="", buyer="", seller="", item="")
    m = re.search(r"发票号码[:：]?\s*(\d{8,20})", t) or re.search(r"(?<!\d)(\d{20})(?!\d)", t)
    if m:
        info["inv_no"] = m.group(1)
    m = re.search(r"(20\d{2})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日", t)
    if m:
        info["inv_date"] = "%s-%02d-%02d" % (m.group(1), int(m.group(2)), int(m.group(3)))
    # 价税合计＝带 ¥ 的金额里最大的那个（¥ 可能在数字前，也可能被排版挤到下一行）
    amts = [float(x.replace(",", "")) for x in re.findall(r"[¥￥]\s*([\d,]+\.\d{1,2})", t)]
    amts += [float(x.replace(",", "")) for x in re.findall(r"([\d,]+\.\d{2})\s*\n\s*[¥￥]", t)]
    m = re.search(r"[（(]\s*小写\s*[）)]\s*[¥￥]?\s*([\d,]+\.\d{2})", t)
    if m:
        amts.append(float(m.group(1).replace(",", "")))
    if amts:
        info["amount"] = round(max(amts), 2)
    orgs = []
    for ln in t.splitlines():
        ln = ln.strip()
        mm = re.search(r"名\s*称[:：]\s*(\S{2,40})", ln)
        nm = mm.group(1) if mm else (ln if ORG_RE.match(ln) else "")
        if nm and nm not in orgs:
            orgs.append(nm)
    if orgs:
        info["buyer"] = orgs[0]
    if len(orgs) > 1:
        info["seller"] = orgs[1]
    m = re.search(r"\*([^*\n]{1,20})\*([^\n]{0,20})", t)
    if m:
        info["item"] = ("*%s*%s" % (m.group(1), m.group(2))).strip()
    if "铁路电子客票" in t:
        # 火车票：销售方写「铁路 · 出发站→到达站 车次」，内容写「乘车日期 席别 乘车人」
        lines = [x.strip() for x in t.splitlines() if x.strip()]
        st = [x for x in lines if re.match(r"^[\u4e00-\u9fa5]{1,8}站$", x)][:2]
        tr = next((x for x in lines if re.match(r"^[GDCZTKYLS]\d{1,5}$", x)), "")
        ds = re.findall(r"(20\d{2})年(\d{1,2})月(\d{1,2})日", t)
        ride = "%s-%02d-%02d" % (ds[1][0], int(ds[1][1]), int(ds[1][2])) if len(ds) > 1 else ""
        seat = next((x for x in lines if re.match(r"^(商务座|一等座|二等座|特等座|硬座|软座|硬卧|软卧|无座|动卧|一等卧|二等卧)$", x)), "")
        who = ""
        for i, x in enumerate(lines):
            if re.match(r"^\d{6,}\*{2,}\w*$", x) and i + 1 < len(lines):
                who = lines[i + 1]
                break
        m = re.search(r"购买方名称[:：]\s*(\S+)", t)
        if m:
            info["buyer"] = m.group(1)
        info["seller"] = "铁路 · " + "→".join(s_.rstrip("站") for s_ in st) + (" " + tr if tr else "")
        info["item"] = " ".join(x for x in ("火车票", ride, seat, who) if x)
    return info


def is_trip(text, name=""):
    """打车/货运行程单（滴滴、高德、曹操、T3、货拉拉……）：有「行程单」字样、又不是发票本身。"""
    t = text + " " + name
    return bool(re.search(r"行程单|行程报销单|行程明细", t)) and not re.search(r"发票号码", text)


def parse_trip(text):
    info = dict(amount=0.0, inv_no="", inv_date="", buyer="", seller="", item="打车行程单")
    t = text.replace("\u3000", " ")
    m = re.search(r"合计\s*[:：]?\s*[¥￥]?\s*([\d,]+\.\d{1,2})\s*元?", t) or re.search(r"总金额\s*[:：]?\s*[¥￥]?\s*([\d,]+\.\d{1,2})", t)
    if m:
        info["amount"] = float(m.group(1).replace(",", ""))
    m = re.search(r"共\s*(\d+)\s*笔行程", t)
    if m:
        info["item"] = f"打车行程单 · {m.group(1)} 笔"
    m = re.search(r"行程(?:起止)?(?:日期|时间)\s*[:：]?\s*(20\d{2}[-./年]\d{1,2}[-./月]\d{1,2})", t)
    ds = re.findall(r"(20\d{2})[-./年](\d{1,2})[-./月](\d{1,2})", m.group(1) if m else t)
    if ds:
        info["inv_date"] = "%s-%02d-%02d" % (ds[0][0], int(ds[0][1]), int(ds[0][2]))
    for k, v in (("滴滴", "滴滴出行"), ("高德", "高德打车"), ("曹操", "曹操出行"), ("T3", "T3出行"), ("货拉拉", "货拉拉"), ("花小猪", "花小猪打车"),
                 ("首汽", "首汽约车"), ("享道", "享道出行"), ("如祺", "如祺出行"), ("美团", "美团打车")):
        if k in t:
            info["seller"] = v
            break
    return info


def render_pdf(data):
    """PDF → ([(页PNG bytes, w, h)], 全部文字)。"""
    import fitz
    doc = fitz.open(stream=data, filetype="pdf")
    pages, texts = [], []
    for page in doc:
        texts.append(page.get_text())
        pix = page.get_pixmap(dpi=300)
        pages.append((pix.tobytes("png"), pix.width, pix.height))
    return pages, "\n".join(texts)


def to_png(data):
    """任意图片 bytes → (bytes, 扩展名, w, h)。HEIC 等不常见格式用 macOS 自带 sips 转成 JPG。"""
    from PIL import Image
    try:
        im = Image.open(io.BytesIO(data))
        im.load()
    except Exception:
        tmp = "/tmp/cdinv-" + uuid.uuid4().hex
        open(tmp, "wb").write(data)
        try:
            subprocess.run(["sips", "-s", "format", "jpeg", tmp, "--out", tmp + ".jpg"], capture_output=True, timeout=30)
            data = open(tmp + ".jpg", "rb").read()
            im = Image.open(io.BytesIO(data))
            im.load()
        except Exception:
            raise HTTPException(400, "不是图片或 PDF")
        finally:
            for p in (tmp, tmp + ".jpg"):
                try:
                    os.remove(p)
                except OSError:
                    pass
    fmt = (im.format or "").lower()
    if fmt in ("png", "jpeg", "webp", "gif", "bmp"):
        return data, ".jpg" if fmt == "jpeg" else "." + fmt, im.size[0], im.size[1]
    buf = io.BytesIO()
    im.convert("RGB").save(buf, "PNG")
    return buf.getvalue(), ".png", im.size[0], im.size[1]


def setup(app, h):
    store, project_detail, bt = h["store"], h["project_detail"], h["bt"]
    INBOX = os.path.join(store.FILES, "inbox")
    MAILCFG = os.path.join(bt.STATE, "邮箱.json")
    os.makedirs(INBOX, exist_ok=True)

    # ------------------------------------------------------------ 成本行直接上传（替换 app.py 的旧版）
    def save_to_line(c, lid, kind, name, data, inv_no=""):
        """一个文件存到成本行。PDF：原件保留 + 每页 PNG；图片：原样保存。返回新增 files.id 列表。"""
        pdir = os.path.join(store.FILES, str(lid))
        os.makedirs(pdir, exist_ok=True)
        base = os.path.splitext(name)[0] or "发票"
        out = []
        if data[:5] == b"%PDF-" or name.lower().endswith(".pdf"):
            try:
                pages, text = render_pdf(data)
            except Exception:
                raise HTTPException(400, f"{name} 打不开，不是有效的 PDF")
            if not pages:
                raise HTTPException(400, f"{name} 是空 PDF")
            if not inv_no and kind == "invoice":
                inv_no = parse_pdf_text(text)["inv_no"]
            orig = os.path.join(pdir, uuid.uuid4().hex[:10] + ".pdf")
            open(orig, "wb").write(data)
            for i, (b, w, hh) in enumerate(pages):
                p = os.path.join(pdir, uuid.uuid4().hex[:10] + ".png")
                open(p, "wb").write(b)
                nm = f"{base}.pdf" if len(pages) == 1 else f"{base}-第{i + 1}页.pdf"
                out.append(c.execute("insert into files(line_id,kind,path,name,w,h,orig,inv_no) values(?,?,?,?,?,?,?,?)",
                                     (lid, kind, p, nm, w, hh, orig, inv_no)).lastrowid)
        else:
            b, ext, w, hh = to_png(data)
            p = os.path.join(pdir, uuid.uuid4().hex[:10] + ext)
            open(p, "wb").write(b)
            nm = name if os.path.splitext(name)[1] else name + ext
            out.append(c.execute("insert into files(line_id,kind,path,name,w,h,orig,inv_no) values(?,?,?,?,?,?,?,?)",
                                 (lid, kind, p, nm, w, hh, "", inv_no)).lastrowid)
        return out

    h["save_to_line"] = save_to_line

    @app.get("/api/files/{fid}/orig")
    def file_orig(fid: int):
        """打开原始文件：PDF 发票给原 PDF，图片给原图。"""
        with store.db() as c:
            f = c.execute("select * from files where id=?", (fid,)).fetchone()
        if not f:
            raise HTTPException(404, "文件不存在")
        p = f["orig"] if f["orig"] and os.path.exists(f["orig"]) else f["path"]
        if not os.path.exists(p):
            raise HTTPException(404, "文件不存在")
        nm = f["name"]
        if p.endswith(".pdf"):
            nm = re.sub(r"-第\d+页\.pdf$", ".pdf", nm)
            if not nm.endswith(".pdf"):
                nm += ".pdf"
        return FileResponse(p, filename=nm, content_disposition_type="inline")

    # ------------------------------------------------------------ 发票夹
    def add_to_inbox(c, name, data, src="upload", mail_key="", subject="", sender="", mdate=""):
        """一个文件进发票夹。返回 (id 或 None, 说明)。同一张发票（号码或内容相同）不重复进。"""
        sha = hashlib.sha1(data).hexdigest()
        kind = "trip" if re.search(r"行程单|行程报销", name) else "invoice"
        if c.execute("select 1 from inv where sha=?", (sha,)).fetchone():
            return None, "重复"
        info = dict(amount=0.0, inv_no="", inv_date="", buyer="", seller="", item="")
        ext = os.path.splitext(name)[1].lower()
        is_pdf = data[:5] == b"%PDF-" or ext == ".pdf"
        pages = []
        if is_pdf:
            try:
                pp, text = render_pdf(data)
            except Exception:
                return None, "PDF 打不开"
            if is_trip(text, name):
                kind = "trip"
                info.update(parse_trip(text))
            else:
                info.update(parse_pdf_text(text))
            ext = ".pdf"
            for b, w, hh in pp:
                p = os.path.join(INBOX, uuid.uuid4().hex[:10] + ".png")
                open(p, "wb").write(b)
                pages.append(p)
        else:
            try:
                b, ext, w, hh = to_png(data)
            except HTTPException:
                return None, "不是图片或 PDF"
            data = b
        if info["inv_no"]:
            if c.execute("select 1 from inv where inv_no=?", (info["inv_no"],)).fetchone() or \
                    c.execute("select 1 from files where inv_no=?", (info["inv_no"],)).fetchone():
                return None, "重复"
        path = os.path.join(INBOX, uuid.uuid4().hex[:10] + ext)
        open(path, "wb").write(data)
        if not pages:
            pages = [path]
        if not info["inv_date"] and mdate:
            info["inv_date"] = mdate[:10]
        iid = c.execute("""insert into inv(src,mail_key,subject,sender,mdate,name,path,pages,sha,amount,seller,buyer,inv_no,inv_date,item,kind)
                           values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (src, mail_key, subject, sender, mdate, name, path, json.dumps(pages), sha, info["amount"], info["seller"],
                         info["buyer"], info["inv_no"], info["inv_date"], info["item"], kind)).lastrowid
        return iid, ""

    def line_rows(c):
        rows = c.execute("""select l.id, l.name, l.vendor, l.date, l.qty*l.price as amount, l.sec, p.id as pid, p.name as project,
                                   (select count(*) from files f where f.line_id=l.id and f.kind='invoice') as n_inv,
                                   (select count(*) from files f where f.line_id=l.id and f.kind='trip') as n_trip
                            from lines l join projects p on p.id=l.project_id""").fetchall()
        return [dict(r) for r in rows]

    def suggest(it, lines):
        """按金额（±0.01）推荐成本行；还没发票的、名字/供应商和销售方沾边的、日期近的排前面。"""
        if not it["amount"]:
            return []
        seller = it["seller"] or ""
        out = []
        for l in lines:
            if abs((l["amount"] or 0) - it["amount"]) > 0.011:
                continue
            has = l["n_trip"] if it.get("kind") == "trip" else l["n_inv"]
            score = 0 if has else 10
            if it.get("kind") == "trip" and TAXI_RE.search((l["name"] or "") + (l["vendor"] or "")):
                score += 6
            txt = (l["name"] or "") + (l["vendor"] or "")
            if seller and any(seller[i:i + 2] in txt for i in range(0, max(1, len(seller) - 1))
                              if seller[i:i + 2] not in ("有限", "公司", "上海", "北京", "科技", "服务", "管理", "限公")):
                score += 5
            if it["inv_date"] and l["date"]:
                try:
                    d = abs((datetime.strptime(it["inv_date"], "%Y-%m-%d") - datetime.strptime(l["date"][:10], "%Y-%m-%d")).days)
                    score += max(0, 5 - d / 15)
                except ValueError:
                    pass
            out.append(dict(line_id=l["id"], pid=l["pid"], project=l["project"], name=l["name"] or "(未命名)",
                            amount=round(l["amount"], 2), date=l["date"], has_inv=bool(has), score=score))
        out.sort(key=lambda x: -x["score"])
        return out[:4]

    def pairs_of(rows):
        """发票 ↔ 行程单配对：同一封邮件（或记账本同一笔账）里金额一样的；手动上传的，金额一样且只有唯一一个候选也配上。"""
        new = [r for r in rows if r["status"] == "new"]
        out = {}
        for a in new:
            if (a["kind"] or "invoice") != "invoice" or a["id"] in out:
                continue
            cand = [b for b in new if b["kind"] == "trip" and b["id"] not in out and abs((b["amount"] or 0) - (a["amount"] or 0)) < 0.011 and a["amount"]]
            same = [b for b in cand if (a["mail_key"] and b["mail_key"] == a["mail_key"]) or (a["tx_uid"] and b["tx_uid"] == a["tx_uid"])]
            pick = same[0] if same else None
            if not pick and len(cand) == 1 and not a["mail_key"] and not cand[0]["mail_key"]:
                pick = cand[0]
            if pick:
                out[a["id"]], out[pick["id"]] = pick["id"], a["id"]
        return out

    def inv_view(r, lines=None):
        d = dict(r)
        d["pages"] = json.loads(d["pages"] or "[]")
        d["n_pages"] = len(d["pages"])
        d["is_pdf"] = d["path"].endswith(".pdf")
        if lines is not None and d["status"] == "new":
            d["sugg"] = suggest(d, lines)
        return d

    @app.get("/api/inbox")
    def inbox_list(status: str = "new"):
        with store.db() as c:
            lines = line_rows(c)
            q = "select * from inv" + (" where status=?" if status != "all" else "") + " order by coalesce(nullif(inv_date,''),created) desc, id desc"
            rows = c.execute(q, (status,) if status != "all" else ()).fetchall()
            cnt = {r[0]: r[1] for r in c.execute("select status,count(*) from inv group by status")}
            used = {r["id"]: r for r in c.execute("select l.id, l.name, p.name as project, p.id as pid from lines l join projects p on p.id=l.project_id")}
        with store.db() as c:
            pr = pairs_of(c.execute("select * from inv where status='new'").fetchall())
        items = []
        for r in rows:
            d = inv_view(r, lines)
            d["pair"] = pr.get(d["id"], 0)
            if d["line_id"] and d["line_id"] in used:
                u = used[d["line_id"]]
                d["used"] = dict(project=u["project"], pid=u["pid"], name=u["name"])
            items.append(d)
        return dict(items=items, counts=dict(new=cnt.get("new", 0) - len(pr) // 2, used=cnt.get("used", 0), ignored=cnt.get("ignored", 0)),
                    mail=mail_public())

    @app.post("/api/inbox/upload")
    async def inbox_upload(files: List[UploadFile] = File(...)):
        added, dup, bad, reimbs_done = 0, 0, [], []
        with store.db() as c:
            for f in files:
                nm = f.filename or "发票.png"
                data = await f.read()
                if nm.lower().endswith(".xlsx") and h.get("add_reimb"):    # 报销申请单：自动找到对应项目放进去
                    import tempfile
                    tp = tempfile.mktemp(suffix=".xlsx"); open(tp, "wb").write(data)
                    ok = h["is_reimb_xlsx"](tp)
                    proj = None
                    if ok:
                        try:
                            import openpyxl
                            wb_ = openpyxl.load_workbook(tp, data_only=True)
                            if "项目组支出" in wb_.sheetnames:
                                for r_ in wb_["项目组支出"].iter_rows(values_only=True):
                                    if str(r_[0] or "").startswith("项目名称"):
                                        proj = h["reimb_match_project"](str(r_[1] or ""))
                                        break
                        except Exception:
                            pass
                    os.remove(tp)
                    if ok and proj:
                        h["add_reimb"](proj["id"], nm, data)
                        reimbs_done.append(f"{nm} → {proj['name']}")
                    elif ok:
                        bad.append(f"{nm}（报销申请单：没认出是哪个项目，请到项目页「上传报销申请单」）")
                    else:
                        bad.append(f"{nm}（不是发票，也不是报销申请单）")
                    continue
                for n2, d2 in expand(nm, data):
                    iid, why = add_to_inbox(c, n2, d2)
                    if iid:
                        added += 1
                    elif why == "重复":
                        dup += 1
                    else:
                        bad.append(f"{n2}（{why}）")
        return dict(added=added, dup=dup, bad=bad, reimbs=reimbs_done)

    @app.get("/api/inbox/{iid}/page/{i}")
    def inbox_page(iid: int, i: int = 0, thumb: int = 0):
        with store.db() as c:
            r = c.execute("select pages from inv where id=?", (iid,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这张发票")
        ps = json.loads(r["pages"] or "[]")
        if i >= len(ps) or not os.path.exists(ps[i]):
            raise HTTPException(404, "文件不存在")
        p = ps[i]
        if thumb:
            from PIL import Image
            tp = p + ".t.jpg"
            if not os.path.exists(tp):
                with Image.open(p) as im:
                    im = im.convert("RGB")
                    im.thumbnail((360, 360))
                    im.save(tp, "JPEG", quality=80)
            return FileResponse(tp)
        return FileResponse(p)

    @app.get("/api/inbox/{iid}/orig")
    def inbox_orig(iid: int):
        with store.db() as c:
            r = c.execute("select path,name from inv where id=?", (iid,)).fetchone()
        if not r or not os.path.exists(r["path"]):
            raise HTTPException(404, "文件不存在")
        return FileResponse(r["path"], filename=r["name"], content_disposition_type="inline")

    class InvEdit(BaseModel):
        amount: Optional[float] = None
        seller: Optional[str] = None
        inv_date: Optional[str] = None
        status: Optional[str] = None
        kind: Optional[str] = None

    @app.put("/api/inbox/{iid}")
    def inbox_edit(iid: int, b: InvEdit):
        sets = {k: v for k, v in b.dict().items() if v is not None}
        if "status" in sets and sets["status"] not in ("new", "ignored"):
            raise HTTPException(400, "状态只能是 new / ignored")
        if "kind" in sets and sets["kind"] not in ("invoice", "trip"):
            raise HTTPException(400, "类型只能是 发票 / 行程单")
        if sets:
            with store.db() as c:
                c.execute("update inv set " + ",".join(f"{k}=?" for k in sets) + " where id=?", (*sets.values(), iid))
        return dict(ok=True)

    class Assign(BaseModel):
        line_id: int
        pair: int = 0


    @app.post("/api/inbox/{iid}/assign")
    def inbox_assign(iid: int, b: Assign):
        """把发票夹里的一张发票放进成本行（发票列）。"""
        with store.db() as c:
            r = c.execute("select * from inv where id=?", (iid,)).fetchone()
            ln = c.execute("select project_id from lines where id=?", (b.line_id,)).fetchone()
            if not r:
                raise HTTPException(404, "没有这张发票")
            if not ln:
                raise HTTPException(404, "没有这一行")
            if r["status"] == "used":
                raise HTTPException(400, "这张发票已经放进成本单了")
            save_to_line(c, b.line_id, r["kind"] or "invoice", r["name"], open(r["path"], "rb").read(), r["inv_no"])
            c.execute("update inv set status='used', line_id=? where id=?", (b.line_id, iid))
            paired = 0
            if b.pair:
                o = c.execute("select * from inv where id=? and status='new'", (b.pair,)).fetchone()
                if o:
                    save_to_line(c, b.line_id, o["kind"] or "invoice", o["name"], open(o["path"], "rb").read(), o["inv_no"])
                    c.execute("update inv set status='used', line_id=? where id=?", (b.line_id, o["id"]))
                    paired += 1
            elif r["mail_key"] or r["tx_uid"]:
                # 同一封邮件 / 同一笔账里、金额一样的另一种单据（发票 ↔ 行程单）一起放进去
                other = "trip" if (r["kind"] or "invoice") == "invoice" else "invoice"
                for o in c.execute("select * from inv where status='new' and kind=? and abs(amount-?)<0.011 and "
                                   "((mail_key<>'' and mail_key=?) or (tx_uid<>'' and tx_uid=?))",
                                   (other, r["amount"], r["mail_key"], r["tx_uid"])).fetchall():
                    save_to_line(c, b.line_id, other, o["name"], open(o["path"], "rb").read(), o["inv_no"])
                    c.execute("update inv set status='used', line_id=? where id=?", (b.line_id, o["id"]))
                    paired += 1
        return dict(ok=True, pid=ln["project_id"], paired=paired)

    class ToProject(BaseModel):
        project: str
        pair: int = 0
        sec: str = ""
        name: str = ""

    @app.post("/api/inbox/{iid}/to-project")
    def inbox_to_project(iid: int, b: ToProject):
        """按这张票在项目里新建一行（项目不存在就新建项目），票放进这一行。"""
        with store.db() as c:
            r = c.execute("select * from inv where id=?", (iid,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这张发票")
        if r["status"] == "used":
            raise HTTPException(400, "这张票已经放进成本单了")
        pid, created = h["ensure_project"](b.project)
        trip = r["kind"] == "trip" or TAXI_RE.search((r["item"] or "") + (r["seller"] or ""))
        sec = b.sec if b.sec in store.SECTIONS and b.sec != "备用金" else ("执行人员杂费" if trip else "物料部分")
        nm = b.name.strip() or ("打车费" if trip else re.sub(r"^\*[^*]*\*", "", r["item"] or "").strip() or r["seller"] or "发票")
        with store.db() as c:
            seq = c.execute("select coalesce(max(seq),0)+1 from lines where project_id=? and sec=?", (pid, sec)).fetchone()[0]
            lid = c.execute("insert into lines(project_id,sec,cat,seq,name,qty,unit,price,vendor,pay,date) values(?,?,?,?,?,?,?,?,?,?,?)",
                            (pid, sec, "", seq, nm[:40], 1, "项", r["amount"] or 0, r["seller"] or "", "已付", r["inv_date"] or "")).lastrowid
        res = inbox_assign(iid, Assign(line_id=lid, pair=b.pair))
        res.update(created=created, line_id=lid, sec=sec, name=nm)
        return res

    @app.post("/api/inbox/{iid}/unassign")
    def inbox_unassign(iid: int):
        """放错了：从成本行撤回，回到发票夹。"""
        with store.db() as c:
            r = c.execute("select * from inv where id=?", (iid,)).fetchone()
            if not r or r["status"] != "used":
                raise HTTPException(400, "这张发票不在成本单里")
            fs = c.execute("select * from files where line_id=? and kind=? and (inv_no=? and ?<>'' or name=? or name like ?)",
                           (r["line_id"], r["kind"] or "invoice", r["inv_no"], r["inv_no"], r["name"],
                            os.path.splitext(r["name"])[0] + "-第%页.pdf")).fetchall()
            for f in fs:
                for p in (f["path"], f["path"] + ".t.jpg"):
                    try:
                        os.remove(p)
                    except OSError:
                        pass
                c.execute("delete from files where id=?", (f["id"],))
            for orig in {f["orig"] for f in fs if f["orig"]}:
                if not c.execute("select 1 from files where orig=?", (orig,)).fetchone():
                    try:
                        os.remove(orig)
                    except OSError:
                        pass
            c.execute("update inv set status='new', line_id=0 where id=?", (iid,))
        # 一起放进去的另一半（发票 ↔ 行程单）也一起撤回
        with store.db() as c:
            other = c.execute("select id from inv where status='used' and line_id=? and id<>? and kind<>?",
                              (r["line_id"], iid, r["kind"] or "invoice")).fetchall()
        if other and not getattr(inbox_unassign, "_inner", False):
            inbox_unassign._inner = True
            try:
                for o in other:
                    inbox_unassign(o["id"])
            finally:
                inbox_unassign._inner = False
        return dict(ok=True, line_id=r["line_id"], also=len(other))

    @app.delete("/api/inbox/{iid}")
    def inbox_delete(iid: int):
        with store.db() as c:
            r = c.execute("select * from inv where id=?", (iid,)).fetchone()
            if not r:
                raise HTTPException(404, "没有这张发票")
            for p in set(json.loads(r["pages"] or "[]") + [r["path"]]):
                for q in (p, p + ".t.jpg"):
                    try:
                        os.remove(q)
                    except OSError:
                        pass
            c.execute("delete from inv where id=?", (iid,))
        return dict(ok=True)

    @app.get("/api/projects/{pid}/inbox-match")
    def project_inbox_match(pid: int):
        """发票夹里「最可能属于这个项目」的票：按金额推荐时排第一的是本项目的行、且那一行还没有这类票。"""
        with store.db() as c:
            lines = line_rows(c)
            rows = c.execute("select * from inv where status='new' and amount>0").fetchall()
            pr = pairs_of(c.execute("select * from inv where status='new'").fetchall())
        out, taken = [], set()
        for r in rows:
            d = dict(r)
            if d["kind"] == "trip" and pr.get(d["id"]):          # 配了发票的行程单跟着发票走
                continue
            sg = suggest(d, lines)
            if not sg or sg[0]["pid"] != pid or sg[0]["has_inv"] or sg[0]["line_id"] in taken:
                continue
            if len(sg) > 1 and sg[1]["score"] == sg[0]["score"] and not sg[1]["has_inv"]:
                continue                                      # 两行一样像：不替你选
            l0 = next((l for l in lines if l["id"] == sg[0]["line_id"]), {})
            ltxt = (l0.get("name") or "") + (l0.get("vendor") or "") + (l0.get("sec") or "")
            seller = d["seller"] or ""
            transport = d["kind"] == "trip" or re.search(r"铁路|出行|滴滴|航空|客运|交通|高德|曹操", seller + (d["item"] or ""))
            same_seller = any(seller[i:i + 2] in ltxt for i in range(max(0, len(seller) - 1))
                              if seller[i:i + 2] not in ("有限", "公司", "上海", "北京", "科技", "服务", "管理", "限公", "文化", "传播"))
            if not (same_seller or (transport and TAXI_RE.search(ltxt + "交通" * 0)) or (transport and re.search(r"交通|车票|打车|高铁|机票|差旅", ltxt))):
                continue                                      # 只是金额碰巧一样：不放进一键清单（📧 里仍能手动选）
            taken.add(sg[0]["line_id"])
            out.append(dict(id=d["id"], kind=d["kind"], amount=d["amount"], seller=d["seller"], name=d["name"],
                            line_id=sg[0]["line_id"], line_name=sg[0]["name"], pair=pr.get(d["id"], 0)))
        return out

    class ApplyMatch(BaseModel):
        items: List[dict]

    @app.post("/api/projects/{pid}/inbox-apply")
    def project_inbox_apply(pid: int, b: ApplyMatch):
        n = 0
        for it in b.items:
            try:
                inbox_assign(int(it["id"]), Assign(line_id=int(it["line_id"]), pair=int(it.get("pair") or 0)))
                n += 1
            except HTTPException:
                pass
        return dict(n=n)

    @app.get("/api/lines/{lid}/inbox-sugg")
    def line_sugg(lid: int):
        """某个成本行：发票夹里金额对得上的发票。"""
        with store.db() as c:
            l = c.execute("select qty*price as amount from lines where id=?", (lid,)).fetchone()
            if not l:
                raise HTTPException(404, "没有这一行")
            rows = c.execute("select * from inv where status='new' and abs(amount-?)<0.011", (l["amount"] or 0,)).fetchall()
        return [inv_view(r) for r in rows]

    # ------------------------------------------------------------ 压缩包 / 邮件里的附件展开
    def expand(name, data):
        """zip 里的 PDF/图片拆出来；OFD、XML 跳过（同一封邮件里一般也带 PDF）。"""
        ext = os.path.splitext(name)[1].lower()
        if ext == ".zip" or data[:4] == b"PK\x03\x04" and ext not in (".ofd", ".xlsx", ".docx"):
            out = []
            try:
                z = zipfile.ZipFile(io.BytesIO(data))
                for zi in z.infolist()[:50]:
                    nm = zi.filename
                    try:
                        nm = nm.encode("cp437").decode("gbk")
                    except Exception:
                        pass
                    e2 = os.path.splitext(nm)[1].lower()
                    if (e2 == ".pdf" or e2 in IMG_EXT) and zi.file_size < 30 * 1024 * 1024:
                        out.append((os.path.basename(nm), z.read(zi)))
            except zipfile.BadZipFile:
                pass
            return out
        if ext == ".pdf" or ext in IMG_EXT or data[:5] == b"%PDF-":
            return [(name, data)]
        return []

    h["expand"] = expand

    def reparse():
        """之前没读出金额的 PDF（比如加「行程单」识别前进来的）：重新识别一次。"""
        with store.db() as c:
            for r in c.execute("select id,name,path from inv where status='new' and (amount=0 or seller='') and path like '%.pdf'").fetchall():
                try:
                    _, text = render_pdf(open(r["path"], "rb").read())
                except Exception:
                    continue
                if is_trip(text, r["name"]):
                    i = parse_trip(text)
                    c.execute("update inv set kind='trip', amount=?, inv_date=?, seller=?, item=? where id=?",
                              (i["amount"], i["inv_date"], i["seller"], i["item"], r["id"]))
                else:
                    i = parse_pdf_text(text)
                    if i["amount"] or i["seller"]:
                        c.execute("update inv set amount=?, seller=?, buyer=?, inv_no=?, inv_date=?, item=? where id=?",
                                  (i["amount"], i["seller"], i["buyer"], i["inv_no"], i["inv_date"] or "", i["item"], r["id"]))

    threading.Thread(target=reparse, daemon=True).start()

    # ------------------------------------------------------------ 记账本里某一笔账的发票
    def attach_pending():
        """记账本里上传、当时还没进成本单的发票：这笔账进了成本单就自动放进对应行。"""
        with store.db() as c:
            for r in c.execute("select i.id, i.name, i.path, i.inv_no, i.kind, l.id as lid from inv i join lines l on l.uid=i.tx_uid "
                               "where i.status='new' and i.tx_uid<>''").fetchall():
                save_to_line(c, r["lid"], r["kind"] or "invoice", r["name"], open(r["path"], "rb").read(), r["inv_no"])
                c.execute("update inv set status='used', line_id=? where id=?", (r["lid"], r["id"]))

    if h.get("hooks") is not None:
        h["hooks"]["inv_attach"] = attach_pending

    def tx_files(uid):
        with store.db() as c:
            fs = c.execute("select f.id, f.name, f.orig, f.kind, l.id as lid, p.name as project from files f join lines l on l.id=f.line_id "
                           "join projects p on p.id=l.project_id where l.uid=? and f.kind in ('invoice','trip') order by f.id", (uid,)).fetchall()
            ins = c.execute("select * from inv where tx_uid=? and status='new' order by id", (uid,)).fetchall()
        return dict(files=[dict(id=f["id"], name=f["name"], pdf=bool(f["orig"]), project=f["project"], kind=f["kind"]) for f in fs],
                    inbox=[dict(id=r["id"], name=r["name"], pdf=r["path"].endswith(".pdf"), amount=r["amount"], kind=r["kind"]) for r in ins])

    @app.get("/api/tx-invoices")
    def tx_invoices(uid: str):
        return tx_files(uid)

    @app.post("/api/tx-invoices")
    async def tx_invoice_upload(uid: str = Form(...), amount: float = Form(0), date: str = Form(""), who: str = Form(""),
                                kind: str = Form("invoice"), files: List[UploadFile] = File(...)):
        """记账本「编辑交易」里上传发票：这笔已在成本单 → 直接放进那一行；还没在 → 先进发票夹并记住是哪笔账。"""
        n, dup = 0, 0
        with store.db() as c:
            ln = c.execute("select id from lines where uid=? order by id limit 1", (uid,)).fetchone()
            for f in files:
                items = expand(f.filename or "发票.png", await f.read())
                if not items:
                    raise HTTPException(400, f"{f.filename} 不是图片或 PDF")
                for nm, data in items:
                    if kind not in ("invoice", "trip"):
                        raise HTTPException(400, "类型只能是 发票 / 行程单")
                    if ln:
                        save_to_line(c, ln["id"], kind, nm, data)
                        n += 1
                        continue
                    iid, why = add_to_inbox(c, nm, data, "tx", mdate=date)
                    if iid:
                        c.execute("update inv set tx_uid=?, subject=?, kind=?, amount=case when amount>0 then amount else ? end where id=?",
                                  (uid, who, kind, amount, iid))
                        n += 1
                    elif why == "重复":
                        dup += 1
        d = tx_files(uid)
        d.update(n=n, dup=dup, to_line=bool(ln))
        return d

    # ------------------------------------------------------------ QQ 邮箱
    def mail_cfg():
        return bt.load_json(MAILCFG, {}) or {}

    def kc_get(acct):
        r = subprocess.run(["security", "find-generic-password", "-s", KC_SERVICE, "-a", acct, "-w"], capture_output=True, text=True)
        return r.stdout.strip() if r.returncode == 0 else ""

    def kc_set(acct, code):
        subprocess.run(["security", "add-generic-password", "-U", "-s", KC_SERVICE, "-a", acct, "-w", code], capture_output=True, check=True)

    def kc_del(acct):
        subprocess.run(["security", "delete-generic-password", "-s", KC_SERVICE, "-a", acct], capture_output=True)

    MS = dict(running=False, msg="", last_added=0)

    def mail_public():
        cf = mail_cfg()
        return dict(email=cf.get("email", ""), on=bool(cf.get("email")), last_sync=cf.get("last_sync", ""),
                    last_result=cf.get("last_result", ""), running=MS["running"], msg=MS["msg"], days=cf.get("days", 90))

    def imap_login(acct, code):
        M = imaplib.IMAP4_SSL("imap.qq.com", 993, timeout=30)
        try:
            M.login(acct, code)
        except imaplib.IMAP4.error as e:
            raise HTTPException(400, "QQ 邮箱登录失败：请确认邮箱地址正确、IMAP 已开启、填的是「授权码」而不是 QQ 密码（%s）" % str(e)[:60])
        return M

    class MailCfg(BaseModel):
        email: str
        code: str = ""
        days: int = 90

    @app.post("/api/mail/config")
    def mail_config(b: MailCfg):
        acct = b.email.strip()
        if not re.match(r"^[^@\s]+@(qq|foxmail|vip\.qq)\.com$", acct, re.I):
            raise HTTPException(400, "请填 QQ 邮箱地址（xxx@qq.com 或 @foxmail.com）")
        code = re.sub(r"\s+", "", b.code) or kc_get(acct)
        if not code:
            raise HTTPException(400, "请填授权码")
        M = imap_login(acct, code)
        try:
            M.logout()
        except Exception:
            pass
        kc_set(acct, code)
        cf = mail_cfg()
        if cf.get("email") and cf["email"] != acct:
            kc_del(cf["email"])
        cf.update(email=acct, days=max(7, min(730, b.days)))
        json.dump(cf, open(MAILCFG, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        return mail_public()

    @app.delete("/api/mail/config")
    def mail_unlink():
        cf = mail_cfg()
        if cf.get("email"):
            kc_del(cf["email"])
        try:
            os.remove(MAILCFG)
        except OSError:
            pass
        return mail_public()

    def dec(s):
        try:
            return str(make_header(decode_header(s or "")))
        except Exception:
            return s or ""

    def body_links(msg):
        links = []
        for part in msg.walk():
            if part.get_content_type() in ("text/html", "text/plain"):
                try:
                    txt = part.get_payload(decode=True).decode(part.get_content_charset() or "utf-8", "ignore")
                except Exception:
                    continue
                for u in re.findall(r"https?://[^\s\"'<>]+", txt):
                    u = u.replace("&amp;", "&").rstrip(").,;")
                    lu = u.lower()
                    if ("pdf" in lu or "download" in lu or "xiazai" in lu or "fp" in lu.split("?")[0][-30:]) and u not in links:
                        links.append(u)
        return links[:6]

    def fetch_link(u):
        try:
            import requests
            r = requests.get(u, timeout=20, headers={"User-Agent": "Mozilla/5.0"}, allow_redirects=True)
            if r.status_code == 200 and r.content[:5] == b"%PDF-" and len(r.content) < 30 * 1024 * 1024:
                cd = r.headers.get("content-disposition", "")
                m = re.search(r"filename\*?=(?:UTF-8'')?\"?([^\";]+)", cd)
                from urllib.parse import unquote
                nm = unquote(m.group(1)) if m else "发票.pdf"
                return nm if nm.lower().endswith(".pdf") else nm + ".pdf", r.content
        except Exception:
            pass
        return None

    def sync_once(days=None):
        cf = mail_cfg()
        acct = cf.get("email")
        if not acct:
            return "还没关联邮箱"
        code = kc_get(acct)
        if not code:
            return "钥匙串里没有授权码，请在「发票夹」重新填一次"
        days = days or cf.get("days", 90)
        since = (datetime.now() - timedelta(days=days)).strftime("%d-%b-%Y")
        M = imap_login(acct, code)
        added = dup = mails = links = 0
        try:
            M.select("INBOX", readonly=True)
            typ, d = M.uid("search", None, "SINCE", since)
            uids = (d[0] or b"").split()
            hits = []
            for i in range(0, len(uids), 200):
                MS["msg"] = f"正在看邮件标题 {min(i + 200, len(uids))}/{len(uids)}"
                typ, d = M.uid("fetch", b",".join(uids[i:i + 200]), "(BODY.PEEK[HEADER.FIELDS (SUBJECT FROM DATE MESSAGE-ID)])")
                for it in d:
                    if not isinstance(it, tuple):
                        continue
                    m = re.search(rb"UID (\d+)", it[0])
                    hm = email.message_from_bytes(it[1])
                    subj = dec(hm.get("Subject"))
                    if m and SUBJ_RE.search(subj + " " + dec(hm.get("From"))):
                        hits.append((m.group(1), subj, dec(hm.get("From")), hm.get("Date"), (hm.get("Message-ID") or "").strip()))
            done = set(cf.get("seen", []))
            for k, (uid, subj, frm, dt, mid) in enumerate(hits):
                key = mid or uid.decode()
                if key in done:
                    continue
                MS["msg"] = f"正在下载发票邮件 {k + 1}/{len(hits)}"
                typ, d = M.uid("fetch", uid, "(BODY.PEEK[])")
                raw = next((x[1] for x in d if isinstance(x, tuple)), None)
                if not raw:
                    continue
                msg = email.message_from_bytes(raw)
                try:
                    mdate = parsedate_to_datetime(dt).strftime("%Y-%m-%d %H:%M") if dt else ""
                except Exception:
                    mdate = ""
                files = []
                for part in msg.walk():
                    fn = part.get_filename()
                    if fn:
                        data = part.get_payload(decode=True)
                        if data:
                            files += expand(dec(fn), data)
                if not any(f[0].lower().endswith(".pdf") or f[1][:5] == b"%PDF-" for f in files):
                    for u in body_links(msg):
                        got = fetch_link(u)
                        if got:
                            files.append(got)
                            links += 1
                            break
                mails += 1
                with store.db() as c:
                    for nm, data in files:
                        iid, why = add_to_inbox(c, nm, data, "mail", key, subj, frm, mdate)
                        if iid:
                            added += 1
                        elif why == "重复":
                            dup += 1
                done.add(key)
            cf = mail_cfg()
            cf["seen"] = list(done)[-3000:]
        finally:
            try:
                M.logout()
            except Exception:
                pass
        res = f"看了 {len(hits)} 封发票邮件，新进发票夹 {added} 张" + (f"，{dup} 张之前已有" if dup else "") + \
              (f"（其中 {links} 张是从邮件里的下载链接拿的）" if links else "")
        cf.update(last_sync=datetime.now().strftime("%Y-%m-%d %H:%M"), last_result=res)
        json.dump(cf, open(MAILCFG, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
        MS["last_added"] = added
        return res

    def run_sync(days=None):
        if MS["running"]:
            return
        MS["running"] = True
        MS["msg"] = "正在连接 QQ 邮箱…"
        try:
            MS["msg"] = sync_once(days)
        except HTTPException as e:
            MS["msg"] = "⚠ " + e.detail
        except Exception as e:
            MS["msg"] = "⚠ 拉取失败：%s" % str(e)[:120]
        finally:
            MS["running"] = False

    class SyncReq(BaseModel):
        days: int = 0

    @app.post("/api/mail/sync")
    def mail_sync(b: SyncReq):
        if not mail_cfg().get("email"):
            raise HTTPException(400, "还没关联 QQ 邮箱")
        threading.Thread(target=run_sync, args=(b.days or None,), daemon=True).start()
        time.sleep(0.3)
        return mail_public()

    @app.get("/api/mail/status")
    def mail_status():
        return mail_public()

    def loop():
        time.sleep(90)
        while True:
            if mail_cfg().get("email"):
                run_sync()
            time.sleep(6 * 3600)

    threading.Thread(target=loop, daemon=True).start()
