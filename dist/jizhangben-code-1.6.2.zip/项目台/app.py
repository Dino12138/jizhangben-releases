"""CD的记账本 · 项目台（后端）
功能：账单上传分类(工作/生活/待确认)、项目与成本单、发票/支付截图上传、按模板导出带高清图的成本单 Excel，
并把账单/项目支出同步进CD的记账本(ezBookkeeping)。
"""
import json, os, re, shutil, sys, tempfile, threading, time, uuid
from datetime import datetime, date, timedelta
from typing import List, Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

HERE = os.path.dirname(os.path.abspath(__file__))
TOOLS = os.environ.get("CHAIMI_TOOLS", os.path.join(os.path.dirname(HERE), "工具"))
sys.path.insert(0, TOOLS)
sys.path.insert(0, HERE)
import store, exporter                   # noqa: E402
import bill_tool as bt                    # noqa: E402
import cost_match as cm                   # noqa: E402
from api_import import Api, ApiError, push_rows, rid  # noqa: E402

store.init()
app = FastAPI(title="CD的记账本·项目台")
import guard                               # noqa: E402
guard.install(app)                         # 只接受本机页面的请求
_last = threading.local()                  # 这次请求里刚新建的借款/还款编号（每个请求各记各的，不会串）

# 临时文件统一放到数据目录下的「临时」文件夹，每次启动清空（原来散落在系统临时目录里没人清）
_TMP = os.path.join(store.DATA, "临时")
shutil.rmtree(_TMP, ignore_errors=True)
os.makedirs(_TMP, exist_ok=True)
tempfile.tempdir = _TMP
# 导出的成本单 Excel 只是给你下载用的副本：超过 30 天的启动时清掉（要用随时能重新导出），免得越积越大
try:
    _exp = os.path.join(store.DATA, "exports")
    for _f in (os.listdir(_exp) if os.path.isdir(_exp) else []):
        _p = os.path.join(_exp, _f)
        if os.path.isfile(_p) and time.time() - os.path.getmtime(_p) > 30 * 86400:
            store.safe_rm(_p)
except Exception:
    pass


def seed_projects():
    """首次启动把工具里已登记的项目带进项目台，避免项目周期丢失。"""
    ps = []
    for src in (lambda: json.load(open(bt.PROJECTS, encoding="utf-8")),
                lambda: [dict(p, customer=(store.name_kw("mode_a") or [""])[0]) for p in bt.load_json(bt.RULES, {}).get("项目周期", [])]):
        try:
            ps += src()
        except Exception:
            pass
    with store.db() as c:
        for p in ps:
            if not c.execute("select 1 from projects where name=?", (p["name"],)).fetchone():
                c.execute("insert into projects(name,customer,start,end,params) values(?,?,?,?,'{}')",
                          (p["name"], p.get("customer", ""), p.get("start", ""), p.get("end", "")))


seed_projects()


# ---------------------------------------------------------------- 记账软件连接
_api = {"obj": None, "key": None}
_tx_cache = {"t": 0, "rows": None}


def ezb():
    cfg = store.load_config()
    key = (os.environ.get("CHAIMI_EZB_API") or cfg["ezb_url"], cfg["ezb_user"], cfg["ezb_pass"])
    if not cfg["ezb_user"]:
        raise HTTPException(400, "还没设置记账软件账号，请先到「设置」里填写。")
    if _api["key"] != key:
        try:
            _api["obj"], _api["key"] = Api(*key), key
        except ApiError as e:
            raise HTTPException(400, f"登录记账软件失败：{e}")
    return _api["obj"]


_fx = {"t": 0, "acc": {}, "rate": {}}


def fx_info():
    """账户币种 + 汇率（1 外币 = ? 人民币，用记账本自带的汇率源）；10 分钟刷新一次。"""
    if time.time() - _fx["t"] > 600:
        try:
            api = ezb()
            _fx["acc"] = {str(a["id"]): (a.get("currency") or "CNY").upper() for a in api.call("GET", "/api/v1/accounts/list.json")}
            if any(c != "CNY" for c in _fx["acc"].values()):
                d = api.call("GET", "/api/v1/exchange_rates/latest.json")
                base = {r["currency"]: float(r["rate"]) for r in d.get("exchangeRates", [])}
                base[d.get("baseCurrency", "EUR")] = 1.0
                if base.get("CNY"):
                    _fx["rate"] = {k: base["CNY"] / v for k, v in base.items() if v}
            try:                                             # 你在「我的钱」里自己填的汇率优先
                with store.db() as c:
                    for r in c.execute("select a.name, a.currency, a.rate from acc_cal a where a.rate>0 and a.currency<>''"):
                        _fx["rate"][r["currency"].upper()] = r["rate"]
            except Exception as e:
                store.log_err("读取你自己填的汇率", e)
        except Exception as e:
            store.log_err("取汇率（外币账先按原数显示）", e)
        _fx["t"] = time.time()
    return _fx


_tx_lock = threading.Lock()


def ezb_transactions(force=False):
    # 账有改动时会主动作废缓存（项目台自己改的、在记账本界面里改的都会通知）；30 秒只是兜底
    with _tx_lock:          # 同时有几处要账时只取一次（启动时后台预先取的那次，页面直接等着用）
        return _ezb_transactions(force)


def _ezb_transactions(force=False):
    if force or time.time() - _tx_cache["t"] > 30 or _tx_cache["rows"] is None:
        rows = ezb().call("GET", "/api/v1/transactions/list/all.json?start_time=0&end_time=9999999999999")
        fx = fx_info()
        for t in rows:                                       # 外币账户的账：统计时按汇率折成人民币（_cny，单位：分）
            cur = fx["acc"].get(str(t.get("sourceAccountId")), "CNY")
            t["_cur"] = cur
            if t.get("type") == 4:
                t["_dcur"] = fx["acc"].get(str(t.get("destinationAccountId")), "CNY")
            if cur != "CNY":
                r = fx["rate"].get(cur)
                t["_cny"] = int(round(t["sourceAmount"] * r)) if r else t["sourceAmount"]
        _tx_cache["rows"] = rows
        _tx_cache["t"] = time.time()
    return _tx_cache["rows"]


def ezb_existing_ids():
    return {rid(t.get("comment")) for t in ezb_transactions() if rid(t.get("comment"))}


HOOKS = {}          # txedit 注册的钩子（账单→成本单自动同步）


_ver = {"boot": str(int(time.time())), "n": 0}     # 数据版本号：账一有改动就 +1，页面靠它知道「该刷新了」


def data_ver():
    return f"{_ver['boot']}-{_ver['n']}"


def invalidate():
    _tx_cache["rows"] = None
    _catname["t"] = 0
    _ver["n"] += 1


@app.post("/api/invalidate")
def api_invalidate():
    """记账本界面里改了账/账户/分类：入口会来通知一声，这边马上用最新数据。"""
    invalidate()
    _fx["t"] = 0
    return dict(ok=True)


# ---------------------------------------------------------------- 小工具
def row(r):
    return dict(r) if r is not None else None


def parse_dates(text):
    """'2026年1月5日-1月7日' → ('2026-01-05','2026-01-07')"""
    m = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日?\s*[-~—至到]+\s*(?:(\d{4})年)?(?:(\d{1,2})月)?(\d{1,2})日?", text or "")
    if m:
        y = int(m.group(1))
        s = date(y, int(m.group(2)), int(m.group(3)))
        e = date(int(m.group(4) or y), int(m.group(5) or m.group(2)), int(m.group(6)))
        return s.isoformat(), e.isoformat()
    m = re.search(r"(\d{4})年(\d{1,2})月(\d{1,2})日?", text or "")
    if m:
        d = date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
        return d, d
    return "", ""


def sync_projects_json():
    """把项目登记表同步给分类器（夜间打车按项目周期归项目）。"""
    with store.db() as c:
        ps = [dict(name=r["name"], start=r["start"], end=r["end"], customer=r["customer"]) for r in c.execute("select * from projects")]
    store.write_json(bt.PROJECTS, ps)
    threading.Thread(target=_ensure_project_cats, args=([p["name"] for p in ps],), daemon=True).start()


def _ensure_project_cats(names):
    """记账本里给每个项目建好『项目·名称』大类和子分类（在记账本里选项目时能接着选子分类）。"""
    try:
        from api_import import ensure_project_categories, ensure_base_categories
        try:
            _merge_dup_cats()
        except Exception as e:
            store.log_err("合并重复分类", e)
        cs = custom_subs()
        n = ensure_base_categories(ezb(), {"工作": [x for x in WORK_SUBS if x not in WORK_INC_SUBS] + [x for x in cs["工作"] if x not in WORK_INC_SUBS], "生活": [x for x in LIFE_SUBS if x not in ("红包转账", "工资薪酬")] + cs["生活"]})
        if ensure_project_categories(ezb(), names, [x for x in cs["工作"] if x not in WORK_INC_SUBS]) + n:
            invalidate()
    except Exception as e:
        store.log_err("给项目建记账本分类", e)


def ezb_modify_tx(api, body):
    """改记账本里的一笔账。账户被隐藏时记账本不让改：先临时显示出来，改完再藏回去。"""
    try:
        return api.call("POST", "/api/v1/transactions/modify.json", body)
    except Exception as e:
        if "hidden account" not in str(e):
            raise
    ids = {str(body.get("sourceAccountId") or "0"), str(body.get("destinationAccountId") or "0")} - {"0"}
    shown = []
    try:
        for a in api.call("GET", "/api/v1/accounts/list.json"):
            if str(a["id"]) in ids and a.get("hidden"):
                api.call("POST", "/api/v1/accounts/hide.json", dict(id=str(a["id"]), hidden=False))
                shown.append(str(a["id"]))
        return api.call("POST", "/api/v1/transactions/modify.json", body)
    finally:
        for i in shown:
            try:
                api.call("POST", "/api/v1/accounts/hide.json", dict(id=i, hidden=True))
            except Exception as e2:
                store.log_err("把账户重新隐藏", e2)


def _merge_dup_cats():
    """记账本里同名的重复分类（大类重复、同一大类下子类重复）合成一个：账挪到保留的那个上，空壳删掉。没有重复就什么都不做。"""
    from api_import import _flat_categories, CAT_LOCK
    from collections import Counter, defaultdict
    with CAT_LOCK:
        api = ezb()
        flat = _flat_categories(api)
        kids = defaultdict(list)
        tops = defaultdict(list)
        for c_ in flat:
            if str(c_.get("parentId", "0")) == "0":
                tops[(c_["type"], c_["name"])].append(c_)
            else:
                kids[str(c_["parentId"])].append(c_)
        dup_top = any(len(v) > 1 for v in tops.values())
        dup_kid = any(len({k["name"] for k in ks}) < len(ks) for ks in kids.values())
        if not dup_top and not dup_kid:
            return 0
        txs = ezb_transactions(force=True)
        use = Counter(str(t["categoryId"]) for t in txs)
        try:
            do_backup("自动")
        except Exception as e:
            store.log_err("合并重复分类前备份", e)
        move, drop_kid, drop_top = {}, [], []          # move: 旧子类id -> 保留的子类id
        for (ct, name), group in tops.items():
            w = lambda g: (sum(use[str(k["id"])] for k in kids[str(g["id"])]), len(kids[str(g["id"])]), -int(g["id"]))
            keep = max(group, key=w)
            mine = {}
            for k in sorted(kids[str(keep["id"])], key=lambda k: (-use[str(k["id"])], int(k["id"]))):
                if k["name"] in mine:
                    move[str(k["id"])] = str(mine[k["name"]])
                    drop_kid.append(k)
                else:
                    mine[k["name"]] = k["id"]
            for g in group:
                if g is keep:
                    continue
                for k in kids[str(g["id"])]:
                    if use[str(k["id"])]:
                        if k["name"] not in mine:
                            mine[k["name"]] = api.call("POST", "/api/v1/transaction/categories/add.json", dict(
                                name=k["name"], type=ct, parentId=str(keep["id"]), icon=str(k.get("icon") or "1"), iconType=0,
                                color=k.get("color") or "999999", comment=""))["id"]
                        move[str(k["id"])] = str(mine[k["name"]])
                    drop_kid.append(k)
                drop_top.append(g)
        moved = 0
        bad = set()
        for t in txs:
            to = move.get(str(t["categoryId"]))
            if not to:
                continue
            try:
                ezb_modify_tx(api, dict(
                    id=str(t["id"]), type=t["type"], categoryId=to, time=t["time"], utcOffset=t["utcOffset"],
                    sourceAccountId=str(t["sourceAccountId"]), destinationAccountId=str(t.get("destinationAccountId") or 0),
                    sourceAmount=t["sourceAmount"], destinationAmount=t.get("destinationAmount", 0), hideAmount=t.get("hideAmount", False),
                    tagIds=[str(x) for x in (t.get("tagIds") or [])], pictureIds=[p_["pictureId"] for p_ in (t.get("pictures") or [])],
                    comment=t.get("comment") or ""))
                moved += 1
            except Exception as e:
                bad.add(str(t["categoryId"]))
                store.log_err("合并重复分类·挪账", e)
        gone = 0
        bad_top = {str(k["parentId"]) for k in drop_kid if str(k["id"]) in bad}
        for c_ in [k for k in drop_kid if str(k["id"]) not in bad] + [g for g in drop_top if str(g["id"]) not in bad_top]:
            try:
                api.call("POST", "/api/v1/transaction/categories/delete.json", {"id": str(c_["id"])})
                gone += 1
            except Exception as e:
                store.log_err("合并重复分类·删空壳", e)
        invalidate()
        return gone


def line_amount(l):
    return 0 if l["pay"] == "无需付款" else round((l["qty"] or 0) * (l["price"] or 0), 2)


def summarize(lines):
    lines = [l for l in lines if not l.get("hold")]       # 待核对的不算
    total = sum(line_amount(l) for l in lines if l["sec"] != "备用金")
    paid = sum(line_amount(l) for l in lines if l["sec"] != "备用金" and l["pay"] in ("已付", "备用金垫付"))
    adv = sum((l["qty"] or 0) * (l["price"] or 0) for l in lines if l["sec"] == "备用金")
    cash_used = sum(line_amount(l) for l in lines if l["sec"] != "备用金" and l["pay"] == "备用金垫付")
    return dict(total=round(total, 2), paid=round(paid, 2), unpaid=round(total - paid, 2), advance=round(adv, 2),
                cash_used=round(cash_used, 2), cash_left=round(adv - cash_used, 2))


def _pct(r):
    return f"{round((r or 0) * 100, 4):g}%"


def _lab(P, k, d):
    """利润测算各项的名字：这个项目改过名就用改的（去掉「点数/税率」这类尾巴）"""
    v = ((P.get("labels") or {}).get(k) or "").strip()
    return v or d


def _step(t, f, amt, kind="minus", conv=None):
    return dict(t=t, f=f, amt=round(amt, 2), kind=kind, conv=conv)


CUSTOM_KINDS = ("pct_quote", "pct_left", "amt", "cost")


def custom_profit(P, total):
    """自定义公式：从客户报价开始一项一项往下算，剩下的就是利润。"""
    Q = float(P.get("quote") or 0)
    left, steps = Q, [_step("客户报价", "你填的", Q, "start")]
    for it in (P.get("custom") or []):
        kind, v, name = it.get("kind"), float(it.get("v") or 0), (it.get("name") or "").strip() or "未命名"
        plus = it.get("op") == "+"
        if kind == "pct_quote":
            d, f = Q * v, f"客户报价 × {_pct(v)}"
        elif kind == "pct_left":
            d, f = left * v, f"上一步剩下的 {left:,.2f} × {_pct(v)}"
        elif kind == "cost":
            d, f = total, "成本单合计"
        else:
            d, f = v, "固定金额"
        left = left + d if plus else left - d
        steps.append(_step(name, f, d, "plus" if plus else "minus"))
    steps.append(_step("利润", "客户报价一项项加减下来剩下的", left, "end"))
    return dict(income=round(Q, 2), tax=0.0, income_tax=0.0, profit=round(left, 2), rate=round(left / Q, 4) if Q else 0,
                mid_fee=0.0, steps=steps, custom=True)


def mode_a_profit(P, total):
    """模式A：中间方收款用闭式解，避免返点↔税费↔中间方收款的循环引用。"""
    N = store.names()
    MID = N["mid"] + "收款"
    Q, R = P["quote"], P["reimb"]
    F = R * P["r_reimb_fee"]
    g_rb, g_zh, g_tx, g_it = P["r_rebate"], P["r_mid"], P["r_tax"], P["r_income_tax"]
    den = 1 - g_rb * g_zh * (1 - g_tx)
    ZH = (g_zh * (Q - R - F) * (1 - g_rb) + g_rb * g_zh * g_tx * Q) / den if den else 0
    TX = (Q - ZH) * g_tx
    RB = (Q - F - ZH - TX - R) * g_rb
    IT = (Q - total - TX - ZH) * g_it
    PF = Q - total - RB - ZH - TX - IT
    simple_zh = not g_rb and not R
    st = [_step("客户报价", "你填的", Q, "start"),
          _step(_lab(P, "r_mid", MID), f"客户报价 × {_pct(g_zh)}" if simple_zh else
                f"{_pct(g_zh)} × 扣掉实报实销后的金额（和返点、税费互相牵扯，软件一次解出来）", ZH, conv=dict(kind="pct_quote", v=g_zh) if simple_zh else None),
          _step(_lab(P, "r_tax", "税费"), f"(客户报价 − {_lab(P, 'r_mid', MID)}) × {_pct(g_tx)}", TX, conv=dict(kind="pct_left", v=g_tx)),
          _step(_lab(P, "r_rebate", "返点+公关费"), f"(客户报价 − 实报实销及服务费 − {_lab(P, 'r_mid', MID)} − 税费) × {_pct(g_rb)}", RB,
                conv=dict(kind="pct_left", v=g_rb) if not R else None),
          _step("项目成本", "成本单合计", total, conv=dict(kind="cost", v=0)),
          _step(_lab(P, "r_income_tax", "企业所得税"), f"(客户报价 − 成本 − 税费 − {_lab(P, 'r_mid', MID)}) × {_pct(g_it)}", IT,
                conv=dict(kind="pct_left", v=g_it) if not RB else None),
          _step(_lab(P, "o_profit", "利润"), "客户报价减去上面各项", PF, "end")]
    if R:
        st.insert(1, _step("实报实销返还 + 服务费", f"{R:,.2f} + {R:,.2f} × {_pct(P['r_reimb_fee'])}（是我方收入，不扣）", R + F, "note"))
    st = [s for s in st if s["kind"] != "minus" or abs(s["amt"]) > 0.004 or s["t"] == "项目成本"]
    return dict(income=round(Q - ZH, 2), tax=round(TX, 2), income_tax=round(IT, 2), profit=round(PF, 2),
                rate=round(PF / Q, 4) if Q else 0, reimb_fee=round(F, 2), rebate=round(RB, 2), mid_fee=round(ZH, 2), steps=st)


def profit(params, total):
    P = {**store.base_params(), **params}
    if P.get("mode") == "mode_a":
        return mode_a_profit(P, total)
    if P.get("mode") == "custom":
        return custom_profit(P, total)
    q, yd, ju = P["quote"], P["adv_daifu"], P["ch_daifu"]
    adv_fee = yd * (1 + P["r_adv_fee"]) * (1 + P["r_tax"]) if P["r_adv_fee"] > 0 else 0
    ju_fee = ju * P["r_ch_fee"]
    ju_tax = (ju + ju_fee) * P["r_ch_tax"]
    ch = (q - adv_fee - ju - ju_fee - ju_tax) * P["r_channel"]
    zh = q * P["r_mid"]
    income = q - adv_fee - ju - ju_fee - ju_tax - ch - zh
    tax = income * P["r_tax"]
    itax = (income - total - tax) * P["r_income_tax"]
    pf = income - total - tax - itax
    base = income - yd
    N = store.names()
    ADV, CH, MID = N["adv"], N["ch"], N["mid"] + "收款"
    chl = _lab(P, "r_channel", f"{CH}返点" if P.get("mode") == "mode_b" else "渠道返点")
    st = [_step("客户报价", "你填的", q, "start"),
          _step(_lab(P, "r_adv_fee", f"{ADV}代垫付（含服务费、税）"), f"{ADV}代垫付 {yd:,.2f} × (1 + {_pct(P['r_adv_fee'])}) × (1 + {_pct(P['r_tax'])})", adv_fee, conv=dict(kind="amt", v=round(adv_fee, 2))),
          _step(_lab(P, "ch_daifu", f"{CH}代垫付"), "你填的", ju, conv=dict(kind="amt", v=ju)),
          _step(_lab(P, "r_ch_fee", f"{CH}服务费"), f"{CH}代垫付 × {_pct(P['r_ch_fee'])}", ju_fee, conv=dict(kind="amt", v=round(ju_fee, 2))),
          _step(_lab(P, "r_ch_tax", f"{CH}税"), f"({CH}代垫付 + 服务费) × {_pct(P['r_ch_tax'])}", ju_tax, conv=dict(kind="amt", v=round(ju_tax, 2))),
          _step(chl, f"(客户报价 − 上面几项) × {_pct(P['r_channel'])}", ch, conv=dict(kind="pct_left", v=P["r_channel"])),
          _step(_lab(P, "r_mid", MID), f"客户报价 × {_pct(P['r_mid'])}", zh, conv=dict(kind="pct_quote", v=P["r_mid"])),
          _step(_lab(P, "o_income", f"{ADV}收款"), "客户报价减去上面各项", income, "sub"),
          _step(_lab(P, "r_tax", "税费"), f"{_lab(P, 'o_income', ADV + '收款')} × {_pct(P['r_tax'])}", tax, conv=dict(kind="pct_left", v=P["r_tax"])),
          _step("项目成本", "成本单合计", total, conv=dict(kind="cost", v=0)),
          _step(_lab(P, "r_income_tax", "企业所得税"), f"({_lab(P, 'o_income', ADV + '收款')} − 税费 − 成本) × {_pct(P['r_income_tax'])}", itax, conv=dict(kind="pct_left", v=P["r_income_tax"])),
          _step(_lab(P, "o_profit", "利润"), f"{_lab(P, 'o_income', ADV + '收款')}减去税费、成本、所得税", pf, "end")]
    st = [s for s in st if s["kind"] != "minus" or abs(s["amt"]) > 0.004 or s["t"] == "项目成本"]
    return dict(income=round(income, 2), tax=round(tax, 2), income_tax=round(itax, 2), profit=round(pf, 2),
                rate=round(pf / base, 4) if base else 0, mid_fee=round(zh, 2), steps=st)


# 「钱怎么走的」里能改的文字：各方名字、各方下面的小字、箭头上的字、各项扣款的名字、最后一段的说明
CHAIN_KEYS = ("client", "mid", "exec", "me", "role_client", "role_mid", "role_exec", "role_me", "hop_h1", "hop_h2", "hop_last",
              "d_keep", "d_tax", "d_rebate", "d_income_tax", "d_other", "d_cost", "note")


def money_chain(p, pf, total, recs, oinv):
    """钱怎么走的：甲方 →（中间方扣点）→ 执行方（扣税、付成本）→ 我。每段转款挂上对应的发票，最后一段对上我实际到账。"""
    P = p["params"]
    Q = float(P.get("quote") or 0)
    N = P.get("chain") or {}
    if Q <= 0:                                      # 还没填报价：卡片照样显示，让你在上面直接填
        return dict(empty=True, nodes=[], hops=[], names=dict(client=N.get("client") or p.get("customer") or "甲方",
                    mid=N.get("mid") or p.get("source") or "中间方", exec=N.get("exec") or "执行方"), has_mid=False)
    ZH = float(pf.get("mid_fee") or 0)
    client = N.get("client") or p.get("customer") or "甲方"
    mid = N.get("mid") or p.get("source") or "中间方"
    exe = N.get("exec") or "执行方"
    has_mid = ZH > 0.004
    after = round(Q - ZH, 2)
    ded = []
    if pf.get("custom"):
        for i, s_ in enumerate(pf.get("steps") or []):
            if s_["kind"] in ("minus", "plus"):
                ded.append(dict(k="cost" if s_["f"] == "成本单合计" else f"c{i}", t=s_["t"] + ("（加回）" if s_["kind"] == "plus" else ""),
                                amt=s_["amt"] if s_["kind"] == "minus" else -s_["amt"]))
    other = round(after - float(pf.get("income") or 0), 2)
    if other > 0.01:
        ded.append(dict(k="other", t="代付 / 渠道等费用", amt=other))
    for k, t, rk in [] if pf.get("custom") else (("tax", "税费", "r_tax"), ("rebate", "返点", "r_rebate"), ("income_tax", "企业所得税", "r_income_tax")):
        v = float(pf.get(k) or 0)
        if v > 0.004:
            ded.append(dict(k=k, t=t, amt=round(v, 2), rate=P.get(rk)))
    if total > 0.004 and not pf.get("custom"):
        ded.append(dict(k="cost", t="项目成本（成本单合计）", amt=round(total, 2)))
    nodes = [dict(k="client", name=client, role="甲方")]
    hops = []
    if has_mid:
        nodes.append(dict(k="mid", name=mid, role="中间方", keep=round(ZH, 2), rate=P.get("r_mid")))
        hops.append(dict(k="h1", frm=client, to=mid, amount=round(Q, 2)))
        hops.append(dict(k="h2", frm=mid, to=exe, amount=after))
    else:
        hops.append(dict(k="h1", frm=client, to=exe, amount=round(Q, 2)))
    nodes.append(dict(k="exec", name=exe, role="执行方", ded=ded))
    nodes.append(dict(k="me", name="我", role=""))
    got = round(sum(r["amount"] for r in recs if r["amount"] > 0), 2)
    hops.append(dict(k="last", frm=exe, to="我", amount=round(float(pf.get("profit") or 0), 2), got=got, last=True))
    for h in hops:
        iv = [o for o in oinv if (o.get("hop") or "h1") == h["k"]]
        h["inv"] = [dict(id=o["id"], amount=o["amount"], status=o["status"], issuer=o.get("issuer") or "", title=o.get("title") or "", no=o.get("no") or "",
                         has_file=bool(o.get("has_file") or o.get("files")), files=o.get("files") or [], fname=o.get("fname") or "") for o in iv]
        h["billed"] = round(sum(o["amount"] for o in iv if o["status"] != "待开"), 2)
    return dict(nodes=nodes, hops=hops, names=dict(client=client, mid=mid, exec=exe), has_mid=has_mid)


def project_detail(pid):
    if HOOKS.get("cost_sync"):
        try:
            HOOKS["cost_sync"]()
        except Exception as e:
            print("成本单自动同步失败：", e)
    if HOOKS.get("inv_attach"):
        try:
            HOOKS["inv_attach"]()
        except Exception as e:
            print("发票自动放进成本行失败：", e)
    with store.db() as c:
        p = row(c.execute("select * from projects where id=?", (pid,)).fetchone())
        if not p:
            raise HTTPException(404, "项目不存在")
        lines = [row(r) for r in c.execute("select * from lines where project_id=? order by case sec when '备用金' then 0 when '搭建部分' then 1 when '第三方人员' then 2 when '物料部分' then 3 else 4 end, seq, id", (pid,))]
        hold = [l for l in lines if l.get("hold")]
        lines = [l for l in lines if not l.get("hold")]
        fl = {}
        for f in c.execute("select * from files where line_id in (select id from lines where project_id=?) order by id", (pid,)):
            fl.setdefault(f["line_id"], []).append(dict(id=f["id"], kind=f["kind"], name=f["name"], w=f["w"], h=f["h"], orig=bool(f["orig"])))
    saved = json.loads(p["params"] or "{}")
    if "mode" not in saved:
        saved = {**store.mode_defaults(store.detect_mode(p)), **saved}
    p["params"] = {**store.base_params(), **saved}
    p["mode_name"] = store.mode_names().get(p["params"]["mode"], "")
    for l in lines + hold:
        l["amount"] = line_amount(l)
        l["files"] = fl.get(l["id"], [])
    inc = []
    if HOOKS.get("project_income"):
        try:
            inc = HOOKS["project_income"](p["name"])
        except Exception as e:
            store.log_err("读项目回款·" + p["name"], e)
            inc = []
    # 每行归到哪个月：自己的日期 > 对上的账单日期 > 项目开始日期；都没有就是「未标日期」
    try:
        tdate = HOOKS["tx_dates"]() if HOOKS.get("tx_dates") else {}
    except Exception as e:
        store.log_err("读账单日期", e)
        tdate = {}
    p_month = (p.get("start") or "")[:7]
    for l in lines:
        d = l.get("date") or (tdate.get(l["uid"], "") if l.get("uid") else "")
        l["month"] = d[:7] if d else p_month
    for v in inc:
        v["month"] = v["date"][:7]

    def view_of(ls, iv):
        s = summarize(ls)
        s["income"] = round(sum(v["amount"] for v in iv), 2)
        s["net"] = round(s["income"] - s["total"], 2)
        if not float(p["params"].get("quote") or 0):     # 客户报价没填：不套结算公式，直接按 项目收入 − 项目支出
            pf = dict(simple=True, income=s["income"], total=s["total"], profit=s["net"],
                      rate=round(s["net"] / s["income"], 4) if s["income"] else 0,
                      tax=0, income_tax=0, reimb_fee=0, rebate=0, mid_fee=0)
        else:
            pf = profit(p["params"], s["total"])
        return s, pf

    s, pf = view_of(lines, inc)
    months = sorted({l["month"] for l in lines if l["sec"] != "备用金" or l["month"]} | {v["month"] for v in inc})
    by_month = {}
    if months:
        for m in months:
            ms, mp = view_of([l for l in lines if l["month"] == m], [v for v in inc if v["month"] == m])
            by_month[m or "未标日期"] = dict(summary=ms, profit=mp)
    with store.db() as c:
        segs = {r["month"]: r["name"] for r in c.execute("select month,name from segs where project_id=?", (pid,))}
        dset = {r["month"]: dict(rate=r["rate"], amount=r["amount"], settle=r["settle"]) for r in c.execute("select * from div_set where project_id=?", (pid,))}
        drec = [row(r) for r in c.execute("select * from divs where project_id=? and coalesce(uid,'')='' order by date, id", (pid,))]
        oinv = [dict(row(r), has_file=bool(r["path"])) for r in c.execute("select * from out_inv where project_id=? order by date, id", (pid,))]
        for o in oinv:                         # 文件和成本行一样存在 files 表里，line_id = -发票记录 id
            o["files"] = [dict(id=f["id"], kind=f["kind"], name=f["name"], w=f["w"], h=f["h"], orig=bool(f["orig"]))
                          for f in c.execute("select * from files where line_id=? order by id", (-o["id"],))]
    for o in oinv:
        o.pop("path", None)
    # 分红到账以账单为准：归成「工作·项目分红」的收入就是到账，「分红转出」的支出从里面扣；老版本手填、账单里没有的到账记录照旧算
    try:
        drec += HOOKS["project_div"](p["name"]) if HOOKS.get("project_div") else []
    except Exception as e:
        store.log_err("读分红流水·" + p["name"], e)
    drec.sort(key=lambda d: d["date"] or "")
    # 和公司的往来（备用金 / 垫付 / 报销 / 项目款转出）
    funds, passes = None, []
    try:
        if HOOKS.get("project_funds"):
            funds = next((f for f in HOOKS["project_funds"](ezb_transactions(), True) if f["name"] == p["name"]), None)
        passes = HOOKS["project_pass"](p["name"]) if HOOKS.get("project_pass") else []
    except Exception as e:
        store.log_err("算公司往来·" + p["name"], e)
    for k, v in by_month.items():
        v["name"] = segs.get(k, "")
    # ---- 我的分红：应得 = 利润 × 分红比例（某个月单独填了比例/金额就用那个月的）；到账另记，和应得分开
    base = dset.get("", {})
    for d in drec:
        d["month"] = (d["date"] or "")[:7]

    def div_of(key, prof, recs):
        st = dset.get(key, {}) if key else base
        rate = st.get("rate") if st.get("rate") is not None else (base.get("rate") if key else None)
        auto = round(max(prof or 0, 0) * (rate or 0) / 100, 2)
        manual = st.get("amount")
        got = round(sum(r["amount"] for r in recs if not r.get("fee")), 2)      # 实际到账：到账 − 分红转出（不是我的那部分）
        fee = round(-sum(r["amount"] for r in recs if r.get("fee")), 2)          # 我从自己分红里付出去的提成
        return dict(rate=rate, own_rate=st.get("rate"), manual=manual, auto=auto, profit=round(prof or 0, 2),
                    due=round(manual if manual is not None else auto, 2), got=got, fee=fee, net=round(got - fee, 2), records=recs,
                    settle=round(st.get("settle") or 0, 2))

    for k, v in by_month.items():
        m = "" if k == "未标日期" else k
        v["div"] = div_of(k, v["profit"].get("profit", 0), [d for d in drec if d["month"] == m])
    dv = div_of("", pf.get("profit", 0), drec)
    own = [k for k in by_month if (k if k != "未标日期" else "未标日期") in dset]
    if base.get("amount") is None and len(by_month) > 1 and own:   # 有月份单独填了比例/金额：整个项目的应得 = 各月应得相加
        dv["auto"] = round(sum(v["div"]["due"] for v in by_month.values()), 2)
        dv["due"] = dv["auto"]
        dv["by_month_sum"] = True
    for x in [dv] + [v["div"] for v in by_month.values()]:
        x["gap"] = round(x["due"] - x["got"] - (x.get("settle") or 0), 2)     # 算结清的差额（手续费等）不再算「没到账」
    rb = HOOKS["reimbs"](pid) if HOOKS.get("reimbs") else []
    # 回款进度：应收 = 项目金额（没填就用客户报价）；已开票 = 开给甲方的发票合计
    target = float(p["params"].get("contract") or 0) or float(p["params"].get("quote") or 0)
    billed = round(sum(o["amount"] for o in oinv if o["status"] != "待开" and (o.get("hop") or "h1") == "h1"), 2)   # 只算开给甲方的那段
    recv = dict(target=round(target, 2), got=s["income"], gap=round(target - s["income"], 2) if target else 0, billed=billed,
                unbilled=round(target - billed, 2) if target else 0)
    return dict(project=p, lines=lines, hold=hold, summary=s, profit=pf, income=inc, by_month=by_month, div=dv, reimbs=rb,
                funds=funds, passes=passes, out_inv=oinv, recv=recv, chain=money_chain(p, pf, s.get("total", 0), drec, oinv), ver=data_ver())


# ---------------------------------------------------------------- 开给甲方的发票（项目收入这边）
class OutInv(BaseModel):
    date: str = ""
    amount: float = 0
    no: str = ""
    title: str = ""
    status: str = "已开"
    note: str = ""
    issuer: str = ""        # 开票方（谁开的）
    hop: str = "h1"         # 对应哪一段转款：h1=甲方那段，h2=中间方 → 执行方


def _out_inv_check(b):
    if b.status not in ("待开", "已开", "已回款"):
        raise HTTPException(400, "状态只能是 待开 / 已开 / 已回款")
    if not b.amount or b.amount <= 0:
        raise HTTPException(400, "请填开票金额")
    return (b.date[:10], round(b.amount, 2), b.no.strip()[:60], b.title.strip()[:80], b.status, b.note.strip()[:200],
            b.issuer.strip()[:80], b.hop if b.hop in ("h1", "h2", "last") else "h1")


@app.post("/api/projects/{pid}/out-inv")
def add_out_inv(pid: int, b: OutInv):
    vals = _out_inv_check(b)
    with store.db() as c:
        if not c.execute("select 1 from projects where id=?", (pid,)).fetchone():
            raise HTTPException(404, "项目不存在")
        cur = c.execute("insert into out_inv(project_id,date,amount,no,title,status,note,issuer,hop) values(?,?,?,?,?,?,?,?,?)", (pid,) + vals)
        new_id = cur.lastrowid
    return dict(project_detail(pid), new_id=new_id)


def _out_inv_row(oid):
    with store.db() as c:
        r = c.execute("select * from out_inv where id=?", (oid,)).fetchone()
    if not r:
        raise HTTPException(404, "没有这张发票记录")
    return r


@app.put("/api/out-inv/{oid}")
def edit_out_inv(oid: int, b: OutInv):
    r = _out_inv_row(oid)
    vals = _out_inv_check(b)
    with store.db() as c:
        c.execute("update out_inv set date=?,amount=?,no=?,title=?,status=?,note=?,issuer=?,hop=? where id=?", vals + (oid,))
    return project_detail(r["project_id"])


def _out_inv_rm_file(r):
    if r["path"]:
        store.safe_rm(r["path"])


@app.delete("/api/out-inv/{oid}")
def del_out_inv(oid: int):
    r = _out_inv_row(oid)
    _out_inv_rm_file(r)
    with store.db() as c:
        _drop_files(c, -oid)
        c.execute("delete from out_inv where id=?", (oid,))
    return project_detail(r["project_id"])


@app.post("/api/out-inv/{oid}/file")
async def out_inv_upload(oid: int, file: UploadFile = File(...)):
    """发票文件（PDF / 图片 / OFD）：原样存下，一张记录一个文件，再传就替换。发票号、开票日期没填的，从发票里读出来补上。"""
    r = _out_inv_row(oid)
    data, ext = _out_inv_data(await file.read(), file.filename)
    info = _inv_read(file.filename, data)
    _out_inv_save_file(r, data, ext, file.filename)
    with store.db() as c:
        if info.get("inv_no") and not r["no"]:
            c.execute("update out_inv set no=? where id=?", (info["inv_no"][:60], oid))
    d_ = project_detail(r["project_id"])
    if info.get("amount") and abs(info["amount"] - (r["amount"] or 0)) > 0.01:
        d_["warn"] = f"发票上读到的金额是 {info['amount']:,.2f}，和这条记的 {r['amount']:,.2f} 不一样，看一下哪个对"
    return d_


def _out_inv_data(data, name):
    if not data:
        raise HTTPException(400, "文件是空的")
    if len(data) > 30 * 1024 * 1024:
        raise HTTPException(400, "文件太大了（最多 30MB）")
    ext = os.path.splitext(name or "")[1].lower()
    if ext not in (".pdf", ".png", ".jpg", ".jpeg", ".webp", ".heic", ".ofd", ".xml", ".zip"):
        raise HTTPException(400, "只能传 PDF / 图片 / OFD / XML / ZIP")
    return data, ext


def _inv_read(name, data):
    """读发票：PDF 读文字，图片用系统自带的文字识别；读不出来就返回空的，不影响保存。"""
    try:
        import invoices as _iv
        kind, info, _t = _iv.sniff(name or "", data)
        return info if kind == "invoice" else {}
    except Exception as e:
        store.log_err("读开出去的发票", e)
        return {}


@app.post("/api/out-inv/parse")
async def out_inv_parse(file: UploadFile = File(...)):
    """只读不存：记发票时先选文件，金额 / 发票号 / 日期自动填进表单。"""
    data, _ext = _out_inv_data(await file.read(), file.filename)
    i = _inv_read(file.filename, data)
    return dict(amount=i.get("amount") or 0, no=i.get("inv_no") or "", date=i.get("inv_date") or "", buyer=i.get("buyer") or "", seller=i.get("seller") or "")


@app.post("/api/projects/{pid}/out-inv/from-file")
async def out_inv_from_file(pid: int, file: UploadFile = File(...), hop: str = Form("h1"), issuer: str = Form(""), title: str = Form(""), amount: float = Form(0)):
    """在「钱怎么走的」某一段直接传发票：读出金额 / 发票号 / 日期，记一张已开的发票并存下文件。读不出金额就用这段转款的金额。"""
    data, ext = _out_inv_data(await file.read(), file.filename)
    i = _inv_read(file.filename, data)
    amt = round(float(i.get("amount") or 0) or float(amount or 0), 2)
    if amt <= 0:
        raise HTTPException(400, "发票上没读到金额，请用「＋ 记一张发票」手动填")
    with store.db() as c:
        if not c.execute("select 1 from projects where id=?", (pid,)).fetchone():
            raise HTTPException(404, "项目不存在")
        cur = c.execute("insert into out_inv(project_id,date,amount,no,title,status,note,issuer,hop) values(?,?,?,?,?,?,?,?,?)",
                        (pid, (i.get("inv_date") or date.today().isoformat())[:10], amt, (i.get("inv_no") or "")[:60], title.strip()[:80], "已开", "",
                         issuer.strip()[:80], hop if hop in ("h1", "h2", "last") else "h1"))
        oid = cur.lastrowid
        for nm, dd in (INV["expand"](file.filename or "发票.pdf", data) or [(file.filename or "发票.pdf", data)]):
            INV["save_to_line"](c, -oid, "invoice", nm, dd)
    d_ = project_detail(pid)
    d_["read"] = dict(amount=bool(i.get("amount")), no=bool(i.get("inv_no")), date=bool(i.get("inv_date")))
    return d_


class FromInbox(BaseModel):
    iid: int
    hop: str = "h1"
    issuer: str = ""
    title: str = ""


@app.post("/api/projects/{pid}/out-inv/from-inbox")
def out_inv_from_inbox(pid: int, b: FromInbox):
    """从邮箱 / 发票夹里选一张，直接记成这段转款的发票：金额、发票号、日期用发票夹读出来的，文件搬过来。"""
    with store.db() as c:
        r = c.execute("select * from inv where id=?", (b.iid,)).fetchone()
        if not r:
            raise HTTPException(404, "发票夹里没有这张")
        if r["status"] == "used":
            raise HTTPException(400, "这张已经放到别处了")
        if not (r["amount"] or 0) > 0:
            raise HTTPException(400, "这张没读到金额，请先在发票夹里填上金额")
        cur = c.execute("insert into out_inv(project_id,date,amount,no,title,status,note,issuer,hop) values(?,?,?,?,?,?,?,?,?)",
                        (pid, (r["inv_date"] or date.today().isoformat())[:10], round(r["amount"], 2), (r["inv_no"] or "")[:60], b.title.strip()[:80],
                         "已开", "", b.issuer.strip()[:80], b.hop if b.hop in ("h1", "h2", "last") else "h1"))
        oid = cur.lastrowid
        INV["save_to_line"](c, -oid, "invoice", r["name"], open(r["path"], "rb").read(), r["inv_no"] or "")
        c.execute("update inv set status='used', line_id=? where id=?", (-oid, b.iid))
    return project_detail(pid)


def _out_inv_save_file(r, data, ext, name):
    oid = r["id"]
    d = os.path.join(store.FILES, "outinv")
    os.makedirs(d, exist_ok=True)
    path = os.path.join(d, f"{oid}_{uuid.uuid4().hex[:10]}{ext}")
    with open(path, "wb") as fh:
        fh.write(data)
    _out_inv_rm_file(r)
    with store.db() as c:
        c.execute("update out_inv set path=?, fname=? where id=?", (path, (name or "发票" + ext)[:120], oid))


@app.get("/api/out-inv/{oid}/file")
def out_inv_file(oid: int):
    r = _out_inv_row(oid)
    if not r["path"] or not os.path.exists(r["path"]):
        raise HTTPException(404, "这张发票还没传文件")
    return FileResponse(r["path"], filename=r["fname"] or os.path.basename(r["path"]))


# ---------------------------------------------------------------- 我的分红
class DivSet(BaseModel):
    month: str = ""                 # '' = 整个项目；'2026-09' = 只改这个月
    rate: Optional[float] = None    # 分红比例 %，不填 = 跟整个项目的比例
    amount: Optional[float] = None  # 直接填分红金额（覆盖自动计算）；不填 = 按 利润 × 比例 自动算


@app.put("/api/projects/{pid}/div")
def set_div(pid: int, b: DivSet):
    m = "" if b.month in ("", "未标日期") else b.month
    if b.rate is not None and not (0 <= b.rate <= 100):
        raise HTTPException(400, "分红比例要在 0 到 100 之间")
    with store.db() as c:
        old = c.execute("select settle from div_set where project_id=? and month=?", (pid, m)).fetchone()
        settle = old["settle"] if old else None
        if b.rate is None and b.amount is None and not settle:
            c.execute("delete from div_set where project_id=? and month=?", (pid, m))
        else:
            c.execute("insert or replace into div_set(project_id,month,rate,amount,settle) values(?,?,?,?,?)", (pid, m, b.rate, b.amount, settle))
    return project_detail(pid)


class DivSettle(BaseModel):
    month: str = ""
    settle: Optional[float] = None   # 没到账、不用再等的差额（转账手续费等）；None = 撤销


@app.put("/api/projects/{pid}/div-settle")
def set_div_settle(pid: int, b: DivSettle):
    m = "" if b.month in ("", "未标日期") else b.month
    s = round(b.settle, 2) if b.settle else None
    with store.db() as c:
        old = c.execute("select rate,amount from div_set where project_id=? and month=?", (pid, m)).fetchone()
        if old:
            c.execute("update div_set set settle=? where project_id=? and month=?", (s, pid, m))
            if s is None and old["rate"] is None and old["amount"] is None:
                c.execute("delete from div_set where project_id=? and month=?", (pid, m))
        elif s is not None:
            c.execute("insert into div_set(project_id,month,rate,amount,settle) values(?,?,?,?,?)", (pid, m, None, None, s))
    return project_detail(pid)


class DivGot(BaseModel):
    date: str
    amount: float
    note: str = ""


@app.post("/api/projects/{pid}/div-got")
def add_div_got(pid: int, b: DivGot):
    if not b.amount:
        raise HTTPException(400, "请填到账金额")
    with store.db() as c:
        c.execute("insert into divs(project_id,date,amount,note) values(?,?,?,?)", (pid, b.date[:10], round(b.amount, 2), b.note.strip()))
    return project_detail(pid)


@app.delete("/api/div-got/{did}")
def del_div_got(did: int):
    with store.db() as c:
        r = c.execute("select project_id from divs where id=?", (did,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这条到账记录")
        c.execute("delete from divs where id=?", (did,))
    return project_detail(r["project_id"])


# ---------------------------------------------------------------- 设置
class Cfg(BaseModel):
    ezb_url: str
    ezb_user: str
    ezb_pass: str = ""


@app.get("/api/config")
def get_config():
    c = store.load_config()
    return dict(ezb_url=c["ezb_url"], ezb_user=c["ezb_user"], has_pass=bool(c["ezb_pass"]))


class MeIn(BaseModel):
    my_name: str = ""


class HolderIn(BaseModel):
    name: str = ""


@app.put("/api/config/cash-holder")
def put_cash_holder(b: HolderIn):
    """新建项目时默认的备用金经手人（比如小助理）。"""
    cfg = store.load_config()
    cfg["cash_holder"] = b.name.strip()[:20]
    store.save_config(cfg)
    return dict(ok=True, name=cfg["cash_holder"])


@app.get("/api/config/me")
def get_me():
    return dict(my_name=store.load_config().get("my_name", ""), cash_holder=store.load_config().get("cash_holder", ""), names=store.names())


@app.put("/api/config/me")
def put_me(b: MeIn):
    """成本单里打车行「工艺说明」开头写的乘车人（如「小王 家-公司」）"""
    cfg = store.load_config()
    cfg["my_name"] = b.my_name.strip()[:20]
    store.save_config(cfg)
    if HOOKS.get("cab_refresh"):
        HOOKS["cab_refresh"]()
    return dict(ok=True, my_name=cfg["my_name"])


@app.put("/api/config")
def put_config(c: Cfg):
    old = store.load_config()
    store.save_config(dict(old, ezb_url=c.ezb_url.strip(), ezb_user=c.ezb_user.strip(), ezb_pass=c.ezb_pass or old["ezb_pass"]))
    _api["key"] = None
    invalidate()
    try:
        ezb()
        return dict(ok=True, msg="已连上CD的记账本")
    except HTTPException as e:
        return dict(ok=False, msg=e.detail)


# ---------------------------------------------------------------- 项目
class ProjectIn(BaseModel):
    name: str
    leader: str = ""
    time_text: str = ""
    location: str = ""
    customer: str = ""
    source: str = ""
    start: str = ""
    end: str = ""
    quote: Optional[float] = None       # 客户报价（给甲方报的总价）
    contract: Optional[float] = None    # 项目金额（合同 / 最后结算的金额）


def _money_params(p):
    out = {}
    for k in ("quote", "contract"):
        v = getattr(p, k)
        if v is not None:
            if v != v or v < 0 or v > 1e12:
                raise HTTPException(400, f"「{store.param_labels().get(k, k)}」要填不小于 0 的数字")
            out[k] = round(float(v), 2)
    return out


_lp_lock = threading.Lock()
_lp_warm = {"res": None, "at": 0, "w": -1, "rows": None}     # 启动时后台先算好的项目列表（只给页面第一次用）
_writes = {"n": 0}                                          # 有过多少次保存类请求（有保存就不用先算好的）


@app.get("/api/projects")
def list_projects():
    with _lp_lock:          # 同时来的请求排队，不会同时同步成本单
        w = _lp_warm
        if w["res"] is not None:
            res, fresh = w["res"], (time.time() - w["at"] < 8 and w["w"] == _writes["n"] and w["rows"] is _tx_cache["rows"])
            w["res"] = None
            if fresh:
                return res
        return _list_projects()


def _list_projects():
    out = []
    with store.db() as c:
        ps = [row(r) for r in c.execute("select * from projects order by id desc")]
    for p in ps:
        d = project_detail(p["id"])
        nfiles = sum(len(l["files"]) for l in d["lines"])
        out.append(dict(**{k: v for k, v in p.items() if k != 'params'}, mode=d['project']['params']['mode'], mode_name=d['project']['mode_name'], summary=d["summary"], profit=d["profit"], n_lines=len(d["lines"]), n_files=nfiles,
                        div={k: d["div"].get(k, 0) for k in ("rate", "due", "got", "gap", "fee", "net")}))
    return out


def _check_project_name(name, pid=0):
    """项目名：不能空、不能和别的项目重名、不能带记账本备注里用来分隔的符号。"""
    name = (name or "").strip()
    if not name:
        raise HTTPException(400, "请填项目名")
    if len(name) > 60:
        raise HTTPException(400, "项目名太长了（最多 60 个字）")
    bad = [ch for ch in "【】｜〔〕;" if ch in name]
    if bad:
        raise HTTPException(400, f"项目名里不能有「{bad[0]}」这个符号（它在账单备注里有特殊用途），换个写法")
    with store.db() as c:
        if c.execute("select 1 from projects where name=? and id<>?", (name, pid)).fetchone():
            raise HTTPException(400, f"已经有一个叫「{name}」的项目了，换个名字")
    return name


@app.post("/api/projects")
def create_project(p: ProjectIn):
    s, e = parse_dates(p.time_text)
    name = _check_project_name(p.name)
    mp = _money_params(p)
    with store.db() as c:
        md = store.detect_mode(dict(name=name, customer=p.customer, source=p.source))
        cur = c.execute("insert into projects(name,leader,time_text,location,customer,source,start,end,params) values(?,?,?,?,?,?,?,?,?)",
                        (name, p.leader, p.time_text, p.location, p.customer, p.source, p.start or s, p.end or e, json.dumps({**store.mode_defaults(md), **mp, **({"cash_holder": store.load_config().get("cash_holder", "")} if store.load_config().get("cash_holder") else {})})))
        pid = cur.lastrowid
    sync_projects_json()
    return project_detail(pid)


@app.put("/api/projects/{pid}")
def update_project(pid: int, p: ProjectIn):
    s, e = parse_dates(p.time_text)
    name = _check_project_name(p.name, pid)
    mp = _money_params(p)
    with store.db() as c:
        r = c.execute("select name from projects where id=?", (pid,)).fetchone()
    if not r:
        raise HTTPException(404, "项目不存在")
    old, moved = r["name"], None
    if old != name:                       # 改名：先把记账本里的分类、标签、账单备注一起改，成功了再改项目台（中途失败不会两边对不上）
        try:
            moved = HOOKS["rename_project"](old, name)
        except HTTPException:
            raise
        except Exception as ex:
            store.log_err("项目改名", ex)
            raise HTTPException(400, f"记账本那边没改成，项目名先不动：{ex}")
    with store.db() as c:
        c.execute("update projects set name=?,leader=?,time_text=?,location=?,customer=?,source=?,start=?,end=? where id=?",
                  (name, p.leader, p.time_text, p.location, p.customer, p.source, p.start or s, p.end or e, pid))
        if mp:
            old_p = json.loads(c.execute("select params from projects where id=?", (pid,)).fetchone()["params"] or "{}")
            c.execute("update projects set params=? where id=?", (json.dumps({**old_p, **mp}), pid))
    sync_projects_json()
    invalidate()
    d = project_detail(pid)
    if moved is not None:
        d["renamed"] = dict(old=old, new=name, **moved)
    return d


class ModeIn(BaseModel):
    mode: str


@app.put("/api/projects/{pid}/mode")
def set_mode(pid: int, m: ModeIn):
    """切换结算逻辑：套用该类型的默认点数/税率，保留客户报价等已填金额。"""
    if m.mode not in store.MODE_DEFAULTS:
        raise HTTPException(400, "类型不对")
    with store.db() as c:
        r = c.execute("select params from projects where id=?", (pid,)).fetchone()
        old = json.loads(r["params"] or "{}") if r else {}
        keep = {k: old[k] for k in ("quote", "contract", "adv_daifu", "ch_daifu", "reimb", "labels", "chain", "cash_holder", "custom") if k in old}
        c.execute("update projects set params=? where id=?", (json.dumps({**store.mode_defaults(m.mode), **keep}), pid))
    return project_detail(pid)


@app.put("/api/projects/{pid}/params")
def update_params(pid: int, params: dict):
    clean = {}
    for k, v in (params or {}).items():          # 只收认识的参数；数字必须是数字，比例在 0~100% 之间，金额不能是负数
        if k == "mode":
            if v not in store.MODE_DEFAULTS:
                raise HTTPException(400, "结算类型不对")
            clean[k] = v
            continue
        if k == "custom":                        # 自定义公式：[{name, op(+/-), kind, v}]
            if isinstance(v, list):
                items = []
                for it in v[:30]:
                    if not isinstance(it, dict) or it.get("kind") not in CUSTOM_KINDS:
                        continue
                    try:
                        x = float(it.get("v") or 0)
                    except (TypeError, ValueError):
                        raise HTTPException(400, f"「{it.get('name') or '某一项'}」要填数字")
                    if it["kind"].startswith("pct") and not 0 <= x <= 1:
                        raise HTTPException(400, f"「{it.get('name') or '某一项'}」的百分比要在 0%～100% 之间")
                    if x < 0:
                        raise HTTPException(400, f"「{it.get('name') or '某一项'}」不能是负数，要加回来的请选「加」")
                    items.append(dict(name=str(it.get("name") or "").strip()[:20], op="+" if it.get("op") == "+" else "-", kind=it["kind"], v=x))
                clean[k] = items
            continue
        if k == "cash_holder":                   # 备用金在谁手里（空 = 在我自己手里）
            clean[k] = str(v or "").strip()[:20]
            continue
        if k == "chain":                         # 钱怎么走的：甲方 / 中间方 / 执行方 叫什么
            if isinstance(v, dict):
                ch = {a: str(v.get(a) or "").strip()[:300 if a == "note" else 30] for a in CHAIN_KEYS if str(v.get(a) or "").strip()}
                if ch:
                    clean[k] = ch
            continue
        if k == "labels":                        # 你给参数改的名字（每个项目可以不一样）：{参数: 新名字}
            if isinstance(v, dict):
                lb = {a: str(b).strip()[:20] for a, b in v.items() if (a in store.PARAM_KEYS or a in ("o_income", "o_profit")) and str(b or "").strip() and str(b).strip() != store.param_labels().get(a)}
                if lb:
                    clean[k] = lb
            continue
        if k not in store.PARAM_KEYS:
            continue
        try:
            x = float(v if v not in ("", None) else 0)
        except (TypeError, ValueError):
            raise HTTPException(400, f"「{store.param_labels().get(k, k)}」要填数字")
        if x != x or x in (float("inf"), float("-inf")):
            raise HTTPException(400, f"「{store.param_labels().get(k, k)}」要填数字")
        if k.startswith("r_") and not 0 <= x <= 1:
            raise HTTPException(400, f"「{store.param_labels().get(k, k)}」是比例，应在 0%～100% 之间")
        if not k.startswith("r_") and x < 0:
            raise HTTPException(400, f"「{store.param_labels().get(k, k)}」不能是负数")
        clean[k] = x
    params = clean
    with store.db() as c:
        if not c.execute("select 1 from projects where id=?", (pid,)).fetchone():
            raise HTTPException(404, "项目不存在")
        c.execute("update projects set params=? where id=?", (json.dumps(params), pid))
    return project_detail(pid)


@app.delete("/api/projects/{pid}")
def delete_project(pid: int, detach: int = 0):
    """删项目：成本行、发票图、分期名、分红、报销单一起清干净。记账本里的账不删；
    detach=1 时把这些账改成「无项目」（否则它们还带着这个项目名）。"""
    with store.db() as c:
        r = c.execute("select name from projects where id=?", (pid,)).fetchone()
    if not r:
        raise HTTPException(404, "项目不存在")
    name, moved = r["name"], 0
    if detach:
        try:
            moved = HOOKS["detach_project"](name)
        except HTTPException:
            raise
        except Exception as ex:
            store.log_err("删项目·账单改无项目", ex)
            raise HTTPException(400, f"记账本那边没改成，项目先没删：{ex}")
    with store.db() as c:
        ids = [r["id"] for r in c.execute("select id from lines where project_id=?", (pid,))]
        for lid in ids:
            _drop_files(c, lid)
        c.execute("delete from lines where project_id=?", (pid,))
        for o in c.execute("select id, path from out_inv where project_id=?", (pid,)).fetchall():
            _out_inv_rm_file(o)
            _drop_files(c, -o["id"])
        for tb in ("segs", "div_set", "divs", "out_inv"):
            c.execute(f"delete from {tb} where project_id=?", (pid,))
        for rb in c.execute("select path from reimbs where project_id=?", (pid,)).fetchall():
            try:
                os.remove(rb["path"])
            except (OSError, TypeError):
                pass
        c.execute("delete from reimbs where project_id=?", (pid,))
        c.execute("delete from projects where id=?", (pid,))
    sync_projects_json()
    try:
        _drop_project_cats(name)
    except Exception as e:
        store.log_err("删项目·清记账本分类", e)
    invalidate()
    return dict(ok=True, moved=moved)


def _drop_project_cats(name):
    """删项目后，记账本里「项目·项目名」这套分类如果一笔账都没有了，就一起删掉，免得还出现在选分类的下拉里。
    还有账的（没选「改成无项目」时）留着不动。返回删掉的个数。"""
    from api_import import _flat_categories, CAT_LOCK
    with CAT_LOCK:
        api = ezb()
        flat = _flat_categories(api)
        tops = [c_ for c_ in flat if str(c_.get("parentId", "0")) == "0" and c_["name"] == "项目·" + name]
        if not tops:
            return 0
        ids = {str(c_["id"]) for c_ in tops}
        kids = [c_ for c_ in flat if str(c_.get("parentId", "0")) in ids]
        used = {str(t["categoryId"]) for t in ezb_transactions(force=True)}
        if used & (ids | {str(k["id"]) for k in kids}):
            return 0
        gone = 0
        for c_ in kids + tops:
            try:
                api.call("POST", "/api/v1/transaction/categories/delete.json", {"id": str(c_["id"])})
                gone += 1
            except Exception as e:
                store.log_err("删项目·清记账本分类", e)
        invalidate()
        return gone


@app.post("/api/admin/drop-project-cats")
def drop_project_cats_api(b: dict):
    """手动清掉已删除项目留在记账本里的空分类（项目已不存在、分类里也没账的才清）。"""
    with store.db() as c:
        alive = {r["name"] for r in c.execute("select name from projects")}
    out = {}
    for n in (b or {}).get("names", []):
        if n in alive:
            out[n] = "项目还在，不清"
            continue
        out[n] = _drop_project_cats(n)
    return out


@app.get("/api/projects/{pid}/tx-count")
def project_tx_count(pid: int):
    """这个项目在记账本里有几笔账（删项目前给你看一眼）。"""
    with store.db() as c:
        r = c.execute("select name from projects where id=?", (pid,)).fetchone()
    if not r:
        raise HTTPException(404, "项目不存在")
    try:
        return dict(n=sum(1 for t in ezb_transactions() if _project_of(t) == r["name"]))
    except Exception:
        return dict(n=None)


@app.get("/api/projects/{pid}")
def get_project(pid: int):
    return project_detail(pid)


# ---------------------------------------------------------------- 成本行
class LineIn(BaseModel):
    sec: str
    cat: str = ""
    name: str = ""
    spec: str = ""
    craft: str = ""
    qty: float = 1
    unit: str = "项"
    price: float = 0
    vendor: str = ""
    pay: str = "未付"
    date: str = ""
    who: str = ""
    inv_note: str = ""
    memo: str = ""


@app.post("/api/projects/{pid}/lines")
def add_line(pid: int, l: LineIn):
    if l.sec not in store.SECTIONS:
        raise HTTPException(400, "板块不对")
    with store.db() as c:
        seq = (c.execute("select coalesce(max(seq),0)+1 from lines where project_id=? and sec=?", (pid, l.sec)).fetchone()[0])
        c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,date,who,inv_note,memo) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                  (pid, l.sec, l.cat, seq, l.name, l.spec, l.craft, l.qty, l.unit, l.price, l.vendor, l.pay, l.date, l.who, l.inv_note, l.memo))
    return project_detail(pid)


def _sync_line_to_ledger(lid):
    """成本行是『记入记账本』的备用金支出时，改了金额/名称，记账本里那一笔同步改。"""
    try:
        with store.db() as c:
            l = row(c.execute("select * from lines where id=?", (lid,)).fetchone())
            p = row(c.execute("select * from projects where id=?", (l["project_id"],)).fetchone()) if l else None
        if not l or not p or not l["uid"].startswith("成本单:"):
            return
        if l["pay"] != "备用金垫付":                       # 不再是备用金垫付：从记账本撤掉
            _delete_ledger_tx(l["uid"])
            with store.db() as c:
                c.execute("update lines set uid='' where id=?", (lid,))
            return
        when_day = p["start"] or date.today().isoformat()
        desc = " | ".join(x for x in (l["name"], l["spec"], l["vendor"][:60]) if x)
        r_ = _row_for(None, p, l, l["uid"], "备用金", f"{when_day} 12:00:00", line_amount(l), "支出", desc)
        push_rows(ezb(), [r_], log=lambda *_: None)
        invalidate()
    except Exception as e:
        store.log_err("备用金支出同步到记账本", e)


def _delete_ledger_tx(uid):
    for t in ezb_transactions(force=True):
        if rid(t.get("comment")) == uid:
            ezb().call("POST", "/api/v1/transactions/delete.json", {"id": str(t["id"])})
    invalidate()


@app.put("/api/lines/{lid}")
def update_line(lid: int, l: LineIn):
    with store.db() as c:
        r = c.execute("select project_id from lines where id=?", (lid,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这一行")
        c.execute("update lines set sec=?,cat=?,name=?,spec=?,craft=?,qty=?,unit=?,price=?,vendor=?,pay=?,date=?,who=?,inv_note=?,memo=? where id=?",
                  (l.sec, l.cat, l.name, l.spec, l.craft, l.qty, l.unit, l.price, l.vendor, l.pay, l.date, l.who, l.inv_note, l.memo, lid))
    _sync_line_to_ledger(lid)
    return project_detail(r["project_id"])


def _drop_files(c, lid):
    fs = c.execute("select * from files where line_id=?", (lid,)).fetchall()
    for f in fs:
        for p_ in (f["path"], f["path"] + ".t.jpg"):
            store.safe_rm(p_)
    c.execute("delete from files where line_id=?", (lid,))
    for o in {f["orig"] for f in fs if f["orig"]}:
        if not c.execute("select 1 from files where orig=?", (o,)).fetchone():
            store.safe_rm(o)
    c.execute("update inv set status='new', line_id=0 where line_id=?", (lid,))


@app.delete("/api/lines/{lid}")
def delete_line(lid: int):
    with store.db() as c:
        r = c.execute("select project_id from lines where id=?", (lid,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这一行")
        _drop_files(c, lid)
        lr = c.execute("select uid,auto from lines where id=?", (lid,)).fetchone()
        uid = lr["uid"] if lr else ""
        c.execute("delete from lines where id=?", (lid,))
    if lr and lr["auto"] and uid and HOOKS.get("cost_ignore"):
        HOOKS["cost_ignore"](uid)          # 自动同步来的行被手动删掉：以后不再自动加回来
    if uid.startswith("成本单:"):
        try:
            _delete_ledger_tx(uid)
        except Exception as e:
            store.log_err("删成本行时同步删记账本那笔", e)
    return project_detail(r["project_id"])


# ---------------------------------------------------------------- 发票/支付截图
def _save_image_bytes(lid, kind, name, data, c):
    from PIL import Image
    import io
    ext = os.path.splitext(name)[1].lower()
    saved = []
    imgs = []
    if ext == ".pdf":
        import fitz
        doc = fitz.open(stream=data, filetype="pdf")
        for i, page in enumerate(doc):
            pix = page.get_pixmap(dpi=300)
            imgs.append((f"{os.path.splitext(name)[0]}-{i + 1}.png", pix.tobytes("png")))
    else:
        imgs.append((name, data))
    pdir = os.path.join(store.FILES, str(lid))
    os.makedirs(pdir, exist_ok=True)
    for nm, b in imgs:
        try:
            im = Image.open(io.BytesIO(b))
            w, h = im.size
        except Exception:
            raise HTTPException(400, f"{nm} 不是图片或PDF")
        e = os.path.splitext(nm)[1].lower() or ".png"
        if e not in (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp"):
            e = ".png"
            buf = io.BytesIO()
            im.convert("RGB").save(buf, "PNG")
            b = buf.getvalue()
        path = os.path.join(pdir, f"{uuid.uuid4().hex[:10]}{e}")
        open(path, "wb").write(b)
        cur = c.execute("insert into files(line_id,kind,path,name,w,h) values(?,?,?,?,?,?)", (lid, kind, path, nm, w, h))
        saved.append(cur.lastrowid)
    return saved


@app.post("/api/lines/{lid}/files")
async def upload_files(lid: int, kind: str = Form("invoice"), files: List[UploadFile] = File(...)):
    """成本行上传发票/支付截图：图片（截图、照片、HEIC）或 PDF（原件保留，每页转图）都行，zip 会自动拆开。"""
    if kind not in ("invoice", "pay", "trip"):
        raise HTTPException(400, "类型只能是 发票 / 支付截图 / 行程单")
    # lid 是负数 = 「开出去的发票」那一条（-发票记录 id），文件和成本行的发票存在一起、同样处理
    oinv, first = lid < 0, None
    with store.db() as c:
        r = c.execute("select project_id, no, amount from out_inv where id=?", (-lid,)).fetchone() if oinv else \
            c.execute("select project_id from lines where id=?", (lid,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这张发票记录" if oinv else "没有这一行")
        moved = 0
        for f in files:
            items = INV["expand"](f.filename or "image.png", await f.read())
            if not items:
                raise HTTPException(400, f"{f.filename} 不是图片或 PDF")
            for nm, data in items:
                k2 = "invoice" if oinv else INV["auto_kind"](kind, nm, data)
                moved += k2 != kind
                INV["save_to_line"](c, lid, k2, nm, data)
                first = first or (nm, data)
    d = project_detail(r["project_id"])
    d["moved"] = moved
    if oinv and first:                       # 发票号没填的从发票上补；金额对不上给个提示
        info = _inv_read(*first)
        if info.get("inv_no") and not r["no"]:
            with store.db() as c:
                c.execute("update out_inv set no=? where id=?", (info["inv_no"][:60], -lid))
            d = project_detail(r["project_id"])
        if info.get("amount") and abs(info["amount"] - (r["amount"] or 0)) > 0.01:
            d["warn"] = f"发票上读到的金额是 {info['amount']:,.2f}，和这条记的 {r['amount']:,.2f} 不一样，看一下哪个对"
    return d


@app.get("/api/files/{fid}")
def get_file(fid: int, thumb: int = 0):
    with store.db() as c:
        f = c.execute("select * from files where id=?", (fid,)).fetchone()
    if not f or not os.path.exists(f["path"]):
        raise HTTPException(404, "文件不存在")
    if thumb:
        from PIL import Image
        tp = f["path"] + ".t.jpg"
        if not os.path.exists(tp):
            with Image.open(f["path"]) as im:
                im = im.convert("RGB")
                im.thumbnail((360, 360))
                im.save(tp, "JPEG", quality=80)
        return FileResponse(tp)
    return FileResponse(f["path"], filename=f["name"])


@app.delete("/api/files/{fid}")
def delete_file(fid: int):
    with store.db() as c:
        f = c.execute("select f.*, coalesce(l.project_id, o.project_id) project_id from files f left join lines l on l.id=f.line_id "
                      "left join out_inv o on o.id=-f.line_id where f.id=?", (fid,)).fetchone()
        if not f or f["project_id"] is None:
            raise HTTPException(404, "文件不存在")
        for p in (f["path"], f["path"] + ".t.jpg"):
            store.safe_rm(p)
        c.execute("delete from files where id=?", (fid,))
        if f["orig"] and not c.execute("select 1 from files where orig=?", (f["orig"],)).fetchone():
            store.safe_rm(f["orig"])
        if f["inv_no"]:
            c.execute("update inv set status='new', line_id=0 where inv_no=? and line_id=?", (f["inv_no"], f["line_id"]))
    return project_detail(f["project_id"])


# ---------------------------------------------------------------- 导入已有成本单
@app.post("/api/projects/import-cost")
async def import_cost(file: UploadFile = File(...), replace: int = Form(0), target: str = Form("")):
    tmp = tempfile.mkdtemp()
    path = os.path.join(tmp, "cost.xlsx")
    open(path, "wb").write(await file.read())
    try:
        info, params, lines, imgs = store.parse_cost_xlsx(path)
    except Exception as e:
        raise HTTPException(400, f"读不懂这个成本单（需要『成本汇总』表）：{e}")
    if target.strip():
        info["name"] = target.strip()  # 导入到指定名字的项目（记账本标签用的就是这个名字）
    if not info["name"]:
        raise HTTPException(400, "成本单里没有项目名称")
    s, e = parse_dates(info["time_text"])
    with store.db() as c:
        ex = c.execute("select id from projects where name=?", (info["name"],)).fetchone()
        if ex and not replace:
            raise HTTPException(409, f"已有项目「{info['name']}」。要覆盖请勾选『覆盖同名项目』。")
        if ex:
            pid = ex["id"]
            for r in c.execute("select id from lines where project_id=?", (pid,)).fetchall():
                _drop_files(c, r["id"])
            c.execute("delete from lines where project_id=?", (pid,))
            c.execute("update projects set leader=?,time_text=?,location=?,customer=?,source=?,start=?,end=?,params=? where id=?",
                      (info["leader"], info["time_text"], info["location"], info["customer"], info["source"], s, e, json.dumps(params), pid))
        else:
            pid = c.execute("insert into projects(name,leader,time_text,location,customer,source,start,end,params) values(?,?,?,?,?,?,?,?,?)",
                            (info["name"], info["leader"], info["time_text"], info["location"], info["customer"], info["source"], s, e, json.dumps(params))).lastrowid
        seqs, n_img = {}, 0
        for l in lines:
            seqs[l["sec"]] = seqs.get(l["sec"], 0) + 1
            lid = c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,date,who,inv_note,memo) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            (pid, l["sec"], l["cat"], seqs[l["sec"]], l["name"], l["spec"], l["craft"], l["qty"], l["unit"], l["price"], l["vendor"], l["pay"], l["date"], l["who"], l.get("inv_note", ""), l.get("memo", ""))).lastrowid
            for kind, key in (("invoice", "_inv"), ("pay", "_pay")):
                if l.get(key) and l[key] in imgs:
                    ext, b = imgs[l[key]]
                    _save_image_bytes(lid, kind, f"{kind}.{ext}", b, c)
                    n_img += 1
    sync_projects_json()
    shutil.rmtree(tmp, ignore_errors=True)
    d = project_detail(pid)
    d["imported"] = dict(lines=len(lines), images=n_img)
    return d


class HoldIn(BaseModel):
    action: str          # keep = 算进成本单；drop = 不算（以后也不再自动加回来）


@app.post("/api/lines/{lid}/hold")
def resolve_hold(lid: int, b: HoldIn):
    """「待核对」的行：算进成本单，或者不算。"""
    with store.db() as c:
        l = c.execute("select * from lines where id=?", (lid,)).fetchone()
        if not l:
            raise HTTPException(404, "这一行不存在")
        if b.action == "keep":
            c.execute("update lines set hold=0 where id=?", (lid,))
        elif b.action == "drop":
            if l["uid"]:
                c.execute("create table if not exists cost_ignore(uid text primary key)")
                c.execute("insert or ignore into cost_ignore(uid) values(?)", (l["uid"],))
            if c.execute("select count(*) from files where line_id=?", (lid,)).fetchone()[0]:
                raise HTTPException(400, "这一行上传过发票/截图，先把图片挪到对应的成本行再点「不算」")
            c.execute("delete from lines where id=?", (lid,))
        else:
            raise HTTPException(400, "action 只能是 keep / drop")
        pid = l["project_id"]
    return project_detail(pid)


@app.post("/api/projects/{pid}/upload-cost")
async def upload_cost_into(pid: int, file: UploadFile = File(...)):
    """在项目里上传之前做好的成本单：
    1) 成本单里的行替换这个项目里手动加的行（从账单自动同步来的行先保留）；
    2) 自动同步来的行和成本单里金额一样的行合并（成本单那行接管这笔账，图片也搬过去），避免重复；
    3) 剩下的行再去记账本里按金额/日期/名称匹配账单，对上的把项目名和用途写回账单。"""
    with store.db() as c:
        p = c.execute("select * from projects where id=?", (pid,)).fetchone()
    if not p:
        raise HTTPException(404, "项目不存在")
    tmp = tempfile.mkdtemp()
    path = os.path.join(tmp, "cost.xlsx")
    open(path, "wb").write(await file.read())
    try:
        info, params, lines, imgs = store.parse_cost_xlsx(path)
    except Exception as e:
        shutil.rmtree(tmp, ignore_errors=True)
        raise HTTPException(400, f"读不懂这个成本单（需要『成本汇总』表）：{e}")
    if not lines:
        raise HTTPException(400, "成本单里没有读到成本行")
    merged = n_img = kept = carried = 0
    with store.db() as c:
        olds = [dict(r) for r in c.execute("select l.*, (select count(*) from files f where f.line_id=l.id) as nf from lines l "
                                           "where project_id=? and auto=0", (pid,))]
        old = dict(json.loads(p["params"] or "{}"))
        if params:
            old.update({k: v for k, v in params.items() if v not in (None, "")})
        upd = dict(leader=p["leader"] or info.get("leader", ""), time_text=p["time_text"] or info.get("time_text", ""),
                   location=p["location"] or info.get("location", ""), customer=p["customer"] or info.get("customer", ""))
        c.execute("update projects set leader=?,time_text=?,location=?,customer=?,params=? where id=?",
                  (upd["leader"], upd["time_text"], upd["location"], upd["customer"], json.dumps(old), pid))
        seqs, new_ids = {}, []
        for l in lines:
            seqs[l["sec"]] = seqs.get(l["sec"], 0) + 1
            lid = c.execute("insert into lines(project_id,sec,cat,seq,name,spec,craft,qty,unit,price,vendor,pay,date,who,inv_note,memo) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                            (pid, l["sec"], l["cat"], seqs[l["sec"]], l["name"], l["spec"], l["craft"], l["qty"], l["unit"], l["price"], l["vendor"], l["pay"], l["date"], l["who"], l.get("inv_note", ""), l.get("memo", ""))).lastrowid
            new_ids.append(lid)
            for kind, key in (("invoice", "_inv"), ("pay", "_pay")):
                if l.get(key) and l[key] in imgs:
                    ext, b = imgs[l[key]]
                    _save_image_bytes(lid, kind, f"{kind}.{ext}", b, c)
                    n_img += 1
        # 原来手动的行：同板块+同名+同金额的，把发票/截图和对上的账单搬到新行；新成本单里没有、但有发票或对上了账单的，原样保留
        news0 = {r["id"]: dict(r) for r in c.execute("select * from lines where id in (%s)" % ",".join("?" * len(new_ids)), new_ids)}
        used_new = set()
        for o in olds:
            oa = round(o["qty"] * o["price"], 2)
            hit = next((n for n in news0.values() if n["id"] not in used_new and n["sec"] == o["sec"]
                        and (n["name"] or "").strip() == (o["name"] or "").strip() and abs(round(n["qty"] * n["price"], 2) - oa) < 0.011), None)
            if hit:
                used_new.add(hit["id"])
                if o["nf"]:
                    # 原来传的发票/截图是原件，优先保留；成本单表格里嵌的同类图片就不要了（避免一张票出现两次）
                    for k in {r["kind"] for r in c.execute("select kind from files where line_id=?", (o["id"],))}:
                        for f in c.execute("select * from files where line_id=? and kind=?", (hit["id"], k)).fetchall():
                            for p_ in (f["path"], f["path"] + ".t.jpg"):
                                try:
                                    os.remove(p_)
                                except OSError:
                                    pass
                            c.execute("delete from files where id=?", (f["id"],))
                    c.execute("update files set line_id=? where line_id=?", (hit["id"], o["id"]))
                    c.execute("update inv set line_id=? where line_id=?", (hit["id"], o["id"]))
                    carried += 1
                if o["uid"] and not hit["uid"]:
                    c.execute("update lines set uid=? where id=?", (o["uid"], hit["id"]))
                c.execute("delete from lines where id=?", (o["id"],))
            elif o["nf"] or o["uid"]:
                kept += 1
            else:
                c.execute("delete from lines where id=?", (o["id"],))
        # 自动同步行 ↔ 成本单行：金额一样（日期近的优先）就合并
        autos = [dict(r) for r in c.execute("select * from lines where project_id=? and auto=1", (pid,))]
        news = [dict(r) for r in c.execute("select * from lines where id in (%s)" % ",".join("?" * len(new_ids)), new_ids)]
        for a in sorted(autos, key=lambda x: -(x["qty"] * x["price"])):
            amt = round(a["qty"] * a["price"], 2)
            cand = [n for n in news if not n["uid"] and n["sec"] != "备用金" and abs(round(n["qty"] * n["price"], 2) - amt) < 0.011]
            if not cand:
                continue
            def dd(n):
                try:
                    return abs((datetime.strptime(n["date"][:10], "%Y-%m-%d") - datetime.strptime(a["date"][:10], "%Y-%m-%d")).days)
                except Exception:
                    return 999
            n = min(cand, key=dd)
            n["uid"] = a["uid"]
            c.execute("update lines set uid=?, date=case when date='' then ? else date end where id=?", (a["uid"], a["date"], n["id"]))
            c.execute("update files set line_id=? where line_id=?", (n["id"], a["id"]))
            c.execute("update inv set line_id=? where line_id=?", (n["id"], a["id"]))
            c.execute("delete from lines where id=?", (a["id"],))
            merged += 1
        # 剩下没合并上的自动同步行：放进「待核对」（不算合计、不导出），免得和成本单重复计算
        held = c.execute("update lines set hold=1 where project_id=? and auto=1", (pid,)).rowcount
    shutil.rmtree(tmp, ignore_errors=True)
    try:
        rep = match_bills(pid, apply=1)
    except Exception as e:
        rep = dict(n_matched=0, n_unmatched=0, matched=[], unmatched=[], error=str(e)[:120])
    d = project_detail(pid)
    d["imported"] = dict(lines=len(lines), images=n_img, merged=merged, matched=rep.get("n_matched", 0),
                         unmatched=rep.get("n_unmatched", 0), kept=kept, carried=carried, held=held)
    d["report"] = rep
    return d


# ---------------------------------------------------------------- 成本行 ↔ 账单 匹配
def _strip_prefix(comment):
    return re.sub(r"^【[^】]*】", "", re.sub(r"〔ID:.*?〕", "", comment or ""))


def _bills_from_ezb():
    out = []
    for t in ezb_transactions():
        i = rid(t.get("comment"))
        if not i or t["type"] not in (2, 3):
            continue
        dt = datetime.fromtimestamp(t["time"], store.TZ)
        out.append(dict(uid=i, kind="收入" if t["type"] == 2 else "支出", amount=t.get("_cny", t["sourceAmount"]) / 100, day=dt.date(),
                        time=dt.strftime("%Y-%m-%d %H:%M:%S"), cp=_strip_prefix(t["comment"]), item="", note="",
                        src=(t.get("sourceAccount") or {}).get("name", ""), _tx=t))
    return out


def _sub_of_line(l):
    class _I(dict):
        pass
    it = dict(sec=l["sec"], name=l["name"], spec=l["spec"], kind="收入" if l["sec"] == "备用金" else "支出")
    return cm.sub_of(it)


def _purpose_of_line(l):
    return cm.purpose_of(dict(sec=l["sec"], name=l["name"], spec=(l["spec"] + " " + l["craft"]).strip(), kind="支出"))


def _row_for(tx_or_none, p, l, uid, account, when, amount, kind, extra_desc=""):
    purpose = _purpose_of_line(l) if l["sec"] != "备用金" else "备用金"
    sub = _sub_of_line(l)
    pre = f"【{p['name']}｜{purpose}】"
    core = extra_desc
    return {"Time": when, "Type": "Income" if kind == "收入" else "Expense", "Category": "工作", "Sub Category": f"工作·{sub}",
            "Account": account, "Amount": f"{amount:.2f}", "Tags": f"工作;项目:{p['name']}", "Description": pre + core[:max(0, 240 - len(pre))] + f"〔ID:{uid}〕"}


@app.post("/api/projects/{pid}/match")
def match_bills(pid: int, apply: int = 1):
    d = project_detail(pid)
    p, lines = d["project"], d["lines"]
    items, by_id = [], {}
    linked = 0
    for l in lines:
        if l.get("uid"):                 # 已经对上账单的行不再重新匹配（避免改掉原来的对应关系）
            linked += 1
            continue
        if l["sec"] == "备用金":
            if l["date"]:
                items.append(dict(sec="备用金", no=l["id"], name="备用金", spec=l["who"], remark="", amount=l["qty"] * l["price"],
                                  date=datetime.strptime(l["date"][:10], "%Y-%m-%d").date(), kind="收入"))
            by_id[l["id"]] = l
            continue
        if l["pay"] in ("未付", "无需付款", "预付"):
            items.append(dict(sec=l["sec"], no=l["id"], name=l["name"], spec=l["spec"], remark=l["vendor"], amount=line_amount(l), date=None, kind="支出", skip="未付/无需付款"))
        elif l["pay"] == "已付" and "微信" not in l["vendor"]:
            items.append(dict(sec=l["sec"], no=l["id"], name=l["name"], spec="", remark="", amount=line_amount(l), date=None, kind="支出", skip="他人支付/非微信，账单里不会有"))
        else:
            items.append(dict(sec=l["sec"], no=l["id"], name=l["name"], spec=l["spec"] + " " + l["craft"], remark=l["vendor"], amount=line_amount(l), date=None, kind="支出"))
        by_id[l["id"]] = l
    s = p["start"] or (p["created"] or "")[:10] or date.today().isoformat()      # 没填开始日期：按建项目那天算
    e = p["end"] or s
    from datetime import timedelta
    start = datetime.strptime(s, "%Y-%m-%d").date() - timedelta(days=45)
    end = datetime.strptime(e, "%Y-%m-%d").date() + timedelta(days=90)
    with store.db() as c:
        taken = {r["uid"] for r in c.execute("select uid from lines where uid<>'' union select uid from divs where uid<>''")}
    bills = [b for b in _bills_from_ezb() if start <= b["day"] <= end and b["uid"] not in taken]
    res = cm.match(items, bills, (start, end))
    ok = [r for r in res if r[3] == "确认"]
    report = dict(matched=[], unmatched=[])
    rows = []
    for it, b, cands, why in res:
        l = by_id[it["no"]]
        if why == "确认":
            report["matched"].append(dict(line=l["name"] or l["who"], amount=it["amount"], bill_time=b["time"], bill_cp=b["cp"][:30]))
            if apply:
                tx = b["_tx"]
                rows.append(_row_for(tx, p, l, b["uid"], b["src"], b["time"], b["amount"], b["kind"], b["cp"]))
                with store.db() as c:
                    c.execute("update lines set uid=? where id=?", (b["uid"], l["id"]))
        else:
            report["unmatched"].append(dict(line=l["name"] or l["who"], sec=l["sec"], amount=it["amount"], pay=l["pay"], why=why))
    if apply and rows:
        push_rows(ezb(), rows, log=lambda *_: None)
        invalidate()
    report["n_matched"], report["n_unmatched"] = len(report["matched"]), len(report["unmatched"])
    report["n_linked"] = linked
    return report


@app.post("/api/projects/{pid}/sync-cash")
def sync_cash(pid: int):
    """成本单里没有对上账单的：『备用金垫付』的行 → 备用金账户的工作支出；备用金入款 → 备用金账户的收入（项目备用金入款）。"""
    d = project_detail(pid)
    p, lines = d["project"], d["lines"]
    if any(l["sec"] == "备用金" and "【同事经手】" in (l["vendor"] or "") for l in lines):
        # 备用金在同事那里、不是我的钱：不往我的记账本里记，只在项目成本单里体现
        return dict(added=0, skipped=0, updated=0, total=0, note="这个项目的备用金在同事那里，备用金垫付的支出不记入你的记账本")
    when_day = p["start"] or date.today().isoformat()
    rows, ids = [], []
    for l in lines:
        if l["sec"] == "备用金" and not l["uid"] and line_amount(l) > 0:
            # 成本单里的备用金、账单里没有对应入款（打到别处了）→ 作为「备用金」账户的入款记进记账本，备用金账户才不会只有支出
            uid = f"成本单:{pid}:{l['id']}"
            d_ = (l["date"] or "")[:10].replace(".", "-") or when_day
            r_ = _row_for(None, p, l, uid, "备用金", f"{d_} 12:00:00", line_amount(l), "收入", f"{l['who'] or l['name']} | 成本单备用金")
            r_["Sub Category"] = "工作·项目备用金入款"
            rows.append(r_)
            ids.append((uid, l["id"]))
            continue
        if l["sec"] == "备用金" or l["pay"] != "备用金垫付" or l["uid"]:
            continue
        uid = f"成本单:{pid}:{l['id']}"
        desc = " | ".join(x for x in (l["name"], l["spec"], l["vendor"][:60]) if x)
        rows.append(_row_for(None, p, l, uid, "备用金", f"{when_day} 12:00:00", line_amount(l), "支出", desc))
        ids.append((uid, l["id"]))
    if rows:
        res = push_rows(ezb(), rows, log=lambda *_: None)
        invalidate()
        with store.db() as c:
            for uid, lid in ids:
                c.execute("update lines set uid=? where id=?", (uid, lid))
    else:
        res = dict(added=0, skipped=0, updated=0)
    return dict(res, total=len(rows))


# ---------------------------------------------------------------- 导出
class ExportFiles(BaseModel):
    month: str = ""
    dest: str = ""          # 留空 = 弹出 Mac 的「选择文件夹」窗口


def _safe(t, n=40):
    t = re.sub(r'[\\/:*?"<>|\n\r\t]+', " ", str(t or "")).strip()
    return t[:n] or "未命名"


@app.post("/api/projects/{pid}/export-files")
def export_files(pid: int, b: ExportFiles):
    """把项目的发票 / 行程单 / 支付截图「原件」导出到你选的文件夹：
    项目名-发票与截图/发票、行程单、支付截图/序号-板块-名称-金额元.pdf|png（PDF 发票导出原 PDF）。"""
    d = project_detail(pid)
    p = d["project"]
    lines = d["lines"]
    if b.month:
        mk = "" if b.month == "未标日期" else b.month
        lines = [l for l in lines if l["month"] == mk]
    ids = [l["id"] for l in lines]
    if not ids:
        raise HTTPException(400, "这个项目（月份）还没有成本行")
    with store.db() as c:
        fs = [dict(r) for r in c.execute("select * from files where line_id in (%s) order by id" % ",".join("?" * len(ids)), ids)]
    if not fs:
        raise HTTPException(400, "这个项目还没有上传过发票 / 行程单 / 支付截图")
    dest = b.dest.strip()
    if not dest:
        r = subprocess.run(["osascript", "-e", 'POSIX path of (choose folder with prompt "选择发票原图导出到哪个文件夹")'],
                           capture_output=True, text=True, timeout=600)
        if r.returncode != 0:
            return dict(cancelled=True)
        dest = r.stdout.strip()
    if not os.path.isdir(dest):
        raise HTTPException(400, f"文件夹不存在：{dest}")
    root = os.path.join(dest, _safe(p["name"] + (f"-{b.month}" if b.month else ""), 60) + "-发票与截图")
    sub = {"invoice": "发票", "trip": "行程单", "pay": "支付截图"}
    seq = {l["id"]: i + 1 for i, l in enumerate(lines)}
    by_line = {l["id"]: l for l in lines}
    done, n, used = set(), 0, set()
    for f in fs:
        l = by_line[f["line_id"]]
        src = f["orig"] if f.get("orig") and os.path.exists(f["orig"]) else f["path"]
        if src in done or not os.path.exists(src):
            continue                                           # 多页 PDF 只导出一份原 PDF
        done.add(src)
        folder = os.path.join(root, sub.get(f["kind"], "其他"))
        os.makedirs(folder, exist_ok=True)
        base = f"{seq[l['id']]:02d}-{_safe(l['sec'], 8)}-{_safe(l['name'] or l['cat'] or l['who'], 24)}-{round((l['qty'] or 0) * (l['price'] or 0), 2):g}元"
        ext = os.path.splitext(src)[1].lower() or ".png"
        nm, k = base + ext, 2
        while os.path.join(folder, nm) in used or os.path.exists(os.path.join(folder, nm)):
            nm = f"{base}-{k}{ext}"; k += 1
        used.add(os.path.join(folder, nm))
        shutil.copy2(src, os.path.join(folder, nm))
        n += 1
    subprocess.run(["open", root])
    cnt = {sub[k]: len([1 for f in fs if f["kind"] == k]) for k in sub}
    return dict(ok=True, n=n, folder=root, counts=cnt)


@app.get("/api/projects/{pid}/export")
def export_xlsx(pid: int, month: str = ""):
    d = project_detail(pid)
    if month:                                         # 只导出某个月（同一项目不同月份分开结算）
        mk = "" if month == "未标日期" else month
        bm = d["by_month"].get(month)
        d["lines"] = [l for l in d["lines"] if l["month"] == mk]
        d["income"] = [v for v in d["income"] if v["month"] == mk]
        if bm:
            d["summary"], d["profit"] = bm["summary"], bm["profit"]
    p = d["project"]
    with store.db() as c:
        files = {}
        for f in c.execute("select * from files where line_id in (select id from lines where project_id=?) order by id", (pid,)):
            files.setdefault(f["line_id"], []).append(dict(kind=f["kind"], path=f["path"], name=f["name"]))
    outdir = os.path.join(store.DATA, "exports")
    os.makedirs(outdir, exist_ok=True)
    fname = f"{p['name']}{'-' + month if month else ''}内部成本单.xlsx"
    out = os.path.join(outdir, fname)
    exporter.export_project(p, p["params"], d["lines"], files, out, reimbs=d.get("reimbs") or [])
    return FileResponse(out, filename=fname, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# ---------------------------------------------------------------- 账单上传 / 待确认
def _public_row(d):
    return dict(uid=d["uid"], time=d["time"], src=d["src"], kind=d["kind"], amount=d["amount"], cp=d["cp"], item=d["item"],
                scope=d["scope"], sub=d["sub"], project=d["project"], purpose=d.get("purpose", ""), why=d["why"])


def _batch_view(bid):
    with store.db() as c:
        b = c.execute("select * from batches where id=?", (bid,)).fetchone()
    if not b:
        raise HTTPException(404, "没有这个批次")
    rows = json.loads(b["rows"])
    stats = json.loads(b["stats"])
    groups, allg = {}, {}
    for r in rows:
        if r["status"] == "exists":
            continue
        k = r["cp"] or "(无对方)"
        a = allg.setdefault(k, dict(cp=k, n=0, total=0.0, kinds=set(), example=r["item"], why=r["why"], sc={}, sub={}, pj={}, pu={}))
        a["n"] += 1
        a["total"] += r["amount"]
        a["kinds"].add(r["kind"])
        for f, key in (("sc", "scope"), ("sub", "sub"), ("pj", "project"), ("pu", "purpose")):
            v_ = r.get(key) or ""
            a[f][v_] = a[f].get(v_, 0) + 1
        if r["scope"] == "待确认":
            g = groups.setdefault(r["cp"] or "(无对方)", dict(cp=r["cp"] or "(无对方)", n=0, total=0.0, kinds=set(), example=r["item"], why=r["why"]))
            g["n"] += 1
            g["total"] += r["amount"]
            g["kinds"].add(r["kind"])
    def top_(d):
        return max(d, key=d.get) if d else ""
    all_groups = sorted((dict(cp=g["cp"], n=g["n"], total=round(g["total"], 2), kinds=sorted(g["kinds"]), example=g["example"], why=g["why"],
                              scope=top_(g["sc"]), sub=top_(g["sub"]), project=top_(g["pj"]), purpose=top_(g["pu"]), mixed=len(g["sc"]) > 1)
                         for g in allg.values()), key=lambda x: -x["total"])
    pend = sorted(({**g, "kinds": sorted(g["kinds"]), "total": round(g["total"], 2)} for g in groups.values()), key=lambda x: -x["total"])
    new = [r for r in rows if r["status"] != "exists"]
    by = {}
    for r in new:
        if r["kind"] == "支出":
            by[r["scope"]] = round(by.get(r["scope"], 0) + r["amount"], 2)
    with store.db() as c:
        projects = [r["name"] for r in c.execute("select name from projects order by id desc")]
    return dict(id=bid, status=b["status"], names=b["names"], stats=stats, n_total=len(rows), n_new=len(new),
                n_exists=len(rows) - len(new), by_scope=by, pending=pend, groups=all_groups, projects=projects,
                sample=[_public_row(r) for r in new[:200]])


@app.post("/api/bills/upload")
async def upload_bills(files: List[UploadFile] = File(...)):
    tmp = tempfile.mkdtemp()
    paths, names = [], []
    for f in files:
        fn = os.path.basename((f.filename or "账单").replace("\\", "/")).lstrip(".") or "账单"      # 只留文件名，不让它跑出临时文件夹
        p = os.path.join(tmp, fn)
        open(p, "wb").write(await f.read())
        paths.append(p)
        names.append(fn)
    try:
        recs, stats, _ = bt.process(paths, ignore_seen=True)
    except SystemExit as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(400, f"读不懂这个账单：{e}")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    try:
        existing = ezb_existing_ids()
    except HTTPException:
        existing = set()
    rows = []
    for d in recs:
        r = {k: d[k] for k in ("uid", "time", "src", "kind", "amount", "cp", "item", "note", "typ", "id", "status", "method", "refund", "scope", "sub", "project", "why")}
        r["purpose"] = d.get("purpose", "")
        r["status"] = "exists" if d["uid"] in existing else "new"
        rows.append(r)
    with store.db() as c:
        bid = c.execute("insert into batches(names,stats,rows) values(?,?,?)", ("、".join(names), json.dumps(stats), json.dumps(rows, ensure_ascii=False))).lastrowid
    return _batch_view(bid)


@app.get("/api/bills/batches/{bid}")
def get_batch(bid: int):
    return _batch_view(bid)


@app.get("/api/bills/batches")
def list_batches():
    with store.db() as c:
        return [dict(id=r["id"], created=r["created"], names=r["names"], status=r["status"]) for r in c.execute("select * from batches order by id desc limit 20")]


class Decision(BaseModel):
    cp: str
    scope: str                 # 工作 / 生活
    project: str = ""          # 已有项目名
    new_project: str = ""      # 新项目名（优先）
    purpose: str = ""
    sub: str = ""


class Decisions(BaseModel):
    decisions: List[Decision]


@app.post("/api/bills/batches/{bid}/decide")
def decide(bid: int, body: Decisions):
    learned = bt.load_json(bt.LEARNED, {})
    created = []
    for d in body.decisions:
        if d.scope not in ("工作", "生活"):
            continue
        proj = (d.new_project or d.project or "").strip()
        if HOOKS.get("norm_project"):
            proj = HOOKS["norm_project"](proj)
        if HOOKS.get("fix_sub") and d.scope in ("工作", "生活"):
            v = dict(scope=d.scope, type="exp", sub=d.sub, project="" if proj == "(无项目)" else proj, purpose=d.purpose)
            HOOKS["fix_sub"](v, any_type=True)
            d.scope, d.sub, d.purpose = v["scope"], v["sub"], v["purpose"]
            proj = v["project"] or proj
        if proj in ("(无项目)",) or d.scope != "工作":
            proj = ""
        if proj:
            with store.db() as c:
                if not c.execute("select 1 from projects where name=?", (proj,)).fetchone():
                    c.execute("insert into projects(name,params) values(?, '{}')", (proj,))
                    created.append(proj)
        key = d.cp.strip().lower()
        if key and key != "(无对方)":
            learned[key] = dict(scope=d.scope, sub=d.sub.strip(), project=proj, purpose=d.purpose.strip())
    store.write_json(bt.LEARNED, learned)
    sync_projects_json()
    # 重新按最新规则分类这一批
    with store.db() as c:
        b = c.execute("select * from batches where id=?", (bid,)).fetchone()
        rows = json.loads(b["rows"])
        rules = bt.load_json(bt.RULES, None)
        rules["项目周期"] = bt.load_projects(rules)
        ann = bt.load_json(bt.ANN, {})
        for r in rows:
            r["purpose"] = ""
            r.update(bt.classify(r, rules, learned, ann))
        c.execute("update batches set rows=? where id=?", (json.dumps(rows, ensure_ascii=False), bid))
    v = _batch_view(bid)
    v["created_projects"] = created
    return v


@app.post("/api/bills/batches/{bid}/commit")
def commit(bid: int):
    with store.db() as c:
        b = c.execute("select * from batches where id=?", (bid,)).fetchone()
    if not b:
        raise HTTPException(404, "没有这个批次")
    rows = json.loads(b["rows"])
    out = []
    for d in rows:
        if d["status"] == "exists":
            continue
        d.setdefault("purpose", "")
        tags = [d["scope"]] + ([f"项目:{d['project']}"] if d["project"] else [])
        out.append({"Time": d["time"], "Type": "Income" if d["kind"] == "收入" else "Expense", "Category": d["scope"],
                    "Sub Category": f"{d['scope']}·{d['sub']}", "Account": bt.account_of(d["src"], d.get("method", "")), "Amount": f"{d['amount']:.2f}",
                    "Tags": ";".join(tags), "Description": bt.rec_description(d)})
    res = push_rows(ezb(), out, log=lambda *_: None) if out else dict(skipped=0, updated=0, added=0)
    invalidate()
    with store.db() as c:
        c.execute("update batches set status='done' where id=?", (bid,))
    res = dict(res, merged=0, pairs=[])
    if HOOKS.get("dupes"):               # 之前手记过的账和刚导入的账单像是同一笔：不再自动合并，列出来（工作、生活都列）让你逐笔确认
        try:
            res["pairs"] = HOOKS["dupes"]()["pairs"]
        except Exception as e:
            store.log_err("找手记和账单的重复", e)
    return res



# ---------------------------------------------------------------- 总览（个人生活收支 / 预算 / 攒钱目标）
def _scope_of(t):
    """以记账本里的分类为准（「工作·xxx」「生活·xxx」「待确认·xxx」）；不是我们的分类时再看标签。"""
    cat = (t.get("category") or {}).get("name", "")
    if "·" in cat:
        pre = cat.split("·", 1)[0]
        if pre in ("工作", "生活", "待确认"):
            return pre
    names = {x["name"] for x in (t.get("tags") or [])}
    if "工作" in names:
        return "工作"
    if "待确认" in names:
        return "待确认"
    return "生活"


_catname = {"t": 0, "m": {}}


def _cat_names():
    """记账本分类 id → 名称（判断『项目·xx』大类用），30 秒缓存。"""
    if time.time() - _catname["t"] > 30 or not _catname["m"]:
        try:
            from api_import import _flat_categories
            _catname["m"] = {str(c["id"]): c["name"] for c in _flat_categories(ezb())}
            _catname["t"] = time.time()
        except Exception as e:
            store.log_err("读记账本分类名", e)
    return _catname["m"]


def _project_of(t):
    """项目：先看分类大类（记账本里选的『项目·xx』），再看标签『项目:xx』，最后看备注【xx】。"""
    pid = str((t.get("category") or {}).get("parentId") or "")
    if pid and pid != "0":
        pn = _cat_names().get(pid, "")
        if pn.startswith("项目·"):
            return pn[3:]
    for x in (t.get("tags") or []):
        if x["name"].startswith("项目:"):
            return x["name"][3:]
    m = re.match(r"^【([^｜】]+)", t.get("comment") or "")
    return m.group(1) if m else ""


def _sub_name(t):
    n = (t.get("category") or {}).get("name", "未分类")
    return n.split("·", 1)[1] if "·" in n else n


def _is_div_out(t):
    """分红转出：到账的分红里替别人收的、我又转给别人的那部分。不是成本，从『我的收入·项目分红』里扣掉。"""
    return t["type"] == 3 and _scope_of(t) == "工作" and _sub_name(t) in DIV_OUT_SUBS


def _is_pass(t):
    """过手的钱（分红转出、项目款转出）：支出方向，但不是项目成本。"""
    return t["type"] == 3 and _scope_of(t) == "工作" and _sub_name(t) in PASS_SUBS


def _mine_inc(t):
    """这笔算不算『我的收入』：1 算（生活收入、项目分红），-1 要扣掉（分红转出），0 不算。"""
    sc, sn = _scope_of(t), _sub_name(t)
    if t["type"] == 2:
        return 1 if (sc == "生活" and sn != "借款往来") or (sc == "工作" and sn == "项目分红") else 0
    return -1 if _is_div_out(t) else 0


def _months_of(txs):
    """有账的月份 + 当前月份（没账也要能选当月，默认落在当月）。"""
    ms = {_month_of(t) for t in txs}
    if ms:
        ms.add(date.today().strftime("%Y-%m"))
    return sorted(ms)


def _month_of(t):
    return datetime.fromtimestamp(t["time"], store.TZ).strftime("%Y-%m")


@app.get("/api/overview")
def overview(month: str = ""):
    txs = [t for t in ezb_transactions() if t["type"] in (2, 3)]
    months = _months_of(txs)
    if not months:
        return dict(months=[], month="", empty=True)
    if month != "all":
        month = month if month in months else months[-1]
    Z = lambda: dict(inc_life=0.0, inc_work=0.0, inc_pend=0.0, inc_div=0.0, inc_adv=0.0, inc_reimb=0.0, div_out=0.0, exp_life=0.0, exp_work=0.0, exp_pend=0.0, loan_in=0.0, loan_out=0.0)
    agg = {m: Z() for m in months}
    for t in txs:
        m = _month_of(t)
        a = agg.setdefault(m, Z())
        sc = _scope_of(t)
        if sc == "生活" and _sub_name(t) == "借款往来":        # 借进借出、还款：不是收入也不是支出
            a["loan_" + ("in" if t["type"] == 2 else "out")] = a.get("loan_" + ("in" if t["type"] == 2 else "out"), 0) + t.get("_cny", t["sourceAmount"]) / 100
            continue
        if _is_div_out(t):                                   # 分红转出：从我的分红收入里扣掉，不算工作支出
            v_ = t.get("_cny", t["sourceAmount"]) / 100
            a["inc_div"] -= v_
            a["inc_work"] -= v_
            a["div_out"] += v_
            continue
        key = ("inc_" if t["type"] == 2 else "exp_") + {"生活": "life", "工作": "work", "待确认": "pend"}[sc]
        a[key] += t.get("_cny", t["sourceAmount"]) / 100
        if t["type"] == 2 and sc == "工作":
            sn = _sub_name(t)
            if sn == "项目分红":
                a["inc_div"] += t.get("_cny", t["sourceAmount"]) / 100        # 分红：算我的收入
            elif sn == "项目备用金入款":
                a["inc_adv"] += t.get("_cny", t["sourceAmount"]) / 100
            elif sn == "项目报销":
                a["inc_reimb"] += t.get("_cny", t["sourceAmount"]) / 100      # 报销：我垫的钱公司还回来，不算收入也不算回款
    if month == "all":
        cur = {k: round(sum(a[k] for a in agg.values()), 2) for k in next(iter(agg.values()))}
    else:
        cur = {k: round(v, 2) for k, v in agg[month].items()}
    cur["inc_total"] = round(cur["inc_life"] + cur["inc_work"] + cur["inc_pend"], 2)
    cur["exp_total"] = round(cur["exp_life"] + cur["exp_work"] + cur["exp_pend"], 2)
    # 三本账分开：我的收支（生活 + 项目分红）／ 项目资金（备用金入款、客户回款 vs 工作支出）／ 待确认（不计入）
    cur["my_inc"] = round(cur["inc_life"] + cur["inc_div"], 2)
    cur["my_exp"] = round(cur["exp_life"], 2)
    cur["proj_in"] = round(cur["inc_work"] - cur["inc_div"], 2)
    cur["proj_back"] = round(cur["proj_in"] - cur["inc_adv"] - cur["inc_reimb"], 2)
    cur["proj_out"] = round(cur["exp_work"], 2)
    cats, merchants = {}, {}
    wcats, wproj, pend = {}, {}, {}
    for t in txs:
        if (month != "all" and _month_of(t) != month) or t["type"] != 3:
            continue
        sc_ = _scope_of(t)
        if sc_ == "生活" and _sub_name(t) == "借款往来":
            continue
        a_ = t.get("_cny", t["sourceAmount"]) / 100
        if sc_ == "工作":
            if _sub_name(t) in DIV_OUT_SUBS:
                continue
            wcats[_sub_name(t)] = wcats.get(_sub_name(t), 0) + a_
            pn_ = _project_of(t) or "(没归项目)"
            wproj[pn_] = wproj.get(pn_, 0) + a_
            continue
        if sc_ == "待确认":
            cp_ = _strip_prefix(t.get("comment", "")).split(" | ")[0].strip() or "(无对方)"
            e_ = pend.setdefault(cp_, [0.0, 0])
            e_[0] += a_
            e_[1] += 1
            continue
        amt = t.get("_cny", t["sourceAmount"]) / 100
        cats[_sub_name(t)] = cats.get(_sub_name(t), 0) + amt
        cp = _strip_prefix(t.get("comment", "")).split(" | ")[0].strip() or "(无对方)"
        merchants[cp] = merchants.get(cp, 0) + amt
    tot = sum(cats.values()) or 1
    cat_rows = [dict(name=k, amount=round(v, 2), pct=round(v / tot * 100, 1)) for k, v in sorted(cats.items(), key=lambda x: -x[1])]
    top = [dict(name=k, amount=round(v, 2)) for k, v in sorted(merchants.items(), key=lambda x: -x[1])[:10]]
    wt = sum(wcats.values()) or 1
    cats_work = [dict(name=k, amount=round(v, 2), pct=round(v / wt * 100, 1)) for k, v in sorted(wcats.items(), key=lambda x: -x[1])]
    proj_rows = [dict(name=k, amount=round(v, 2), pct=round(v / wt * 100, 1)) for k, v in sorted(wproj.items(), key=lambda x: -x[1])]
    pend_rows = [dict(name=k, amount=round(v[0], 2), n=v[1]) for k, v in sorted(pend.items(), key=lambda x: -x[1][0])]
    idx = len(months) - 1 if month == "all" else months.index(month)
    trend = []
    for m in months[max(0, idx - 11): idx + 1]:
        a = agg[m]
        trend.append(dict(month=m, inc=round(a["inc_life"] + a["inc_div"], 2), exp=round(a["exp_life"], 2), work=round(a["exp_work"], 2)))
    cfg = store.load_config()
    return dict(months=months, month=month, cur=cur, cats=cat_rows, top=top, trend=trend, cats_work=cats_work, projects=proj_rows,
                pend=pend_rows[:12], n_pend=len(pend_rows),
                surplus=round(cur["my_inc"] - cur["my_exp"], 2), budget=float(cfg.get("monthly_budget", 0) or 0))


@app.get("/api/todo")
def todo():
    """总览「待处理」用：全部账单（不分月份）里还没分工作/生活的、工作支出没归项目的，各有几笔、多少钱。"""
    out = dict(pend=dict(n=0, amount=0.0), noproj=dict(n=0, amount=0.0))
    try:
        for t in ezb_transactions():
            if t["type"] not in (2, 3):
                continue
            sc = _scope_of(t)
            k = "pend" if sc == "待确认" else ("noproj" if sc == "工作" and t["type"] == 3 and not _project_of(t) else "")
            if k:
                out[k]["n"] += 1
                out[k]["amount"] += t.get("_cny", t["sourceAmount"]) / 100
    except Exception as e:
        store.log_err("待处理统计", e)
    for v in out.values():
        v["amount"] = round(v["amount"], 2)
    return out


class BudgetIn(BaseModel):
    monthly_budget: float


@app.put("/api/budget")
def set_budget(b: BudgetIn):
    cfg = store.load_config()
    cfg["monthly_budget"] = b.monthly_budget
    store.save_config(cfg)
    return dict(ok=True)


class GoalIn(BaseModel):
    name: str
    target: float = 0
    deadline: str = ""
    saved0: float = 0
    note: str = ""


class DepositIn(BaseModel):
    date: str = ""
    amount: float
    note: str = ""


def _goal_view(g, deps):
    saved = round(g["saved0"] + sum(d["amount"] for d in deps), 2)
    left = round(max(g["target"] - saved, 0), 2)
    months_left, per_month = None, None
    if g["deadline"]:
        try:
            dl = datetime.strptime(g["deadline"], "%Y-%m-%d").date()
            today = date.today()
            months_left = max((dl.year - today.year) * 12 + dl.month - today.month, 0)
            per_month = round(left / months_left, 2) if months_left else left
        except ValueError:
            pass
    return dict(**g, saved=saved, left=left, pct=round(min(saved / g["target"], 1) * 100, 1) if g["target"] else 0,
                months_left=months_left, per_month=per_month, deposits=deps)


@app.get("/api/goals")
def list_goals():
    with store.db() as c:
        gs = [row(r) for r in c.execute("select * from goals order by id")]
        out = []
        for g in gs:
            deps = [row(r) for r in c.execute("select * from deposits where goal_id=? order by date desc, id desc", (g["id"],))]
            out.append(_goal_view(g, deps))
    return out


@app.post("/api/goals")
def add_goal(g: GoalIn):
    with store.db() as c:
        c.execute("insert into goals(name,target,deadline,saved0,note) values(?,?,?,?,?)", (g.name.strip(), g.target, g.deadline, g.saved0, g.note))
    return list_goals()


@app.put("/api/goals/{gid}")
def edit_goal(gid: int, g: GoalIn):
    with store.db() as c:
        c.execute("update goals set name=?,target=?,deadline=?,saved0=?,note=? where id=?", (g.name.strip(), g.target, g.deadline, g.saved0, g.note, gid))
    return list_goals()


@app.delete("/api/goals/{gid}")
def del_goal(gid: int):
    with store.db() as c:
        c.execute("delete from deposits where goal_id=?", (gid,))
        c.execute("delete from goals where id=?", (gid,))
    return list_goals()


@app.post("/api/goals/{gid}/deposits")
def add_deposit(gid: int, d: DepositIn):
    with store.db() as c:
        c.execute("insert into deposits(goal_id,date,amount,note) values(?,?,?,?)", (gid, d.date or date.today().isoformat(), d.amount, d.note))
    return list_goals()


@app.delete("/api/deposits/{did}")
def del_deposit(did: int):
    with store.db() as c:
        c.execute("delete from deposits where id=?", (did,))
    return list_goals()



@app.get("/api/dashboard")
def dashboard(range: str = "12m"):
    txs = [t for t in ezb_transactions() if t["type"] in (2, 3)]
    months = _months_of(txs)
    if not months:
        return dict(empty=True)
    if range == "12m":
        keep = set(months[-12:])
    elif range == "year":
        keep = {m for m in months if m[:4] == months[-1][:4]}
    else:
        keep = set(months)
    series = {m: dict(month=m, inc=0.0, exp=0.0, inc_life=0.0, inc_work=0.0, inc_div=0.0, exp_life=0.0, exp_work=0.0, exp_pend=0.0) for m in months if m in keep}
    cl, cw, ml, mw = {}, {}, {}, {}
    meta = {}
    tot = dict(inc_life=0.0, inc_work=0.0, inc_pend=0.0, inc_div=0.0, inc_adv=0.0, inc_reimb=0.0, exp_life=0.0, exp_work=0.0, exp_pend=0.0)
    for t in txs:
        m = _month_of(t)
        if m not in keep:
            continue
        a = t.get("_cny", t["sourceAmount"]) / 100
        sc = _scope_of(t)
        if sc == "生活" and _sub_name(t) == "借款往来":        # 借款往来不算收支
            continue
        if _is_div_out(t):                                   # 分红转出：从分红收入里扣掉
            for d_ in (tot, series[m]):
                d_["inc_div"] -= a
                d_["inc_work"] -= a
            series[m]["inc"] -= a
            continue
        k = {"生活": "life", "工作": "work", "待确认": "pend"}[sc]
        tot[("inc_" if t["type"] == 2 else "exp_") + k] += a
        if t["type"] == 2 and k == "work":
            if _sub_name(t) == "项目分红":
                tot["inc_div"] += a
                series[m]["inc_div"] += a
            elif _sub_name(t) == "项目备用金入款":
                tot["inc_adv"] += a
            elif _sub_name(t) == "项目报销":
                tot["inc_reimb"] += a
        series[m]["inc" if t["type"] == 2 else "exp"] += a
        if t["type"] == 2 and k in ("life", "work"):
            series[m]["inc_" + k] += a
        if t["type"] == 3:
            series[m]["exp_" + k] += a
            cp = _strip_prefix(t.get("comment", "")).split(" | ")[0].strip() or "(无对方)"
            if k in ("life", "work"):
                pm = re.match(r"^【([^｜】]*)(?:｜([^】]*))?】", t.get("comment") or "")
                mm = meta.setdefault((k, cp), dict(pj={}, pu={}, sub={}, n=0))
                mm["n"] += 1
                mm["sub"][_sub_name(t)] = mm["sub"].get(_sub_name(t), 0) + a
                pn_ = _project_of(t)
                if pn_:
                    mm["pj"][pn_] = mm["pj"].get(pn_, 0) + a
                if pm and (pm.group(2) or "").strip():
                    mm["pu"][pm.group(2).strip()] = mm["pu"].get(pm.group(2).strip(), 0) + a
            if k == "life":
                cl[_sub_name(t)] = cl.get(_sub_name(t), 0) + a
                ml[cp] = ml.get(cp, 0) + a
            elif k == "work":
                cw[_sub_name(t)] = cw.get(_sub_name(t), 0) + a
                mw[cp] = mw.get(cp, 0) + a
    def top(d, n=10, scope=None):
        out = []
        for k, v in sorted(d.items(), key=lambda x: -x[1])[:n]:
            it = dict(name=k, amount=round(v, 2))
            if scope:
                mm = meta.get((scope, k), {})
                it["project"] = max(mm.get("pj", {}), key=mm["pj"].get) if mm.get("pj") else ""
                it["n_projects"] = len(mm.get("pj", {}))
                it["purpose"] = max(mm.get("pu", {}), key=mm["pu"].get) if mm.get("pu") else ""
                it["sub"] = max(mm.get("sub", {}), key=mm["sub"].get) if mm.get("sub") else ""
                it["n"] = mm.get("n", 0)
            out.append(it)
        return out
    pj, pjn, ppay = {}, {}, {}
    for t in txs:
        if t["type"] == 3 and _month_of(t) in keep and not _is_pass(t):
            pn = _project_of(t)
            if pn:
                pj[pn] = pj.get(pn, 0) + t.get("_cny", t["sourceAmount"]) / 100
                pjn[pn] = pjn.get(pn, 0) + 1
                who_ = re.sub(r"〔ID:.*?〕", "", _strip_prefix(t.get("comment", ""))).split(" | ")[0].strip() or "(无对方)"
                pp_ = ppay.setdefault(who_, dict(amount=0.0, n=0, pj={}))
                pp_["amount"] += t.get("_cny", t["sourceAmount"]) / 100
                pp_["n"] += 1
                pp_["pj"][pn] = pp_["pj"].get(pn, 0) + t.get("_cny", t["sourceAmount"]) / 100
                pm_ = re.match(r"^【([^｜】]*)(?:｜([^】]*))?】", t.get("comment") or "")
                if pm_ and (pm_.group(2) or "").strip():
                    pu_ = pp_.setdefault("pu", {})
                    pu_[pm_.group(2).strip()] = pu_.get(pm_.group(2).strip(), 0) + t.get("_cny", t["sourceAmount"]) / 100
    projects = []
    with store.db() as c:
        ps = [row(r) for r in c.execute("select id,name from projects")]
    for p in ps:
        d = project_detail(p["id"])
        if d["summary"]["total"] > 0:
            projects.append(dict(name=p["name"], total=d["summary"]["total"], paid=d["summary"]["paid"], profit=d["profit"]["profit"], rate=d["profit"]["rate"], quote=d["project"]["params"].get("quote", 0)))
    projects.sort(key=lambda x: -x["total"])
    n_m = max(len(series), 1)
    tot["inc_total"] = tot["inc_life"] + tot["inc_work"] + tot["inc_pend"]
    tot["exp_total"] = tot["exp_life"] + tot["exp_work"] + tot["exp_pend"]
    return dict(range=range, months=[{k: (round(v, 2) if k != "month" else v) for k, v in series[m].items()} for m in sorted(series)],
                tot={k: round(v, 2) for k, v in tot.items()}, avg_life=round(tot["exp_life"] / n_m, 2),
                cats_life=top(cl, 12), cats_work=top(cw, 12), top_life=top(ml, 10, 'life'), top_work=top(mw, 10, 'work'),
                top_proj_pay=[dict(name=k, amount=round(v['amount'], 2), n=v['n'], project=max(v['pj'], key=v['pj'].get), n_projects=len(v['pj']), purpose=(max(v['pu'], key=v['pu'].get) if v.get('pu') else '')) for k, v in sorted(ppay.items(), key=lambda x: -x[1]['amount'])[:10]], projects=projects,
                top_projects=[dict(name=k, amount=round(v, 2), n=pjn[k]) for k, v in sorted(pj.items(), key=lambda x: -x[1])[:10]])



@app.get("/api/drill")
def drill(range: str = "12m", month: str = "", scope: str = "生活", type: str = "exp", cat: str = "", project: str = ""):
    """看板点击某个月/某个分类后的金额明细。"""
    txs = [t for t in ezb_transactions() if t["type"] in (2, 3)]
    months = _months_of(txs)
    keep = set(months[-12:]) if range == "12m" else ({m for m in months if m[:4] == months[-1][:4]} if range == "year" else set(months))
    want = 2 if type == "inc" else 3
    rows, total = [], 0.0
    mine = scope == "我的" and type == "inc"                 # 我的收入 = 生活收入 + 项目分红 − 分红转出（和总览的数一致）
    for t in txs:
        m = _month_of(t)
        if (month and m != month) or (not month and m not in keep):
            continue
        sign = 1
        if mine:
            sign = _mine_inc(t)
            if not sign:
                continue
        elif t["type"] != want or (scope != "全部" and not project and _scope_of(t) != scope):
            continue
        elif scope == "工作" and not project and _is_div_out(t):
            continue
        if cat and _sub_name(t) != cat:
            continue
        if project and _project_of(t) != project:
            continue
        a = sign * t.get("_cny", t["sourceAmount"]) / 100
        total += a
        rows.append(dict(time=datetime.fromtimestamp(t["time"], store.TZ).strftime("%Y-%m-%d %H:%M"), amount=round(a, 2), cat=_sub_name(t),
                         name=_strip_prefix(t.get("comment", "")).strip()[:60], uid=rid(t.get("comment")) or "", tx_id=str(t["id"]), scope=_scope_of(t), project=_project_of(t), account=(t.get("sourceAccount") or {}).get("name", "")))
    rows.sort(key=lambda r: -r["amount"])
    return dict(total=round(total, 2), n=len(rows), rows=rows[:200])



class Reclass(BaseModel):
    cp: str = ""            # 按交易对方：该对象所有账单一起改，并记住以后自动归类
    uid: str = ""           # 或按单笔账单
    tx_id: str = ""         # 记账本里手动记的账（没有账单编号）用它
    scope: str              # 工作 / 生活
    project: str = ""
    new_project: str = ""
    purpose: str = ""
    sub: str = ""


@app.post("/api/reclassify")
def reclassify(b: Reclass):
    if HOOKS.get("undo_begin"):
        HOOKS["undo_begin"]("按对象改「" + (b.cp or "这一笔")[:16] + "」→ " + (b.scope or ""))
    try:
        return _reclassify(b)
    finally:
        if HOOKS.get("undo_commit"):
            HOOKS["undo_commit"]()


def _reclassify(b: Reclass):
    if b.scope not in ("工作", "生活"):
        raise HTTPException(400, "请选择工作或生活")
    if not b.cp and not b.uid and not b.tx_id:
        raise HTTPException(400, "没有指定对象")
    proj = (b.new_project or b.project or "").strip()
    if HOOKS.get("norm_project"):
        proj = HOOKS["norm_project"](proj)
    note = ""
    if HOOKS.get("fix_sub"):                        # 子类防填错（按对象改：收入/支出子类都算合法）
        v = dict(scope=b.scope, type="exp", sub=b.sub, project="" if proj == "(无项目)" else proj, purpose=b.purpose)
        note = HOOKS["fix_sub"](v, any_type=True)
        b.scope, b.sub, b.purpose = v["scope"], v["sub"], v["purpose"]
        proj = v["project"] or proj
    if proj == "(无项目)" or b.scope != "工作":
        proj = ""
    if proj:
        with store.db() as c:
            if not c.execute("select 1 from projects where name=?", (proj,)).fetchone():
                c.execute("insert into projects(name,params) values(?,?)", (proj, json.dumps(store.mode_defaults(store.detect_mode(dict(name=proj))))))
        sync_projects_json()
    if b.cp.strip() and b.cp.strip() != "(无对方)":
        learned = bt.load_json(bt.LEARNED, {})
        learned[b.cp.strip().lower()] = dict(scope=b.scope, sub=b.sub.strip(), project=proj, purpose=b.purpose.strip())
        store.write_json(bt.LEARNED, learned)
    if b.tx_id and not b.uid:      # 手动记的账：先给它补一个编号，之后和其它账单一样处理
        api = ezb()
        for t in ezb_transactions(force=True):
            if str(t["id"]) == b.tx_id and not rid(t.get("comment")):
                nid = f"手动:{t['id']}"
                if HOOKS.get("undo_snap"):
                    HOOKS["undo_snap"](t)
                ezb_modify_tx(api, dict(
                    id=str(t["id"]), type=t["type"], categoryId=str(t["categoryId"]), time=t["time"], utcOffset=t["utcOffset"],
                    sourceAccountId=str(t["sourceAccountId"]), destinationAccountId=str(t.get("destinationAccountId") or 0),
                    sourceAmount=t["sourceAmount"], destinationAmount=t.get("destinationAmount", 0), hideAmount=t.get("hideAmount", False),
                    tagIds=[str(x) for x in (t.get("tagIds") or [])], pictureIds=[p["pictureId"] for p in (t.get("pictures") or [])],
                    comment=((t.get("comment") or "").strip() + f"〔ID:{nid}〕")[:255]))
                b.uid = nid
                break
        invalidate()
    rows = []
    for t in ezb_transactions(force=True):
        i = rid(t.get("comment"))
        if not i or t["type"] not in (2, 3):
            continue
        core = _strip_prefix(t["comment"]).strip()
        who = core.split(" | ")[0].strip()
        if not ((b.uid and i == b.uid) or (b.cp and who.lower() == b.cp.strip().lower())):
            continue
        if HOOKS.get("undo_snap"):
            HOOKS["undo_snap"](t)                      # 撤回用：改之前原样存下
        cur_scope, cur_sub = _scope_of(t), _sub_name(t)
        sub = b.sub.strip()
        if not sub:
            if cur_scope == b.scope:
                sub = cur_sub
            else:
                sub = ("项目回款" if t["type"] == 2 else "项目支出") if b.scope == "工作" else ("红包转账" if t["type"] == 2 else "其他")
        pre = f"【{proj}｜{b.purpose.strip()}】" if proj and b.purpose.strip() else (f"【{proj}】" if proj else (f"【｜{b.purpose.strip()}】" if b.purpose.strip() else ""))
        suf = f"〔ID:{i}〕"
        desc = pre + core[:max(0, 250 - len(pre) - len(suf))] + suf
        rows.append({"Time": datetime.fromtimestamp(t["time"], store.TZ).strftime("%Y-%m-%d %H:%M:%S"), "Type": "Income" if t["type"] == 2 else "Expense",
                     "Category": b.scope, "Sub Category": f"{b.scope}·{sub}", "Account": (t.get("sourceAccount") or {}).get("name", "微信"),
                     "Amount": f"{t['sourceAmount'] / 100:.2f}", "Tags": b.scope + (f";项目:{proj}" if proj else ""), "Description": desc})
    if not rows:
        raise HTTPException(404, "没找到对应的账单")
    res = push_rows(ezb(), rows, log=lambda *_: None)
    invalidate()
    return dict(n=len(rows), note=note, **res)



# ---------------------------------------------------------------- 借款 / 还款 / 到期提醒
import subprocess, threading


class DebtIn(BaseModel):
    name: str
    direction: str = "owe"          # owe=我欠别人（需要我还） / lent=别人欠我（等对方还）
    amount: float = 0
    borrow_date: str = ""
    due_date: str = ""
    remind_days: int = 3
    note: str = ""
    mac_reminder: int = 1           # 同时加入 macOS「提醒事项」（App 没开也会提醒）


class RepayIn(BaseModel):
    date: str = ""
    amount: float
    note: str = ""


def _debt_view(d, reps):
    paid = round(sum(r["amount"] for r in reps), 2)
    remain = round(max(d["amount"] - paid, 0), 2)
    days = None
    status = "done" if remain <= 0.005 else "normal"
    if d["due_date"]:
        try:
            days = (datetime.strptime(d["due_date"], "%Y-%m-%d").date() - date.today()).days
            if status != "done":
                status = "overdue" if days < 0 else ("soon" if days <= (d["remind_days"] or 3) else "normal")
        except ValueError:
            pass
    return dict(d, paid=paid, remain=remain, pct=round(min(paid / d["amount"], 1) * 100, 1) if d["amount"] else 0,
                days_to_due=days, status=status, repayments=reps)


def _mac_run(script, timeout=15):
    if store.DEV:
        return False, "开发沙盒不调用系统提醒"
    try:
        r = subprocess.run(["osascript", "-e", script], capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, (r.stdout or r.stderr).strip()
    except Exception as e:
        return False, str(e)


def _asq(s):
    """放进 AppleScript 双引号里的文字：转义反斜杠和引号、去掉换行，防止名字里带引号把脚本弄坏。"""
    return str(s or "").replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ").replace("\r", " ")


def _as_date(d, hour=9):
    y, m, dd = [int(x) for x in d.split("-")]
    return f"set d to (current date)\nset day of d to 1\nset year of d to {y}\nset month of d to {m}\nset day of d to {dd}\nset time of d to {hour * 3600}"


def _reminders_add(debt):
    """在 macOS『提醒事项』里建「还款提醒」列表，并在到期前 N 天和到期当天各加一条。返回 id 列表。"""
    if not debt["due_date"]:
        return []
    ids = []
    who = "还给" if debt["direction"] == "owe" else "向对方收款："
    title = f"还款：{who}{debt['name']} ¥{debt['amount']:,.2f}" if debt["direction"] == "owe" else f"收款提醒：{debt['name']} 应还我 ¥{debt['amount']:,.2f}"
    when = [(debt["due_date"], f"{title}（今天到期）")]
    if debt["remind_days"]:
        dt = datetime.strptime(debt["due_date"], "%Y-%m-%d").date() - timedelta(days=debt["remind_days"])
        if dt >= date.today():
            when.insert(0, (dt.isoformat(), f"{title}（{debt['remind_days']}天后到期）"))
    for d, name in when:
        script = f'''{_as_date(d)}
tell application "Reminders"
  if not (exists list "还款提醒") then make new list with properties {{name:"还款提醒"}}
  set r to make new reminder at end of reminders of list "还款提醒" with properties {{name:"{_asq(name)}", due date:d, remind me date:d, body:"{_asq(debt['note'])}"}}
  return id of r
end tell'''
        ok, out = _mac_run(script)
        if ok and out:
            ids.append(out)
    return ids


def _reminders_delete(ids):
    for i in ids:
        _mac_run(f'tell application "Reminders" to delete (first reminder whose id is "{i}")')


@app.get("/api/debts")
def list_debts():
    with store.db() as c:
        ds = [row(r) for r in c.execute("select * from debts order by (due_date='' ), due_date, id")]
        out = []
        for d in ds:
            reps = [row(r) for r in c.execute("select * from repayments where debt_id=? order by date desc, id desc", (d["id"],))]
            out.append(_debt_view(d, reps))
    return out


@app.get("/api/debts/summary")
def debts_summary():
    ds = list_debts()
    open_ = [d for d in ds if d["status"] != "done"]
    owe = [d for d in open_ if d["direction"] == "owe"]
    lent = [d for d in open_ if d["direction"] == "lent"]
    alerts = [dict(id=d["id"], name=d["name"], direction=d["direction"], remain=d["remain"], due_date=d["due_date"], days=d["days_to_due"], status=d["status"])
              for d in open_ if d["status"] in ("overdue", "soon")]
    # 按月的待还/待收时间线
    tl = {}
    for d in open_:
        if d["due_date"]:
            m = d["due_date"][:7]
            t = tl.setdefault(m, dict(month=m, owe=0.0, lent=0.0))
            t["owe" if d["direction"] == "owe" else "lent"] += d["remain"]
    return dict(owe_total=round(sum(d["remain"] for d in owe), 2), lent_total=round(sum(d["remain"] for d in lent), 2),
                n_owe=len(owe), n_lent=len(lent), alerts=sorted(alerts, key=lambda a: (a["days"] if a["days"] is not None else 9999)),
                timeline=[dict(v, owe=round(v["owe"], 2), lent=round(v["lent"], 2)) for _, v in sorted(tl.items())])


@app.post("/api/debts")
def add_debt(b: DebtIn):
    if not b.name.strip() or b.amount <= 0:
        raise HTTPException(400, "请填对方和金额")
    with store.db() as c:
        did = c.execute("insert into debts(name,direction,amount,borrow_date,due_date,remind_days,note,mac_reminder) values(?,?,?,?,?,?,?,?)",
                        (b.name.strip(), b.direction, b.amount, b.borrow_date or date.today().isoformat(), b.due_date, b.remind_days, b.note, b.mac_reminder)).lastrowid
    _last.debt = did
    msg = ""
    if b.mac_reminder and b.due_date:
        with store.db() as c:
            d = row(c.execute("select * from debts where id=?", (did,)).fetchone())
        ids = _reminders_add(d)
        with store.db() as c:
            c.execute("update debts set reminder_ids=? where id=?", (json.dumps(ids), did))
        msg = "已加入「提醒事项」" if ids else "（没能写入「提醒事项」，App 内仍会提醒）"
    return dict(debts=list_debts(), msg=msg)


@app.put("/api/debts/{did}")
def edit_debt(did: int, b: DebtIn):
    with store.db() as c:
        r = c.execute("select * from debts where id=?", (did,)).fetchone()
        if not r:
            raise HTTPException(404, "没有这笔")
        _reminders_delete(json.loads(r["reminder_ids"] or "[]"))
        c.execute("update debts set name=?,direction=?,amount=?,borrow_date=?,due_date=?,remind_days=?,note=?,mac_reminder=?,reminder_ids='[]',last_notified='' where id=?",
                  (b.name.strip(), b.direction, b.amount, b.borrow_date, b.due_date, b.remind_days, b.note, b.mac_reminder, did))
    if b.mac_reminder and b.due_date:
        with store.db() as c:
            d = row(c.execute("select * from debts where id=?", (did,)).fetchone())
        ids = _reminders_add(d)
        with store.db() as c:
            c.execute("update debts set reminder_ids=? where id=?", (json.dumps(ids), did))
    return dict(debts=list_debts(), msg="")


@app.delete("/api/debts/{did}")
def del_debt(did: int):
    with store.db() as c:
        r = c.execute("select reminder_ids from debts where id=?", (did,)).fetchone()
        if r:
            _reminders_delete(json.loads(r["reminder_ids"] or "[]"))
        links = [r_[0] for r_ in c.execute("select tx_uid from repayments where debt_id=? and tx_uid<>''", (did,))]
        dtx = c.execute("select tx_uid from debts where id=?", (did,)).fetchone()
        c.execute("delete from repayments where debt_id=?", (did,))
        c.execute("delete from debts where id=?", (did,))
    if HOOKS.get("drop_loan_tx"):                          # 账单那边跟着改
        for u in links + ([dtx[0]] if dtx and dtx[0] else []):
            try:
                HOOKS["drop_loan_tx"](u)
            except Exception as e:
                print("借款关联账单处理失败：", e)
    return list_debts()


@app.post("/api/debts/{did}/repay")
def repay(did: int, b: RepayIn):
    if b.amount <= 0:
        raise HTTPException(400, "金额要大于 0")
    with store.db() as c:
        _last.repay = c.execute("insert into repayments(debt_id,date,amount,note) values(?,?,?,?)", (did, b.date or date.today().isoformat(), b.amount, b.note)).lastrowid
        r = c.execute("select * from debts where id=?", (did,)).fetchone()
        paid = c.execute("select coalesce(sum(amount),0) from repayments where debt_id=?", (did,)).fetchone()[0]
        if r and paid >= r["amount"] - 0.005:           # 还清了：撤掉还没到点的提醒
            _reminders_delete(json.loads(r["reminder_ids"] or "[]"))
            c.execute("update debts set reminder_ids='[]' where id=?", (did,))
    return list_debts()


@app.delete("/api/repayments/{rid_}")
def del_repay(rid_: int):
    with store.db() as c:
        r_ = c.execute("select tx_uid from repayments where id=?", (rid_,)).fetchone()
        c.execute("delete from repayments where id=?", (rid_,))
    if r_ and r_[0] and HOOKS.get("drop_loan_tx"):
        try:
            HOOKS["drop_loan_tx"](r_[0])
        except Exception as e:
            print("还款关联账单处理失败：", e)
    return list_debts()


def _notify_loop():
    """App 开着时，每 30 分钟检查一次：到提醒日/已逾期的未还款项，发 macOS 通知（每笔每天一次）。"""
    while True:
        try:
            today = date.today().isoformat()
            for d in list_debts():
                if d["status"] in ("overdue", "soon") and d["last_notified"] != today:
                    who = "还给" if d["direction"] == "owe" else "向"
                    if d["status"] == "overdue":
                        txt = f"{who}{d['name']}的 ¥{d['remain']:,.2f} 已逾期 {-d['days_to_due']} 天"
                    else:
                        txt = f"{who}{d['name']}的 ¥{d['remain']:,.2f}，{d['days_to_due']} 天后（{d['due_date']}）到期" if d["days_to_due"] else f"{who}{d['name']}的 ¥{d['remain']:,.2f} 今天到期"
                    _mac_run(f'display notification "{_asq(txt)}" with title "CD的记账本 · {"还款" if d["direction"] == "owe" else "收款"}提醒" sound name "Glass"')
                    with store.db() as c:
                        c.execute("update debts set last_notified=? where id=?", (today, d["id"]))
        except Exception as e:
            store.log_err("还款到期提醒", e)
        time.sleep(1800)


if not store.DEV:
    threading.Thread(target=_notify_loop, daemon=True).start()



# ---------------------------------------------------------------- 下拉选项（常用项 + 你以前填过的）
DEFAULT_CATS = {"搭建部分": ["场地搭建", "展台搭建", "灯光音响", "舞台", "道具"],
                "第三方人员": ["兼职运营", "督导", "安保", "设计费", "摄影摄像", "项目助理"],
                "物料部分": ["物料采购", "快印", "物流"],
                "执行人员杂费": ["交通费", "餐补", "住宿", "业务招待"]}
DEFAULT_NAMES = ["货拉拉", "顺丰/快递", "打车费", "酒店住宿", "执行 交通费（高铁/飞机）", "客户咖啡等", "兼职奶茶饮品费用", "KT板", "物料打印", "喷绘写真", "工作牌", "矿泉水", "安保", "兼职运营人员", "督导", "设计费", "施工入场保险", "帐篷租赁", "仓储货车费用"]
UNITS = ["项", "个", "套", "趟", "人天", "天", "人", "件", "张", "米", "平米", "箱", "次"]
WORK_SUBS = ["物料搭建", "第三方人员", "设计费", "餐补", "场地费", "礼品采购", "办公用品", "税费手续费", "人员劳务", "供应商执行", "快递物流", "差旅住宿", "软件工具", "打印复印", "招待", "交通", "分红转出", "分红提成", "项目款转出", "项目支出", "项目回款"]
# 工作收入的四种：只有「项目分红」算我自己的收入；「项目回款」是项目的收入；「备用金入款」「项目报销」是公司和我之间的往来，不算收入
WORK_INC_SUBS = ["项目回款", "项目分红", "项目备用金入款", "项目报销"]
# 过手的钱（支出方向，但不是项目成本，不进成本单）：分红转出=到账的分红里替别人收的、转给别人的那部分；项目款转出=客户款先到我这，我再转给公司
# 分红提成：从「我自己那份分红」里付给别人的提成。和分红转出一样从「我的收入」里扣，但不扣「实际到账」（钱是先到了我手上、算我的那份）
PASS_SUBS = ("分红转出", "分红提成", "项目款转出")
DIV_OUT_SUBS = ("分红转出", "分红提成")
LIFE_SUBS = ["餐饮", "买菜超市", "日用百货", "服饰美妆", "休闲护理", "交通出行", "购物", "居家", "房租", "水电燃气", "通讯网络", "旅行度假", "运动健身", "学习教育", "保险", "宠物", "家人孝敬", "数码NAS网络", "娱乐订阅", "医疗健康", "烟酒", "人情往来", "红包转账", "工资薪酬", "其他", "借款往来"]
DEFAULT_PURPOSES = ["KT板制作", "物料打印", "物料采购", "货拉拉运输", "快递物流", "场地搭建", "兼职费用", "设计费", "打车", "差旅交通", "住宿", "客户招待", "备用金", "押金", "项目回款", "劳务费"]


# ---------------------------------------------------------------- 自定义子类（你自己新增的，和内置的一样能选，防填错不会拦）
CUSTOM_SUBS = os.path.join(bt.STATE, "自定义子类.json")


def custom_subs():
    d = bt.load_json(CUSTOM_SUBS, {}) or {}
    return {"工作": list(d.get("工作", [])), "生活": list(d.get("生活", []))}


def all_subs(scope):
    base = [x for x in WORK_SUBS if x not in WORK_INC_SUBS] if scope == "工作" else LIFE_SUBS
    return base + [x for x in custom_subs()[scope] if x not in base and not (scope == "工作" and x in WORK_INC_SUBS)]


class SubIn(BaseModel):
    scope: str
    name: str


def _sub_usage():
    from collections import Counter
    return Counter((_scope_of(t), _sub_name(t)) for t in ezb_transactions() if t["type"] in (2, 3))


@app.get("/api/subs")
def list_subs():
    use, cs = _sub_usage(), custom_subs()
    return {sc: [dict(name=x, custom=x in cs[sc], n=use.get((sc, x), 0)) for x in all_subs(sc)] for sc in ("工作", "生活")}


@app.post("/api/subs")
def add_sub(b: SubIn):
    name = re.sub(r"\s+", "", b.name or "").replace("·", "").strip()
    if b.scope not in ("工作", "生活"):
        raise HTTPException(400, "只能给「工作」或「生活」加子类")
    if not name or len(name) > 12:
        raise HTTPException(400, "子类名称 1–12 个字")
    if name in all_subs(b.scope):
        return list_subs()
    with store.db() as c:
        if c.execute("select 1 from projects where name=?", (name,)).fetchone():
            raise HTTPException(400, f"「{name}」是项目名，请在「项目」里选，不要当子类")
    d = custom_subs()
    d[b.scope].append(name)
    store.write_json(CUSTOM_SUBS, d)
    from api_import import ensure_project_categories, ensure_base_categories
    api = ezb()
    ensure_base_categories(api, {b.scope: [name]})
    if b.scope == "工作":
        with store.db() as c:
            names = [r["name"] for r in c.execute("select name from projects")]
        ensure_project_categories(api, names, [name])
    invalidate()
    return list_subs()


@app.delete("/api/subs")
def del_sub(scope: str, name: str):
    d = custom_subs()
    if name not in d.get(scope, []):
        raise HTTPException(400, "只能删除你自己新增的子类")
    n = _sub_usage().get((scope, name), 0)
    if n:
        raise HTTPException(400, f"还有 {n} 笔账在用「{name}」，先在账单明细里把它们改到别的子类")
    from api_import import _flat_categories
    api = ezb()
    for cat in _flat_categories(api):
        if cat["name"] == f"{scope}·{name}" and str(cat.get("parentId", "0")) != "0":
            try:
                api.call("POST", "/api/v1/transaction/categories/delete.json", {"id": str(cat["id"])})
            except Exception:
                pass
    d[scope].remove(name)
    store.write_json(CUSTOM_SUBS, d)
    invalidate()
    return list_subs()


@app.get("/api/suggest")
def suggest():
    from collections import Counter
    with store.db() as c:
        ls = [row(r) for r in c.execute("select sec,cat,name,spec,vendor,unit from lines")]
        who = [r["name"] for r in c.execute("select name from debts")]
    def top(seq, extra=(), n=40):
        cnt = Counter(x for x in seq if x)
        out = [k for k, _ in cnt.most_common(n)]
        return out + [e for e in extra if e not in out]
    cats = {sec: top([l["cat"] for l in ls if l["sec"] == sec], DEFAULT_CATS.get(sec, [])) for sec in store.SECTIONS if sec != "备用金"}
    learned = bt.load_json(bt.LEARNED, {})
    purposes = top([v.get("purpose", "") for v in learned.values()], DEFAULT_PURPOSES)
    return dict(cats=cats, names=top([l["name"] for l in ls], DEFAULT_NAMES, 60), specs=top([l["spec"] for l in ls], (), 60),
                vendors=top([l["vendor"][:30] for l in ls], (), 40), units=top([l["unit"] for l in ls], UNITS, 20),
                purposes=purposes, work_subs=all_subs("工作"), work_inc_subs=list(WORK_INC_SUBS), pass_subs=list(PASS_SUBS), life_subs=all_subs("生活"), debt_names=top(who))


# ---------------------------------------------------------------- 自动备份
AS_DIR = os.path.dirname(store.DATA)                      # ~/Library/Application Support/CD的记账本
BACKUP_DIR = os.path.join(AS_DIR, "备份")
KEEP_BACKUPS = 14


def _sqlite_copy(src, dst):
    import sqlite3
    if not os.path.exists(src):
        return False
    a, b = sqlite3.connect(src), sqlite3.connect(dst)
    with b:
        a.backup(b)
    a.close(); b.close()
    return True


BK_RE = re.compile(r"^(\d{4}-\d{2}-\d{2}_\d{4})(?:_(手动|恢复前))?$")
KEEP_MANUAL, KEEP_PRE, KEEP_MONTHS = 10, 5, 12


def _bk_kind(name):
    m = BK_RE.match(name)
    return (m.group(2) or "自动") if m else ""


def _prune_backups():
    """清旧备份。三种分开算，互不挤占：
    自动的——最近 14 天全留，更早的每个月只留最后一份（最多留 12 个月）；
    手动的——留最近 10 份；恢复前自动存的——留最近 5 份。"""
    names = sorted(d for d in os.listdir(BACKUP_DIR) if _bk_kind(d) and os.path.isdir(os.path.join(BACKUP_DIR, d)))
    drop = []
    manual = [d for d in names if _bk_kind(d) == "手动"]
    pre = [d for d in names if _bk_kind(d) == "恢复前"]
    auto = [d for d in names if _bk_kind(d) == "自动"]
    drop += manual[:-KEEP_MANUAL] + pre[:-KEEP_PRE]
    edge = (datetime.now() - timedelta(days=KEEP_BACKUPS)).strftime("%Y-%m-%d")
    old = [d for d in auto if d[:10] < edge]
    last_of_month = {}
    for d in old:
        last_of_month[d[:7]] = d
    keep_months = sorted(last_of_month)[-KEEP_MONTHS:]
    drop += [d for d in old if last_of_month.get(d[:7]) != d or d[:7] not in keep_months]
    # 改程序前存的保险副本（「改前_」开头）：只留最新 3 份，免得越积越多
    pre_change = sorted((d for d in os.listdir(BACKUP_DIR) if d.startswith("改前_")),
                        key=lambda d: os.path.getmtime(os.path.join(BACKUP_DIR, d)), reverse=True)
    drop += pre_change[3:]
    for d in drop:
        p_ = os.path.join(BACKUP_DIR, d)
        if os.path.isdir(p_):
            shutil.rmtree(p_, ignore_errors=True)
        else:
            try:
                os.remove(p_)
            except OSError:
                pass
    return drop


def do_backup(reason="自动"):
    """记账本数据库 + 项目台数据库 + 发票图片 + 分类规则/记住的判断，打包到「备份/日期时间」。"""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    name = datetime.now().strftime("%Y-%m-%d_%H%M") + ("_" + reason if reason in ("手动", "恢复前") else "")
    dst = os.path.join(BACKUP_DIR, name)
    os.makedirs(dst, exist_ok=True)
    _sqlite_copy(os.path.join(AS_DIR, "记账本", "data", "ezbookkeeping.db"), os.path.join(dst, "记账本.db"))
    _sqlite_copy(store.DB, os.path.join(dst, "项目台.db"))
    for sub in ("状态",):
        p = os.path.join(AS_DIR, sub)
        if os.path.isdir(p):
            shutil.copytree(p, os.path.join(dst, sub), dirs_exist_ok=True)
    if os.path.exists(store.CONFIG):
        shutil.copy2(store.CONFIG, dst)
        store._private(os.path.join(dst, os.path.basename(store.CONFIG)))
    # 发票图片：只增不减，放在共用的 files 目录（省空间），每份备份记一个清单
    fdst = os.path.join(BACKUP_DIR, "发票图片")
    if os.path.isdir(store.FILES):
        for root, _, fs in os.walk(store.FILES):
            for f in fs:
                if f.endswith(".t.jpg"):           # 缩略图随时能重新生成，不用备份
                    continue
                s_ = os.path.join(root, f)
                d_ = os.path.join(fdst, os.path.relpath(s_, store.FILES))
                if not os.path.exists(d_) or os.path.getsize(d_) != os.path.getsize(s_):
                    os.makedirs(os.path.dirname(d_), exist_ok=True)
                    shutil.copy2(s_, d_)
    _prune_backups()
    mirror = (store.load_config().get("backup_mirror") or "").strip()
    mirrored = ""
    if mirror:
        try:
            if os.path.isdir(mirror):
                tgt = os.path.join(os.path.expanduser(mirror), "CD的记账本备份")
                shutil.copytree(dst, os.path.join(tgt, name), dirs_exist_ok=True)
                if os.path.isdir(fdst):
                    shutil.copytree(fdst, os.path.join(tgt, "发票图片"), dirs_exist_ok=True)
                mirrored = tgt
        except Exception as e:
            store.log_err("备份另存一份", e)
            mirrored = f"失败：{e}"
    return dict(name=name, path=dst, mirrored=mirrored)


def _backup_list():
    if not os.path.isdir(BACKUP_DIR):
        return []
    out = []
    for d in sorted(os.listdir(BACKUP_DIR), reverse=True):
        p = os.path.join(BACKUP_DIR, d)
        if _bk_kind(d) and os.path.isdir(p):
            size = sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(p) for f in fs)
            out.append(dict(name=d, kind=_bk_kind(d), when=d[:10] + " " + d[11:13] + ":" + d[13:15], size_mb=round(size / 1048576, 1),
                            ok=os.path.exists(os.path.join(p, "记账本.db")) and os.path.exists(os.path.join(p, "项目台.db"))))
    return out


def _backup_loop():
    time.sleep(20)
    while True:
        try:
            bl = [b for b in _backup_list() if b["kind"] == "自动"]
            last = bl[0]["name"][:15] if bl else ""
            if not last or datetime.now() - datetime.strptime(last, "%Y-%m-%d_%H%M") > timedelta(hours=20):
                do_backup()
        except Exception as e:
            store.log_err("每天自动备份", e)
        time.sleep(3600)


if not store.DEV:
    threading.Thread(target=_backup_loop, daemon=True).start()


@app.get("/api/backups")
def list_backups():
    return dict(dir=BACKUP_DIR, keep=KEEP_BACKUPS, keep_manual=KEEP_MANUAL, mirror=store.load_config().get("backup_mirror", ""), items=_backup_list())


@app.post("/api/backups")
def backup_now():
    r = do_backup("手动")
    return dict(r, items=_backup_list())


# ---- 从备份恢复：先把现在的数据另存一份（恢复前），再把备份放回去；记账本服务会自动重启一下
def _db_check(path):
    import sqlite3
    try:
        from urllib.parse import quote
        c = sqlite3.connect("file:" + quote(path) + "?mode=ro&immutable=1", uri=True)      # immutable：备份文件不会再变，不需要旁边的临时文件
        ok = c.execute("pragma integrity_check").fetchone()[0] == "ok"
        c.close()
        return ok
    except Exception:
        return False


def _ezb_port():
    m = re.search(r":(\d+)", os.environ.get("CHAIMI_EZB_API") or "http://127.0.0.1:8090")
    return int(m.group(1)) if m else 8090


def _port_open(port):
    import socket
    s_ = socket.socket()
    s_.settimeout(0.5)
    try:
        return s_.connect_ex(("127.0.0.1", port)) == 0
    finally:
        s_.close()


def _ezb_stop():
    import signal
    pidf = os.path.join(AS_DIR, "ezb.pid")
    try:
        os.kill(int(open(pidf).read().strip()), signal.SIGTERM)
    except Exception as e:
        raise HTTPException(400, f"没能让记账本暂停（{e}）。请退出 App 重新打开后再试")
    for _ in range(40):
        if not _port_open(_ezb_port()):
            return
        time.sleep(0.25)
    raise HTTPException(400, "记账本没停下来，没有动任何数据。请退出 App 重新打开后再试")


def _ezb_start():
    import subprocess as _sp
    ez = os.environ.get("CHAIMI_EZB_DIR") or os.path.join(os.environ.get("CHAIMI_PAYLOAD") or "", "ezbookkeeping")
    ini = os.path.join(AS_DIR, "记账本", "ezbookkeeping.ini")
    logd = os.environ.get("CHAIMI_LOGDIR") or os.path.expanduser("~/Library/Logs/CD的记账本")
    os.makedirs(logd, exist_ok=True)
    p = _sp.Popen(["./ezbookkeeping", "--conf-path", ini, "server", "run"], cwd=ez, stdout=open(os.path.join(logd, "记账本.log"), "ab"),
                  stderr=_sp.STDOUT, start_new_session=True)
    open(os.path.join(AS_DIR, "ezb.pid"), "w").write(str(p.pid))
    for _ in range(40):
        if _port_open(_ezb_port()):
            return True
        time.sleep(0.25)
    return False


class RestoreIn(BaseModel):
    name: str


_restore_lock = threading.Lock()


@app.post("/api/backups/restore")
def restore_backup(b: RestoreIn):
    """把数据恢复到某一份备份。恢复前先自动把现在的数据存一份（名字带「恢复前」），后悔了可以再恢复回来。"""
    import sqlite3
    if not _bk_kind(b.name):
        raise HTTPException(400, "没有这份备份")
    src = os.path.join(BACKUP_DIR, b.name)
    s_ezb, s_xmt = os.path.join(src, "记账本.db"), os.path.join(src, "项目台.db")
    if not (os.path.exists(s_ezb) and os.path.exists(s_xmt)):
        raise HTTPException(400, "这份备份不完整（缺数据库文件），不能用来恢复")
    if not (_db_check(s_ezb) and _db_check(s_xmt)):
        raise HTTPException(400, "这份备份的数据库文件是坏的，不能用来恢复。没有动你现在的数据")
    if not _restore_lock.acquire(blocking=False):
        raise HTTPException(400, "正在恢复中，请稍等")
    try:
        pre = do_backup("恢复前")
        live = os.path.join(AS_DIR, "记账本", "data", "ezbookkeeping.db")
        _ezb_stop()
        try:
            tmp = live + ".恢复中"
            if os.path.exists(tmp):
                os.remove(tmp)
            _sqlite_copy(s_ezb, tmp)
            for ext in ("-wal", "-shm"):
                if os.path.exists(live + ext):
                    os.remove(live + ext)
            os.replace(tmp, live)
            a, d = sqlite3.connect(s_xmt), sqlite3.connect(store.DB, timeout=15)
            with d:
                a.backup(d)
            a.close(); d.close()
            st = os.path.join(src, "状态")
            if os.path.isdir(st):
                shutil.copytree(st, os.path.join(AS_DIR, "状态"), dirs_exist_ok=True)
            cf = os.path.join(src, os.path.basename(store.CONFIG))
            if os.path.exists(cf):
                shutil.copy2(cf, store.CONFIG)
                store._private(store.CONFIG)
        finally:
            started = _ezb_start()
        store.init()                                   # 老备份的库：补上后来新加的表和索引
        _api["obj"], _api["key"] = None, None
        _fx["t"] = 0
        invalidate()
        try:                                           # 让免登录入口重新登录（原来的登录凭证跟着旧数据一起换掉了）
            import urllib.request
            urllib.request.urlopen(urllib.request.Request((os.environ.get("CHAIMI_PRX") or "http://127.0.0.1:8080") + "/cd-relogin", method="POST"), timeout=5).read()
        except Exception as e:
            store.log_err("恢复后刷新免登录入口", e)
        if not started:
            raise HTTPException(400, "数据已经换回备份，但记账本没自动启动起来。请退出 App 重新打开")
        n = len(ezb_transactions(force=True))
        return dict(ok=True, name=b.name, pre=pre["name"], n=n, items=_backup_list())
    finally:
        _restore_lock.release()


@app.get("/api/errors")
def list_errors():
    """最近出过的错（程序没崩、但有一步没做成）。给「设置」页看。"""
    return dict(items=list(reversed(store.ERRORS)))


@app.get("/api/health")
def health():
    """设置页「程序状态」：记账本连得上吗、界面补丁还在不在、最近有没有出错。"""
    out = dict(ezb=False, patches=None, errors=len(store.ERRORS))
    try:
        ezb().call("GET", "/api/v1/accounts/list.json")
        out["ezb"] = True
    except Exception as e:
        out["ezb_error"] = str(getattr(e, "detail", e))
    try:
        import urllib.request
        out["patches"] = json.loads(urllib.request.urlopen((os.environ.get("CHAIMI_PRX") or "http://127.0.0.1:8080") + "/cd-patches", timeout=40).read())
    except Exception as e:
        out["patches"] = dict(ok=False, error=str(e), items=[])
    return out


@app.delete("/api/errors")
def clear_errors():
    del store.ERRORS[:]
    return dict(ok=True)


class MirrorIn(BaseModel):
    path: str = ""


@app.put("/api/backups/mirror")
def set_mirror(b: MirrorIn):
    p = os.path.expanduser(b.path.strip())
    if p and not os.path.isdir(p):
        raise HTTPException(400, f"找不到这个文件夹：{p}（NAS 要先挂载）")
    cfg = store.load_config()
    cfg["backup_mirror"] = p
    store.save_config(cfg)
    return dict(ok=True, mirror=p)


@app.post("/api/open-folder")
def open_folder(b: MirrorIn):
    import subprocess as _sp
    p = os.path.expanduser(b.path or BACKUP_DIR)
    if not p.startswith(AS_DIR) and p != store.load_config().get("backup_mirror"):
        raise HTTPException(400, "只能打开备份文件夹")
    os.makedirs(p, exist_ok=True)
    _sp.run(["open", p])
    return dict(ok=True)


@app.get("/api/pending-objects")
def pending_objects(month: str = ""):
    """还没分工作/生活的账，按对象（交易对方）合并，方便一个对象一次判断完。"""
    g = {}
    for t in ezb_transactions():
        if t["type"] not in (2, 3) or _scope_of(t) != "待确认":
            continue
        if month and _month_of(t) != month:
            continue
        cp = _strip_prefix(t.get("comment", "")).split(" | ")[0].strip() or "(无对方)"
        e = g.setdefault(cp, dict(name=cp, exp=0.0, inc=0.0, n=0, last="", subs={}, note=""))
        a = t.get("_cny", t["sourceAmount"]) / 100
        e["exp" if t["type"] == 3 else "inc"] += a
        e["n"] += 1
        d = datetime.fromtimestamp(t["time"], store.TZ).strftime("%Y-%m-%d")
        if d > e["last"]:
            e["last"] = d
            rest = _strip_prefix(t.get("comment", "")).split(" | ")
            e["note"] = " | ".join(rest[1:])[:60]
        e["subs"][_sub_name(t)] = e["subs"].get(_sub_name(t), 0) + 1
    rows = []
    for e in g.values():
        e["why"] = max(e["subs"], key=e["subs"].get)
        del e["subs"]
        e["exp"], e["inc"] = round(e["exp"], 2), round(e["inc"], 2)
        rows.append(e)
    rows.sort(key=lambda e: -(e["exp"] + e["inc"]))
    return dict(n=len(rows), total_exp=round(sum(e["exp"] for e in rows), 2), total_inc=round(sum(e["inc"] for e in rows), 2), rows=rows)


@app.post("/api/admin/project-categories")
def migrate_project_categories():
    """一次性整理：已归项目的工作账，移到记账本『项目·项目名』大类下。"""
    with store.db() as c:
        names = [r[0] for r in c.execute("select name from projects")]
    txs = ezb_transactions(force=True)
    names += sorted({_project_of(t) for t in txs if _project_of(t)} - set(names))
    from api_import import ensure_project_categories
    created = ensure_project_categories(ezb(), names)
    invalidate()
    cats = _cat_names()
    todo = []
    for t in ezb_transactions(force=True):
        if t["type"] not in (2, 3) or _scope_of(t) != "工作" or not _project_of(t):
            continue
        parent = cats.get(str((t.get("category") or {}).get("parentId") or ""), "")
        if parent != "项目·" + _project_of(t):
            todo.append(t)
    n = txedit_apply([(t, {"project": _project_of(t)}) for t in todo]) if todo else 0
    return dict(categories_created=created, moved=n, projects=len(names))


@app.get("/api/ping")
def ping():
    return dict(ok=True, ver=data_ver())



# ---------------------------------------------------------------- 账单明细（直接改记账本）
import txedit                              # noqa: E402
txedit_apply = txedit.setup(app, dict(ezb=ezb, ezb_modify_tx=ezb_modify_tx, ezb_transactions=ezb_transactions, invalidate=invalidate, _scope_of=_scope_of, _project_of=_project_of,
                       _sub_name=_sub_name, _month_of=_month_of, push_rows=push_rows, rid=rid, bt=bt, store=store,
                       sync_projects_json=sync_projects_json, hooks=HOOKS, WORK_SUBS=WORK_SUBS, WORK_INC_SUBS=WORK_INC_SUBS, PASS_SUBS=PASS_SUBS, LIFE_SUBS=LIFE_SUBS, all_subs=lambda sc: all_subs(sc),
                       add_debt=lambda b: add_debt(b), repay=lambda did, b: repay(did, b), last=_last, list_debts=lambda: list_debts(), fx_info=fx_info))

import invoices                            # noqa: E402
def _ensure_project(name):
    """按名字找项目；「项目 · 分期名」按项目算；没有就新建（和「新建项目」按钮一样）。返回 (pid, 是否新建)。"""
    name = (name or "").strip()
    if HOOKS.get("norm_project"):
        name = HOOKS["norm_project"](name)
    if not name:
        raise HTTPException(400, "请填项目名")
    with store.db() as c:
        r = c.execute("select id from projects where name=?", (name,)).fetchone()
    if r:
        return r["id"], False
    return create_project(ProjectIn(name=name))["project"]["id"], True


INV = dict(store=store, project_detail=project_detail, bt=bt, hooks=HOOKS, ensure_project=_ensure_project)
invoices.setup(app, INV)
import reimb                               # noqa: E402
reimb.setup(app, INV)
import updater                             # noqa: E402
updater.setup(app, dict(store=store))
import accounts as _accounts                 # noqa: E402
_accounts.setup(app, dict(store=store, ezb_modify_tx=ezb_modify_tx, ezb=ezb, ezb_transactions=ezb_transactions, invalidate=invalidate, view=None,
                          _project_of=_project_of, _sub_name=_sub_name, _scope_of=_scope_of, rid=rid, hooks=HOOKS))

import insights as _insights                     # noqa: E402
_insights.setup(app, dict(ezb_transactions=ezb_transactions, _scope_of=_scope_of, _sub_name=_sub_name, store=store))

import tools as _tools                           # noqa: E402
_tools.setup(app)


def _migrate_outinv_files():
    """上一版「开出去的发票」的文件单独放在 files/outinv 里；转成和成本单一样的发票格（缩略图、看大图、能删）。
    只换存放方式，金额 / 发票号 / 日期都不动；转好了旧文件才删。"""
    with store.db() as c:
        rows = c.execute("select * from out_inv where coalesce(path,'')<>''").fetchall()
        for r in rows:
            try:
                if not os.path.exists(r["path"]) or not os.path.realpath(r["path"]).startswith(os.path.realpath(store.DATA) + os.sep):
                    continue
                if not c.execute("select 1 from files where line_id=?", (-r["id"],)).fetchone():
                    data = open(r["path"], "rb").read()
                    items = INV["expand"](r["fname"] or os.path.basename(r["path"]), data) or []
                    for nm, dd in items:
                        INV["save_to_line"](c, -r["id"], "invoice", nm, dd, r["no"] or "")
                    if not items:
                        continue                        # OFD / XML 这类转不了，留着原样
                if not store.safe_rm(r["path"]):
                    continue                            # 不在本程序数据文件夹里（比如测试副本）：不动它
                c.execute("update out_inv set path='', fname='' where id=?", (r["id"],))
            except Exception as e:
                store.log_err("转换开出去的发票文件", e)


try:
    _migrate_outinv_files()
except Exception as e:
    store.log_err("转换开出去的发票文件", e)

sync_projects_json()


@app.middleware("http")
async def _no_cache_pages(request, call_next):
    """页面本身不缓存：改了功能后刷新就能看到最新版（图片/脚本库照常缓存）。"""
    if request.method not in ("GET", "HEAD", "OPTIONS"):
        _writes["n"] += 1
    resp = await call_next(request)
    p = request.url.path
    if p == "/" or p.endswith(".html"):
        resp.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    return resp


app.mount("/", StaticFiles(directory=os.path.join(HERE, "static"), html=True), name="static")


def _warm_up():
    """打开软件时在后台先把记账本里的账取好、项目列表算一遍，页面第一次打开就不用干等。
    记账本可能比这里晚一秒起来：没起来就每 0.3 秒再试，最多等 15 秒。"""
    for _ in range(50):
        try:
            ezb_transactions()      # 记账本还没起来会报错，先试这个，免得往错误记录里写一堆
            break
        except Exception:
            time.sleep(0.3)
    else:
        return
    try:
        with _lp_lock:              # 项目列表（含成本单同步，和平时打开项目列表做的一样）
            n, rows = _writes["n"], _tx_cache["rows"]
            res = _list_projects()
            _lp_warm.update(res=res, at=time.time(), w=n, rows=rows)
    except Exception as e:
        store.log_err("启动时预先算项目列表", e)


if os.environ.get("CHAIMI_NO_WARMUP") != "1":
    threading.Thread(target=_warm_up, daemon=True).start()
