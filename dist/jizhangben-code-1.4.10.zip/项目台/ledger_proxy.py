"""记账本免登录入口：8080 端口 → 记账本内部端口(8090)。
页面打开时自动带上登录状态（本机单人使用，不需要登录页）。"""
import json, os, re, time
from urllib.parse import parse_qsl, urlencode
import requests
from fastapi import FastAPI, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import Response

UP = os.environ.get("CHAIMI_EZB_API", "http://127.0.0.1:8090").rstrip("/")
CFG = os.path.join(os.environ.get("CHAIMI_DATA", os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")), "config.json")
app = FastAPI()
_tok = {"t": 0, "token": None, "user": None}
HOP = {"transfer-encoding", "content-encoding", "content-length", "connection", "keep-alive"}


def login():
    if _tok["token"] and time.time() - _tok["t"] < 3600:
        return _tok
    try:
        cfg = json.load(open(CFG, encoding="utf-8"))
        r = requests.post(UP + "/api/authorize.json", json=dict(loginName=cfg["ezb_user"], password=cfg["ezb_pass"]),
                          headers={"X-Timezone-Offset": "-480"}, timeout=15).json()
        if r.get("success"):
            _tok.update(t=time.time(), token=r["result"]["token"], user=r["result"].get("user"))
    except Exception:
        pass
    return _tok


# 「编辑交易」弹窗顶部加「快速归类」：工作/生活、子类、项目、用途都能直接打字或下拉选；可新增/删除自己的子类
EDIT_JS = r"""<style>
.cdq{--fg:rgb(var(--v-theme-on-surface,33,33,33));--bg:rgb(var(--v-theme-surface,255,255,255));--ln:rgba(var(--v-theme-on-surface,33,33,33),.18);--mu:rgba(var(--v-theme-on-surface,33,33,33),.55);--ac:#c8823f;
  border:1px solid rgba(200,130,63,.35);border-radius:12px;padding:14px 16px 12px;margin:0 0 18px;background:rgba(200,130,63,.05);font-size:14px;color:var(--fg)}
.cdq h4{margin:0 0 12px;font-size:15px;font-weight:600;color:var(--ac);display:flex;gap:10px;align-items:baseline;flex-wrap:wrap}
.cdq h4 span{font-weight:400;font-size:12px;color:var(--mu)}
.cdq .g{display:grid;grid-template-columns:120px minmax(0,1fr) minmax(0,1.3fr) minmax(0,1fr) auto;gap:10px;align-items:end}
.cdq label.t{display:block;font-size:12px;color:var(--mu);margin:0 0 5px;line-height:16px;height:16px;white-space:nowrap}
.cdq input,.cdq select{width:100%;height:40px;box-sizing:border-box;padding:0 10px;border:1px solid var(--ln);border-radius:8px;background:var(--bg);color:var(--fg);font-size:14px;line-height:38px;margin:0}
.cdq select{appearance:none;-webkit-appearance:none;padding-right:28px;cursor:pointer;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%23999'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 10px center}
.cdq input::placeholder{color:var(--mu);opacity:.8}
.cdq input:focus,.cdq select:focus{outline:none;border-color:var(--ac);box-shadow:0 0 0 3px rgba(200,130,63,.15)}
.cdq button.s{height:40px;padding:0 18px;border:0;border-radius:8px;background:var(--ac);color:#fff;font-weight:600;font-size:14px;cursor:pointer;white-space:nowrap}
.cdq button.s:hover{filter:brightness(1.06)}.cdq button.s:disabled{opacity:.5}
.cdq .msg{font-size:12px;margin-top:8px;color:var(--ac)}.cdq .msg:empty{display:none}
.cdq .w{position:relative}
.cdq .dd{position:absolute;left:0;min-width:100%;top:100%;z-index:9999;max-height:280px;overflow:auto;background:var(--bg);color:var(--fg);border:1px solid var(--ln);border-radius:8px;margin-top:4px;padding:4px;display:none;box-shadow:0 8px 24px rgba(0,0,0,.14)}
.cdq .dd div{padding:7px 10px;border-radius:6px;cursor:pointer;display:flex;justify-content:space-between;gap:12px;white-space:nowrap;line-height:20px}
.cdq .dd div:hover{background:rgba(200,130,63,.13)}.cdq .dd .n{color:var(--mu);font-size:12px}
.cdq .dd .add{color:var(--ac);font-weight:600}.cdq .dd .x{color:var(--mu);font-size:12px}.cdq .dd .x:hover{color:#d9534f}
.cdq .off{opacity:.4;pointer-events:none}
.cdq .iv{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:12px;padding-top:12px;border-top:1px dashed var(--ln)}
.cdq .iv .lb{font-size:12px;color:var(--mu);width:120px;flex:none}
.cdq .iv .ths{display:inline-flex;gap:6px;flex-wrap:wrap;align-items:center}.cdq .iv .ths:empty{display:none}
.cdq .iv .th{position:relative;display:block;flex:none;width:48px;height:48px;border:1px solid var(--ln);border-radius:6px;overflow:hidden;cursor:zoom-in;background:var(--bg)}
.cdq .iv .th img{width:100%;height:100%;object-fit:cover}.cdq .iv .th b{position:absolute;left:0;bottom:0;font-size:9px;line-height:12px;padding:0 3px;background:rgba(0,0,0,.6);color:#fff;font-weight:600}
.cdq .iv .up{height:36px;display:inline-flex;align-items:center;padding:0 14px;border:1px dashed var(--ac);border-radius:8px;color:var(--ac);cursor:pointer;font-size:13px;font-weight:600}
.cdq .iv .up:hover{background:rgba(200,130,63,.08)}.cdq .iv .tip{font-size:12px;color:var(--mu)}
.cdq .ivp{border-top:0;margin-top:6px;padding-top:0}.cdq .ivp select{height:32px;padding:0 8px;border:1px solid var(--ln);border-radius:8px;background:var(--bg);color:var(--fg)}
.cdq .iv2{border-top:0;margin-top:2px;padding-top:6px}
.cdq.drag{border-color:var(--ac);background:rgba(200,130,63,.12)}
.cdq .ivl select,.cdq .ivl input{height:34px;width:auto;min-width:120px}.cdq .ivl .st{color:var(--ac)}.cdq .ivl .s2{height:34px;padding:0 14px;border:1px solid var(--ln);border-radius:8px;background:var(--bg);color:var(--fg);cursor:pointer}
.cdq .msg a{color:var(--ac);text-decoration:underline;cursor:pointer;margin-left:8px}
.cdq .iv .mail{height:36px;display:inline-flex;align-items:center;padding:0 12px;border:1px solid var(--ln);border-radius:8px;color:var(--fg);cursor:pointer;font-size:13px}
.cdq .iv .mail:hover{border-color:var(--ac);color:var(--ac)}
.cdq .ipk{flex-basis:100%;max-height:300px;overflow:auto;border:1px solid var(--ln);border-radius:8px;background:var(--bg);padding:6px}
.cdq .ipk .it{display:flex;align-items:center;gap:10px;padding:6px 8px;border-radius:6px;cursor:pointer}.cdq .ipk .it:hover{background:rgba(200,130,63,.12)}
.cdq .ipk .it img{width:40px;height:40px;object-fit:cover;border-radius:4px;border:1px solid var(--ln)}.cdq .ipk .it .a{font-weight:600;min-width:80px;text-align:right}
.cdq .ipk .it .m{flex:1;min-width:0;font-size:12px;color:var(--mu);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.cdq .ipk .hit{color:var(--ac);font-size:11px;font-weight:600}
</style><script>(function(){
const API='/cd-api/';let SUBS=null,PROJ=[],PUR=[];
const j=(u,o)=>fetch(API+u,o).then(async r=>{const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.detail||('出错了 '+r.status));return d});
const J=(m,b)=>({method:m,headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
async function loadLists(){const [s,p,g]=await Promise.all([j('subs'),j('project-names'),j('suggest')]);SUBS=s;PROJ=p;PUR=g.purposes||[]}
function combo(inp,getItems,opt){const dd=document.createElement('div');dd.className='dd';inp.parentNode.appendChild(dd);let typed=false;
  function render(){const q=typed?inp.value.trim().toLowerCase():'';const all=getItems();const it=q?all.filter(x=>x.name.toLowerCase().includes(q)):all;dd.innerHTML='';
    it.slice(0,200).forEach(x=>{const d=document.createElement('div');const t=document.createElement('span');t.textContent=x.name;if(x.n!=null){const c=document.createElement('span');c.className='n';c.textContent=x.n+' 笔';t.appendChild(document.createTextNode(' '));t.appendChild(c)}d.appendChild(t);
      if(x.custom&&opt&&opt.del){const k=document.createElement('span');k.className='x';k.textContent='删除';k.title='删除这个自己新增的子类';k.onmousedown=e=>{e.preventDefault();e.stopPropagation();opt.del(x.name)};d.appendChild(k)}
      d.onmousedown=e=>{e.preventDefault();inp.value=x.name;dd.style.display='none';inp.dispatchEvent(new Event('change'))};dd.appendChild(d)});
    const v=inp.value.trim();if(opt&&opt.add&&v&&typed&&!all.some(x=>x.name===v)){const d=document.createElement('div');d.className='add';d.textContent='＋ 新增子类「'+v+'」';d.onmousedown=e=>{e.preventDefault();dd.style.display='none';opt.add(v)};dd.appendChild(d)}
    dd.style.display=dd.children.length?'block':'none'}
  inp.addEventListener('focus',()=>{typed=false;render()});inp.addEventListener('click',()=>{if(dd.style.display!=='block'){typed=false;render()}});inp.addEventListener('input',()=>{typed=true;render()});inp.addEventListener('blur',()=>setTimeout(()=>dd.style.display='none',150));return render}
async function build(host,id){const box=document.createElement('div');box.className='cdq';box.dataset.id=id;
  box.innerHTML='<h4>快速归类 <span>直接打字或下拉选；保存后项目台、成本单一起更新（这里改归类，下面的「保存」用来改金额/时间等）</span></h4><div class="g">'+
   '<div><label class="t">工作/生活</label><select class="sc"><option>生活</option><option>工作</option><option>待确认</option></select></div>'+
   '<div class="w"><label class="t">子类</label><input class="sb" placeholder="选或输入新的"></div>'+
   '<div class="w pj"><label class="t">项目（只有工作）</label><input class="pr" placeholder="选或输入新项目"></div>'+
   '<div class="w"><label class="t">用途</label><input class="pu" placeholder="选或自己写"></div>'+
   '<div><label class="t">&nbsp;</label><button class="s">保存归类</button></div></div>'+
   '<div class="iv ivl"><span class="lb">借款 / 还款</span><span class="lst" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;flex:1"></span></div>'+
   '<div class="iv ivr" style="display:none"><span class="lb">打车路线</span><input class="rf" placeholder="起点" style="width:160px"><span style="margin:0 6px">→</span><input class="rt" placeholder="终点" style="width:160px"><span class="tip">填了会写进用途，如「打车（公司→场馆）」，成本单里也能看到</span></div>'+
   '<div class="iv ivp" style="display:none"><span class="lb">付款情况</span><select class="py" style="width:240px"><option value="已付">已付（我自己垫付）</option><option value="备用金垫付">备用金垫付（用公司备用金）</option></select><span class="tip">账户照实选（钱从哪出就选哪）；这里决定成本单里记「已付」还是「备用金垫付」</span></div>'+
   '<div class="iv" data-k="invoice"><span class="lb">发票</span><span class="ths"></span><a class="mail" title="从 QQ 邮箱收到的 / 发票夹里选">📧 从邮箱 / 发票夹选</a><label class="up">＋ 上传发票<input type="file" multiple accept="image/*,application/pdf,.pdf,.heic,.zip" style="display:none"></label><span class="tip"></span></div>'+
   '<div class="iv iv2" data-k="trip" style="display:none"><span class="lb">行程单</span><span class="ths"></span><a class="mail" title="从 QQ 邮箱收到的 / 发票夹里选">📧 从邮箱 / 发票夹选</a><label class="up">＋ 上传行程单<input type="file" multiple accept="image/*,application/pdf,.pdf,.heic,.zip" style="display:none"></label><span class="tip"></span></div><div class="msg"></div>';
  host.parentNode.insertBefore(box,host);
  const $=c=>box.querySelector(c),sc=$('.sc'),sb=$('.sb'),pr=$('.pr'),pu=$('.pu'),msg=$('.msg'),btn=$('.s');
  let v;try{if(!SUBS)await loadLists();v=await j('tx/one/'+id)}catch(e){msg.textContent='⚠ '+e.message;return}
  const isInc=v.type==='inc';
  const subsOf=()=>{const s=sc.value;if(s==='待确认')return[];if(isInc)return(s==='工作'?['项目备用金入款','项目分红','项目回款']:['工资薪酬','红包转账','还款退款','理财利息','其他收入']).map(n=>({name:n}));return SUBS[s]||[]};
  const RT=x=>{const m=(x||'').match(/^(.*?)（([^（）]*?)→([^（）]*?)）$/);return m?{b:m[1],f:m[2],t:m[3]}:{b:x||'',f:'',t:''}};
  const rf=$('.rf'),rt=$('.rt'),ivr=$('.ivr'),CAB=/打车|出租|滴滴|网约车|曹操|T3|花小猪|首汽|如祺|享道|嘀嗒|快车|专车|车费|的士/;
  const r0=RT(v.purpose);sc.value=v.scope;sb.value=v.sub;pr.value=v.project;pu.value=r0.b;rf.value=r0.f;rt.value=r0.t;
  const syncR=()=>{ivr.style.display=(isInc?false:CAB.test(pu.value+' '+(v.who||'')+' '+sb.value)||rf.value||rt.value)?'':'none'};syncR();pu.addEventListener('input',syncR);pu.addEventListener('change',syncR);
  const py=$('.py'),ivp=$('.ivp');py.value=v.pay||'已付';
  const syncPj=()=>{$('.pj').classList.toggle('off',sc.value!=='工作');if(sc.value!=='工作')pr.value='';ivp.style.display=(sc.value==='工作'&&pr.value.trim()&&!isInc)?'':'none'};syncPj();pr.addEventListener('change',syncPj);pr.addEventListener('input',syncPj);
  sc.onchange=()=>{syncPj();sb.value=''};pr.onchange=()=>{if(pr.value.trim()&&sc.value!=='工作')sc.value='工作'};
  const rs=combo(sb,subsOf,isInc?null:{add:async n=>{try{SUBS=await j('subs',J('POST',{scope:sc.value==='待确认'?'生活':sc.value,name:n}));sb.value=n;msg.textContent='已新增子类「'+n+'」，以后可直接选（记账本分类里刷新页面后也会有）'}catch(e){msg.textContent='⚠ '+e.message}},
    del:async n=>{if(!confirm('删除子类「'+n+'」？'))return;try{SUBS=await j('subs?scope='+encodeURIComponent(sc.value)+'&name='+encodeURIComponent(n),{method:'DELETE'});if(sb.value===n)sb.value='';msg.textContent='已删除「'+n+'」';rs()}catch(e){msg.textContent='⚠ '+e.message}}});
  combo(pr,()=>PROJ.map(n=>({name:n})));combo(pu,()=>PUR.map(n=>({name:n})));
  const uid=v.uid||('ezb:'+id);const NM={invoice:'发票',trip:'行程单'};const rows={};box.querySelectorAll('.iv[data-k]').forEach(r=>rows[r.dataset.k]=r);
  const TAXI=/打车|出租|滴滴|网约车|曹操|高德|T3|花小猪|首汽|如祺|享道|嘀嗒|快车|专车|车费|用车|交通|货拉拉|快狗|差旅/;let last={files:[],inbox:[]};
  const tripOn=()=>TAXI.test(sb.value+' '+pu.value+' '+(v.who||''))||last.files.concat(last.inbox).some(f=>f.kind==='trip');
  function showInv(d){last=d;Object.keys(rows).forEach(k=>{const r=rows[k],ths=r.querySelector('.ths'),tip=r.querySelector('.tip');ths.innerHTML='';
      const fs=(d.files||[]).filter(f=>(f.kind||'invoice')===k),ib=(d.inbox||[]).filter(f=>(f.kind||'invoice')===k);
      fs.forEach(f=>{const a=document.createElement('a');a.className='th';a.href=API+'files/'+f.id+'/orig';a.target='_blank';a.title=f.name+'（已在「'+f.project+'」成本单）';
        a.innerHTML='<img src="'+API+'files/'+f.id+'?thumb=1">'+(f.pdf?'<b>PDF</b>':'');ths.appendChild(a)});
      ib.forEach(f=>{const a=document.createElement('a');a.className='th';a.href=API+'inbox/'+f.id+'/orig';a.target='_blank';a.title=f.name+'（在发票夹，这笔进了成本单会自动配上）';
        a.innerHTML='<img src="'+API+'inbox/'+f.id+'/page/0?thumb=1">'+(f.pdf?'<b>PDF</b>':'');ths.appendChild(a)});
      tip.textContent=(fs.length||ib.length)?(fs.length?'已放进「'+fs[0].project+'」成本单':'已存进发票夹，这笔进了项目成本单后自动配上')+' · 点缩略图看原件':'截图、照片、PDF 都行；也可以拖进来，鼠标停在这行按 ⌘V 粘贴'});
    rows.trip.style.display=tripOn()?'':'none'}
  showInv(last);sb.addEventListener('change',()=>showInv(last));sb.addEventListener('input',()=>showInv(last));pu.addEventListener('input',()=>showInv(last));pu.addEventListener('change',()=>showInv(last));
  j('tx-invoices?uid='+encodeURIComponent(uid)).then(showInv).catch(()=>{});
  async function upInv(files,k){files=[...files].filter(f=>f&&f.size);if(!files.length)return;const fd=new FormData();fd.append('uid',uid);fd.append('amount',v.amount);fd.append('date',v.date);fd.append('who',v.who||'');fd.append('kind',k);
    files.forEach((f,i)=>fd.append('files',f,f.name||('截图'+(i+1)+'.png')));msg.textContent='上传中…';
    try{const d=await j('tx-invoices',{method:'POST',body:fd});showInv(d);msg.textContent='✓ '+NM[k]+'已上传 '+d.n+' 个'+(d.dup?'（'+d.dup+' 个之前传过，跳过）':'')+(d.to_line?'，已放进成本单':'，已存进发票夹')}catch(e){msg.textContent='⚠ '+e.message}}
  async function pickFrom(k,r){const old=r.querySelector('.ipk');if(old){old.remove();return}
    const box_=document.createElement('div');box_.className='ipk';box_.textContent='读取发票夹…';r.appendChild(box_);
    try{const d=await j('inbox');const NM2={invoice:'发票',trip:'行程单'};
      const its=(d.items||[]).filter(x=>(x.kind||'invoice')===k).map(x=>({x,da:Math.abs((x.amount||0)-v.amount),dd:Math.abs((new Date((x.inv_date||x.mdate||'').slice(0,10))-new Date(v.date))/864e5)||999}))
        .sort((a,b)=>(a.da<0.011?0:1)-(b.da<0.011?0:1)||a.dd-b.dd).slice(0,40);
      box_.innerHTML='';if(!its.length){box_.textContent='发票夹里没有还没用的'+NM2[k]+'（关联 QQ 邮箱后会自动收；也可以在项目台「发票夹」里上传）';return}
      its.forEach(({x,da})=>{const it=document.createElement('div');it.className='it';
        it.innerHTML='<img src="'+API+'inbox/'+x.id+'/page/0?thumb=1"><span class="a">¥'+(x.amount||0).toFixed(2)+'</span><span class="m"></span>'+(da<0.011?'<span class="hit">金额对得上</span>':'');
        it.querySelector('.m').textContent=[(x.inv_date||x.mdate||'').slice(0,10),x.seller||x.subject||x.name].filter(Boolean).join(' · ');
        it.onclick=async()=>{msg.textContent='放进去…';try{const r2=await j('tx-invoices/pick',J('POST',{uid,inv_id:x.id,who:v.who||''}));box_.remove();showInv(r2);msg.textContent='✓ 已选'+NM2[k]+(r2.to_line?'，已放进成本单':'，这笔进了成本单会自动配上')}catch(e){msg.textContent='⚠ '+e.message}};
        box_.appendChild(it)})}catch(e){box_.textContent='⚠ '+e.message}}
  Object.keys(rows).forEach(k=>{const a=rows[k].querySelector('.mail');if(a)a.onclick=()=>pickFrom(k,rows[k])});
  let reloadT=null;
  async function offerUndo(prefix){try{const u=await j('undo/last');if(!u||!u.id)return;const a=document.createElement('a');a.textContent='撤回';a.onclick=async()=>{clearTimeout(reloadT);try{await j('undo/'+u.id,{method:'POST'});msg.textContent='已撤回：'+u.label+'，1 秒后刷新';setTimeout(()=>location.reload(),1000)}catch(e){msg.textContent='⚠ '+e.message}};msg.appendChild(a)}catch(e){}}
  const ivl=$('.ivl'),lst=ivl.querySelector('.lst');
  const el=(tag,props,txt)=>{const e=document.createElement(tag);Object.assign(e,props||{});if(txt!=null)e.textContent=txt;return e};
  async function loanUI(){let DEBTS=[];try{DEBTS=await j('debts')}catch(e){}
    const u2=v.uid||('手动:'+id);let link=null;
    for(const d of DEBTS){if(d.tx_uid===u2){link={k:'debt',d};break}if((d.repayments||[]).some(x=>x.tx_uid===u2)){link={k:'repay',d};break}}
    lst.innerHTML='';
    if(link){const d=link.d;const st=d.status==='done'?'已还清':(d.direction==='owe'?'待还款（我还给'+d.name+'）':'待收回（'+d.name+'还我）');
      lst.appendChild(el('span',{},(link.k==='debt'?(d.direction==='owe'?'借入':'借出'):'还款')+' · '+d.name+' · 借 ¥'+Number(d.amount).toFixed(2)+'，已还 ¥'+Number(d.paid).toFixed(2)));
      lst.appendChild(el('b',{className:'st'},st));
      if(d.status!=='done'){const b=el('button',{className:'s',style:'height:34px'},d.direction==='owe'?'我已还款':'对方已还款');
        b.onclick=async()=>{if(!confirm((d.direction==='owe'?'还给 ':'收回 ')+d.name+' ¥'+Number(d.remain).toFixed(2)+'，记为已还款？\n借款变成「已还清」，账单里补一笔还款（不算收支）'))return;
          try{await j('debts/'+d.id+'/settle',J('POST',{}));msg.textContent='✓ 已记为已还款，账单里补了一笔还款';offerUndo();loanUI()}catch(e){msg.textContent='⚠ '+e.message}};
        const pa=el('input',{type:'number',step:'0.01',placeholder:'还一部分：金额（还剩 ¥'+Number(d.remain).toFixed(2)+'）',style:'width:220px'});
        const pb=el('button',{className:'s2'},'还一部分');
        pb.onclick=async()=>{const a=+pa.value;if(!(a>0)){msg.textContent='请填这次还了多少';return}if(a>d.remain+0.005){msg.textContent='比还剩的 ¥'+Number(d.remain).toFixed(2)+' 多';return}
          try{await j('debts/'+d.id+'/settle',J('POST',{amount:a}));msg.textContent='✓ 已记还款 ¥'+a.toFixed(2)+'，账单里补了一笔（不算收支）';offerUndo();loanUI()}catch(e){msg.textContent='⚠ '+e.message}};
        lst.appendChild(pa);lst.appendChild(pb);b.textContent+=('（全部）');lst.appendChild(b)}
      lst.appendChild(el('span',{className:'tip'},'详情在项目台「数据看板 → 借款 / 还款」'));return}
    const modes=isInc?[['','不是借款'],['borrow','别人借给我'],['repay','别人还我的钱']]:[['','不是借款'],['lend','我借给别人'],['repay','我还别人的钱']];
    const ms=el('select');modes.forEach(m=>ms.appendChild(el('option',{value:m[0]},m[1])));lst.appendChild(ms);
    const nm=el('input',{placeholder:'对方',value:(v.who||'').split(' | ')[0].replace(/[（(].*$/,'').trim().slice(0,20)});
    const due=el('input',{type:'date',title:'约定还款日（可不填，填了到期提醒）'});
    const ds=el('select');const sv=el('button',{className:'s',style:'height:34px'},'保存借款 / 还款');
    const fill=()=>{const m=ms.value;nm.style.display=due.style.display=(m==='lend'||m==='borrow')?'':'none';ds.style.display=m==='repay'?'':'none';sv.style.display=m?'':'none';
      ds.innerHTML='';const want=isInc?'lent':'owe';const ok=DEBTS.filter(d=>d.status!=='done'&&d.direction===want);
      ds.appendChild(el('option',{value:0},ok.length?'— 还的是哪一笔 —':'还没有对应的借款记录'));ok.forEach(d=>ds.appendChild(el('option',{value:d.id},d.name+' · 借 ¥'+Number(d.amount).toFixed(2)+' · 还剩 ¥'+Number(d.remain).toFixed(2))))};
    ms.onchange=fill;[nm,due,ds,sv].forEach(x=>lst.appendChild(x));fill();
    sv.onclick=async()=>{const m=ms.value;if(m==='repay'&&!+ds.value){msg.textContent='请选还的是哪一笔借款';return}if(m!=='repay'&&!nm.value.trim()){msg.textContent='请填对方';return}
      try{await j('tx/'+id+'/loan',J('POST',{mode:m,name:nm.value.trim(),due_date:due.value,debt_id:+ds.value||0}));msg.textContent='✓ 已保存'+(m==='repay'?'还款':'借款')+'，并关联这笔账（这笔归到「生活·借款往来」，不算收支），4 秒后刷新列表';offerUndo();reloadT=setTimeout(()=>location.reload(),4000)}catch(e){msg.textContent='⚠ '+e.message}};
    if(isInc){const ab=el('button',{className:'s2',title:'公司打给你办项目的钱：不算你的收入，算进项目的备用金'},'设为项目备用金入款');
      ab.onclick=()=>{sc.value='工作';syncPj();sb.value='项目备用金入款';msg.textContent='已填好「工作 · 项目备用金入款」：再选项目，点「保存归类」';pr.focus()};lst.appendChild(ab)}}
  loanUI();
  let hov='invoice';
  Object.keys(rows).forEach(k=>{const r=rows[k],fin=r.querySelector('input');fin.onchange=()=>{upInv(fin.files,k);fin.value=''};r.addEventListener('mouseenter',()=>hov=k);
    r.addEventListener('dragover',e=>{e.preventDefault();e.stopPropagation();r.style.background='rgba(200,130,63,.12)'});r.addEventListener('dragleave',()=>r.style.background='');
    r.addEventListener('drop',e=>{e.preventDefault();e.stopPropagation();r.style.background='';upInv(e.dataTransfer.files,k)})});
  box.addEventListener('dragover',e=>{e.preventDefault();box.classList.add('drag')});box.addEventListener('dragleave',()=>box.classList.remove('drag'));
  box.addEventListener('drop',e=>{e.preventDefault();box.classList.remove('drag');upInv(e.dataTransfer.files,'invoice')});
  const onPaste=e=>{if(!document.body.contains(box)){document.removeEventListener('paste',onPaste);return}const fs=[...(e.clipboardData||{}).files||[]];if(fs.length){e.preventDefault();upInv(fs,hov)}};
  document.addEventListener('paste',onPaste);
  btn.onclick=async()=>{btn.disabled=true;msg.textContent='保存中…';
    try{const f=rf.value.trim(),t=rt.value.trim(),pb=RT(pu.value.trim()).b;const body={scope:sc.value,sub:sb.value.trim(),purpose:(f||t)?((pb||'打车')+'（'+f+'→'+t+'）'):pb};if(sc.value==='工作')body.project=pr.value.trim()||'(无项目)';if(ivp.style.display!=='none'&&py.value!==(v.pay||'已付'))body.pay=py.value;
      const r=await j('tx/'+id,J('PUT',body));sc.value=r.scope;sb.value=r.sub;pr.value=r.project||'';{const q=RT(r.purpose||'');pu.value=q.b;rf.value=q.f;rt.value=q.t}
      msg.textContent='✓ 已保存'+(r.note?'。'+r.note:'')+'，4 秒后刷新列表';offerUndo();reloadT=setTimeout(()=>location.reload(),4000)}
    catch(e){msg.textContent='⚠ '+e.message;btn.disabled=false}}}
function scan(){const id=window.__cdTxId;document.querySelectorAll('.v-overlay--active .v-card').forEach(card=>{
  const t=(card.querySelector('.v-card-title,.text-h5,.text-h4')||{}).innerText||'';if(t.indexOf('编辑交易')<0&&t.indexOf('交易详情')<0)return;
  const old=card.querySelector('.cdq');if(old&&old.dataset.id===id)return;if(old)old.remove();if(!id)return;
  const lab=[...card.querySelectorAll('label')].find(l=>/金额/.test(l.innerText||''));if(!lab)return;
  let host=lab.closest('.v-input');if(host&&host.parentElement&&host.parentElement.classList.contains('v-col'))host=host.parentElement.closest('.v-row')||host;if(!host)return;build(host,id)})}
let pend=false;new MutationObserver(()=>{if(pend)return;pend=true;setTimeout(()=>{pend=false;try{scan()}catch(e){}},200)}).observe(document.documentElement,{childList:true,subtree:true});
})();</script>"""

# 「添加交易 / 编辑交易」：金额下面加「币种」（外币按汇率折成账户币种填进金额，描述里注明原币）
EDIT_JS += r"""<style>
.cdx{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin:-6px 0 14px;font-size:13px;color:rgba(255,255,255,.7)}
.cdx .lb{min-width:44px}.cdx select,.cdx input{height:32px;border:1px solid rgba(255,255,255,.25);border-radius:6px;background:transparent;color:inherit;padding:0 8px;font-size:13px}
.cdx select option{background:#222}.cdx input{width:120px}.cdx .ok{color:#d39a55}
.cdx .ch{height:30px;padding:0 12px;border:1px solid rgba(255,255,255,.22);border-radius:15px;background:transparent;color:inherit;cursor:pointer;font-size:13px;white-space:nowrap}
.cdx .ch:hover{border-color:#d39a55}.cdx .ch.on{background:#c8823f;border-color:#c8823f;color:#fff}.cdx .ch i{font-style:normal;opacity:.7;margin-left:4px}
.v-theme--light .cdx{color:rgba(0,0,0,.7)}.v-theme--light .cdx .ch,.v-theme--light .cdx select,.v-theme--light .cdx input{border-color:rgba(0,0,0,.2)}.v-theme--light .cdx select option{background:#fff}
</style><script>(function(){
const W=t=>new Promise(r=>setTimeout(r,t));
let ACC=null,RT=null,SYM={};
async function load(){if(ACC&&Date.now()-load.t<30000)return;load.t=Date.now();
  const [a,r]=await Promise.all([fetch('/cd-api/accounts').then(x=>x.json()),fetch('/cd-api/accounts/rates').then(x=>x.json())]);ACC=a.accounts||[];RT=r.rates||{};SYM=r.sym||{}}
const rate=c=>{if(c==='CNY')return 1;const a=ACC.find(x=>x.currency===c&&x.rate);return (a&&a.my_rate&&a.rate)||RT[c]||(a&&a.rate)||0};
const fmt=n=>Number(n).toLocaleString('zh-CN',{minimumFractionDigits:2,maximumFractionDigits:2});
function setVal(el,v){el.focus();el.value=v;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));el.blur()}
const fieldOf=(card,re)=>{const l=[...card.querySelectorAll('label')].find(l=>re.test((l.innerText||'').trim()));return l&&l.closest('.v-input')};
const accName=card=>{const f=fieldOf(card,/^账户$/);return f?(f.querySelector('.v-select__selection,.v-field__input')||{}).innerText.trim():''};
function build(card){if(card.querySelector('.cdx'))return;const amt=fieldOf(card,/^(支出|收入)金额$/),acf=fieldOf(card,/^账户$/);if(!amt||!acf)return;
  const curs=[...new Set(['CNY',...ACC.map(x=>x.currency),'USD','HKD','EUR','JPY','GBP'])].filter(c=>c==='CNY'||RT[c]||ACC.some(x=>x.currency===c&&x.rate));
  const cr=document.createElement('div');cr.className='cdx';cr.innerHTML='<span class="lb">币种</span><select class="cu">'+curs.map(c=>'<option value="'+c+'">'+(SYM[c]||'')+' '+c+'</option>').join('')+'</select><span class="fx" style="display:none">原币金额 <input class="oa" inputmode="decimal" placeholder="例如 32.8"> <span class="ok"></span></span><span class="tip"></span>';
  (amt.closest('.v-col')||amt).after(cr);
  const cu=cr.querySelector('.cu'),fx=cr.querySelector('.fx'),oa=cr.querySelector('.oa'),ok=cr.querySelector('.ok'),tip=cr.querySelector('.tip');let lastAcc=null,touched=false;
  const acur=()=>{const a=ACC.find(x=>x.name===accName(card));return a?a.currency:'CNY'};
  function calc(){const c=cu.value,ac=acur();const same=c===ac;fx.style.display=same?'none':'';tip.textContent=same?'（和账户「'+accName(card)+'」同币种，直接填上面的金额）':'';if(same){ok.textContent='';return}
    const r1=rate(c),r2=rate(ac),v=parseFloat(oa.value);if(!(r1&&r2)){ok.textContent='没有 '+c+' 的汇率';return}
    const k=r1/r2;if(!(v>0)){ok.textContent='1 '+c+' = '+(SYM[ac]||'')+k.toFixed(4)+' '+ac;return}
    const out=Math.round(v*k*100)/100;setVal(amt.querySelector('input'),String(out));
    const ta=card.querySelector('textarea');if(ta){const s=(ta.value||'').replace(/（[A-Z]{3} [\d.,]+）$/,'');setVal(ta,s+'（'+c+' '+v.toFixed(2)+'）')}
    ok.textContent='→ 已折成 '+(SYM[ac]||'')+fmt(out)+' 填入金额（1 '+c+' = '+(SYM[ac]||'')+k.toFixed(4)+'），描述里注明了原币'}
  cu.onchange=()=>{touched=true;calc()};oa.oninput=calc;
  function tick(){if(!card.isConnected)return clearInterval(tm);const n=accName(card);if(n!==lastAcc){lastAcc=n;if(!touched)cu.value=acur();calc()}}
  const tm=setInterval(tick,400);tick()}
async function scan(){const cards=[...document.querySelectorAll('.v-dialog.v-overlay--active .v-card')].filter(c=>{const t=(c.querySelector('.v-card-title')||{}).innerText||'';return /添加交易|编辑交易/.test(t)&&!c.querySelector('.cdx')});
  if(!cards.length)return;try{await load()}catch(e){return}cards.forEach(c=>{try{build(c)}catch(e){console.warn('cdx',e)}})}
let pend=false;new MutationObserver(()=>{if(pend)return;pend=true;setTimeout(()=>{pend=false;scan()},250)}).observe(document.documentElement,{childList:true,subtree:true});
})();</script>"""


# 交易列表只改「显示」，不改数据：和项目台「账单明细」一个口径
#   分类=工作/生活·子类；「标签」列改成「项目 / 用途」；「描述」列去掉〔ID:…〕编号和【项目｜用途】前缀，只留对象/备注
LIST_JS = r"""<style>
.cd-hide-tags .transaction-tag{display:none!important}
td.cd-desc{font-size:0!important}td.cd-desc>.cd-v{font-size:14px}
td.cd-hide-tags{max-width:260px;width:260px}.cd-pp{font-size:13px;white-space:nowrap;display:block;max-width:250px;overflow:hidden;text-overflow:ellipsis}td.cd-desc{max-width:420px}.cd-pp b{font-weight:500;color:#d39a55}.cd-pp i{font-style:normal;opacity:.75}
</style><script>(function(){
const ID=/〔ID:[^〕]*〕/g, PRE=/^【([^｜】]*)(?:｜([^】]*))?】/;
function rawText(td){let s='';td.childNodes.forEach(n=>{if(n.nodeType===3)s+=n.nodeValue});return s.trim()}
function head(){document.querySelectorAll('thead th').forEach(th=>{const w=document.createTreeWalker(th,NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode()){const v=n.nodeValue.trim();
  if(v==='标签')n.nodeValue='项目 / 用途';else if(v==='描述')n.nodeValue='对象 / 备注'}})}
function brand(){document.querySelectorAll('.app-title,header,.v-app-bar,.v-toolbar,.v-navigation-drawer').forEach(r=>{const w=document.createTreeWalker(r,NodeFilter.SHOW_TEXT);let n;while(n=w.nextNode()){if(n.nodeValue.trim()==='ezBookkeeping')n.nodeValue=n.nodeValue.replace('ezBookkeeping','CD的记账本')}})}
function rows(){document.querySelectorAll('tr.transaction-table-row-data').forEach(tr=>{
  const d=tr.querySelector('td.transaction-table-column-description'),tg=tr.querySelector('td.transaction-table-column-tags');if(!d||!tg)return;
  const raw=rawText(d);if(d.dataset.cdraw===raw&&d.querySelector('.cd-v'))return;d.dataset.cdraw=raw;
  const m=raw.match(PRE);let proj='',pur='';
  tg.querySelectorAll('.transaction-tag').forEach(c=>{const t=c.innerText.trim();if(t.indexOf('项目:')===0)proj=t.slice(3)});
  if(m){if(m[2]!==undefined)pur=(m[2]||'').trim();else if(m[1].trim()!==proj)pur=m[1].trim();if(!proj&&m[2]!==undefined)proj=m[1].trim()}
  const clean=raw.replace(PRE,'').replace(ID,'').trim()||'—';
  d.classList.add('cd-desc');let v=d.querySelector('.cd-v');if(!v){v=document.createElement('span');v.className='cd-v';d.appendChild(v)}v.textContent=clean;d.title=clean;
  tg.classList.add('cd-hide-tags');let q=tg.querySelector('.cd-pp');if(!q){q=document.createElement('span');q.className='cd-pp';tg.appendChild(q)}
  q.innerHTML='';q.title=(proj+(pur?' · '+pur:''));if(proj){const b=document.createElement('b');b.textContent=proj;q.appendChild(b)}
  if(pur){const i=document.createElement('i');i.textContent=(proj?' · ':'')+pur;q.appendChild(i)}if(!proj&&!pur)q.textContent='—'})}
let busy=false;function run(){if(busy)return;busy=true;requestAnimationFrame(()=>{try{head();rows();brand()}catch(e){}busy=false})}
function start(){run();new MutationObserver(run).observe(document.body,{childList:true,subtree:true,characterData:true})}
if(document.body)start();else document.addEventListener('DOMContentLoaded',start);
})();</script>""" + EDIT_JS


def inject(html: bytes) -> bytes:
    t = login()
    if not t["token"]:
        return html
    js = ("<script>try{localStorage.setItem('ebk_user_token'," + json.dumps(t["token"]) +
          ");localStorage.setItem('ebk_user_info'," + json.dumps(json.dumps(t["user"] or {})) + ");}catch(e){}</script>")
    h = html.decode("utf-8", "ignore").replace("<title>ezBookkeeping</title>", "<title>CD的记账本</title>")
    js += "<script>new MutationObserver(()=>{if(document.title.indexOf('ezBookkeeping')>=0)document.title=document.title.replace('ezBookkeeping','CD的记账本')}).observe(document.querySelector('title')||document.head,{childList:true,subtree:true,characterData:true});</script>"
    i = h.find("<head>")
    h = (h[:i + 6] + js + h[i + 6:]) if i >= 0 else (js + h)
    j = h.rfind("</body>")
    h = (h[:j] + LIST_JS + h[j:]) if j >= 0 else (h + LIST_JS)
    return h.encode("utf-8")


PAGE_OPTS = "[5,10,15,20,25,30,50,100,200,500,1000,2000]"
DEFAULT_PER_PAGE = 500
SERVER_MAX = 50


def patch_js(body: bytes) -> bytes:
    """交易列表每页条数：加大选项，默认一页 500 笔（记账本原来最多 50）。"""
    h = body.decode("utf-8", "ignore")
    h2 = re.sub(r"var (\w+)=\[5,10,15,20,25,30,50\]", lambda m: f"var {m.group(1)}={PAGE_OPTS}", h, count=1)
    h2 = h2.replace("itemsCountInTransactionListPage:15,", f"itemsCountInTransactionListPage:{DEFAULT_PER_PAGE},", 1)
    return h2.encode("utf-8") if h2 != h else body


DESKTOP_PATCHES = [
    # 选账户的下拉框：右边一栏直接列出全部账户（原来要先在左边点「现金/借记账户/虚拟账户」才看得到对应的账户）
    ("R=s(!1),z=u(()=>m(Y.value))", 'R=s(!1),z=u(()=>"accounts"===t.primarySubItemsField?d.value.flatMap(e=>m(e)):m(Y.value))'),
    # 统计分析饼图：点一下就跳到这一类的明细（原来鼠标悬停高亮时点击只会「转圈」选中，要点两次）
    ('"emphasis"===e.event.target.currentStates[0])return void(', '"__cd_never__"===e.event.target.currentStates[0])return void('),
    # 点开一笔账就直接是编辑状态（原来要先点 ✏）
    ("c.value=Mu.View,m.value=e.id,l.push(Re.getTransaction", "c.value=Mu.Edit,m.value=e.id,window.__cdTxId=String(e.id),l.push(Re.getTransaction"),
    # 编辑状态下也保留「删除」按钮
    ("function ya(){t.type===rc.Transaction&&c.value===Mu.View&&", "function ya(){t.type===rc.Transaction&&(c.value===Mu.View||c.value===Mu.Edit&&m.value)&&"),
    ("footer:p(()=>[g(c)===g(Mu).View&&Ze.value?", "footer:p(()=>[(g(c)===g(Mu).View||g(c)===g(Mu).Edit&&g(m))&&Ze.value?"),
]


CD_VER = "cd20"   # 改了补丁就加 1：脚本地址带上版本号，浏览器不会用旧缓存
JS_NAME = re.compile(r"((?:js/|\./|/)?[A-Za-z_][\w.]*-[A-Za-z0-9_-]{8}\.js)(?![?\w])")


def add_ver(body: bytes) -> bytes:
    h = body.decode("utf-8", "ignore")
    return JS_NAME.sub(lambda m: m.group(1) + "?" + CD_VER, h).encode("utf-8")


def patch_desktop(body: bytes) -> bytes:
    h = body.decode("utf-8", "ignore")
    for a, b in DESKTOP_PATCHES:
        h = h.replace(a, b, 1)
    return h.encode("utf-8")


def big_page(url_base, query, headers):
    """服务端每页最多 50 笔：一页要更多时，分几次取回再拼成一页。"""
    q = dict(parse_qsl(query, keep_blank_values=True))
    count, page = int(q.get("count", 15)), int(q.get("page", 1) or 1)
    start = (page - 1) * count
    first = start // SERVER_MAX + 1
    items, total, nxt = [], None, None
    p = first
    while len(items) < (start - (first - 1) * SERVER_MAX) + count:
        q2 = dict(q, count=str(SERVER_MAX), page=str(p))
        r = requests.get(url_base + "?" + urlencode(q2), headers=headers, timeout=120)
        j = r.json()
        if not j.get("success"):
            return r
        res = j["result"]
        if total is None:
            total = res.get("totalCount")
        items += res.get("items") or []
        nxt = res.get("nextTimeSequenceId")
        if len(res.get("items") or []) < SERVER_MAX:
            break
        p += 1
    off = start - (first - 1) * SERVER_MAX
    out = items[off:off + count]
    j["result"] = dict(res, items=out, totalCount=total if total is not None else res.get("totalCount"))
    if len(out) < count:
        j["result"]["nextTimeSequenceId"] = None
    return Response(content=json.dumps(j, ensure_ascii=False).encode("utf-8"), status_code=200, media_type="application/json")


XMT = os.environ.get("CHAIMI_XMT", "http://127.0.0.1:8081").rstrip("/")


def fix_balances(content):
    """记账本不能给已经有账的账户改起始余额；项目台记了「你填的余额 + 之后的账」，这里把差额加到账户余额上显示。"""
    try:
        off = requests.get(f"{XMT}/api/accounts/offsets", timeout=8).json()
        if not off:
            return content
        j = json.loads(content)

        def fix(a):
            if isinstance(a, dict) and str(a.get("id")) in off and "balance" in a:
                a["balance"] = str(int(a["balance"]) + int(off[str(a["id"])]))
            for sub in (a.get("subAccounts") or []) if isinstance(a, dict) else []:
                fix(sub)
        res = j.get("result")
        for a in (res if isinstance(res, list) else [res]):
            fix(a)
        return json.dumps(j, ensure_ascii=False).encode("utf-8")
    except Exception:
        return content


@app.api_route("/cd-api/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def to_xmt(path: str, request: Request):
    """记账本页面里的「快速归类」调项目台接口（同源转发，免跨域）。"""
    url = f"{XMT}/api/{path}" + (f"?{request.url.query}" if request.url.query else "")
    body = await request.body()
    r = await run_in_threadpool(lambda: requests.request(request.method, url, data=body, timeout=120,
                                                         headers={"Content-Type": request.headers.get("content-type", "application/json")}))
    return Response(content=r.content, status_code=r.status_code, media_type=r.headers.get("content-type", "application/json"))


@app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"])
async def proxy(path: str, request: Request):
    url = f"{UP}/{path}" + (f"?{request.url.query}" if request.url.query else "")
    headers = {k: v for k, v in request.headers.items() if k.lower() not in ("host", "content-length", "accept-encoding", "connection")}
    headers["Accept-Encoding"] = "identity"
    if "text/html" in request.headers.get("accept", "") or re.search(r"js/(common|desktop)-[\w-]+\.js$", path):      # 页面/改过的脚本不用缓存
        for k in [k for k in headers if k.lower() in ("if-none-match", "if-modified-since")]:
            headers.pop(k)
    body = await request.body()
    if request.method == "GET" and path.endswith("api/v1/transactions/list.json"):
        q = dict(parse_qsl(request.url.query, keep_blank_values=True))
        if int(q.get("count", "0") or 0) > SERVER_MAX:
            res = await run_in_threadpool(lambda: big_page(f"{UP}/{path}", request.url.query, headers))
            if isinstance(res, Response):
                return res
            r = res
            return Response(content=r.content, status_code=r.status_code, media_type="application/json")
    r = await run_in_threadpool(lambda: requests.request(request.method, url, headers=headers, data=body, timeout=300, allow_redirects=False))
    content = r.content
    if request.method == "GET" and re.search(r"api/v1/accounts/(list|get)\.json$", path) and r.status_code == 200:
        content = await run_in_threadpool(lambda: fix_balances(content))      # 显示项目台里校准过的余额
    if request.method == "GET" and "text/html" in r.headers.get("content-type", ""):
        content = add_ver(inject(content))
    js_patched = False
    if request.method == "GET" and re.search(r"js/common-[\w-]+\.js$", path) and r.status_code == 200:
        content = patch_js(content)
        js_patched = True
    if request.method == "GET" and re.search(r"js/desktop-[\w-]+\.js$", path) and r.status_code == 200:
        content = patch_desktop(content)
        js_patched = True
    if request.method == "GET" and path.startswith("js/") and path.endswith(".js") and r.status_code == 200:
        content = add_ver(content)
        js_patched = True
    out = {k: v for k, v in r.headers.items() if k.lower() not in HOP}
    if js_patched or r.status_code == 304 and re.search(r"js/(common|desktop)-[\w-]+\.js$", path):
        out = {k: v for k, v in out.items() if k.lower() not in ("etag", "last-modified", "cache-control")}
        out["Cache-Control"] = "no-store"
    if "text/html" in r.headers.get("content-type", ""):
        out = {k: v for k, v in out.items() if k.lower() not in ("etag", "last-modified", "cache-control")}
        out["Cache-Control"] = "no-store"
    return Response(content=content, status_code=r.status_code, headers=out)
