"""账户余额：记账本只允许在账户还没有账的时候录起始余额，所以余额校准放在项目台：
你填「现在这个账户里有多少钱」+ 填写时间 → 以后显示的余额 = 你填的数 + 这之后这个账户的每一笔（收入加、支出减、转账两边一加一减）。
之后补导入的旧账单（时间早于校准时间）不影响余额。记账本的账户页通过入口代理（ledger_proxy）显示同一个数。
"""
import time
from typing import Optional

from fastapi import HTTPException
from pydantic import BaseModel

LIAB = (4, 6)            # 记账本账户类型：4 信用卡 6 负债


def setup(app, h):
    store, ezb, ezb_transactions, invalidate = h["store"], h["ezb"], h["ezb_transactions"], h["invalidate"]
    from api_import import acc_name, acc_category, ACC_COLORS

    with store.db() as c:
        c.execute("create table if not exists acc_cal(name text primary key, balance real, as_of integer, note text default '', hidden integer default 0)")

    def cals():
        with store.db() as c:
            return {r["name"]: dict(r) for r in c.execute("select * from acc_cal")}

    def kind_of(a):
        n, cat = a["name"], a.get("category", 1)
        if n == "备用金":
            return "备用金"
        if "亲属卡" in n:
            return "亲属卡"
        if cat in LIAB or "信用卡" in n or n == "花呗":
            return "负债"
        return "资产"

    def compute():
        """每个账户：记账本里的原始余额、校准后的余额、偏移（给记账本页面用）"""
        api = ezb()
        accs = [a for a in api.call("GET", "/api/v1/accounts/list.json") if not a.get("hidden")]
        txs = ezb_transactions()
        cal = cals()
        net_all, net_after, last = {}, {}, {}
        for t in txs:
            ty, sid, did = t["type"], str(t.get("sourceAccountId")), str(t.get("destinationAccountId") or 0)
            amt, damt, tm = t.get("sourceAmount", 0), t.get("destinationAmount", 0), t.get("time", 0)
            moves = []
            if ty == 1 or ty == 2:             # 余额调整 / 收入
                moves.append((sid, amt))
            elif ty == 3:
                moves.append((sid, -amt))
            elif ty == 4:
                moves += [(sid, -amt), (did, damt)]
            for aid, v in moves:
                net_all[aid] = net_all.get(aid, 0) + v
                last[aid] = max(last.get(aid, 0), tm)
                net_after.setdefault(aid, []).append((tm, v))
        out = []
        for a in accs:
            aid = str(a["id"])
            raw = net_all.get(aid, 0) / 100
            c = cal.get(a["name"])
            hid = bool(c and c["hidden"])
            c = c if c and c["as_of"] > 0 else None
            if c:
                after = sum(v for tm, v in net_after.get(aid, []) if tm > c["as_of"]) / 100
                bal = round(c["balance"] + after, 2)
            else:
                bal = round(raw, 2)
            k = kind_of(a)
            out.append(dict(id=aid, name=a["name"], category=a.get("category"), kind=k, raw=round(raw, 2), balance=bal,
                            calibrated=bool(c), as_of=time.strftime("%Y-%m-%d %H:%M", time.localtime(c["as_of"])) if c else "",
                            cal_value=c["balance"] if c else None, hidden=hid,
                            offset_cents=int(round((bal - raw) * 100)), last=time.strftime("%Y-%m-%d", time.localtime(last[aid])) if aid in last else "",
                            n=len(net_after.get(aid, []))))
        order = {"资产": 0, "负债": 1, "备用金": 2, "亲属卡": 3}
        out.sort(key=lambda x: (order.get(x["kind"], 9), -abs(x["balance"])))
        vis = [x for x in out if not x["hidden"]]
        ok = [x for x in vis if x["calibrated"]]                                           # 只算录过余额的账户，没录的原始收支差没有意义
        avail = round(sum(x["balance"] for x in ok if x["kind"] == "资产"), 2)
        debt = round(sum(x["balance"] for x in ok if x["kind"] == "负债"), 2)           # 信用卡/花呗：负数 = 欠的钱
        funds = project_funds(txs)
        company = round(sum(f["net"] for f in funds if f["net"] > 0 and not f["unassigned"]), 2)
        owed = round(sum(-f["net"] for f in funds if f["net"] < 0 and not f["unassigned"]), 2)
        return dict(accounts=out, available=avail, debt=debt, net=round(avail + debt, 2),
                    funds=funds, company=company, owed=owed, mine=round(avail - company, 2),
                    cash=round(sum(x["balance"] for x in vis if x["kind"] == "备用金"), 2),
                    uncal=[x["name"] for x in vis if not x["calibrated"] and x["kind"] in ("资产", "负债") and (x["n"] or x["name"] != "现金")])

    def project_funds(txs):
        """每个项目「在我手上的公司的钱」：
        · 有成本单备用金的项目：照成本单算——备用金总额（成本单备用金 + 账单里没对上成本单的备用金入款）− 备用金垫付的支出，
          和成本单抬头「备用金剩余」一样（杭马 = 3,409.72）。
        · 没有成本单的项目：照账单算——收到的备用金入款 / 客户回款 − 归到这个项目的工作支出。
        · 备用金在同事那里的（【同事经手】）不算；还没归项目的工作收支单独列，不计入合计。
        正数 = 手上还有公司的钱；负数 = 我垫付的，公司欠我。"""
        pj, sub, rid = h["_project_of"], h["_sub_name"], h["rid"]
        led = {}
        for t in txs:
            if t["type"] not in (2, 3) or h["_scope_of"](t) != "工作":
                continue
            p = pj(t) or "(没归项目)"
            e = led.setdefault(p, dict(inflow=0.0, outflow=0.0, adv_tx=[]))
            a = t["sourceAmount"] / 100
            if t["type"] == 2:
                if sub(t) in ("项目备用金入款", "项目回款"):
                    e["inflow"] += a
                    e["adv_tx"].append((rid(t.get("comment")) or f"手动:{t['id']}", a))
            else:
                e["outflow"] += a
        sheet = {}
        with store.db() as c:
            for r in c.execute("select p.name, l.sec, l.qty*l.price amt, l.uid, l.vendor, l.pay from lines l join projects p on p.id=l.project_id "
                               "where coalesce(l.hold,0)=0 and (l.sec='备用金' or l.pay in ('备用金垫付','已付'))"):
                e = sheet.setdefault(r["name"], dict(adv=0.0, used=0.0, mine=0.0, uids=set(), colleague=False))
                if r["sec"] != "备用金" and r["pay"] == "已付":
                    # 「已付」只算我自己垫的：对上我账单（微信/支付宝/手记）的行；没对上的多半是公司或别人直接付的
                    if (r["uid"] or "").startswith(("微信:", "支付宝:", "快记:", "手动:", "ezb:", "还款:")):
                        e["mine"] += r["amt"] or 0
                    continue
                if r["sec"] == "备用金":
                    if "【同事经手】" in (r["vendor"] or ""):
                        e["colleague"] = True
                        continue
                    e["adv"] += r["amt"] or 0
                    if r["uid"]:
                        e["uids"].add(r["uid"])
                else:
                    e["used"] += r["amt"] or 0
        out = []
        for name in set(led) | set(sheet):
            sh, lg = sheet.get(name), led.get(name, dict(inflow=0.0, outflow=0.0, adv_tx=[]))
            if sh and sh["colleague"] and not sh["adv"]:
                continue                                       # 备用金在同事那里：钱没经过我
            if sh and sh["adv"] > 0:
                # 有成本单备用金：备用金剩余（成本单抬头那个数）＋ 账单里另外收到的备用金/报销 − 我自己垫付的「已付」
                extra = round(sum(a for u, a in lg["adv_tx"] if u not in sh["uids"]), 2)
                row = dict(adv=sh["adv"], used=sh["used"], left=round(sh["adv"] - sh["used"], 2), mine=sh["mine"], extra=extra, how="成本单")
            else:
                # 没有成本单备用金：照账单——收到的备用金入款/回款 − 归到这个项目的工作支出（都是从我账户出的）
                row = dict(adv=0.0, used=0.0, left=0.0, mine=lg["outflow"], extra=lg["inflow"], how="账单")
            net = row["left"] + row["extra"] - row["mine"]
            out.append(dict(row, name=name, inflow=round(row["adv"] + row["extra"], 2), outflow=round(row["used"] + row["mine"], 2),
                            mine=round(row["mine"], 2), net=round(net, 2), unassigned=name == "(没归项目)"))
        return sorted([x for x in out if abs(x["net"]) > 0.005], key=lambda x: (x["unassigned"], x["net"]))

    class AccDel(BaseModel):
        name: str
        move_to: str = ""

    @app.post("/api/accounts/delete")
    def acc_delete(b: AccDel):
        """删除账户：账户里有账要先挪到别的账户（move_to），账不会丢；记账本里一起删。"""
        api = ezb()
        accs = {a["name"]: a for a in api.call("GET", "/api/v1/accounts/list.json")}
        a = accs.get(b.name)
        if not a:
            raise HTTPException(404, "没有这个账户")
        ts = [t for t in ezb_transactions(force=True) if str(t.get("sourceAccountId")) == str(a["id"]) or str(t.get("destinationAccountId") or 0) == str(a["id"])]
        if ts:
            if not b.move_to or b.move_to == b.name or b.move_to not in accs:
                raise HTTPException(400, f"这个账户里有 {len(ts)} 笔账，先选一个账户把它们挪过去")
            to = str(accs[b.move_to]["id"])
            for t in ts:
                body = dict(id=str(t["id"]), type=t["type"], categoryId=str(t["categoryId"]), time=t["time"], utcOffset=t["utcOffset"],
                            sourceAccountId=to if str(t["sourceAccountId"]) == str(a["id"]) else str(t["sourceAccountId"]),
                            destinationAccountId=(to if str(t.get("destinationAccountId") or 0) == str(a["id"]) else str(t.get("destinationAccountId") or 0)),
                            sourceAmount=t["sourceAmount"], destinationAmount=t.get("destinationAmount", 0), hideAmount=t.get("hideAmount", False),
                            tagIds=[str(x) for x in (t.get("tagIds") or [])], pictureIds=[p_["pictureId"] for p_ in (t.get("pictures") or [])],
                            comment=t.get("comment") or "")
                api.call("POST", "/api/v1/transactions/modify.json", body)
        api.call("POST", "/api/v1/accounts/delete.json", dict(id=str(a["id"])))
        with store.db() as c:
            c.execute("delete from acc_cal where name=?", (b.name,))
        invalidate()
        return compute()

    @app.get("/api/accounts")
    def accounts():
        return compute()

    @app.get("/api/accounts/offsets")
    def offsets():
        """记账本页面显示余额用：账户 id → 要加上的分"""
        try:
            return {x["id"]: x["offset_cents"] for x in compute()["accounts"] if x["offset_cents"]}
        except Exception:
            return {}

    class AccSet(BaseModel):
        name: str
        balance: float
        note: str = ""
        hidden: Optional[bool] = None

    @app.post("/api/accounts/set")
    def set_balance(b: AccSet):
        """录入「现在这个账户里有多少钱」。没有这个账户就新建（例如新的银行卡）。信用卡/花呗填欠款时用负数。"""
        name = acc_name(b.name.strip())
        if not name:
            raise HTTPException(400, "账户名不能为空")
        api = ezb()
        if name not in {a["name"] for a in api.call("GET", "/api/v1/accounts/list.json")}:
            api.call("POST", "/api/v1/accounts/add.json", dict(name=name, category=acc_category(name), type=1, icon="1", iconType=0,
                                                               color=ACC_COLORS.get(name, "888888"), currency="CNY", balance="0", comment=""))
            invalidate()
        with store.db() as c:
            c.execute("insert into acc_cal(name,balance,as_of,note,hidden) values(?,?,?,?,0) on conflict(name) do update set balance=excluded.balance, as_of=excluded.as_of, note=excluded.note",
                      (name, round(b.balance, 2), int(time.time()), b.note))
        return compute()

    @app.post("/api/accounts/hide")
    def hide(b: AccSet):
        with store.db() as c:
            if not c.execute("select 1 from acc_cal where name=?", (b.name,)).fetchone():
                c.execute("insert into acc_cal(name,balance,as_of,hidden) values(?,?,?,?)", (b.name, 0, 0, 0))
                # 没校准过：用记账本原始余额（as_of=0 → 所有账都算在后面，等于原始余额）
            c.execute("update acc_cal set hidden=? where name=?", (1 if b.hidden else 0, b.name))
        return compute()

    @app.delete("/api/accounts/cal")
    def uncal(name: str):
        with store.db() as c:
            c.execute("delete from acc_cal where name=?", (name,))
        return compute()

    @app.get("/api/accounts/names")
    def names():
        try:
            return [a["name"] for a in ezb().call("GET", "/api/v1/accounts/list.json") if not a.get("hidden")]
        except Exception:
            return []
