// 金额框里直接写算式：45.5+87.44、200×3-15、(1200+300)÷4
// 离开输入框 / 按回车 / 点保存时，框里的算式换成计算结果；算式看不懂就恢复成原来的数，框闪红。
// 项目台和记账本共用这一份（记账本由 ledger_proxy.py 把本文件内联注入）。
(function () {
  if (window.__cdCalc) return; window.__cdCalc = 1;
  const LEDGER = !!window.__cdCalcLedger;
  const OPCH = /[+\-*/×÷xX＋－—–＊／（）()]/;
  const norm = s => String(s).replace(/＋/g, '+').replace(/[－—–]/g, '-').replace(/[×xX＊]/g, '*')
    .replace(/[÷／]/g, '/').replace(/（/g, '(').replace(/）/g, ')').replace(/。/g, '.').replace(/[，,¥￥\s]/g, '');
  // 只认数字、小数点、加减乘除和括号；不用 eval
  function calc(src) {
    const s = norm(src); let i = 0;
    if (!s || /[^0-9.+\-*/()]/.test(s)) return NaN;
    const num = () => { const m = /^\d*\.?\d+|^\d+\.?/.exec(s.slice(i)); if (!m) throw 0; i += m[0].length; return parseFloat(m[0]); };
    const atom = () => {
      if (s[i] === '-') { i++; return -atom(); }
      if (s[i] === '+') { i++; return atom(); }
      if (s[i] === '(') { i++; const v = expr(); if (s[i] !== ')') throw 0; i++; return v; }
      return num();
    };
    const term = () => { let v = atom(); while (s[i] === '*' || s[i] === '/') { const o = s[i++], b = atom(); v = o === '*' ? v * b : v / b; } return v; };
    const expr = () => { let v = term(); while (s[i] === '+' || s[i] === '-') { const o = s[i++], b = term(); v = o === '+' ? v + b : v - b; } return v; };
    try { const v = expr(); return i === s.length && isFinite(v) ? v : NaN; } catch (e) { return NaN; }
  }
  // 框里是不是算式（纯数字不管，照原样走）
  const isF = v => !/^\s*-?\d*\.?\d*\s*$/.test(v) && (OPCH.test(v) || /[，,。¥￥]/.test(v));
  const fmt = (el, v) => {
    const st = el.getAttribute('step'); let d = 2;
    if (st === 'any') d = 6; else if (st && /^\d*\.?\d+$/.test(st)) d = Math.max(0, (st.split('.')[1] || '').length);
    if (el.dataset.calc === 'amt') d = 2;
    return String(+v.toFixed(d));
  };
  const on = el => el && el.tagName === 'INPUT' && !!el.dataset.calc;

  function scan() {
    if (LEDGER) {
      document.querySelectorAll('input.v-field__input:not([data-calc]):not([data-calc-ov])').forEach(el => {
        if (el.type !== 'text') return; const f = el.closest('.v-field');
        if (f && /金额|余额/.test([...f.querySelectorAll('label')].map(l => l.textContent).join(' '))) el.dataset.calc = 'amt';
      });
      document.querySelectorAll('input.oa:not([data-calc])').forEach(el => { el.dataset.calc = 'amt'; });
    } else {
      document.querySelectorAll('input[type=number]').forEach(el => {
        el.type = 'text'; if (!el.getAttribute('inputmode')) el.setAttribute('inputmode', 'decimal');
        el.dataset.calc = '1'; el.setAttribute('autocomplete', 'off');
      });
    }
  }
  let pend = false;
  const kick = () => { if (pend) return; pend = true; requestAnimationFrame(() => { pend = false; try { scan(); } catch (e) {} }); };
  const start = () => { scan(); new MutationObserver(kick).observe(document.body, { childList: true, subtree: true }); };
  if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);

  const fire = el => el.dispatchEvent(new Event('input', { bubbles: true }));
  function commit(el) {
    if (!isF(el.value)) return true;
    const v = calc(el.value);
    if (isFinite(v)) { el.value = fmt(el, v); fire(el); return true; }
    el.value = el.__cdOld != null ? el.__cdOld : ''; fire(el);
    el.style.outline = '2px solid #e5484d'; el.title = '算式看不懂，已恢复成原来的数';
    setTimeout(() => { el.style.outline = ''; el.title = ''; }, 2500);
    return false;
  }
  window.__cdCalcEval = calc;

  addEventListener('focusin', e => { if (on(e.target)) e.target.__cdOld = e.target.value; }, true);
  // 记账本自己的金额框会把 + × 吞掉、还会在页面刷新时把框里的字改回它记的数：
  // 打到运算符时，原地换一个外观一样的框接着写，算完把结果填回原来的框
  const VF = el => LEDGER && el.classList.contains('v-field__input');
  const flash = el => { el.style.outline = '2px solid #e5484d'; el.title = '算式看不懂，已恢复成原来的数'; setTimeout(() => { el.style.outline = ''; el.title = ''; }, 2500); };
  function overlay(el, val) {
    if (el.__cdOv) return el.__cdOv;
    const o = document.createElement('input');
    o.className = el.className; o.type = 'text'; o.setAttribute('inputmode', 'decimal'); o.setAttribute('autocomplete', 'off');
    o.dataset.calcOv = '1'; o.value = val; o.__cdNative = el; el.__cdOv = o;
    el.style.display = 'none'; el.after(o); o.focus(); o.setSelectionRange(val.length, val.length);
    return o;
  }
  function ovDone(o, refocus) {
    if (o.__done) return; o.__done = true;
    const el = o.__cdNative, v = calc(o.value);
    el.style.display = ''; el.__cdOv = null; o.remove();
    if (isFinite(v)) { el.value = fmt(el, v); fire(el); } else { if (el.__cdOld != null) { el.value = el.__cdOld; fire(el); } flash(el); }
    if (refocus) el.focus();
  }
  addEventListener('keydown', e => {
    const el = e.target;
    if (el && el.dataset && el.dataset.calcOv) {
      if (e.key === 'Enter') { e.preventDefault(); e.stopImmediatePropagation(); ovDone(el, true); }
      else if (e.key === 'Escape') { e.preventDefault(); e.stopImmediatePropagation(); el.__done = true; const n = el.__cdNative; n.style.display = ''; n.__cdOv = null; el.remove(); n.focus(); }
      else e.stopImmediatePropagation();
      return;
    }
    if (!on(el)) return;
    if (e.key === 'Enter') { commit(el); return; }
    if (VF(el) && e.key.length === 1 && /[+*/×÷xX＋－＊／（）()\-]/.test(e.key) && !(e.key === '-' && el.selectionStart === 0)) {
      e.preventDefault(); e.stopImmediatePropagation();
      const a = el.selectionStart, b = el.selectionEnd, v = el.value;
      overlay(el, v.slice(0, a) + e.key + v.slice(b));
    }
  }, true);
  // 换上去的框里打字，记账本一概不插手
  ['keypress', 'keyup', 'beforeinput', 'input', 'compositionstart', 'compositionend', 'paste'].forEach(t => addEventListener(t, e => {
    if (e.target && e.target.dataset && e.target.dataset.calcOv) e.stopImmediatePropagation();
  }, true));
  addEventListener('input', e => {   // 中文输入法、粘贴进来的算式
    const el = e.target; if (!on(el) || !VF(el) || !isF(el.value)) return;
    e.stopImmediatePropagation(); overlay(el, el.value);
  }, true);
  addEventListener('blur', e => { const o = e.target; if (o && o.dataset && o.dataset.calcOv) ovDone(o, false); }, true);
  addEventListener('change', e => { if (on(e.target) && isF(e.target.value) && !commit(e.target)) e.stopImmediatePropagation(); }, true);
  addEventListener('blur', e => { if (on(e.target)) commit(e.target); }, true);
})();
